<?php
declare(strict_types=1);
namespace Sokna\Local\Domain\Notifications;
use PDO;use Throwable;use Sokna\Local\Domain\PublicEdge\PublicEdgeSyncClient;
final class NotificationService
{
    public function __construct(private readonly PDO $pdo,private readonly ?PublicEdgeSyncClient $publicClient=null){}
    public function snapshot(array $user): array
    {
        $uid=$this->uid($user);$this->ensurePreference($uid);$q=$this->pdo->prepare('SELECT in_app_enabled,push_enabled,updated_at FROM notification_preferences WHERE user_id=?');$q->execute([$uid]);$pref=$q->fetch(PDO::FETCH_ASSOC)?:[];
        $q=$this->pdo->prepare('SELECT id,title,body,target_url,read_at,created_at FROM notification_inbox WHERE user_id=? ORDER BY id DESC LIMIT 100');$q->execute([$uid]);$items=$q->fetchAll(PDO::FETCH_ASSOC)?:[];
        $q=$this->pdo->prepare('SELECT COUNT(*) FROM notification_push_subscriptions WHERE user_id=? AND active=1');$q->execute([$uid]);
        $push=$this->remotePushConfig();$push['subscriptions']=(int)$q->fetchColumn();return ['preferences'=>$pref,'items'=>$items,'unread'=>count(array_filter($items,fn($r)=>empty($r['read_at']))),'push'=>$push];
    }
    public function savePreferences(array $input,array $user): array{$uid=$this->uid($user);$q=$this->pdo->prepare('INSERT INTO notification_preferences(user_id,in_app_enabled,push_enabled) VALUES(?,?,?) ON DUPLICATE KEY UPDATE in_app_enabled=VALUES(in_app_enabled),push_enabled=VALUES(push_enabled)');$q->execute([$uid,!empty($input['in_app_enabled'])?1:0,!empty($input['push_enabled'])?1:0]);return $this->snapshot($user)['preferences'];}
    public function registerPush(array $subscription,array $user): array
    {
        $uid=$this->uid($user);$endpoint=trim((string)($subscription['endpoint']??''));$keys=is_array($subscription['keys']??null)?$subscription['keys']:[];$p=trim((string)($keys['p256dh']??''));$a=trim((string)($keys['auth']??''));if($endpoint===''||!str_starts_with(strtolower($endpoint),'https://')||$p===''||$a==='')throw new NotificationException('invalid_subscription','اشتراک Push معتبر نیست.',422);if(strlen($endpoint)>3000||strlen($p)>255||strlen($a)>255)throw new NotificationException('invalid_subscription','اشتراک Push معتبر نیست.',422);$hash=hash('sha256',$endpoint);$q=$this->pdo->prepare('INSERT INTO notification_push_subscriptions(user_id,endpoint_hash,endpoint_url,p256dh_key,auth_secret,active,last_seen_at) VALUES(?,?,?,?,?,1,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE endpoint_url=VALUES(endpoint_url),p256dh_key=VALUES(p256dh_key),auth_secret=VALUES(auth_secret),active=1,last_seen_at=UTC_TIMESTAMP()');$q->execute([$uid,$hash,$endpoint,$p,$a]);$this->pdo->prepare('INSERT INTO notification_preferences(user_id,in_app_enabled,push_enabled) VALUES(?,1,1) ON DUPLICATE KEY UPDATE push_enabled=1')->execute([$uid]);return ['registered'=>true,'endpoint_hash'=>$hash];
    }
    public function unregisterPush(string $endpoint,array $user): array{$uid=$this->uid($user);$hash=hash('sha256',trim($endpoint));$q=$this->pdo->prepare('UPDATE notification_push_subscriptions SET active=0 WHERE user_id=? AND endpoint_hash=?');$q->execute([$uid,$hash]);return ['removed'=>$q->rowCount()];}
    public function markRead(int $id,array $user): array{$uid=$this->uid($user);$q=$this->pdo->prepare('UPDATE notification_inbox SET read_at=COALESCE(read_at,UTC_TIMESTAMP()) WHERE id=? AND user_id=?');$q->execute([$id,$uid]);return ['updated'=>$q->rowCount()];}
    public function compose(array $input,array $actor): array
    {
        if((string)($actor['role']??'')!=='admin')throw new NotificationException('forbidden','ارسال اعلان فقط برای مدیر فعال است.',403);$title=$this->text($input['title']??'',180);$body=$this->text($input['body']??'',600);$url=trim((string)($input['target_url']??''));if($url!==''&&!str_starts_with($url,'/'))throw new NotificationException('invalid_url','لینک اعلان باید داخلی باشد.',422);$role=trim((string)($input['role']??''));$sql="SELECT id FROM users WHERE active=1";$p=[];if($role!==''&&in_array($role,['admin','operator','waiter'],true)){$sql.=' AND role=?';$p[]=$role;}$ids=$this->preparedColumn($sql,$p);$event='manual.'.gmdate('YmdHis').'.'.bin2hex(random_bytes(4));$queued=0;foreach($ids as $uid)$queued+=$this->queueForUser((int)$uid,$event,$title,$body,$url,['source'=>'manual','actor_user_id'=>(int)$actor['id']]);return ['recipients'=>count($ids),'queued'=>$queued,'event_key'=>$event];
    }
    public function queueForUser(int $uid,string $event,string $title,string $body,string $url='',array $payload=[]): int
    {
        $this->ensurePreference($uid);$q=$this->pdo->prepare('SELECT in_app_enabled,push_enabled FROM notification_preferences WHERE user_id=?');$q->execute([$uid]);$pref=$q->fetch(PDO::FETCH_ASSOC)?:[];$channels=[];if(!empty($pref['in_app_enabled']))$channels[]='in_app';if(!empty($pref['push_enabled']))$channels[]='web_push';$count=0;foreach($channels as $ch){$idk=hash('sha256',$event.'|'.$uid.'|'.$ch);$stmt=$this->pdo->prepare("INSERT IGNORE INTO notification_outbox(user_id,event_key,channel,title,body,target_url,payload_json,idempotency_key,state,next_attempt_at) VALUES(?,?,?,?,?,?,?,?,'pending',UTC_TIMESTAMP())");$stmt->execute([$uid,$event,$ch,$title,$body,$url!==''?$url:null,json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR),$idk]);$count+=$stmt->rowCount();}return $count;
    }
    public function processPending(int $limit=50): array
    {
        $limit=max(1,min(200,$limit));$rows=$this->pdo->query("SELECT * FROM notification_outbox WHERE state='pending' AND (next_attempt_at IS NULL OR next_attempt_at<=UTC_TIMESTAMP()) ORDER BY id LIMIT {$limit}")->fetchAll(PDO::FETCH_ASSOC)?:[];$done=0;$failed=0;$skipped=0;
        foreach($rows as $r){$id=(int)$r['id'];$this->pdo->prepare("UPDATE notification_outbox SET state='processing',attempts=attempts+1 WHERE id=? AND state='pending'")->execute([$id]);try{$channel=(string)$r['channel'];if($channel==='in_app'){$this->pdo->prepare('INSERT IGNORE INTO notification_inbox(user_id,outbox_id,title,body,target_url) VALUES(?,?,?,?,?)')->execute([(int)$r['user_id'],$id,(string)$r['title'],(string)$r['body'],$r['target_url']]);$this->delivered($id);$done++;continue;}$result=$this->deliverPush($r);if($result==='skipped'){$this->pdo->prepare("UPDATE notification_outbox SET state='skipped',last_error='push_not_configured_or_no_subscription' WHERE id=?")->execute([$id]);$skipped++;}else{$this->delivered($id);$done++;}}catch(Throwable $e){$attempts=(int)$r['attempts']+1;if($attempts>=5){$this->pdo->prepare("UPDATE notification_outbox SET state='failed',last_error=? WHERE id=?")->execute([substr($e->getMessage(),0,300),$id]);$failed++;}else{$delay=min(3600,30*(2**max(0,$attempts-1)));$next=gmdate('Y-m-d H:i:s',time()+$delay);$this->pdo->prepare("UPDATE notification_outbox SET state='pending',next_attempt_at=?,last_error=? WHERE id=?")->execute([$next,substr($e->getMessage(),0,300),$id]);}}}
        return ['processed'=>count($rows),'delivered'=>$done,'skipped'=>$skipped,'failed'=>$failed];
    }
    public function remoteRows(): array{return $this->pdo->query("SELECT CONCAT('user:',i.user_id) projection_id,i.id,i.title,i.body,i.target_url,i.read_at,i.created_at FROM notification_inbox i WHERE i.created_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 30 DAY) ORDER BY i.id DESC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC)?:[];}
    public function remotePushConfig(): array
    {
        if(!$this->publicClient?->configured())return ['vapid_public_key'=>'','bridge_configured'=>false];
        try{$response=$this->publicClient->pushConfig();$push=is_array($response['body']['push']??null)?$response['body']['push']:[];$key=trim((string)($push['vapid_public_key']??''));return ['vapid_public_key'=>$key,'bridge_configured'=>$key!==''&&($push['bridge_configured']??false)===true];}
        catch(Throwable){return ['vapid_public_key'=>'','bridge_configured'=>false];}
    }
    private function deliverPush(array $r): string
    {
        if(!$this->publicClient?->configured())return 'skipped';
        $q=$this->pdo->prepare('SELECT endpoint_hash,endpoint_url,p256dh_key,auth_secret FROM notification_push_subscriptions WHERE user_id=? AND active=1 ORDER BY id');$q->execute([(int)$r['user_id']]);$subs=$q->fetchAll(PDO::FETCH_ASSOC)?:[];if($subs===[])return 'skipped';
        $payload=['notification'=>['title'=>(string)$r['title'],'body'=>(string)$r['body'],'url'=>(string)($r['target_url']??'/')],'subscriptions'=>array_map(fn($s)=>['endpoint'=>(string)$s['endpoint_url'],'keys'=>['p256dh'=>(string)$s['p256dh_key'],'auth'=>(string)$s['auth_secret']]],$subs),'idempotency_key'=>(string)$r['idempotency_key']];
        $response=$this->publicClient->deliverPush($payload);$body=is_array($response['body']??null)?$response['body']:[];
        foreach((array)($body['gone_endpoint_hashes']??[]) as $hash)if(is_string($hash)&&preg_match('/^[a-f0-9]{64}$/D',$hash))$this->pdo->prepare('UPDATE notification_push_subscriptions SET active=0 WHERE user_id=? AND endpoint_hash=?')->execute([(int)$r['user_id'],$hash]);
        return (int)($body['delivered']??0)>0?'delivered':'skipped';
    }
    private function delivered(int $id): void{$this->pdo->prepare("UPDATE notification_outbox SET state='delivered',delivered_at=UTC_TIMESTAMP(),last_error=NULL WHERE id=?")->execute([$id]);}
    private function ensurePreference(int $uid): void{$this->pdo->prepare('INSERT IGNORE INTO notification_preferences(user_id,in_app_enabled,push_enabled) VALUES(?,1,0)')->execute([$uid]);}
    private function uid(array $u): int{$id=(int)($u['id']??0);if($id<1)throw new NotificationException('unauthenticated','کاربر معتبر نیست.',401);return $id;}
    private function text(mixed $v,int $max): string{$v=trim((string)$v);if($v===''||strlen($v)>$max*4)throw new NotificationException('invalid_text','متن اعلان معتبر نیست.',422);return $v;}
    private function setting(string $k): string{$q=$this->pdo->prepare('SELECT setting_value FROM settings WHERE setting_key=?');$q->execute([$k]);$v=$q->fetchColumn();return $v===false?'':trim((string)$v);}
    private function preparedColumn(string $sql,array $p): array{$q=$this->pdo->prepare($sql);$q->execute($p);return array_map('intval',$q->fetchAll(PDO::FETCH_COLUMN)?:[]);}
}
