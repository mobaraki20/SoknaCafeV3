<?php
declare(strict_types=1);

namespace Sokna\PublicEdge\Http;

use Sokna\PublicEdge\Core\Bootstrap;
use Throwable;

final class PushHttpAdapter
{
    public function __construct(private readonly Bootstrap $core){}
    public function config(string $installationId,string $method,string $path,string $timestamp,string $nonce,string $signature,string $rawBody): array
    {
        $v=$this->core->signedLocalRequests()->verify($installationId,$method,$path,$timestamp,$nonce,$rawBody,$signature);if(($v['ok']??false)!==true)return ['status'=>(int)$v['status'],'body'=>['ok'=>false,'error'=>(string)$v['error']]];
        return ['status'=>200,'body'=>['ok'=>true,'push'=>$this->core->webPush()->publicConfig()]];
    }
    public function deliver(string $installationId,string $method,string $path,string $timestamp,string $nonce,string $signature,string $rawBody): array
    {
        $v=$this->core->signedLocalRequests()->verify($installationId,$method,$path,$timestamp,$nonce,$rawBody,$signature);if(($v['ok']??false)!==true)return ['status'=>(int)$v['status'],'body'=>['ok'=>false,'error'=>(string)$v['error']]];
        $payload=json_decode($rawBody,true);if(!is_array($payload))return ['status'=>400,'body'=>['ok'=>false,'error'=>'invalid_json']];
        try{$result=$this->core->webPush()->deliver((array)($payload['notification']??[]),(array)($payload['subscriptions']??[]),(string)($payload['idempotency_key']??''));return ['status'=>200,'body'=>$result];}
        catch(Throwable $e){return ['status'=>503,'body'=>['ok'=>false,'error'=>'push_delivery_failed']];}
    }
}
