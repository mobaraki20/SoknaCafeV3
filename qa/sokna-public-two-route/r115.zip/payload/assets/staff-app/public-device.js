(()=>{'use strict';
if(document.body?.dataset.staffUiMode!=='public')return;
const body=document.body,base=(body.dataset.appBase||'').replace(/\/$/,'');
const u=p=>base+'/'+String(p||'').replace(/^\//,'');
const absolute=p=>new URL(u(p),location.href).href;
const wait=ms=>new Promise(r=>setTimeout(r,ms));
const terminal=new Set(['committed','rejected','expired','cancelled','needs_review','unknown_review']);
const badTerminal=new Set(['rejected','expired','cancelled','needs_review','unknown_review']);
const msg={pending:'ثبت در سیستم اصلی کافه هنوز نهایی نشده است.',notOwned:'اشتراک مرورگر برای این حساب در سیستم اصلی کافه فعال نیست.',active:'اعلان گوشی برای همین حساب در سیستم اصلی کافه فعال است.'};
// Present domain errors as Persian actions, never as backend implementation codes.
// Do not retry a POST with a new request id after a potentially committed response.
const errorMessages={local_unavailable:'ارتباط با سیستم اصلی کافه برقرار نیست. وضعیت اتصال را بررسی کن و سپس همین درخواست را پیگیری کن.',request_failed:'پاسخ سامانه دریافت نشد. وضعیت ثبت را پیش از ارسال مجدد بررسی کن.',rejected:'درخواست پذیرفته نشد. تنظیمات و مجوز حساب را بررسی کن.',expired:'مهلت درخواست تمام شد. نتیجه را در سامانه بررسی کن.',needs_review:'این درخواست نیازمند بررسی مسئول سامانه است.',unknown_review:'نتیجه درخواست نامشخص است؛ دوباره ثبت نکن.',unauthorized:'نشست شما معتبر نیست؛ دوباره وارد سامانه شو.',forbidden:'برای این عملیات مجوز کافی وجود ندارد.',push_registration_pending:'ثبت اعلان در سیستم اصلی کافه هنوز قطعی نشده است. نتیجه همان درخواست را بررسی کن.',offline_store_unavailable:'حافظه امن دستگاه در دسترس نیست؛ استفاده هنگام قطع اینترنت آماده نیست.'};
const humanError=(e,fallback='عملیات کامل نشد. وضعیت را بررسی کن.')=>{const code=String(e?.code||e?.message||'').trim();return errorMessages[code]||(/[^\x00-\x7f]/.test(code)&&!/[A-Za-z_]{3,}/.test(code)?code:fallback)};
const bindingKey='sokna:public-binding:v1',bindingValue=location.origin+(base||'');
const OFFLINE_DB='sokna-staff-offline-v1',OFFLINE_STORE='bootstrap',OFFLINE_LEGACY_KEY='current',OFFLINE_KEY='current:'+encodeURIComponent(bindingValue);
let busy=false,swReady=null,deferredInstallPrompt=null,installedThisSession=false;
const transitionId=/^rebind-[a-f0-9]{24}$/.test(String(body.dataset.originTransition||''))?String(body.dataset.originTransition):'';
function offlineDb(){return new Promise((resolve,reject)=>{const r=indexedDB.open(OFFLINE_DB,1);r.onupgradeneeded=()=>{const db=r.result;if(!db.objectStoreNames.contains(OFFLINE_STORE))db.createObjectStore(OFFLINE_STORE)};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error||new Error('offline_store_unavailable'))})}
// Keep each installation's LAN token isolated even when several Public paths share an origin.
// A legacy singleton belongs to us only when its recorded binding matches this app.
async function offlinePut(value){const db=await offlineDb();try{await new Promise((resolve,reject)=>{const tx=db.transaction(OFFLINE_STORE,'readwrite'),store=tx.objectStore(OFFLINE_STORE);store.put(value,OFFLINE_KEY);const old=store.get(OFFLINE_LEGACY_KEY);old.onsuccess=()=>{if(old.result?.binding===bindingValue)store.delete(OFFLINE_LEGACY_KEY)};tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error||new Error('offline_store_write_failed'));tx.onabort=()=>reject(tx.error||new Error('offline_store_write_aborted'))})}finally{db.close()}}
async function offlineClear(){try{const db=await offlineDb();await new Promise((resolve,reject)=>{const tx=db.transaction(OFFLINE_STORE,'readwrite'),store=tx.objectStore(OFFLINE_STORE);store.delete(OFFLINE_KEY);const old=store.get(OFFLINE_LEGACY_KEY);old.onsuccess=()=>{if(old.result?.binding===bindingValue)store.delete(OFFLINE_LEGACY_KEY)};tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error||new Error('offline_store_clear_failed'));tx.onabort=()=>reject(tx.error||new Error('offline_store_clear_aborted'))});db.close()}catch{}}
function decodeLanToken(token){try{const parts=String(token||'').split('.');if(parts.length!==3||parts[0]!=='v1')return null;const raw=atob(parts[1].replace(/-/g,'+').replace(/_/g,'/')+'='.repeat((4-parts[1].length%4)%4));const j=JSON.parse(raw);return j&&j.format==='sokna-lan-staff-token-v1'?j:null}catch{return null}}
function normalizedLan(value){try{const x=new URL(String(value||''));if(x.protocol!=='https:'||x.username||x.password||x.search||x.hash||x.origin===location.origin)return '';x.pathname=x.pathname.replace(/\/+$/,'');return x.toString().replace(/\/$/,'')}catch{return ''}}
async function persistOfflineBootstrap(){if(!window.isSecureContext||!('indexedDB'in window)){await offlineClear();return false;}const lan=normalizedLan(body.dataset.lanBaseUrl||''),token=String(body.dataset.lanToken||''),claims=decodeLanToken(token),projection=String(body.dataset.projectionId||''),tokenExpires=String(body.dataset.lanTokenExpiresAt||''),sessionExpires=String(body.dataset.publicSessionExpiresAt||'');const tokenExp=Date.parse(tokenExpires||''),sessionExp=Date.parse(sessionExpires||'');if(!lan||!claims||String(claims.projection_id||'')!==projection||!Number.isFinite(tokenExp)||!Number.isFinite(sessionExp)){await offlineClear();return false}const maxUntil=Math.min(tokenExp,sessionExp,Date.now()+8*60*60*1000);if(maxUntil<=Date.now()+60000){await offlineClear();return false}await offlinePut({version:1,binding:bindingValue,lan_base_url:lan,lan_token:token,lan_token_expires_at:tokenExpires,public_session_expires_at:sessionExpires,projection_id:projection,installation_id:String(claims.installation_id||''),saved_at:new Date().toISOString(),max_until:maxUntil});return true}
async function signalOfflineWorker(type){if(!('serviceWorker'in navigator))return;try{const reg=await navigator.serviceWorker.ready;for(const worker of [reg.active,reg.waiting,reg.installing])try{worker?.postMessage?.({type})}catch{}}catch{}}
function uid(){return `push-${Date.now().toString(36)}-${Math.random().toString(16).slice(2,10)}`}
function isoPlus(sec){return new Date(Date.parse(window.SoknaLocale.nowInstant())+sec*1000).toISOString()}
async function req(url,opt={},timeout=12000){const c=new AbortController(),t=setTimeout(()=>c.abort(),timeout);try{const r=await fetch(url,{cache:'no-store',credentials:'same-origin',headers:{Accept:'application/json','Content-Type':'application/json',...(opt.headers||{})},...opt,signal:c.signal});let j={};try{j=await r.json()}catch{}if(!r.ok||j.ok===false)throw new Error(j.message||j.error||'request_failed');return j}finally{clearTimeout(t)}}
async function model(){return req(u('/api/staff/read')+'?model=notifications')}
async function hashEndpoint(endpoint){const bytes=new TextEncoder().encode(endpoint),digest=await crypto.subtle.digest('SHA-256',bytes);return [...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join('')}
async function command(kind,payload){const request_id=uid(),envelope={request_id,kind,created_at:window.SoknaLocale.nowInstant(),expires_at:isoPlus(120),payload};await req(u('/api/staff/realtime'),{method:'POST',body:JSON.stringify(envelope)},12000);const deadline=Date.now()+20000;while(Date.now()<deadline){const r=await req(u('/api/staff/realtime/result')+'?request_id='+encodeURIComponent(request_id),{},8000);const state=String(r.state||'');if(terminal.has(state)){if(badTerminal.has(state))throw new Error(r.message||state);return r}await wait(500)}throw new Error('push_registration_pending')}
function isSoknaStaffRegistration(reg){try{const worker=reg.active||reg.waiting||reg.installing;if(!worker?.scriptURL)return false;const x=new URL(worker.scriptURL);return x.origin===location.origin&&x.pathname.endsWith('/staff/sw.js')}catch{return false}}
async function reconcileBinding(){
  if(!('serviceWorker'in navigator))return;
  const currentScope=absolute('/staff/');
  // Coexisting Home/Cafe installations may share an origin. Never infer that
  // another staff scope is stale just because it is on that origin.
  const installation=String(decodeLanToken(body.dataset.lanToken||'')?.installation_id||'');
  const ownerKey=installation?'sokna:staff-scope:v1:'+encodeURIComponent(installation):'';
  let previousScope='';try{if(ownerKey)previousScope=String(localStorage.getItem(ownerKey)||'')}catch{}
  let previousValid=false;try{const parsed=new URL(previousScope);previousValid=parsed.origin===location.origin&&parsed.pathname.endsWith('/staff/')}catch{}
  if(previousValid&&previousScope!==currentScope){
    let regs=[];try{regs=await navigator.serviceWorker.getRegistrations()}catch{}
    for(const reg of regs){if(reg.scope!==previousScope||!isSoknaStaffRegistration(reg))continue;let sub=null;try{sub=await reg.pushManager.getSubscription()}catch{}if(sub){const endpoint=String(sub.endpoint||'');try{await Promise.race([command('notification.push.unsubscribe',{endpoint}),wait(1200)])}catch{}try{await sub.unsubscribe()}catch{}}try{await reg.unregister()}catch{}}
  }
  try{if(ownerKey)localStorage.setItem(ownerKey,currentScope);localStorage.setItem(bindingKey,bindingValue)}catch{}
}
async function sw(){if(!('serviceWorker'in navigator))throw new Error('این مرورگر Service Worker را پشتیبانی نمی‌کند.');if(!swReady)swReady=(async()=>{await reconcileBinding();return navigator.serviceWorker.register(u('/staff/sw.js'),{scope:u('/staff/')})})();return swReady}
function vapidBytes(s){const pad='='.repeat((4-s.length%4)%4),raw=atob((s+pad).replace(/-/g,'+').replace(/_/g,'/'));return Uint8Array.from([...raw].map(c=>c.charCodeAt(0)))}
const isStandalone=()=>installedThisSession||window.matchMedia?.('(display-mode: standalone)').matches||window.navigator.standalone===true;
const isIOS=()=>/iphone|ipad|ipod/i.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
const sprite=u('/assets/ui-sprite.svg');
const svg=name=>`<svg class="sc-ui-icon" viewBox="0 0 24 24" aria-hidden="true"><use href="${sprite}#icon-${name}"></use></svg>`;
const appUx={dialog:null,opener:null,transition:null,offlineReady:false,transport:'',stale:false,update:'current',updateWorker:null,updateToastShown:false,swBound:new WeakSet(),reloading:false,reloadDeferred:false,pushActive:false,pushText:'در حال بررسی اعلان‌ها…',notificationPrefs:null,notificationPrefBusy:false};
const installSuggestKey=`sokna:pwa-install-suggest:v2:${location.origin}`,INSTALL_SUGGEST_COOLDOWN=14*24*60*60*1000,INSTALL_SUGGEST_DELAY=30000;
function installGuide(){return isIOS()?'از منوی اشتراک‌گذاری مرورگر «Add to Home Screen / افزودن به صفحه اصلی» را بزنید و اگر «Open as Web App» دیده شد روشن نگه دارید.':'از گزینه «Install app / نصب برنامه» در منوی مرورگر استفاده کنید.'}
function markInstallSuggestion(){try{localStorage.setItem(installSuggestKey,String(Date.now()))}catch{}}
function installSuggestionDue(){try{const at=Number(localStorage.getItem(installSuggestKey)||0);return !Number.isFinite(at)||at<=0||Date.now()-at>=INSTALL_SUGGEST_COOLDOWN}catch{return true}}
function compactBuild(){const raw=String(body.dataset.buildVersion||'');const m=raw.match(/workspace\.([^\s-]+)/);return m?m[1]:raw.replace(/^3\.0\.0-?/,'')||'—'}
function transportLabel(){if(!navigator.onLine)return 'بدون اینترنت';if(appUx.transport==='lan')return 'شبکه کافه';if(appUx.transport==='public')return appUx.stale?'اینترنت · در حال همگام‌سازی':'اینترنت';return 'آنلاین'}
function transitionCopy(t){const cross=String(t?.transition_kind||'')==='cross_origin';if(cross)return 'آدرس عمومی سامانه تغییر کرده است. روی آدرس جدید، ورود و سرویس‌های دستگاه به‌صورت مستقل بررسی می‌شوند.';return 'مسیر سامانه روی همین دامنه تغییر کرده است. هویت اپ حفظ شده و مسیر جدید در حال تطبیق است.'}
function closeUserMenu(){const menu=document.querySelector('[data-user-menu-panel]'),toggle=document.querySelector('[data-theme-menu-toggle]');if(menu)menu.hidden=true;if(toggle)toggle.setAttribute('aria-expanded','false')}
function ensureAppDialog(){
  if(appUx.dialog?.isConnected)return appUx.dialog;
  const d=document.createElement('dialog');d.className='sc-pwa-center';d.dataset.publicPwaCenter='';d.setAttribute('aria-labelledby','soknaPwaCenterTitle');d.setAttribute('aria-describedby','soknaPwaCenterDesc');
  d.innerHTML=`<section class="sc-pwa-center__panel">
    <header class="sc-pwa-center__head"><img class="sc-pwa-center__icon" src="${u('/staff/icon-192.png')}" alt=""><div><h2 id="soknaPwaCenterTitle">اپ سکنا</h2><p id="soknaPwaCenterDesc">نصب، اعلان‌ها، به‌روزرسانی و آمادگی کار در شبکه کافه</p></div><button type="button" class="sc-icon-button sc-pwa-center__close" data-pwa-close aria-label="بستن">${svg('close')}</button></header>
    <div class="sc-pwa-center__overview" aria-live="polite"><span class="sc-pwa-chip" data-pwa-mode-chip></span><span class="sc-pwa-chip" data-pwa-route-chip></span><span class="sc-pwa-chip" data-pwa-update-chip></span></div>
    <div class="sc-pwa-transition" data-pwa-transition hidden><strong>تغییر آدرس سامانه</strong><p data-pwa-transition-copy></p></div>
    <div class="sc-pwa-settings">
      <article class="sc-pwa-setting" data-pwa-install-row><span class="sc-pwa-setting__icon">${svg('device')}</span><div class="sc-pwa-setting__copy"><strong>نصب روی دستگاه</strong><small data-pwa-install-state></small></div><button type="button" class="sc-button sc-button--secondary" data-pwa-install-action></button></article>
      <div class="sc-pwa-guide" data-pwa-install-guide hidden></div>
      <article class="sc-pwa-setting" data-pwa-update-row><span class="sc-pwa-setting__icon">${svg('refresh')}</span><div class="sc-pwa-setting__copy"><strong>به‌روزرسانی اپ</strong><small data-pwa-update-state></small></div><button type="button" class="sc-button sc-button--secondary" data-pwa-update-action>بررسی</button></article>
      <article class="sc-pwa-setting" data-pwa-push-row><span class="sc-pwa-setting__icon">${svg('bell')}</span><div class="sc-pwa-setting__copy"><strong>اعلان‌های این دستگاه</strong><small data-pwa-push-state>در حال بررسی…</small></div><button type="button" class="sc-button sc-button--secondary" data-pwa-push-action>بررسی</button></article>
      <article class="sc-pwa-setting sc-pwa-notification-prefs" data-pwa-notification-prefs><span class="sc-pwa-setting__icon">${svg('settings')}</span><div class="sc-pwa-setting__copy"><strong>نوع اعلان‌های حساب</strong><small>این انتخاب روی همه دستگاه‌های ثبت‌شده برای همین حساب اعمال می‌شود.</small><label class="sc-pwa-toggle"><input type="checkbox" data-pwa-pref-master><span>اعلان روی دستگاه‌های ثبت‌شده</span></label><label class="sc-pwa-toggle"><input type="checkbox" data-pwa-pref-operations><span>سفارش، فراخوان و آماده‌سازی</span></label><label class="sc-pwa-toggle"><input type="checkbox" data-pwa-pref-management><span>مدیریت، مالی و تغییر قیمت</span></label><small data-pwa-pref-state></small></div></article>
      <article class="sc-pwa-setting" data-pwa-offline-row><span class="sc-pwa-setting__icon">${svg('archive')}</span><div class="sc-pwa-setting__copy"><strong>کار هنگام قطع اینترنت</strong><small data-pwa-offline-state></small></div><button type="button" class="sc-button sc-button--secondary" data-pwa-offline-action>بررسی دوباره</button></article>
    </div>
    <footer class="sc-pwa-center__foot"><span>نسخه ${compactBuild()}</span><span>هویت و مسیر اپ از تنظیمات استقرار می‌آید؛ URL داخل اپ ثابت نشده است.</span></footer>
  </section>`;
  d.querySelector('[data-pwa-close]')?.addEventListener('click',()=>d.close());
  d.querySelector('[data-pwa-install-action]')?.addEventListener('click',()=>void requestInstall());
  d.querySelector('[data-pwa-update-action]')?.addEventListener('click',()=>void requestUpdate());
  d.querySelector('[data-pwa-push-action]')?.addEventListener('click',()=>void handlePushAction());
  for(const el of d.querySelectorAll('[data-pwa-pref-master],[data-pwa-pref-operations],[data-pwa-pref-management]'))el.addEventListener('change',()=>void saveNotificationPreferences());
  d.querySelector('[data-pwa-offline-action]')?.addEventListener('click',()=>void refreshOfflineReadiness(true));
  d.addEventListener('click',e=>{if(e.target===d)d.close()});
  d.addEventListener('close',()=>{const o=appUx.opener;appUx.opener=null;if(o?.isConnected)queueMicrotask(()=>o.focus?.({preventScroll:true}))});
  document.body.append(d);appUx.dialog=d;return d;
}
function openAppCenter(){const d=ensureAppDialog();appUx.opener=document.activeElement instanceof HTMLElement?document.activeElement:null;closeUserMenu();syncAppCenter();if(!d.open)d.showModal();queueMicrotask(()=>d.querySelector('[data-pwa-close]')?.focus?.({preventScroll:true}));void status().catch(()=>{});void loadNotificationPreferences().catch(()=>{});void refreshOfflineReadiness(false);void ensureSwLifecycle().catch(()=>{})}
function ensureUi(){
  const panel=document.querySelector('[data-user-menu-panel]');if(!panel)return;
  panel.querySelector('[data-public-pwa-install]')?.remove();panel.querySelector('[data-public-push]')?.remove();
  let wrap=panel.querySelector('[data-public-pwa-entry]');
  if(!wrap){wrap=document.createElement('div');wrap.className='sc-user-menu__section sc-pwa-menu-section';wrap.dataset.publicPwaEntry='';wrap.innerHTML=`<button type="button" class="sc-pwa-menu-entry" data-public-pwa-center-open><span class="sc-pwa-menu-entry__icon">${svg('device')}</span><span class="sc-pwa-menu-entry__copy"><strong>اپ سکنا</strong><small data-public-pwa-menu-summary>وضعیت دستگاه و اعلان‌ها</small></span><span class="sc-pwa-menu-entry__state" data-public-pwa-menu-state aria-hidden="true"></span>${svg('chevron-left')}</button>`;const logout=panel.querySelector('.sc-user-menu__link--logout');panel.insertBefore(wrap,logout);wrap.querySelector('[data-public-pwa-center-open]')?.addEventListener('click',openAppCenter)}
  syncAppCenter();
}
function syncAppCenter(){
  ensureUiShallow();const d=appUx.dialog;
  const standalone=isStandalone(),online=navigator.onLine,updateReady=appUx.update==='ready';
  const summary=document.querySelector('[data-public-pwa-menu-summary]'),dot=document.querySelector('[data-public-pwa-menu-state]');
  if(summary)summary.textContent=updateReady?'نسخه جدید آماده است':standalone?(appUx.pushActive?'نصب‌شده · اعلان فعال':'نصب‌شده روی این دستگاه'):'نصب و تنظیمات دستگاه';
  if(dot){dot.dataset.tone=updateReady?'warning':standalone?'success':'neutral'}
  if(!d)return;
  const mode=d.querySelector('[data-pwa-mode-chip]'),route=d.querySelector('[data-pwa-route-chip]'),up=d.querySelector('[data-pwa-update-chip]');
  if(mode){mode.textContent=standalone?'نصب‌شده':'در مرورگر';mode.dataset.tone=standalone?'success':'neutral'}
  if(route){route.textContent=transportLabel();route.dataset.tone=!online||appUx.stale?'warning':appUx.transport==='lan'?'success':'neutral'}
  if(up){up.textContent=updateReady?'نسخه جدید':'به‌روز';up.dataset.tone=updateReady?'warning':'success'}
  const installState=d.querySelector('[data-pwa-install-state]'),installAction=d.querySelector('[data-pwa-install-action]');
  if(installState&&installAction){const guide=d.querySelector('[data-pwa-install-guide]');if(standalone){installState.textContent='از آیکن دستگاه و بدون نوار مرورگر اجرا می‌شود.';installAction.textContent='نصب شده';installAction.disabled=true;if(guide)guide.hidden=true}else if(deferredInstallPrompt){installState.textContent='مرورگر آماده است اپ سکنا را روی این دستگاه نصب کند.';installAction.textContent='نصب روی دستگاه';installAction.disabled=false}else if(isIOS()){installState.textContent='از Share به صفحه اصلی اضافه می‌شود؛ در iOS 26 حالت Web App پیش‌فرض است.';installAction.textContent='راهنمای نصب';installAction.disabled=false}else{installState.textContent='اگر مرورگر نصب مستقیم ارائه نکند، از منوی مرورگر استفاده کنید.';installAction.textContent='راهنمای نصب';installAction.disabled=false}}
  const updateState=d.querySelector('[data-pwa-update-state]'),updateAction=d.querySelector('[data-pwa-update-action]');
  if(updateState&&updateAction){if(appUx.reloadDeferred){updateState.textContent='نسخه جدید فعال شده؛ بازخوانی صفحه تا تعیین تکلیف سفارش یا پرداخت به تعویق افتاده است.';updateAction.textContent='بازخوانی امن';updateAction.disabled=false}else if(appUx.update==='ready'){updateState.textContent='نسخه جدید دانلود شده؛ با تأیید شما فعال می‌شود تا وسط کار صفحه ناگهانی reload نشود.';updateAction.textContent='به‌روزرسانی';updateAction.disabled=false}else if(appUx.update==='checking'){updateState.textContent='در حال بررسی نسخه جدید…';updateAction.textContent='در حال بررسی…';updateAction.disabled=true}else if(appUx.update==='activating'){updateState.textContent='نسخه جدید در حال فعال‌شدن است…';updateAction.textContent='در حال فعال‌سازی…';updateAction.disabled=true}else{updateState.textContent='به‌روزرسانی در پس‌زمینه بررسی می‌شود و بدون اجازه وسط عملیات reload نمی‌شود.';updateAction.textContent='بررسی';updateAction.disabled=false}}
  const off=d.querySelector('[data-pwa-offline-state]');if(off)off.textContent=appUx.offlineReady?'این دستگاه برای کار محدود در قطعی کوتاه اینترنت آماده است؛ اعتبار دسترسی محدود و امنیتی است.':'برای قطعی کوتاه اینترنت هنوز bootstrap امن این دستگاه آماده نیست.';
  const ps=d.querySelector('[data-pwa-push-state]');if(ps)ps.textContent=appUx.pushText;
  const prefs=appUx.notificationPrefs,master=d.querySelector('[data-pwa-pref-master]'),operations=d.querySelector('[data-pwa-pref-operations]'),management=d.querySelector('[data-pwa-pref-management]'),prefState=d.querySelector('[data-pwa-pref-state]');
  if(master&&operations&&management){const known=!!prefs;master.checked=known&&prefs.push_enabled===true;operations.checked=known&&prefs.push_operations_enabled===true;management.checked=known&&prefs.push_management_enabled===true;for(const el of [master,operations,management])el.disabled=!known||appUx.notificationPrefBusy;operations.disabled=operations.disabled||!master.checked;management.disabled=management.disabled||!master.checked;if(prefState)prefState.textContent=!known?'در حال دریافت تنظیمات حساب…':appUx.notificationPrefBusy?'در حال ذخیره…':master.checked?'نوع اعلان‌های موردنظر را برای همه دستگاه‌های این حساب انتخاب کنید.':'اعلان Push این حساب خاموش است؛ صندوق اعلان داخل سامانه مستقل باقی می‌ماند.';}
  const tr=d.querySelector('[data-pwa-transition]'),tc=d.querySelector('[data-pwa-transition-copy]');if(tr&&tc){tr.hidden=!appUx.transition;if(appUx.transition)tc.textContent=transitionCopy(appUx.transition)+(appUx.transition.pwa_reinstall_required?' نصب روی آدرس جدید را از همین صفحه انجام دهید.':'')+(appUx.transition.push_resubscribe_required?' اعلان‌ها را نیز روی آدرس جدید دوباره بررسی کنید.':'')}
}
function ensureUiShallow(){const panel=document.querySelector('[data-user-menu-panel]');if(!panel)return;if(!panel.querySelector('[data-public-pwa-entry]'))ensureUi()}
function showInstallGuide(){const d=ensureAppDialog(),g=d.querySelector('[data-pwa-install-guide]');if(!g)return;if(isIOS())g.innerHTML='<strong>نصب روی iPhone / iPad</strong><ol><li>منوی Share / اشتراک‌گذاری مرورگر را باز کنید.</li><li>«Add to Home Screen / افزودن به صفحه اصلی» را انتخاب کنید.</li><li>اگر «Open as Web App» نمایش داده شد، روشن بماند و سپس Add را بزنید.</li></ol>';else g.innerHTML='<strong>نصب از مرورگر</strong><p>در منوی مرورگر گزینه «Install app / نصب برنامه» یا «Add to Home Screen» را انتخاب کنید. اگر این گزینه دیده نمی‌شود، مرورگر فعلی نصب مستقیم PWA را ارائه نمی‌کند.</p>';g.hidden=false}
async function requestInstall(){ensureUi();if(isStandalone()){syncAppCenter();return}markInstallSuggestion();if(deferredInstallPrompt){const prompt=deferredInstallPrompt;deferredInstallPrompt=null;try{await prompt.prompt();const result=await prompt.userChoice;if(result?.outcome==='accepted'){installedThisSession=true;window.SoknaUI?.toast?.('نصب اپ سکنا تأیید شد.',{tone:'success',title:'اپ سکنا'});}else window.SoknaUI?.toast?.('نصب انجام نشد؛ هر زمان خواستید از «اپ سکنا» دوباره اقدام کنید.',{tone:'info',title:'اپ سکنا'})}catch{showInstallGuide()}syncAppCenter();return}showInstallGuide();syncAppCenter()}
function maybeSuggestInstall(){if(isStandalone()||!installSuggestionDue())return;if(body.dataset.page!=='home'||document.visibilityState!=='visible'||document.querySelector('dialog[open]'))return;if(!deferredInstallPrompt&&!isIOS())return;markInstallSuggestion();window.SoknaUI?.toast?.('اگر مرتب با سامانه کار می‌کنید، نصب اپ سکنا دسترسی سریع‌تر و تجربه پایدارتر می‌دهد.',{tone:'info',title:'اپ سکنا',duration:9000,actionLabel:'مشاهده',onAction:openAppCenter,key:'sokna-pwa-install-suggestion-v2'})}
function bindServiceWorkerRegistration(reg){
  if(!reg||appUx.swBound.has(reg))return;
  appUx.swBound.add(reg);
  const inspect=worker=>{
    if(!worker)return;
    worker.addEventListener('statechange',()=>{
      if(worker.state!=='installed'||!navigator.serviceWorker.controller)return;
      appUx.update='ready';appUx.updateWorker=reg.waiting||worker;syncAppCenter();
      if(!appUx.updateToastShown){
        appUx.updateToastShown=true;
        window.SoknaUI?.toast?.('نسخه جدید اپ آماده است. هر زمان مناسب بود آن را فعال کنید.',{tone:'info',title:'به‌روزرسانی اپ',duration:8000,actionLabel:'بررسی',onAction:openAppCenter,key:'sokna-pwa-update-ready'});
      }
    });
  };
  if(reg.waiting&&navigator.serviceWorker.controller){appUx.update='ready';appUx.updateWorker=reg.waiting}
  if(reg.installing)inspect(reg.installing);
  reg.addEventListener('updatefound',()=>inspect(reg.installing));
  syncAppCenter();
}
async function ensureSwLifecycle(){const reg=await sw();bindServiceWorkerRegistration(reg);return reg}
// E01/OPS-06: A worker takeover must never throw away an unacknowledged order,
// unfinished draft or unresolved financial command. The check is synchronous so
// controllerchange cannot race with a delayed confirmation dialog.
function unsafeForReload(){
  try{
    const intent=new Event('sokna:pwa-before-reload',{cancelable:true});
    document.dispatchEvent(intent);
    if(intent.defaultPrevented)return true;
    if(window.SoknaHallTransport?.hasUnresolvedMutations?.()===true)return true;
  }catch{return true} // fail closed when the state cannot be checked
  return false;
}
function deferUnsafeReload(){
  appUx.reloading=false;appUx.reloadDeferred=true;appUx.update='ready';syncAppCenter();
  window.SoknaUI?.toast?.('به‌روزرسانی تا تعیین تکلیف سفارش یا پرداخت فعلی عقب افتاد. پس از بررسی نتیجه دوباره از منوی اپ اقدام کنید.',{tone:'warning',title:'به‌روزرسانی اپ',duration:9000});
}
async function requestUpdate(){
  if(appUx.reloading||appUx.update==='activating')return;
  if(appUx.reloadDeferred){
    if(unsafeForReload()){deferUnsafeReload();return}
    appUx.reloadDeferred=false;location.reload();return;
  }
  if(unsafeForReload()){appUx.update='ready';syncAppCenter();window.SoknaUI?.toast?.('پیش از فعال‌سازی نسخه جدید، سفارش یا پرداخت نامطمئن را تعیین تکلیف کنید.',{tone:'warning',title:'به‌روزرسانی اپ'});return}
  try{
    const reg=await ensureSwLifecycle();
    // Re-evaluate after awaiting service worker readiness; work may have started.
    if(unsafeForReload()){appUx.update=reg.waiting?'ready':'current';syncAppCenter();return}
    if(reg.waiting&&navigator.serviceWorker.controller){
      appUx.update='activating';appUx.updateWorker=reg.waiting;appUx.reloading=true;syncAppCenter();
      reg.waiting.postMessage({type:'sokna:activate-update'});return;
    }
    appUx.update='checking';syncAppCenter();await reg.update();await wait(350);
    if(reg.waiting&&navigator.serviceWorker.controller){appUx.update='ready';appUx.updateWorker=reg.waiting;window.SoknaUI?.toast?.('نسخه جدید آماده فعال‌سازی است.',{tone:'info',title:'به‌روزرسانی اپ'});}
    else{appUx.update='current';window.SoknaUI?.toast?.('همین حالا آخرین نسخه در دسترس است.',{tone:'success',title:'به‌روزرسانی اپ'})}
  }catch(e){appUx.reloading=false;appUx.update='current';window.SoknaUI?.toast?.(humanError(e,'بررسی به‌روزرسانی انجام نشد.'),{tone:'warning',title:'به‌روزرسانی اپ'})}
  finally{syncAppCenter()}
}
function onControllerChange(){
  if(appUx.reloading){
    if(unsafeForReload()){deferUnsafeReload();return}
    appUx.reloading=false;location.reload();return;
  }
  if(appUx.reloadDeferred){appUx.update='ready';syncAppCenter();return}
  appUx.update='current';syncAppCenter();
}
async function refreshOfflineReadiness(showFeedback=false){let ok=false;try{ok=await persistOfflineBootstrap();if(ok)await signalOfflineWorker('sokna:warm-offline')}catch{}appUx.offlineReady=ok;syncAppCenter();if(showFeedback)window.SoknaUI?.toast?.(ok?'آمادگی امن این دستگاه برای قطعی کوتاه اینترنت تازه شد.':'آمادگی آفلاین هنوز کامل نیست؛ اتصال Public و شبکه کافه را بررسی کنید.',{tone:ok?'success':'warning',title:'آمادگی قطعی اینترنت'});return ok}
async function renderTransition(){if(!transitionId)return;let t=null;try{t=await req(u('/api/staff/deployment-transition')+'?rebind_id='+encodeURIComponent(transitionId),{},8000)}catch{return}appUx.transition=t;syncAppCenter();try{const x=new URL(location.href);x.searchParams.delete('origin_transition');history.replaceState(history.state,'',x.pathname+(x.searchParams.toString()?'?'+x.searchParams.toString():'')+x.hash)}catch{}window.SoknaUI?.toast?.(transitionCopy(t),{tone:'warning',title:'تغییر آدرس سامانه',duration:9000,actionLabel:'بررسی',onAction:openAppCenter,key:'sokna-origin-transition'})}
async function loadNotificationPreferences(existingModel=null){const m=existingModel||await model(),raw=m?.payload?.push?.preferences||null;if(raw&&typeof raw==='object'){appUx.notificationPrefs={in_app_enabled:Number(raw.in_app_enabled??1)===1,push_enabled:Number(raw.push_enabled??1)===1,push_operations_enabled:Number(raw.push_operations_enabled??1)===1,push_management_enabled:Number(raw.push_management_enabled??1)===1};syncAppCenter();return appUx.notificationPrefs}return null}
async function saveNotificationPreferences(){if(appUx.notificationPrefBusy)return;const d=ensureAppDialog(),master=d.querySelector('[data-pwa-pref-master]'),operations=d.querySelector('[data-pwa-pref-operations]'),management=d.querySelector('[data-pwa-pref-management]');if(!master||!operations||!management)return;const before=appUx.notificationPrefs||{in_app_enabled:true,push_enabled:true,push_operations_enabled:true,push_management_enabled:true};const next={in_app_enabled:before.in_app_enabled!==false,push_enabled:master.checked,push_operations_enabled:operations.checked,push_management_enabled:management.checked};appUx.notificationPrefBusy=true;appUx.notificationPrefs=next;syncAppCenter();try{await command('notification.preferences.save',next);await loadNotificationPreferences();window.SoknaUI?.toast?.('تنظیمات اعلان این حساب ذخیره شد.',{tone:'success',title:'اعلان‌ها'})}catch(e){appUx.notificationPrefs=before;window.SoknaUI?.toast?.(humanError(e,'ذخیره تنظیمات اعلان انجام نشد. وضعیت را قبل از تلاش دوباره بررسی کن.'),{tone:'warning',title:'اعلان‌ها'})}finally{appUx.notificationPrefBusy=false;syncAppCenter()}}
function ui(text,active=false){ensureUi();appUx.pushActive=active;appUx.pushText=String(text||'');const d=appUx.dialog,b=d?.querySelector('[data-pwa-push-action]');if(b){b.disabled=busy;b.textContent=active?'غیرفعال‌کردن':'فعال‌کردن'}syncAppCenter()}
async function status(){ensureUi();if(isIOS()&&!isStandalone()){ui('در iPhone/iPad اعلان Web Push بعد از افزودن اپ به Home Screen قابل فعال‌سازی است.');return {active:false,installRequired:true}}if(!window.isSecureContext||!('serviceWorker'in navigator)||!('PushManager'in window)||!('Notification'in window)||!crypto?.subtle){ui('اعلان گوشی در این مرورگر یا اتصال در دسترس نیست.');return {active:false,unsupported:true}}const reg=await ensureSwLifecycle(),sub=await reg.pushManager.getSubscription();if(!sub){ui(Notification.permission==='denied'?'مجوز اعلان در تنظیمات مرورگر/سیستم مسدود است.':'اعلان روی این دستگاه فعال نیست.');return {active:false,sub:null,reg,permission:Notification.permission}}const h=await hashEndpoint(String(sub.endpoint||'')),m=await model();await loadNotificationPreferences(m);const push=m?.payload?.push||{},rows=Array.isArray(push.subscriptions)?push.subscriptions:[],owned=rows.some(x=>String(x.endpoint_hash||'')===h),bindingReady=push.binding_ready!==false,ready=bindingReady&&push.bridge_configured===true&&!!String(push.vapid_public_key||'').trim(),permission=Notification.permission==='granted',active=owned&&ready&&permission;ui(active?msg.active:(!permission?'مجوز اعلان مرورگر فعال نیست.':(!bindingReady?'دامنه سامانه تغییر کرده؛ اعلان باید روی همین آدرس دوباره فعال شود.':(!ready?'زیرساخت Push در Local آماده نیست.':msg.notOwned))),active);return {active,owned,ready,bindingReady,permission,sub,reg,model:m,hash:h}}
async function handlePushAction(){if(isIOS()&&!isStandalone()){showInstallGuide();syncAppCenter();return}if(typeof Notification!=='undefined'&&Notification.permission==='denied'){window.SoknaUI?.toast?.('مجوز اعلان از سمت مرورگر/سیستم مسدود شده است. آن را از تنظیمات سایت یا سیستم‌عامل فعال کنید.',{tone:'warning',title:'اعلان‌های دستگاه'});return}return toggle()}
async function toggle(){if(busy)return;busy=true;ui('در حال انجام…');try{const st=await status();if(st.unsupported||st.installRequired)return;if(st.sub&&st.active){await command('notification.push.unsubscribe',{endpoint:String(st.sub.endpoint||'')});await st.sub.unsubscribe();ui('اعلان گوشی غیرفعال شد.');return}let sub=st.sub;if(!sub){const cfg=(st.model||await model())?.payload?.push||{};if(!cfg.bridge_configured||!String(cfg.vapid_public_key||'').trim())throw new Error('تنظیمات اعلان در سیستم اصلی کافه کامل نیست.');const permission=Notification.permission==='granted'?'granted':await Notification.requestPermission();if(permission!=='granted')throw new Error('اجازه اعلان داده نشد.');sub=await st.reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:vapidBytes(String(cfg.vapid_public_key))})}await command('notification.push.subscribe',{subscription:sub.toJSON()});ui('درخواست ثبت شد؛ فعال‌شدن اعلان در سیستم اصلی کافه در حال بررسی است.');await wait(1200);await status()}catch(e){ui(humanError(e,'فعال‌سازی اعلان کامل نشد. وضعیت درخواست را بررسی کن.'))}finally{busy=false;syncAppCenter()}}
async function detachBeforeLogout(link){if(busy)return;busy=true;try{await offlineClear();await signalOfflineWorker('sokna:purge-offline');if('serviceWorker'in navigator){const reg=await navigator.serviceWorker.getRegistration(u('/staff/'));const sub=reg?await reg.pushManager.getSubscription():null;if(sub){const endpoint=String(sub.endpoint||'');try{await Promise.race([command('notification.push.unsubscribe',{endpoint}),wait(1200)])}catch{}try{await sub.unsubscribe()}catch{}}}}finally{location.href=link.href}}
document.addEventListener('click',e=>{const a=e.target.closest('a.sc-user-menu__link--logout, .sc-shell__footer a');if(!a||!a.href||!a.href.includes('/staff/logout'))return;e.preventDefault();detachBeforeLogout(a)});
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstallPrompt=e;ensureUi();syncAppCenter()},{passive:false});
window.addEventListener('appinstalled',()=>{deferredInstallPrompt=null;installedThisSession=true;markInstallSuggestion();syncAppCenter();window.SoknaUI?.toast?.('اپ سکنا روی این دستگاه نصب شد.',{tone:'success',title:'اپ سکنا'})});
window.addEventListener('online',()=>{syncAppCenter();void refreshOfflineReadiness(false)},{passive:true});
window.addEventListener('offline',syncAppCenter,{passive:true});
document.addEventListener('sokna:staff-read-meta',e=>{const d=e.detail||{};appUx.transport=String(d.transport||'');appUx.stale=d.stale===true;syncAppCenter()});
if('serviceWorker'in navigator)navigator.serviceWorker.addEventListener('controllerchange',onControllerChange);
ensureUi();void renderTransition();void loadNotificationPreferences().catch(()=>{});status().catch(e=>ui(humanError(e,'بررسی اعلان گوشی کامل نشد.')));
void refreshOfflineReadiness(false);
setTimeout(()=>{void ensureSwLifecycle().then(reg=>reg.update()).catch(()=>{})},8000);
setTimeout(maybeSuggestInstall,INSTALL_SUGGEST_DELAY);
window.addEventListener('pageshow',()=>{syncAppCenter();void refreshOfflineReadiness(false);void ensureSwLifecycle().catch(()=>{})},{passive:true});
window.SoknaPublicDeviceDiagnostics={binding:bindingValue,staffScope:absolute('/staff/'),staffWorker:absolute('/staff/sw.js'),offlineBootstrap:'bounded-lan-v1',installOwner:'public-device-v2',appCenter:'pwa-experience-v1',originTransition:transitionId||''};
})();
