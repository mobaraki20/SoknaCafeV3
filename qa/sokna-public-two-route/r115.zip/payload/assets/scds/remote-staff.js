(()=>{'use strict';
const body=document.body,base=(body?.dataset.basePath||body?.dataset.appBase||'').replace(/\/$/,'');
const u=p=>base+'/'+String(p||'').replace(/^\//,'');
const buttons=[...document.querySelectorAll('[data-model]')],out=document.querySelector('[data-output]'),state=document.querySelector('[data-state]'),conn=document.querySelector('[data-connectivity]'),title=document.querySelector('[data-title]'),modulePanel=document.querySelector('[data-staff-module-panel]'),dashboardOnly=[...document.querySelectorAll('[data-staff-dashboard-only]')],sharedModules=[...document.querySelectorAll('[data-shared-staff-module]')];if(!out)return;
const labels={operations:'سالن و میزها',preparation:'آماده‌سازی',inventory:'انبار',supply:'تأمین و خرید',customers:'مشتریان',inventory_cost:'بهای انبار',reports:'گزارش و تحلیل',notifications:'اعلان‌ها',deferred_context:'اطلاعات پشتیبان'};
const cache={};let activeModel='',activeView='';let readLoadSequence=0,readLastAt=0,readHadError=false,readHadStale=false,readFormDirty=false;
const uid=(p='r')=>`${p}-${Date.now().toString(36)}-${Math.random().toString(16).slice(2,10)}`,now=()=>window.SoknaLocale.nowInstant(),later=(s=90)=>new Date(Date.parse(window.SoknaLocale.nowInstant())+s*1000).toISOString();
const faDigits=v=>String(v??'').replace(/[0-9]/g,d=>'۰۱۲۳۴۵۶۷۸۹'[Number(d)]),number=v=>new Intl.NumberFormat('fa-IR-u-nu-arabext',{maximumFractionDigits:2}).format(Number(v)||0),money=v=>window.SoknaLocale?.money?window.SoknaLocale.money(v):`${new Intl.NumberFormat('fa-IR-u-nu-arabext',{maximumFractionDigits:0}).format(Number(v)||0)} تومان`,text=(v,f='—')=>{const x=String(v??'').trim();return x||f};
const dateTime=v=>window.SoknaLocale.dateTime(v);
const node=(tag,cls='',value)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(value!==undefined&&value!==null)e.textContent=String(value);return e};
const empty=(message='داده‌ای برای نمایش وجود ندارد.')=>{const e=node('div','rs-model-empty');e.append(node('strong','',message));return e};
const metric=(label,value,meta='')=>{const e=node('div','rs-metric');e.append(node('span','rs-metric__label',label),node('strong','rs-metric__value',value));if(meta)e.append(node('small','rs-metric__meta',meta));return e};
const metrics=items=>{const g=node('div','rs-metrics');items.forEach(i=>g.append(metric(i[0],i[1],i[2]||'')));return g};
const section=(heading,copy='')=>{const s=node('section','rs-model-section'),h=node('div','rs-model-section__head');h.append(node('h3','',heading));if(copy)h.append(node('p','',copy));s.append(h);return s};
const statusLabel=v=>({pending_sync:'در انتظار همگام‌سازی',pending:'در انتظار',claimed:'در حال پردازش',committed:'ثبت‌شده',rejected:'ردشده',needs_review:'نیازمند بررسی',unknown_review:'نیازمند بررسی',expired:'منقضی',cancelled:'لغوشده'}[String(v??'')]||text(v));
const deferredKindLabel=v=>({'supply.need.create':'ثبت نیاز خرید','supply.status.prepare':'آماده‌سازی خرید','supply.status.return':'بازگشت خرید','supply.receipt':'ثبت رسید خرید','inventory.waste':'ثبت ضایعات','inventory.count_draft':'پیش‌نویس شمارش انبار','subscriber.payment':'پرداخت مشتری','expense.create':'ثبت هزینه'}[String(v??'')]||text(v));
const errorLabel=v=>({unauthorized:'نشست شما معتبر نیست؛ دوباره وارد شوید.',forbidden:'برای انجام این کار دسترسی ندارید.',invalid_response:'پاسخ معتبر از سرور دریافت نشد.',request_failed:'ارتباط با سرور کامل نشد؛ دوباره تلاش کنید.',request_timeout:'پاسخ شبکه در مهلت تعیین‌شده نرسید؛ وضعیت درخواست را دوباره بررسی کنید.',stale_projection:'نسخه اطلاعات این عملیات با وضعیت فعلی هم‌خوان نیست؛ اطلاعات را تازه کنید و دوباره بررسی کنید.',local_unavailable:'ارتباط با سامانه محلی تازه نیست؛ عملیات حساس موقتاً غیرفعال است.',request_id_conflict:'این درخواست با شناسه تکراری و محتوای متفاوت ثبت شده است.',supply_receipt_pending:'برای این قلم یک رسید تحویل تعیین‌تکلیف‌نشده وجود دارد؛ ابتدا نتیجه آن را بررسی کنید.',remote_disabled:'دسترسی راه‌دور این نصب غیرفعال شده است.',installation_inactive:'این نصب فعال نیست.'}[String(v??'')]||'عملیات انجام نشد؛ وضعیت را دوباره بررسی کنید.');
function hideSharedModules(){sharedModules.forEach(x=>x.hidden=true)}
function showDashboardMode(){dashboardOnly.forEach(x=>x.hidden=false);if(modulePanel)modulePanel.hidden=true;hideSharedModules();buttons.forEach(x=>x.setAttribute('aria-current','false'));activeModel='';activeView=''}
function showModuleMode(){dashboardOnly.forEach(x=>x.hidden=true);hideSharedModules();if(modulePanel)modulePanel.hidden=false}
function showSharedModule(key){dashboardOnly.forEach(x=>x.hidden=true);if(modulePanel)modulePanel.hidden=true;sharedModules.forEach(x=>x.hidden=String(x.dataset.sharedStaffModule||'')!==String(key||''))}
function updateConnectivity(stale,lastSync=''){if(!conn)return;conn.textContent=stale?'اطلاعات نمایش‌داده‌شده ممکن است قدیمی باشد؛ آمادگی هر عملیات جداگانه از مسیر زنده بررسی می‌شود.':'ارتباط با سیستم کافه و اطلاعات همگام‌شده تازه است.';conn.className='rs-alert'+(stale?' is-stale':'');if(state&&activeModel)state.textContent=(stale?'اطلاعات قدیمی · ':'به‌روز · ')+(lastSync?dateTime(lastSync):'—')}
function makeRequestError(code,detail=''){const c=String(code||'request_failed').trim()||'request_failed',e=new Error(detail&&!/^[a-z0-9_.:-]+$/i.test(detail)?detail:errorLabel(c));e.code=c;return e}
function errorInfo(err){const raw=String(err?.message||'').trim(),explicit=String(err?.code||'').trim(),technical=/^[a-z0-9_.:-]+$/i.test(raw),code=explicit||(technical?raw:'');return {message:raw&&!technical?raw:errorLabel(code||'request_failed'),code}}
async function json(url,opt={}){const cfg={...opt},timeoutMs=Number(cfg.timeoutMs||12000),externalSignal=cfg.signal||null,method=String(cfg.method||'GET').toUpperCase(),mutating=!['GET','HEAD','OPTIONS'].includes(method);delete cfg.timeoutMs;delete cfg.signal;const controller=new AbortController(),timer=setTimeout(()=>controller.abort('deadline'),Math.max(250,timeoutMs));let forward=null;if(externalSignal){forward=()=>controller.abort(externalSignal.reason||'cancelled');if(externalSignal.aborted)forward();else externalSignal.addEventListener('abort',forward,{once:true})}try{let r;try{r=await fetch(url,{cache:'no-store',credentials:'same-origin',headers:{Accept:'application/json','Content-Type':'application/json',...(cfg.headers||{})},...cfg,signal:controller.signal})}catch{const e=makeRequestError(controller.signal.aborted?'request_timeout':'request_failed');e.unknown_outcome=mutating;throw e}let j={};try{j=await r.json()}catch{const e=makeRequestError(controller.signal.aborted?'request_timeout':'invalid_response');e.http_status=r.status;e.unknown_outcome=mutating;throw e}if(r.status===401){location.href=u('/staff/login');throw makeRequestError('unauthorized')}if(!r.ok||j.ok===false||j.success===false){const e=makeRequestError(j.error||j.code||'request_failed',j.message||'');e.http_status=r.status;e.unknown_outcome=mutating&&(r.status>=500||[408,425,429].includes(r.status));throw e}return j}finally{clearTimeout(timer);if(externalSignal&&forward)externalSignal.removeEventListener('abort',forward)}}
async function readModel(key){const j=await json(u('/api/staff/read')+'?model='+encodeURIComponent(key));if(!j.payload||typeof j.payload!=='object'||Array.isArray(j.payload))throw makeRequestError('projection_payload_unavailable','داده این بخش هنوز کامل دریافت نشده است.');return j}
async function poll(kind,id){const url=kind==='realtime'?u('/api/staff/realtime/result')+'?request_id=':u('/api/staff/deferred/result')+'?request_id=';let committedPending=null;for(let i=0;i<20;i++){const j=await json(url+encodeURIComponent(id));if(j.terminal||['committed','rejected','needs_review','unknown_review','expired','cancelled'].includes(String(j.state||''))){if(kind==='realtime'&&String(j.state||'')==='committed'&&String(j.visibility?.state||'not_required')==='pending'){committedPending=j;await new Promise(r=>setTimeout(r,750));continue}return j}await new Promise(r=>setTimeout(r,750))}return committedPending?{...committedPending,visibility_pending:true}:{ok:true,state:'pending',terminal:false}}
const postRealtime=envelope=>json(u('/api/staff/realtime'),{method:'POST',body:JSON.stringify(envelope)}),postDeferred=envelope=>json(u('/api/staff/deferred'),{method:'POST',body:JSON.stringify(envelope)});
const actorScope=String(body?.dataset.projectionId||'unknown'),intentLedgerKey=`sokna:remote-staff-command-ledger:v1:${base||'/'}:${actorScope}`,INTENT_TTL_MS=7*24*60*60*1000,INTENT_MAX=100;
function stableValue(v){if(Array.isArray(v))return v.map(stableValue);if(v&&typeof v==='object'){const o={};Object.keys(v).sort().forEach(k=>o[k]=stableValue(v[k]));return o}return v}
function hashText128(value){const seeds=[2166136261,3339675911,2246822519,3266489917];return seeds.map(seed=>{let h=seed>>>0;for(let i=0;i<value.length;i++){h^=value.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16).padStart(8,'0')}).join('')}
function commandFingerprint(channel,kind,payload){return hashText128(JSON.stringify(stableValue({channel,kind,payload})))}
function readIntentLedger(){try{const rows=JSON.parse(localStorage.getItem(intentLedgerKey)||'[]'),t=Date.now();return Array.isArray(rows)?rows.filter(x=>x&&Number(x.keep_until||0)>t):[]}catch{return[]}}
function writeIntentLedger(rows){try{if(!rows.length)localStorage.removeItem(intentLedgerKey);else localStorage.setItem(intentLedgerKey,JSON.stringify(rows));return true}catch{return false}}
function rememberIntent(channel,kind,payload,prefix='cmd'){const fingerprint=commandFingerprint(channel,kind,payload),rows=readIntentLedger(),existing=[...rows].reverse().find(x=>x.fingerprint===fingerprint);if(existing)return {record:existing,reused:true};if(rows.length>=INTENT_MAX){const e=makeRequestError('request_pending','چند درخواست قبلی هنوز تعیین تکلیف نشده‌اند؛ عملیات تازه موقتاً متوقف شد.');e.blocked_before_send=true;throw e}const createdAt=now(),record={request_id:uid(prefix),fingerprint,channel,kind,created_at:createdAt,occurred_at:createdAt,expires_at:later(120),keep_until:Date.now()+INTENT_TTL_MS};rows.push(record);if(!writeIntentLedger(rows)){const e=makeRequestError('request_pending','برای جلوگیری از ثبت تکراری، شناسه این عملیات روی دستگاه ذخیره نشد.');e.blocked_before_send=true;throw e}return {record,reused:false}}
function forgetIntent(requestId){writeIntentLedger(readIntentLedger().filter(x=>String(x.request_id)!==String(requestId)))}
function definitiveClientFailure(error){const status=Number(error?.http_status||0);return !error?.unknown_outcome&&status>=400&&status<500&&![408,425,429].includes(status)}
async function durableCommand(channel,kind,payload,{prefix='cmd',deferred=false}={}){const remembered=rememberIntent(channel,kind,payload,prefix),r=remembered.record,envelope={request_id:r.request_id,kind,created_at:r.created_at,payload};if(deferred)envelope.occurred_at=r.occurred_at;else envelope.expires_at=r.expires_at;try{await (deferred?postDeferred(envelope):postRealtime(envelope))}catch(error){if(definitiveClientFailure(error)){forgetIntent(r.request_id);throw error}}const result=await poll(deferred?'deferred':'realtime',r.request_id);if(result?.terminal||['committed','rejected','needs_review','unknown_review','expired','cancelled'].includes(String(result?.state||'')))forgetIntent(r.request_id);return result}

const resultTone=(v,r=null)=>String(v||'')==='committed'&&String(r?.visibility?.state||'not_required')==='pending'?'warn':['committed'].includes(String(v||''))?'ok':['rejected','expired','cancelled'].includes(String(v||''))?'bad':'warn';
const resultMessage=(r,success='عملیات با موفقیت ثبت شد.')=>{const s=String(r?.state||'');if(s==='committed'&&String(r?.visibility?.state||'not_required')==='pending')return 'عملیات در کافه ثبت شد؛ نمایش عمومی هنوز در حال تازه‌شدن است.';if(s==='committed')return success;if(['pending_sync','pending','claimed'].includes(s))return 'درخواست ثبت شد و در انتظار همگام‌سازی با سامانه محلی است.';if(['needs_review','unknown_review'].includes(s))return 'درخواست ثبت شد، اما نیازمند بررسی در سامانه محلی است.';if(s==='rejected')return 'درخواست توسط سامانه محلی پذیرفته نشد.';if(s==='expired')return 'مهلت این درخواست تمام شد؛ دوباره تلاش کنید.';if(s==='cancelled')return 'درخواست لغو شد.';return `وضعیت درخواست: ${statusLabel(s)}`};
function renderActionState(target,value,tone=''){if(!target)return;target.replaceChildren();target.className='rs-action-state'+(tone?` is-${tone}`:'');target.append(node('span','rs-action-state__message',value?.message??value??''));const code=String(value?.code||'').trim();if(code)target.append(node('small','rs-tech-code',`کد فنی: ${code}`))}
function actionState(form,value,tone=''){renderActionState(form.querySelector('[data-action-state]'),value,tone)}
const canSupplyNeedRemote=()=>body?.dataset.canSupplyNeed==='1',canSupplyManageRemote=()=>body?.dataset.canSupplyManage==='1',canSubscriberPaymentRemote=()=>body?.dataset.canSubscriberPayment==='1';
function option(select,value,label){const o=document.createElement('option');o.value=String(value);o.textContent=label;select.append(o)}
function supplyForm(){if(!canSupplyNeedRemote())return null;const form=node('form','rs-action sc-card');form.dataset.action='supply';const b=node('div','sc-card__body sc-stack');b.append(node('h3','','ثبت نیاز خرید'));const item=node('label','sc-field');item.append(node('span','sc-field__label','قلم'));const select=node('select','sc-control');select.name='inventory_item_id';select.dataset.inventoryItems='';select.required=true;item.append(select);const qty=node('label','sc-field');qty.append(node('span','sc-field__label','مقدار'));const qi=node('input','sc-control');qi.name='quantity_major';qi.inputMode='decimal';qi.required=true;qty.append(qi);const dep=node('label','sc-field');dep.append(node('span','sc-field__label','بخش'));const ds=node('select','sc-control');ds.name='department';[['shared','مشترک'],['kitchen','آشپزخانه'],['bar','بار']].forEach(([v,l])=>option(ds,v,l));dep.append(ds);const note=node('label','sc-field');note.append(node('span','sc-field__label','یادداشت'));const ni=node('input','sc-control');ni.name='note';note.append(ni);const submit=node('button','sc-button','ثبت برای همگام‌سازی');submit.type='submit';const st=node('div','rs-action-state');st.dataset.actionState='';b.append(item,qty,dep,note,submit,st);form.append(b);return form}
function customerForm(){if(!canSubscriberPaymentRemote())return null;const form=node('form','rs-action sc-card');form.dataset.action='subscriber';const b=node('div','sc-card__body sc-stack');b.append(node('h3','','ثبت پرداخت مشتری'));const customer=node('label','sc-field');customer.append(node('span','sc-field__label','مشتری'));const select=node('select','sc-control');select.name='subscriber_id';select.dataset.subscribers='';select.required=true;customer.append(select);const amount=node('label','sc-field');amount.append(node('span','sc-field__label','مبلغ'));const ai=node('input','sc-control');ai.name='amount';ai.inputMode='numeric';ai.dataset.moneyInput='1';ai.required=true;amount.append(ai);const ref=node('label','sc-field');ref.append(node('span','sc-field__label','مرجع'));const ri=node('input','sc-control');ri.name='reference';ref.append(ri);const submit=node('button','sc-button','ثبت پرداخت');submit.type='submit';const st=node('div','rs-action-state');st.dataset.actionState='';b.append(customer,amount,ref,submit,st);form.append(b);return form}
function renderInventory(p,cost=false){const P=window.SoknaStaffDataPanels;if(P)return P.renderInventoryPanel(out,p,{cost});out.append(empty('نمایش مشترک انبار آماده نیست.'))}
function renderReports(p){const P=window.SoknaStaffDataPanels;if(P)return P.renderReportSummary(out,p);out.append(empty('نمایش مشترک گزارش آماده نیست.'))}
function renderNotifications(p){const P=window.SoknaStaffDataPanels;if(P)return P.renderNotificationsPanel(out,p,{linkResolver:u});out.append(empty('نمایش مشترک اعلان‌ها آماده نیست.'))}
function renderCustomers(p){const form=customerForm();if(form){const a=node('div','rs-module-actions');a.append(form);out.append(a)}const P=window.SoknaStaffDataPanels;if(P){const shared=node('div','rs-shared-data-panel');P.renderCustomersPanel(shared,p);out.append(shared)}else out.append(empty('نمایش مشترک مشتریان آماده نیست.'))}
function receiptForm(group){
  const g=group||{},itemId=Number(g.item_id||0),preparing=Number(g.preparing_quantity_base||0);
  // Free-text needs can create an inventory item and require a separate review;
  // do not silently create one from stale Public data.
  if(!canSupplyManageRemote()||itemId<1||g.inventory_active===0||preparing<=0)return null;
  const form=node('form','rs-action sc-stack');form.hidden=true;form.dataset.action='supply-receipt';
  form.dataset.receiptGroup=String(g.group_key||'');form.dataset.receiptItemId=String(itemId);
  form.dataset.receiptExpected=String(preparing);form.dataset.receiptBaseUnit=String(g.base_unit||'count');
  const purchaseUnits=(Array.isArray(cache.deferred_context?.purchase_units)?cache.deferred_context.purchase_units:[])
    .filter(x=>Number(x.inventory_item_id)===itemId&&Number(x.id)>0&&['fixed','actual_quantity'].includes(String(x.effective_mode||'')));
  form.dataset.receiptPurchaseUnits=JSON.stringify(purchaseUnits);
  const unitLabel=({g:'کیلوگرم',ml:'لیتر',count:'عدد'})[String(g.base_unit||'')]||'واحد';
  const heading=node('strong','','ثبت تحویل خرید — '+String(g.name||''));
  const help=node('p','sc-muted','مقدار واقعی را به '+unitLabel+' وارد کنید (مثلاً ۱٫۵ کیلوگرم)؛ تعداد بسته یا کارتن نیست. تا روشن‌شدن نتیجه، خرید را دوباره ثبت نکنید.');
  const field=(label,name,{required=false,moneyInput=false,inputMode='text'}={})=>{
    const holder=node('label','sc-field');holder.append(node('span','sc-field__label',label));
    const input=node('input','sc-control');input.name=name;input.required=required;input.inputMode=inputMode;
    if(moneyInput)input.dataset.moneyInput='1';holder.append(input);return holder;
  };
  const unitHolder=node('label','sc-field');unitHolder.append(node('span','sc-field__label','شیوه ثبت مقدار'));
  const unitSelect=node('select','sc-control');unitSelect.name='purchase_unit_id';
  const baseOption=node('option','',`مقدار واقعی به ${unitLabel} (بدون بسته)`);baseOption.value='0';unitSelect.append(baseOption);
  for(const item of purchaseUnits){
    const mode=String(item.effective_mode||'');const factor=Number(item.base_quantity||0);
    if(mode==='fixed'&&(!Number.isSafeInteger(factor)||factor<1))continue;
    const op=node('option','',String(item.name||'واحد خرید')+(mode==='fixed'?` · هر واحد ${number(factor)} ${String(g.base_unit)==='count'?'عدد':String(g.base_unit)}`:' · مقدار واقعی الزامی'));
    op.value=String(item.id);unitSelect.append(op);
  }
  unitHolder.append(unitSelect);
  const qty=field('مقدار تحویل‌شده ('+unitLabel+')','unit_count',{required:true,inputMode:'decimal'});
  const actual=field('مقدار واقعی محتویات ('+unitLabel+')','actual_major_quantity',{inputMode:'decimal'});
  actual.hidden=true;
  const cost=field('هزینه کل خرید (تومان؛ اختیاری)','total_cost',{moneyInput:true,inputMode:'numeric'});
  const supplier=field('تأمین‌کننده','supplier');const note=field('یادداشت','note');
  const submit=node('button','sc-button','ثبت تحویل برای همگام‌سازی');submit.type='submit';
  const status=node('div','rs-action-state');status.dataset.actionState='';
  form.append(heading,help,unitHolder,qty,actual,cost,supplier,note,submit,status);
  const refreshUnit=()=>{
    const chosen=purchaseUnits.find(x=>String(x.id)===unitSelect.value);
    const isActual=String(chosen?.effective_mode||'')==='actual_quantity';
    actual.hidden=!isActual;actual.querySelector('input').required=isActual;
    qty.querySelector('span').textContent=chosen?'تعداد واحد خرید (بسته/کارتن)':'مقدار تحویل‌شده ('+unitLabel+')';
    help.textContent=chosen?(isActual?'تعداد بسته و مقدار واقعی محتوای آن را جداگانه وارد کنید. Local مقدار واقعی را دوباره تأیید می‌کند.':'مقدار واحد خرید از Local خوانده شده و هنگام همگام‌سازی دوباره اعتبارسنجی می‌شود.'):'مقدار واقعی را با واحد اصلی وارد کنید؛ تعداد بسته یا کارتن نیست.';
  };
  unitSelect.addEventListener('change',refreshUnit);refreshUnit();return form;
}
function buildSupplyReceiptPayload(form){
  const groupKey=String(form.dataset.receiptGroup||'').trim();
  const itemId=Number(form.dataset.receiptItemId||0),expected=Number(form.dataset.receiptExpected||0);
  const unit=String(form.dataset.receiptBaseUnit||'');
  const canonical=s=>String(s??'').trim().replace(/[۰-۹]/g,c=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(c))).replace(/[٠-٩]/g,c=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(c))).replace(/[٫]/g,'.');
  const count=canonical(form.elements.unit_count.value),cost=canonical(form.elements.total_cost.value).replace(/[٬,\s]/g,'');
  const unitId=Number(form.elements.purchase_unit_id?.value||0);
  const options=JSON.parse(form.dataset.receiptPurchaseUnits||'[]');
  const selected=options.find(x=>Number(x.id)===unitId);
  if(!Number.isSafeInteger(unitId)||unitId<0||(unitId>0&&!selected))throw new Error('واحد خرید از اطلاعات معتبر انتخاب نشده؛ صفحه را تازه کنید.');
  const mode=unitId>0?String(selected.effective_mode||''): 'base';
  const factor=unitId>0&&mode==='fixed'?Number(selected.base_quantity):null;
  if(!['base','fixed','actual_quantity'].includes(mode)||
      (mode==='fixed'&&(!Number.isSafeInteger(factor)||factor<1)))throw new Error('تبدیل واحد خرید معتبر نیست؛ در Local آن را اصلاح کنید.');
  const actual=canonical(form.elements.actual_major_quantity?.value||'');
  if(!groupKey||itemId<1||!Number.isSafeInteger(expected)||expected<1||!['g','ml','count'].includes(unit))throw new Error('اطلاعات خرید قدیمی یا نامعتبر است؛ صفحه را تازه کنید.');
  if(!/^(?:[0-9]+(?:\.[0-9]+)?|\.[0-9]+)$/.test(count)||Number(count)<=0||!Number.isFinite(Number(count))||
     (unit==='count'&&mode==='base'&&!Number.isInteger(Number(count))))throw new Error('مقدار واقعی تحویل معتبر نیست.');
  if(mode==='base'&&unit==='count'&&!Number.isInteger(Number(count)))throw new Error('مقدار عددی باید صحیح باشد.');
  if(mode==='actual_quantity'&&(!/^(?:[0-9]+(?:\.[0-9]+)?|\.[0-9]+)$/.test(actual)||Number(actual)<=0||
      !Number.isFinite(Number(actual))||(unit==='count'&&!Number.isInteger(Number(actual)))))
      throw new Error('مقدار واقعی محتوای بسته معتبر نیست.');
  if(cost!==''&&(!/^[0-9]+$/.test(cost)||!Number.isSafeInteger(Number(cost))))throw new Error('مبلغ کل خرید معتبر نیست.');
  const result={group_key:groupKey,expected_preparing_quantity_base:expected,purchase_unit_id:unitId,
    unit_count:count,total_cost:cost,supplier:String(form.elements.supplier.value||'').trim(),
    note:String(form.elements.note.value||'').trim()};
  if(unitId>0){result.expected_purchase_unit_mode=mode;result.expected_purchase_unit_conversion_base=mode==='fixed'?factor:null;
    if(mode==='actual_quantity')result.actual_major_quantity=actual;}
  return result;
}
function renderSupply(p){
  const inv=Array.isArray(p.inventory_items)?p.inventory_items:[],groups=Array.isArray(p.supply_groups)?p.supply_groups:[];
  out.append(metrics([['نیازهای باز',number(groups.length)],['در حال خرید',number(groups.filter(x=>Number(x.preparing_quantity_base||0)>0).length)],['اقلام قابل انتخاب',number(inv.length)]]));
  const form=supplyForm();if(form){const a=node('div','rs-module-actions');a.append(form);out.append(a)}
  const s=section('نیازهای خرید','وضعیت خرید از آخرین اطلاعات همگام‌شده Local نمایش داده می‌شود.'),P=window.SoknaStaffDataPanels;
  if(P){
    const list=node('div','sc-card-grid');P.renderSupplyCards(list,groups,{actions:g=>{
      const controls=node('div','sc-actions');if(canSupplyManageRemote()){
        if(Number(g.uncommitted_quantity_base||0)>0){const b=node('button','sc-button sc-button--secondary','شروع تهیه');b.type='button';b.dataset.supplyAction='prepare';controls.append(b)}
        if(Number(g.preparing_quantity_base||0)>0){
          for(const [action,label] of [['return','بازگشت به نیاز'],['unavailable','ناموجود']]){
            const b=node('button','sc-button sc-button--secondary',label);b.type='button';b.dataset.supplyAction=action;controls.append(b);
          }
          if(Number(g.item_id||0)>0&&Number(g.inventory_active||0)===1){
            const b=node('button','sc-button sc-button--secondary','ثبت تحویل');b.type='button';b.dataset.supplyAction='receive';controls.append(b);
          }
        }
      }return controls;
    },quantityText:(v,unit)=>`${number(v)} ${text(unit,'')}`});
    for(const group of groups){const card=[...list.querySelectorAll('[data-supply-group]')].find(x=>x.dataset.supplyGroup===String(group.group_key||''));const f=receiptForm(group);if(card&&f)card.querySelector('.sc-card__body')?.append(f)}
    s.append(list);
  }else s.append(empty('نمایش مشترک تأمین آماده نیست.'));
  out.append(s);
  if(canSupplyManageRemote()){
    const note=section('ثبت تحویل','ثبت راه‌دور برای اقلام شناسه‌دار با مقدار واقعی یا واحد خرید تعریف‌شده فعال است. اگر تبدیل واحد هنگام قطع ارتباط تغییر کند، Local ثبت را متوقف و برای بررسی ارجاع می‌دهد. نیازهای متنی هنوز نیازمند بررسی محلی‌اند. ثبت اولیه در صف به معنی افزایش موجودی نیست.');
    note.classList.add('rs-projection-note');out.append(note);
  }
  const pending=node('div','rs-deferred-list');pending.dataset.deferredList='';out.append(pending);
}
function renderDeferred(){out.append(empty('این مدل پشتیبان از مسیرهای «تأمین و خرید» و «مشتریان» استفاده می‌شود.'))}
function renderModel(view,p){out.replaceChildren();out.classList.remove('is-error');if(view==='inventory')renderInventory(p,false);else if(view==='inventory_cost')renderInventory(p,true);else if(view==='supply')renderSupply(p);else if(view==='customers')renderCustomers(p);else if(view==='reports')renderReports(p);else if(view==='notifications')renderNotifications(p);else if(view==='deferred_context')renderDeferred();else out.append(empty('نمایش این بخش تعریف نشده است.'))}
function renderModelError(err){const x=errorInfo(err);if(out.childElementCount>0&&!out.classList.contains('is-error')){let banner=out.querySelector('[data-stale-read-error]');if(!banner){banner=node('div','rs-alert is-stale');banner.dataset.staleReadError='';banner.setAttribute('role','status');out.prepend(banner)}banner.textContent='دریافت تازهٔ اطلاعات انجام نشد؛ محتوای زیر آخرین دادهٔ دریافت‌شده است. '+x.message;return}out.replaceChildren();out.classList.add('is-error');const e=node('div','rs-model-empty');e.append(node('strong','','دریافت اطلاعات انجام نشد'),node('span','',x.message));if(x.code)e.append(node('small','rs-tech-code',`کد فنی: ${x.code}`));out.append(e)}
function hydrate(){const ctx=cache.deferred_context||{};const items=document.querySelector('[data-inventory-items]');if(items){items.replaceChildren();option(items,'','انتخاب قلم');(ctx.inventory_items||[]).forEach(i=>option(items,i.id,`${i.name} · ${i.base_unit}`))}const subs=document.querySelector('[data-subscribers]');if(subs){subs.replaceChildren();option(subs,'','انتخاب مشتری');(ctx.subscribers||[]).forEach(s=>option(subs,s.id,`${s.name} · مانده ${money(s.balance||0)}`))}}
async function load(k,b){const seq=++readLoadSequence;const view=String(b?.dataset.view||k);activeModel=k;activeView=view;readLastAt=Date.now();buttons.forEach(x=>x.setAttribute('aria-current',x===b?'true':'false'));if(title)title.textContent=labels[view]||labels[k]||view;if(view==='operations'&&window.SoknaSharedHall){showSharedModule('hall');try{await window.SoknaSharedHall.refresh()}catch{updateConnectivity(true)}return}if(view==='preparation'&&window.SoknaStaffPreparation){showSharedModule('preparation');try{await window.SoknaStaffPreparation.activate()}catch{updateConnectivity(true)}return}showModuleMode();if(state)state.textContent='در حال دریافت…';try{const j=await readModel(k);if(seq!==readLoadSequence)return;cache[k]=j.payload;readHadError=false;readHadStale=j.stale!==false;updateConnectivity(readHadStale,String(j.last_sync_at||''));renderModel(view,j.payload);hydrate();if(view==='supply'||view==='customers')await refreshDeferred()}catch(e){if(seq!==readLoadSequence)return;readHadError=true;readHadStale=true;if(state)state.textContent='خطا';updateConnectivity(true);renderModelError(e)}}
async function refreshDeferred(){const box=document.querySelector('[data-deferred-list]');if(!box)return;try{const j=await json(u('/api/staff/deferred')+'?limit=12'),items=j.items||[];box.replaceChildren();const h=node('div','rs-deferred-head');h.append(node('h2','','آخرین درخواست‌های در انتظار همگام‌سازی'),node('p','','وضعیت درخواست‌هایی که از این پنل ثبت شده‌اند.'));box.append(h);if(!items.length){box.append(empty('درخواستی در انتظار همگام‌سازی ثبت نشده است.'));return}const list=node('div','rs-deferred-items');for(const x of items){const card=node('article','rs-deferred-item'),top=node('div','rs-deferred-item__top');top.append(node('strong','',deferredKindLabel(x.kind)),node('span','rs-badge',statusLabel(x.state)));card.append(top);const meta=node('div','rs-deferred-item__meta');meta.append(node('span','',`ثبت: ${dateTime(x.occurred_at||x.created_at)}`));if(x.updated_at)meta.append(node('span','',`آخرین تغییر: ${dateTime(x.updated_at)}`));card.append(meta);if(x.error_code)card.append(node('small','rs-tech-code',`کد فنی: ${x.error_code}`));list.append(card)}box.append(list)}catch(e){box.replaceChildren();box.append(empty(errorInfo(e).message))}}

document.addEventListener('submit',async e=>{const form=e.target.closest?.('[data-action]');if(!form)return;e.preventDefault();const kind=form.dataset.action;actionState(form,'در حال ثبت…');try{if(kind==='supply-receipt'){
  if(!canSupplyManageRemote())throw new Error('مجوز ثبت تحویل وجود ندارد.');
  const submit=form.querySelector('[type=submit]');if(submit)submit.disabled=true;
  try{const payload=buildSupplyReceiptPayload(form),r=await durableCommand('deferred','supply.receipt',payload,{prefix:'receipt',deferred:true});
    actionState(form,{message:resultMessage(r,'رسید خرید در Local ثبت شد.'),code:String(r.error_code||'')},resultTone(r.state,r));
    if(String(r.state)==='committed')await load('deferred_context',buttons.find(x=>x.dataset.view==='supply'));
  }finally{if(submit)submit.disabled=false}
}else if(kind==='supply'){const payload={inventory_item_id:Number(form.elements.inventory_item_id.value),quantity_major:String(form.elements.quantity_major.value),department:String(form.elements.department.value),note:String(form.elements.note.value||'')},r=await durableCommand('deferred','supply.need.create',payload,{prefix:'supply',deferred:true});actionState(form,{message:resultMessage(r,'نیاز خرید با موفقیت همگام شد.'),code:String(r.error_code||'')},resultTone(r.state,r));await load('deferred_context',buttons.find(x=>x.dataset.view==='supply'))}if(kind==='subscriber'){const sid=Number(form.elements.subscriber_id.value),sub=(cache.deferred_context?.subscribers||[]).find(x=>Number(x.id)===sid);if(!sub)throw new Error('مشتری معتبر نیست');const amount=Number(form.elements.amount.value);if(!Number.isFinite(amount)||amount<1)throw new Error('مبلغ معتبر نیست');const payload={subscriber_id:sid,amount,expected_balance:Number(sub.balance||0),reference:String(form.elements.reference.value||''),reason:'پرداخت ثبت‌شده از دسترسی راه‌دور'},r=await durableCommand('deferred','subscriber.payment',payload,{prefix:'subpay',deferred:true});actionState(form,{message:resultMessage(r,'پرداخت مشتری با موفقیت همگام شد.'),code:String(r.error_code||'')},resultTone(r.state,r));await load('deferred_context',buttons.find(x=>x.dataset.view==='customers'))}}catch(err){actionState(form,errorInfo(err),'bad')}});
document.addEventListener('click',async e=>{const b=e.target.closest?.('[data-supply-action]');if(!b)return;const card=b.closest('[data-supply-group]');if(!card||!canSupplyManageRemote())return;const groupKey=String(card.dataset.supplyGroup||''),action=String(b.dataset.supplyAction||''),uncommitted=Number(card.dataset.supplyUncommitted||0),preparing=Number(card.dataset.supplyPreparing||0),result=card.querySelector('[data-supply-state]');if(!groupKey)return;if(action==='receive'){
  const receipt=card.querySelector('[data-action="supply-receipt"]');if(!receipt)return;
  receipt.hidden=!receipt.hidden;
  if(!receipt.hidden)receipt.querySelector('[name="unit_count"]')?.focus();return;
}card.querySelectorAll('button').forEach(x=>x.disabled=true);renderActionState(result,'در حال ثبت…');try{let kind='',payload={group_key:groupKey};if(action==='prepare'){kind='supply.status.prepare';payload.expected_quantity_base=uncommitted}else if(action==='return'||action==='unavailable'){kind='supply.status.return';payload.outcome=action==='unavailable'?'unavailable':'returned';payload.expected_preparing_quantity_base=preparing}else return;const r=await durableCommand('deferred',kind,payload,{prefix:'supply',deferred:true});renderActionState(result,{message:resultMessage(r,'وضعیت خرید با موفقیت همگام شد.'),code:String(r.error_code||'')},resultTone(r.state,r));await load('deferred_context',buttons.find(x=>x.dataset.view==='supply'))}catch(err){renderActionState(result,errorInfo(err),'bad')}finally{card.querySelectorAll('button').forEach(x=>x.disabled=false)}});

// PWA install, Service Worker binding and Push lifecycle are owned exclusively by public-device.js.
document.addEventListener('sokna:staff-read-meta',e=>{const d=e.detail||{};updateConnectivity(!!d.stale,String(d.last_sync_at||''))});
buttons.forEach(b=>b.addEventListener('click',e=>{e.preventDefault?.();readFormDirty=false;load(b.dataset.model,b)}));
document.querySelectorAll('[data-staff-home]').forEach(b=>b.addEventListener('click',()=>{++readLoadSequence;activeModel='';readFormDirty=false;showDashboardMode();document.querySelector('.rs-page-header')?.scrollIntoView({behavior:'smooth',block:'start'})}));
document.querySelectorAll('[data-staff-order]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();window.SoknaSharedHall?.openOrder?.(0)}));
// Read-only recovery; never replay a deferred/financial mutation and do not erase an edited form.
out.addEventListener('input',()=>{readFormDirty=true},true);
out.addEventListener('change',e=>{if(e.target.closest?.('form'))readFormDirty=true},true);
function recoverActiveRead(){
 if(!activeModel||document.hidden||readFormDirty)return;
 if((activeView==='operations'&&window.SoknaSharedHall)||(activeView==='preparation'&&window.SoknaStaffPreparation))return;
 const a=document.activeElement;
 if(a&&out.contains(a)&&a.matches?.('input,textarea,select,[contenteditable="true"]'))return;
 if(Date.now()-readLastAt<(readHadError||readHadStale?12000:35000))return;
 const b=buttons.find(x=>x.dataset.model===activeModel&&String(x.dataset.view||x.dataset.model)===activeView);
 if(b)void load(activeModel,b);
}
window.setInterval(recoverActiveRead,12000);
window.addEventListener('online',recoverActiveRead);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)recoverActiveRead()});
updatePwaControls();showDashboardMode();
})();
