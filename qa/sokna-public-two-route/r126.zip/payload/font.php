<?php
declare(strict_types=1);
if(function_exists('header_remove')) header_remove('X-Powered-By');
$root=__DIR__;
require_once $root.'/src/Core/PublicSurfacePermissions.php';
require_once $root.'/src/Core/PublicFontRuntime.php';
\Sokna\PublicEdge\Core\PublicSurfacePermissions::repair($root);
use Sokna\PublicEdge\Core\PublicFontRuntime;

if(strtolower(trim((string)($_GET['family']??'vazirmatn'))) !== 'vazirmatn'){
    http_response_code(404);header('Cache-Control: no-store, max-age=0');header('X-Content-Type-Options: nosniff');exit;
}
$path=PublicFontRuntime::fontPath($root);
if(!PublicFontRuntime::valid($path) && !PublicFontRuntime::ensure($root)){
    http_response_code(503);header('Cache-Control: no-store, max-age=0');header('X-Content-Type-Options: nosniff');header('Retry-After: 300');exit;
}
$etag='"'.hash_file('sha256',$path).'"';
if(trim((string)($_SERVER['HTTP_IF_NONE_MATCH']??''))===$etag){
    http_response_code(304);header('ETag: '.$etag);header('Cache-Control: public, max-age=31536000, immutable');exit;
}
header('Content-Type: font/woff2');
header('Content-Length: '.(string)filesize($path));
header('Cache-Control: public, max-age=31536000, immutable');
header('ETag: '.$etag);
header('X-Content-Type-Options: nosniff');
readfile($path);
