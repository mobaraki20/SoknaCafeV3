<?php
declare(strict_types=1);
// This file is a reference only. Browser Setup creates config.php automatically.
return ['db'=>['host'=>'127.0.0.1','port'=>'3306','name'=>'sokna_public','charset'=>'utf8mb4','user'=>'','pass'=>''],'app'=>['default_installation_id'=>'','cookie_secure'=>true,'storage_dir'=>__DIR__.'/storage','base_path'=>'','base_url'=>''],'relay'=>['installation_secrets'=>[],'clock_skew_seconds'=>300,'secret_encryption_key_base64'=>''],'auth'=>['session_ttl_seconds'=>28800,'failure_limit'=>5,'failure_window_seconds'=>900,'block_seconds'=>900]];
