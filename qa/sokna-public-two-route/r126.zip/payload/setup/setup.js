(()=>{
const $=s=>document.querySelector(s),msg=$('[data-msg]');let csrf='',routingProbeOk=false;
const db=()=>Object.fromEntries([...document.querySelectorAll('[data-db]')].map(x=>[x.dataset.db,x.value]));
const show=(t,e=false)=>{msg.hidden=false;msg.textContent=t;msg.classList.toggle('error',e)};
async function api(action,body=null){const o={cache:'no-store',headers:{'Content-Type':'application/json'}};if(body){o.method='POST';o.body=JSON.stringify({...body,csrf})}const r=await fetch('api.php?action='+encodeURIComponent(action),o),j=await r.json();if(!r.ok||j.success===false)throw new Error(j.message||'عملیات کامل نشد.');return j}
async function routeProbe(){try{const r=await fetch('../__sokna_route_probe__?v='+Date.now(),{cache:'no-store'});routingProbeOk=r.status===204&&r.headers.get('X-Sokna-Route-Probe')==='ok'}catch{routingProbeOk=false}return routingProbeOk}
function checks(p){
  const box=$('[data-checks]');box.textContent='';
  const rows=[...(p.checks||[]),{label:'مسیریابی وب (Rewrite)',current:routingProbeOk?'HTTP 204 / probe OK':'probe failed',ok:routingProbeOk}];
  for(const x of rows){const row=document.createElement('div'),info=document.createElement('span'),label=document.createElement('span'),current=document.createElement('small'),state=document.createElement('strong');label.textContent=x.label||x.id||'Check';current.textContent=x.current?String(x.current):'';info.className='check-info';info.append(label,current);state.className=x.ok?'ok':'bad';state.textContent=x.ok?'آماده':'نیاز به بررسی';row.append(info,state);box.append(row)}
  $('[data-detected-base]').textContent=p.base_path||'/';
  $('[data-detected-url]').textContent=p.base_url||location.origin;
}
async function refresh(){const j=await api('status');csrf=j.csrf;await routeProbe();checks(j.preflight);return j}
async function init(){try{const j=await refresh();if(!routingProbeOk)show('Setup باز است، اما Rewrite/مسیریابی هاست برای اجرای Public Edge آماده نیست. تنظیمات .htaccess / AllowOverride / Rewrite را بررسی کن.',true);if(j.setup.installed&&!j.setup.paired){$('[data-pair-card]').hidden=false;$('[data-rotate-wrap]').hidden=false;$('[data-base-url]').value=j.preflight.base_url||location.origin;show('Public Edge نصب شده و آماده اتصال به Local Web است. اگر کد قبلی را نداری، یک کد جدید بساز.')}}catch(e){show(e.message,true)}}
$('[data-preflight]').onclick=async()=>{try{await routeProbe();const j=await api('preflight',{storage_dir:$('[data-storage]').value});checks(j.preflight);show(j.preflight.ok&&routingProbeOk?'پیش‌نیازها آماده‌اند.':'بعضی پیش‌نیازها نیاز به بررسی دارند.',!(j.preflight.ok&&routingProbeOk))}catch(e){show(e.message,true)}};
$('[data-test-db]').onclick=async()=>{try{await api('test_database',{db:db(),create_database:$('[data-create-db]').checked});show('اتصال دیتابیس موفق بود.')}catch(e){show(e.message,true)}};
$('[data-rotate-pair]').onclick=async()=>{try{const j=await api('rotate_pairing',{emergency_password:$('[data-rotate-pass]').value});$('[data-pair-card]').hidden=false;$('[data-pairing-code]').textContent=j.pairing_code;$('[data-base-url]').value=j.base_url;show('کد اتصال جدید ساخته شد.')}catch(e){show(e.message,true)}};
$('[data-install]').onclick=async()=>{try{await routeProbe();if(!routingProbeOk)throw new Error('Rewrite/مسیریابی وب آماده نیست؛ نصب برای جلوگیری از یک استقرار ناقص متوقف شد.');const j=await api('install',{storage_dir:$('[data-storage]').value,db:db(),create_database:$('[data-create-db]').checked,emergency_password:$('[data-emergency]').value,routing_probe_ok:true});$('[data-pair-card]').hidden=false;$('[data-pairing-code]').textContent=j.pairing_code;$('[data-base-url]').value=j.base_url;show('نصب کامل شد؛ حالا اتصال را از Local Web انجام بده.');$('[data-rotate-wrap]').hidden=false}catch(e){show(e.message,true)}};
init();
})();
