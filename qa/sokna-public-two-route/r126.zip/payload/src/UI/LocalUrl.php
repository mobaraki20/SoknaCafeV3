<?php
declare(strict_types=1);

namespace Sokna\Local\UI;

/** Public host adapter for the canonical Local ProductShell URL contract. */
final class LocalUrl
{
    private static string $basePath='';

    public static function configure(string $basePath): void
    {
        $base='/' . trim(str_replace('\\','/',$basePath),'/');
        self::$basePath=$base==='/'?'':rtrim($base,'/');
    }

    public static function basePath(): string{return self::$basePath;}
    public static function baseHref(): string{return self::$basePath===''?'/':self::$basePath.'/';}
    public static function path(string $path): string
    {
        $path=trim($path);
        if($path===''||$path[0]==='#'||preg_match('#^(?:https?:)?//#i',$path)===1||preg_match('#^(?:mailto|tel|data):#i',$path)===1)return $path;
        if($path[0]!=='/')$path='/'.$path;
        if(self::$basePath!==''&&($path===self::$basePath||str_starts_with($path,self::$basePath.'/')))return $path;
        return self::$basePath.$path;
    }
}
