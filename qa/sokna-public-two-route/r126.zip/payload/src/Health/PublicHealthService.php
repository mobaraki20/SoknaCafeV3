<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Health;
use PDO;use Sokna\PublicEdge\Core\SafeErrors;use Sokna\PublicEdge\Deployment\DeploymentIdentity;use Throwable;
final class PublicHealthService
{
    public function __construct(private readonly PDO $pdo,private readonly string $componentRoot='',private readonly string $storageRoot='',private readonly ?DeploymentIdentity $deploymentIdentity=null){}
    public function status(?string $correlationId=null): array
    {
        try{
            $probe=$this->pdo->query('SELECT 1')->fetchColumn();if((int)$probe!==1)return SafeErrors::response(503,'public_unavailable',$correlationId);
            $count=(int)$this->pdo->query('SELECT COUNT(*) FROM schema_migrations')->fetchColumn();$catalog=$this->migrationCatalogCount();$pending=max(0,$catalog-$count);$version=$this->version();$legacy=$this->state('emergency/update/state.json');$routine=$this->state('routine-update-v2/state.json');
            return ['status'=>200,'body'=>[
                'ok'=>true,'component'=>'public-edge','database'=>'ready','applied_migrations'=>$count,'catalog_migrations'=>$catalog,'pending_migrations'=>$pending,'version'=>$version,
                'emergency_ready'=>$this->componentRoot!==''&&is_file($this->componentRoot.'/emergency.php'),
                'update'=>['active_version'=>(string)($legacy['active_version']??$version),'previous_version'=>(string)($legacy['previous_version']??''),'staged_version'=>(string)(($legacy['staged']??[])['version']??''),'lkg_ready'=>(string)($legacy['lkg_recovery_id']??'')!==''],
                'routine_update'=>['protocol'=>2,'active_version'=>(string)($routine['active_version']??$version),'previous_version'=>(string)($routine['previous_version']??''),'staged_version'=>(string)(($routine['staged']??[])['version']??''),'pending_version'=>(string)(($routine['pending_verification']??[])['version']??''),'pending_verification'=>is_array($routine['pending_verification']??null),'lkg_ready'=>(string)($routine['lkg_recovery_id']??'')!==''],
                'update_protocol'=>2,'transport_protocol'=>2,'transport_capabilities'=>['realtime_exchange_v2','read_model_v2','per_model_ack','legacy_v1_compat'],'deployment'=>$this->deploymentIdentity?->snapshot()??['contract'=>'sokna-deployment-binding-v1','configured'=>false],'correlation_id'=>SafeErrors::correlationId($correlationId)
            ]];
        }catch(Throwable){
            $safe=SafeErrors::response(503,'public_unavailable',$correlationId);$safe['body']['component']='public-edge';$safe['body']['database']='unavailable';$safe['body']['version']=$this->version();$safe['body']['emergency_ready']=$this->componentRoot!==''&&is_file($this->componentRoot.'/emergency.php');$safe['body']['update_protocol']=2;return $safe;
        }
    }

    private function migrationCatalogCount(): int
    {
        if($this->componentRoot==='')return 0;$dir=$this->componentRoot.'/database/migrations';if(!is_dir($dir))return 0;$count=0;
        foreach(scandir($dir)?:[] as $name)if(preg_match('/^\d{4}_[a-z0-9_]+\.sql$/D',$name))$count++;
        return $count;
    }
    private function version(): string{$p=$this->componentRoot!==''?$this->componentRoot.'/VERSION.txt':'';$v=$p!==''?@file_get_contents($p):false;return is_string($v)&&trim($v)!==''?trim($v):'unknown';}
    private function state(string $relative): array{$p=$this->storageRoot!==''?rtrim($this->storageRoot,"\\/").'/'.$relative:'';if($p===''||!is_file($p))return [];try{$v=json_decode((string)file_get_contents($p),true,32,JSON_THROW_ON_ERROR);return is_array($v)?$v:[];}catch(Throwable){return [];}}
}
