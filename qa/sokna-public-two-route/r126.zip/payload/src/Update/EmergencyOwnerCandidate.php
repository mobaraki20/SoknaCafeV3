<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Emergency;
use Throwable;
use ZipArchive;

final class PublicUpdateService
{
    private const FORMAT='sokna-component-package-v1';
    private const STATE_FORMAT='sokna-public-update-state-v1';
    private const MAX_FILES=12000;
    private const MAX_EXPANDED=536870912;
    private const STABLE_PREFIXES=['emergency.php','src/Emergency/','resources/update-trust-v1.json','recovery.php','src/Recovery/'];
    /** @var null|callable */ private $health;
    /** @var null|callable: trusted host-supplied DB mutation evidence; NOT a user package field. */
    private $dbBoundaryProof;
    public function __construct(private readonly string $componentRoot,private readonly string $storageRoot,private readonly string $trustFile,?callable $health=null,?callable $dbBoundaryProof=null){$this->health=$health;$this->dbBoundaryProof=$dbBoundaryProof;}
    public function snapshot(): array{$s=$this->state();return ['current_version'=>$this->currentVersion(),'active_version'=>(string)($s['active_version']??$this->currentVersion()),'previous_version'=>(string)($s['previous_version']??''),'lkg_recovery_id'=>(string)($s['lkg_recovery_id']??''),'staged'=>$s['staged']??null,'recovery_required'=>$s['recovery_required']??null,'db_proof_provider_configured'=>is_callable($this->dbBoundaryProof),'history'=>array_slice(array_reverse((array)($s['history']??[])),0,30),'stable_entrypoint'=>'/emergency.php','signature_policy'=>'not_required_for_operator_upload'];}
    public function stageUploadedZip(string $zipPath,string $actor='emergency'): array{$meta=$this->verifyZip($zipPath);$m=$meta['manifest'];$version=(string)$m['version'];$hash=hash_file('sha256',$zipPath);$target=$this->root().'/staged/'.$version;if(is_dir($target)){$x=$this->readJson($target.'/package.json');if(($x['package_sha256']??'')!==$hash)throw new PublicUpdateException('immutable_version_conflict','This version is already staged with different bytes.',409);}else{$tmp=$target.'.staging-'.bin2hex(random_bytes(4));$this->removeTree($tmp);$this->mkdir($tmp.'/payload');$this->extractPayload($zipPath,$tmp.'/payload',(array)$m['files']);copy($zipPath,$tmp.'/package.zip');$this->writeJson($tmp.'/manifest.json',$m);$this->writeJson($tmp.'/package.json',['package_sha256'=>$hash,'signature_status'=>$meta['signature_status'],'staged_at'=>gmdate('c')]);$this->verifyDirectory($tmp.'/payload',(array)$m['files']);if(!@rename($tmp,$target)){ $this->removeTree($tmp);throw new PublicUpdateException('stage_failed','Public stage failed.',500);}}$s=$this->state();$s['staged']=['version'=>$version,'package_sha256'=>$hash,'source_commit'=>(string)($m['source_commit']??''),'signature_status'=>$meta['signature_status'],'staged_at'=>gmdate('c')];$this->event($s,'stage',$version,$actor,['package_sha256'=>$hash]);$this->save($s);return $s['staged'];}
    public function activateStaged(string $actor='emergency'): array
    {
        return $this->withSharedLifecycleLock(function() use ($actor) {

        $s=$this->state();$this->assertNoUnresolvedRecovery($s);
        $version=(string)(($s['staged']??[])['version']??'');
        if($version==='')throw new PublicUpdateException('nothing_staged','No Public package is staged.',409);
        if($version===$this->currentVersion())throw new PublicUpdateException('same_version_requires_repair','Use Repair for the active version.',409);
        $dir=$this->root().'/staged/'.$version;$m=$this->readJson($dir.'/manifest.json');
        $this->verifyDirectory($dir.'/payload',(array)($m['files']??[]));
        $this->assertDestinationCompatible($m);
        // A verified host-controlled mutation cursor is mandatory before ANY live file mutation.
        $before=$this->readDbSafetyEvidence();
        $recovery=$this->createRecoveryPoint('before_activate_'.$version,$actor,$before);
        $old=$this->currentVersion();
        try{
            $this->deployPayload($dir.'/payload');$this->healthCheck();$this->assertTargetManagedTree($m);
        }catch(Throwable $e){
            $this->autoRecoverOrFence($s,$recovery,$version,$actor,$e);
            throw new PublicUpdateException('activation_failed','Public activation failed and pre-DB code was restored.',500);
        }
        $s=$this->state();$s['previous_version']=$old;$s['active_version']=$version;
        $s['lkg_recovery_id']=$recovery['id'];$s['staged']=null;
        $this->event($s,'activate',$version,$actor,['previous'=>$old,'recovery_id'=>$recovery['id']]);
        $this->save($s);return $this->snapshot();
    
        });
    }

    public function repairStaged(string $actor='emergency'): array
    {
        return $this->withSharedLifecycleLock(function() use ($actor) {

        $s=$this->state();$this->assertNoUnresolvedRecovery($s);
        $version=(string)(($s['staged']??[])['version']??'');
        if($version===''||$version!==$this->currentVersion())
            throw new PublicUpdateException('repair_requires_same_version','Repair requires a staged package matching the active version.',409);
        $dir=$this->root().'/staged/'.$version;$m=$this->readJson($dir.'/manifest.json');
        $this->verifyDirectory($dir.'/payload',(array)($m['files']??[]));
        $before=$this->readDbSafetyEvidence();
        $recovery=$this->createRecoveryPoint('before_repair_'.$version,$actor,$before);
        try{$this->deployPayload($dir.'/payload');$this->healthCheck();$this->assertTargetManagedTree($m);}
        catch(Throwable $e){
            $this->autoRecoverOrFence($s,$recovery,$version,$actor,$e);
            throw new PublicUpdateException('repair_failed','Public repair failed and pre-DB code was restored.',500);
        }
        $s=$this->state();$s['staged']=null;$s['lkg_recovery_id']=$recovery['id'];
        $this->event($s,'repair',$version,$actor,['recovery_id'=>$recovery['id']]);
        $this->save($s);return $this->snapshot();
    
        });
    }

    public function rollback(string $actor='emergency'): array
    {
        return $this->withSharedLifecycleLock(function() use ($actor) {

        $s=$this->state();$this->assertNoUnresolvedRecovery($s);
        $id=(string)($s['lkg_recovery_id']??'');
        if($id==='')throw new PublicUpdateException('no_recovery_point','No LKG recovery point exists.',409);
        $this->assertRecoveryDbStillCompatible($id);
        $from=$this->currentVersion();$m=$this->restoreRecoveryPoint($id);$to=(string)($m['version']??'unknown');
        $s=$this->state();$s['active_version']=$to;$s['previous_version']=$from;
        $this->event($s,'rollback',$to,$actor,['from'=>$from,'recovery_id'=>$id]);
        $this->save($s);return $this->snapshot();
    
        });
    }

    /** Fail closed unless an independently wired DB owner proves no forward write occurred. */
    private function readDbSafetyEvidence(): array
    {
        $routine=$this->readJson(rtrim($this->storageRoot,"\\/").'/routine-update-v2/state.json');
        if(is_array($routine['db_forward_fence']??null))
            throw new PublicUpdateException('db_forward_rollback_forbidden','Routine Public has crossed the DB-forward boundary.',409);
        if(is_array($routine['activation_journal']??null)||is_array($routine['pending_verification']??null))
            throw new PublicUpdateException('routine_activation_in_progress','Routine Public update is active; Emergency cannot mutate the same live tree.',409);
        if(!is_callable($this->dbBoundaryProof))
            throw new PublicUpdateException('db_boundary_proof_unavailable','Independent Public database mutation proof is not configured; do not alter the live tree.',503);
        $p=($this->dbBoundaryProof)();
        if(!is_array($p)||($p['authoritative']??null)!==true||($p['covers_all_db_mutations']??null)!==true||($p['forward_only']??null)!==false||
           !is_string($p['db_identity']??null)||!preg_match('/^[a-zA-Z0-9._:-]{8,128}$/D',$p['db_identity'])||
           !is_string($p['schema_sha256']??null)||!preg_match('/^[a-f0-9]{64}$/D',$p['schema_sha256'])||
           !is_string($p['migration_head']??null)||$p['migration_head']===''||
           !is_int($p['mutation_epoch']??null)||$p['mutation_epoch']<0)
            throw new PublicUpdateException('db_boundary_proof_invalid','DB mutation evidence is missing, stale, or not authoritative.',503);
        return array_intersect_key($p,array_flip(['db_identity','schema_sha256','migration_head','mutation_epoch']));
    }

    private function assertRecoveryDbStillCompatible(string $id): void
    {
        $recovery=$this->readJson($this->root().'/recovery-points/'.$id.'/manifest.json');
        $old=$recovery['db_guard']??null;
        if(!is_array($old)||count($old)!==4)
            throw new PublicUpdateException('db_recovery_proof_missing','Recovery point has no verified pre-mutation DB identity.',409);
        $now=$this->readDbSafetyEvidence();
        if($old!==$now)
            throw new PublicUpdateException('db_forward_rollback_forbidden','Database identity, schema, migration head, or mutation epoch changed.',409);
    }

    private function assertNoUnresolvedRecovery(array $state): void
    {
        if(is_array($state['recovery_required']??null))
            throw new PublicUpdateException('recovery_required','An incomplete Public activation must be resolved with forward-safe recovery.',409);
    }

    private function autoRecoverOrFence(array $state,array $recovery,string $version,string $actor,Throwable $cause): void
    {
        try{
            $this->assertRecoveryDbStillCompatible((string)$recovery['id']);
            $this->restoreRecoveryPoint((string)$recovery['id']);
        }catch(Throwable $err){
            $state=$this->state();
            $state['recovery_required']=[
                'version'=>$version,'recovery_id'=>(string)$recovery['id'],
                'reason'=>$err instanceof PublicUpdateException?$err->errorCode:'unverified_restore_failure',
                'original_error'=>$cause instanceof PublicUpdateException?$cause->errorCode:'activation_exception',
                'policy'=>'forward_recovery_only','recorded_at'=>gmdate('c')
            ];
            $this->event($state,'forward_recovery_required',$version,$actor,['recovery_id'=>(string)$recovery['id']]);
            $this->save($state);
            throw new PublicUpdateException('forward_recovery_required','Cannot safely restore previous code after uncertain database mutation; forward recovery is required.',409,['recovery_id'=>(string)$recovery['id']]);
        }
        $state=$this->state();$this->event($state,'rollback_auto',$version,$actor,['error'=>'activation_health_failed']);$this->save($state);
    }
    /** One OS lock for the existing Routine and Emergency live-tree mutation paths. */
    private function withSharedLifecycleLock(callable $work): mixed
    {
        $path=rtrim($this->storageRoot,"\\/").'/public-update-lifecycle.lock';
        $this->mkdir(dirname($path));
        $fh=@fopen($path,'c+');
        if(!is_resource($fh))throw new PublicUpdateException('shared_update_lock_unavailable','Public updater coordination lock cannot be opened.',503);
        try{
            if(!@flock($fh,LOCK_EX|LOCK_NB))throw new PublicUpdateException('shared_update_busy','Another Public update is changing the installation.',409);
            return $work();
        }finally{@flock($fh,LOCK_UN);@fclose($fh);}
    }

    public function incomingDir(): string{$p=$this->root().'/incoming';$this->mkdir($p);return $p;}
    public function currentVersion(): string{$f=@file_get_contents($this->componentRoot.'/VERSION.txt');return is_string($f)&&trim($f)!==''?trim($f):'unknown';}
    private function verifyZip(string $path): array{if(!class_exists(ZipArchive::class))throw new PublicUpdateException('zip_unavailable','PHP ZipArchive is unavailable.',500);if(!is_file($path))throw new PublicUpdateException('package_missing','Update package is missing.',404);$z=new ZipArchive();if($z->open($path)!==true)throw new PublicUpdateException('invalid_zip','Invalid ZIP package.');try{$raw=$z->getFromName('manifest.json');if(!is_string($raw))throw new PublicUpdateException('manifest_missing','manifest.json is required.');$m=json_decode($raw,true,64,JSON_THROW_ON_ERROR);if(!is_array($m)||($m['format']??'')!==self::FORMAT||(int)($m['schema_version']??0)!==1||(string)($m['component']??'')!=='public-edge')throw new PublicUpdateException('manifest_contract','Public update manifest is invalid.');$version=trim((string)($m['version']??''));if(!preg_match('/^[0-9A-Za-z][0-9A-Za-z._+-]{0,63}$/',$version))throw new PublicUpdateException('invalid_version','Package version is invalid.');$files=(array)($m['files']??[]);if($files===[]||count($files)>self::MAX_FILES)throw new PublicUpdateException('invalid_file_count','Package file count is invalid.');$expected=[];$expanded=0;foreach($files as $e){$rel=$this->safeRelative((string)($e['path']??''));$size=(int)($e['size']??-1);$hash=strtolower((string)($e['sha256']??''));$this->assertNotStable($rel,$hash,$size);if($size<0||!preg_match('/^[a-f0-9]{64}$/',$hash)||isset($expected[$rel]))throw new PublicUpdateException('manifest_contract','Package file record is invalid.');$expected[$rel]=[$size,$hash];$expanded+=$size;if($expanded>self::MAX_EXPANDED)throw new PublicUpdateException('package_too_large','Expanded package exceeds limit.',413);} $actual=[];for($i=0;$i<$z->numFiles;$i++){$n=(string)$z->getNameIndex($i);if($n==='manifest.json'||$n==='signature.json')continue;if(str_ends_with($n,'/'))continue;if(!str_starts_with($n,'payload/'))throw new PublicUpdateException('unexpected_entry','Unexpected ZIP entry.');$rel=$this->safeRelative(substr($n,8));if(isset($actual[$rel]))throw new PublicUpdateException('duplicate_entry','Duplicate ZIP path.');$actual[$rel]=true;if(!isset($expected[$rel]))throw new PublicUpdateException('unexpected_entry','ZIP entry is not declared.');[$size,$hash]=$expected[$rel];$stream=$z->getStream($n);if(!is_resource($stream))throw new PublicUpdateException('read_failed','ZIP entry could not be read.',500);$ctx=hash_init('sha256');$read=0;while(!feof($stream)){$buf=fread($stream,1048576);if($buf===false)break;$read+=strlen($buf);hash_update($ctx,$buf);}fclose($stream);if($read!==$size||!hash_equals($hash,hash_final($ctx)))throw new PublicUpdateException('hash_mismatch','Package file hash mismatch.');}if(count($actual)!==count($expected))throw new PublicUpdateException('payload_set_mismatch','Package payload set is incomplete.');$contracts=(array)($m['contracts']??[]);if((int)($contracts['local_public_contract']??0)!==1)throw new PublicUpdateException('incompatible_contract','Local/Public contract is incompatible.',409); $this->assertDestinationCompatible($m);return ['manifest'=>$m,'signature_status'=>$this->verifySignature($z,$raw)];}catch(PublicUpdateException $e){throw $e;}catch(Throwable){throw new PublicUpdateException('package_invalid','Public update package is invalid.');}finally{$z->close();}}
    private function verifySignature(ZipArchive $z,string $manifestRaw): string
    {
        // Canonical policy: no package publisher key, trust enrollment or signature.
        // Authentication/CSRF/authorization belongs to the Emergency UI/controller.
        if($z->locateName('signature.json')!==false)
            throw new PublicUpdateException('publisher_signature_not_allowed','Signed publisher package is not part of the keyless operator-upload contract.',422);
        return 'operator_selected_hash_verified';
    }

    private static function releaseRank(string $v): array
    {
        if(!preg_match('/(?:^|-)workspace\.([0-9]{1,8})([a-z]{1,5})(?:-|$)/D',$v,$m))
            throw new PublicUpdateException('version_order_unknown','Cannot safely compare Public versions.',409);
        $n=0;foreach(str_split($m[2]) as $ch)$n=$n*26+ord($ch)-96;
        return [(int)$m[1],$n];
    }

    private function managedTreeDigest(): string
    {
        $h=hash_init('sha256');$map=[];
        foreach($this->hashTree($this->componentRoot) as $e){
            $rel=(string)$e['path'];
            if(($this->stable($rel)&&!$this->isRecoveryOwner($rel))||$this->runtimeExcluded($rel)
                ||in_array($rel,['README.md','manifest.json'],true)
                ||str_starts_with($rel,'Q3_P1_')||str_starts_with($rel,'tools/'))continue;
            $map[$rel]=(string)$e['sha256'];
        }
        ksort($map,SORT_STRING);
        foreach($map as $name=>$sha){hash_update($h,$name);hash_update($h,"\0");hash_update($h,$sha);hash_update($h,"\n");}
        return hash_final($h);
    }

    private function assertDestinationCompatible(array $m): void
    {
        $current=$this->currentVersion();$target=(string)($m['version']??'');
        if(self::releaseRank($target)<=self::releaseRank($current))
            throw new PublicUpdateException('downgrade_or_reinstall_forbidden','Public Emergency cannot install an older or equal release.',409);
        $compat=$m['compatibility']??null;
        if(!is_array($compat))
            throw new PublicUpdateException('unverified_baseline','Missing verified Public baseline constraints.',409);
        $tree=$this->managedTreeDigest();
        if(array_key_exists('supported_baselines',$compat)){
            if(isset($compat['from_version'])||isset($compat['from_managed_tree_sha256']))
                throw new PublicUpdateException('mixed_baseline_contract','Legacy and multi-baseline contracts cannot coexist.',422);
            $bases=$compat['supported_baselines'];
            if(!is_array($bases)||!array_is_list($bases)||count($bases)<1||count($bases)>64)
                throw new PublicUpdateException('invalid_baselines','Invalid exact compatible Public baselines.',422);
            $matched=false;$seen=[];
            foreach($bases as $b){
                if(!is_array($b)||!is_string($b['version']??null)||!is_string($b['managed_tree_sha256']??null)||
                   !preg_match('/^[a-f0-9]{64}$/D',$b['managed_tree_sha256']))
                    throw new PublicUpdateException('invalid_baselines','Baseline identity invalid.',422);
                if(self::releaseRank($target)<=self::releaseRank($b['version']))
                    throw new PublicUpdateException('invalid_baseline_order','Target must be newer than every declared baseline.',422);
                $id=$b['version']."\0".$b['managed_tree_sha256'];
                if(isset($seen[$id]))throw new PublicUpdateException('duplicate_baseline','Duplicate exact Public baseline.',422);
                $seen[$id]=true;
                if(hash_equals($current,$b['version'])&&hash_equals($tree,$b['managed_tree_sha256']))$matched=true;
            }
            if(!$matched)throw new PublicUpdateException('baseline_not_supported','Installed Public version/tree is outside exact compatible baselines.',409);
            return;
        }
        // Explicit exact-base compatibility retained ONLY to diagnose/bridge old sources;
        // such packages are never qualified as canonical universal releases.
        if(!is_string($compat['from_version']??null)||!is_string($compat['from_managed_tree_sha256']??null)
           ||!hash_equals($current,$compat['from_version'])
           ||!hash_equals($tree,$compat['from_managed_tree_sha256']))
           throw new PublicUpdateException('baseline_mismatch','Installed Public version/tree differs from the exact bridge baseline.',409);
    }

    private function assertTargetManagedTree(array $manifest): void{
     $want=strtolower((string)($manifest['target_managed_tree_sha256']??''));
     $actual=$this->managedTreeDigest();
     if(!preg_match('/^[a-f0-9]{64}$/D',$want)||!hash_equals($want,$actual))
         throw new PublicUpdateException('target_tree_mismatch','Public Emergency installed tree differs from the target manifest.',500,['expected'=>$want,'actual'=>$actual]);
 }
 private function extractPayload(string $zipPath,string $target,array $files): void{$z=new ZipArchive();$z->open($zipPath);try{foreach($files as $e){$rel=$this->safeRelative((string)$e['path']);$dst=$target.'/'.$rel;$this->mkdir(dirname($dst));$in=$z->getStream('payload/'.$rel);$out=fopen($dst,'wb');if(!is_resource($in)||!is_resource($out))throw new PublicUpdateException('extract_failed','Package extraction failed.',500);stream_copy_to_stream($in,$out);fclose($in);fclose($out);}}finally{$z->close();}}
    private function createRecoveryPoint(string $reason,string $actor,array $dbGuard): array{$id=gmdate('Ymd-His').'-'.bin2hex(random_bytes(4));$dir=$this->root().'/recovery-points/'.$id;$this->copyMutableTree($this->componentRoot,$dir.'/payload');$files=$this->hashTree($dir.'/payload');$m=['format'=>'sokna-public-recovery-point-v1','id'=>$id,'version'=>$this->currentVersion(),'created_at'=>gmdate('c'),'reason'=>$reason,'actor_hint'=>$actor,'db_guard'=>$dbGuard,'files'=>$files];$this->writeJson($dir.'/manifest.json',$m);return $m;}
    private function restoreRecoveryPoint(string $id): array{if(!preg_match('/^[0-9]{8}-[0-9]{6}-[a-f0-9]{8}$/',$id))throw new PublicUpdateException('invalid_recovery_id','Recovery id is invalid.');$dir=$this->root().'/recovery-points/'.$id;$m=$this->readJson($dir.'/manifest.json');if(($m['format']??'')!=='sokna-public-recovery-point-v1')throw new PublicUpdateException('recovery_missing','Recovery point is invalid.',404);$this->verifyDirectory($dir.'/payload',(array)$m['files']);$this->deployPayload($dir.'/payload');$this->healthCheck();return $m;}
    private function deployPayload(string $source): void{$this->removeMutableFiles($this->componentRoot);$this->copyTree($source,$this->componentRoot,false);}
    private function healthCheck(): void{foreach(['bootstrap.php','index.php','emergency.php','setup/index.php','setup/api.php'] as $rel)if(!is_file($this->componentRoot.'/'.$rel))throw new PublicUpdateException('health_failed','Critical Public file is missing.',500,['file'=>$rel]);if(is_callable($this->health)){$ok=(bool)($this->health)();if(!$ok)throw new PublicUpdateException('health_failed','Public health callback failed.',500);} }
    private function copyMutableTree(string $src,string $dst): void{$this->removeTree($dst);$this->mkdir($dst);$it=new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($src,\FilesystemIterator::SKIP_DOTS),\RecursiveIteratorIterator::SELF_FIRST);foreach($it as $f){$rel=str_replace('\\','/',substr($f->getPathname(),strlen($src)+1));if($this->stable($rel)||$this->runtimeExcluded($rel))continue;$to=$dst.'/'.$rel;if($f->isDir())$this->mkdir($to);elseif($f->isFile()){ $this->mkdir(dirname($to));if(!copy($f->getPathname(),$to))throw new PublicUpdateException('copy_failed','Recovery copy failed.',500);}}}
    private function removeMutableFiles(string $root): void{$it=new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root,\FilesystemIterator::SKIP_DOTS),\RecursiveIteratorIterator::CHILD_FIRST);foreach($it as $f){$rel=str_replace('\\','/',substr($f->getPathname(),strlen($root)+1));if($this->stable($rel)||$this->runtimeExcluded($rel))continue;if($f->isFile()||$f->isLink())@unlink($f->getPathname());elseif($f->isDir())@rmdir($f->getPathname());}}
    private function runtimeExcluded(string $rel): bool{return in_array($rel,['config.php','install.lock'],true)||str_starts_with($rel,'storage/');}
    private function stable(string $rel): bool{foreach(self::STABLE_PREFIXES as $p)if($rel===$p||str_ends_with($p,'/')&&str_starts_with($rel,$p))return true;return false;}
    private function isRecoveryOwner(string $rel): bool{return $rel==='recovery.php'||str_starts_with($rel,'src/Recovery/');}
 private function assertNotStable(string $rel,string $sha,int $size): void{
     if($this->isRecoveryOwner($rel)){
         $existing=$this->componentRoot.'/'.$rel;
         if(!is_file($existing)||$size<0||(int)filesize($existing)!==$size||!hash_equals($sha,(string)hash_file('sha256',$existing)))
             throw new PublicUpdateException('immutable_recovery_mismatch','The unchanged stable Recovery owner is required on disk.',409,['path'=>$rel]);
         return;
     }
     if($this->stable($rel)||$this->runtimeExcluded($rel))
         throw new PublicUpdateException('stable_path_forbidden','Update may not modify stable/runtime files.',422,['path'=>$rel]);
 }
    private function verifyDirectory(string $root,array $files): void{$expected=[];foreach($files as $e){$rel=$this->safeRelative((string)$e['path']);$expected[$rel]=true;$p=$root.'/'.$rel;if(!is_file($p)||(int)filesize($p)!==(int)$e['size']||!hash_equals(strtolower((string)$e['sha256']),strtolower((string)hash_file('sha256',$p))))throw new PublicUpdateException('staged_integrity_failed','Staged file integrity failed.',422,['file'=>$rel]);}$actual=[];if(is_dir($root)){$it=new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root,\FilesystemIterator::SKIP_DOTS));foreach($it as $f)if($f->isFile())$actual[str_replace('\\','/',substr($f->getPathname(),strlen($root)+1))]=true;}if(count($actual)!==count($expected)||array_diff_key($actual,$expected)||array_diff_key($expected,$actual))throw new PublicUpdateException('payload_set_mismatch','Staged file set changed.',422);}
    private function hashTree(string $root): array{$out=[];if(!is_dir($root))return $out;$it=new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root,\FilesystemIterator::SKIP_DOTS));foreach($it as $f)if($f->isFile()){$rel=str_replace('\\','/',substr($f->getPathname(),strlen($root)+1));$out[]=['path'=>$rel,'size'=>$f->getSize(),'sha256'=>hash_file('sha256',$f->getPathname())];}usort($out,fn($a,$b)=>strcmp($a['path'],$b['path']));return $out;}
    private function copyTree(string $src,string $dst,bool $clear=true): void{if($clear)$this->removeTree($dst);$this->mkdirPublic($dst);$it=new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($src,\FilesystemIterator::SKIP_DOTS),\RecursiveIteratorIterator::SELF_FIRST);foreach($it as $f){$rel=substr($f->getPathname(),strlen($src)+1);if($this->stable(str_replace('\\','/',$rel)))continue;$to=$dst.'/'.$rel;if($f->isDir())$this->mkdirPublic($to);elseif($f->isFile()){ $this->mkdirPublic(dirname($to));if(!copy($f->getPathname(),$to))throw new PublicUpdateException('copy_failed','Lifecycle copy failed.',500);@chmod($to,0644);}}}
    private function mkdirPublic(string $p): void{if(!is_dir($p)&&!@mkdir($p,0755,true)&&!is_dir($p))throw new PublicUpdateException('deploy_unavailable','Public deployment directory is unavailable.',500);@chmod($p,0755);}
    private function removeTree(string $p): void{if(!file_exists($p))return;if(is_file($p)||is_link($p)){@unlink($p);return;}$it=new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($p,\FilesystemIterator::SKIP_DOTS),\RecursiveIteratorIterator::CHILD_FIRST);foreach($it as $f){$f->isDir()?@rmdir($f->getPathname()):@unlink($f->getPathname());}@rmdir($p);}
    private function state(): array{$s=$this->readJson($this->root().'/state.json');if(($s['format']??'')!==self::STATE_FORMAT)$s=['format'=>self::STATE_FORMAT,'schema_version'=>1,'active_version'=>$this->currentVersion(),'previous_version'=>'','lkg_recovery_id'=>'','staged'=>null,'recovery_required'=>null,'history'=>[]];return $s;}
    private function save(array $s): void{$this->writeJson($this->root().'/state.json',$s);}
    private function event(array &$s,string $action,string $version,string $actor,array $extra=[]): void{$s['history'][]=['at'=>gmdate('c'),'action'=>$action,'version'=>$version,'actor_hint'=>substr($actor,0,120),'result'=>'success']+$extra;$s['history']=array_slice($s['history'],-100);}
    private function root(): string{$p=rtrim($this->storageRoot,"\\/").'/emergency/update';$this->mkdir($p);return $p;}
    private function trust(): array{return $this->readJson($this->trustFile);}
    private function readJson(string $p): array{$raw=@file_get_contents($p);if(!is_string($raw)||$raw==='')return [];try{$v=json_decode($raw,true,64,JSON_THROW_ON_ERROR);return is_array($v)?$v:[];}catch(Throwable){return [];}}
    private function writeJson(string $p,array $v): void{$this->mkdir(dirname($p));$tmp=$p.'.tmp-'.bin2hex(random_bytes(4));if(file_put_contents($tmp,json_encode($v,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)."\n",LOCK_EX)===false||!@rename($tmp,$p)){@unlink($tmp);throw new PublicUpdateException('state_write_failed','Lifecycle state write failed.',500);}@chmod($p,0600);}
    private function safeRelative(string $r): string{$r=str_replace('\\','/',trim($r));if($r===''||str_starts_with($r,'/')||preg_match('#(^|/)\.\.(/|$)#',$r)||str_contains($r,"\0"))throw new PublicUpdateException('unsafe_path','Unsafe package path.');return $r;}
    private function mkdir(string $p): void{if(!is_dir($p)&&!@mkdir($p,0700,true)&&!is_dir($p))throw new PublicUpdateException('storage_unavailable','Lifecycle storage is unavailable.',500);}
}
