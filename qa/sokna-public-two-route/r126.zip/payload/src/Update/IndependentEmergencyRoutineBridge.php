<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Update;

use Sokna\PublicEdge\Emergency\PublicUpdateException;
use Throwable;

/**
 * Independent Emergency HTTP controller adapter for the EXISTING Routine v2
 * state machine. No separate ZIP, DB migration engine, recovery ledger or
 * filesystem writer is introduced. The protected five-file Emergency owner
 * and the historical Emergency state stay untouched.
 *
 * This adapter is only safe behind Emergency password + CSRF + HTTPS controls.
 */
final class IndependentEmergencyRoutineBridge
{
    /** @param callable():list<string> $pendingMigrations
     *  @param callable():array<string,mixed> $freshHealthReadback
     */
    public function __construct(
        private readonly RoutinePublicUpdateService $routine,
        private readonly string $storageRoot,
        private readonly mixed $pendingMigrations,
        private readonly mixed $freshHealthReadback,
    ) {
        if (!is_callable($pendingMigrations) || !is_callable($freshHealthReadback)) {
            throw new PublicUpdateException('emergency_forward_provider_missing',
                'Routine and database verification providers are required.', 503);
        }
    }

    public function snapshot(): array
    {
        $snapshot = $this->routine->snapshot();
        $snapshot['channel'] = 'emergency_independent_routine_v2';
        $snapshot['historical_emergency_active_version'] = $snapshot['emergency_active_version'] ?? '';
        $snapshot['forward_only_protected'] = is_array($snapshot['db_forward_fence'] ?? null);
        return $snapshot;
    }

    /** Stage the SAME immutable operator ZIP used by Local -> Public. */
    public function stageUploadedZip(string $path, string $actor='emergency'): array
    {
        $this->requireUnambiguousRoutineState(false);
        return $this->routine->stageUploadedDeltaZip($path, 'emergency:'.$actor, true);
    }

    /** Code-only activation; commit MUST be a distinct authenticated POST. */
    public function activateStaged(string $actor='emergency'): array
    {
        $this->requireUnambiguousRoutineState(true);
        $this->requireNoPendingMigration();
        $this->requireCodeOnlyStagedChange();
        $snapshot=$this->routine->activateStaged('emergency:'.$actor);
        if(!is_array($snapshot['pending_verification']??null))
            throw new PublicUpdateException('emergency_activation_not_pending',
                'Target was not left in verifiable state.', 503);
        return $snapshot;
    }

    /** In a LATER authenticated request, validate actual target and DB before Commit. */
    public function commitPending(string $actor='emergency'): array
    {
        $snapshot=$this->routine->snapshot();
        $p=$snapshot['pending_verification']??null;
        if(!is_array($p) || !is_string($p['version']??null) || $p['version']==='')
            throw new PublicUpdateException('nothing_pending',
                'No independently verifiable Routine activation is pending.', 409);
        if(!hash_equals((string)$p['version'],(string)$snapshot['current_version']) ||
           !hash_equals((string)($p['target_tree_sha256']??''),
               (string)($snapshot['managed_tree_sha256']??'')))
            throw new PublicUpdateException('post_activate_identity_mismatch',
                'Target code and exact managed-tree readback differ.',409);
        $this->requireNoPendingMigration();
        $health=($this->freshHealthReadback)();
        if(!is_array($health) || ($health['ok']??null)!==true ||
           ($health['database']??null)!=='ready' ||
           ($health['emergency_ready']??null)!==true ||
           ($health['pending_migrations']??null)!==0 ||
           !is_string($health['version']??null) ||
           !hash_equals((string)$p['version'],$health['version']))
            throw new PublicUpdateException('emergency_target_health_not_qualified',
                'Fresh target Public health, identity and migration readback are required.',503);
        return $this->routine->commitActivation('emergency:'.$actor);
    }

    /** Prior historical DB forward fence can NEVER authorize old-code rollback. */
    public function rollback(string $actor='emergency'): never
    {
        throw new PublicUpdateException('emergency_rollback_not_qualified',
            'Emergency never restores old code under an unresolved DB boundary.',409);
    }

    public function repairStaged(string $actor='emergency'): never
    {
        throw new PublicUpdateException('emergency_repair_not_qualified',
            'Independent same-version Emergency repair requires separate verification.',409);
    }

    private function requireUnambiguousRoutineState(bool $requireStaged): void
    {
        $s=$this->routine->snapshot();
        if(is_array($s['pending_verification']??null) ||
           is_array($s['activation_journal']??null) ||
           ($s['emergency_state_reconciliation_pending']??false)===true)
            throw new PublicUpdateException('routine_activation_in_progress',
                'An unresolved Routine or external Emergency operation must finish first.',409);
        if(($s['managed_tree_matches_expected']??null)!==true ||
           !hash_equals((string)($s['current_version']??''),
               (string)($s['active_version']??'')))
            throw new PublicUpdateException('routine_owner_not_reconciled',
                'Installed Public code and authoritative Routine ledger differ.',409);
        if($requireStaged&&!is_array($s['staged']??null))
            throw new PublicUpdateException('nothing_staged','No staged Routine package.',409);
    }

    private function requireNoPendingMigration(): void
    {
        try {$pending=($this->pendingMigrations)();}
        catch(Throwable) {
            throw new PublicUpdateException('migration_preflight_unavailable',
                'The Public migration inventory is not available.',503);
        }
        if(!is_array($pending) || !array_is_list($pending) || $pending!==[])
            throw new PublicUpdateException('db_forward_recovery_required',
                'Independent Emergency update cannot cross a pending DB boundary.',409);
    }

    private function requireCodeOnlyStagedChange(): void
    {
        $staged=$this->routine->snapshot()['staged']??null;
        $version=(string)($staged['version']??'');
        $digest=(string)($staged['package_sha256']??'');
        if(!is_array($staged) || !preg_match('/^[A-Za-z0-9._+-]{1,128}$/D',$version) ||
           !preg_match('/^[a-f0-9]{64}$/D',$digest))
            throw new PublicUpdateException('staged_package_identity_invalid',
                'Cannot attest exact staged package identity.',409);
        $path=rtrim($this->storageRoot,'/\\').'/routine-update-v2/staged/'.$version.'/'.$digest.'/manifest.json';
        if(!is_file($path) || !is_readable($path))
            throw new PublicUpdateException('staged_package_missing','Routine stage manifest missing.',409);
        try{$raw=file_get_contents($path);$manifest=is_string($raw)?json_decode($raw,true,64,JSON_THROW_ON_ERROR):null;}
        catch(Throwable){$manifest=null;}
        if(!is_array($manifest) || ($manifest['format']??null)!=='sokna-public-delta-v2' ||
           ($manifest['version']??null)!==$version ||
           !is_array($manifest['files']??null) || !is_array($manifest['deletes']??null))
            throw new PublicUpdateException('staged_manifest_unverified',
                'Routine stage manifest cannot be independently verified.',409);
        foreach(array_merge($manifest['files'],$manifest['deletes']) as $entry){
            $relative=is_array($entry)?($entry['path']??null):$entry;
            if(!is_string($relative) || $relative==='' || str_starts_with($relative,'database/migrations/'))
                throw new PublicUpdateException('emergency_schema_mutation_not_qualified',
                    'Independent Emergency is limited to code-only releases.',409);
        }
    }
}
