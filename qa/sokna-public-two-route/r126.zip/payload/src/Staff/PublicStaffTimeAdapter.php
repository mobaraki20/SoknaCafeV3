<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Staff;
use DateTimeImmutable;use DateTimeZone;use Throwable;
final class PublicStaffTimeAdapter
{
    public function __construct(private readonly string $timezoneName='Asia/Tehran'){}
    public function timezone(): string{return 'Asia/Tehran';}
    public function nowUtcIso(): string{return (new DateTimeImmutable('now',new DateTimeZone('UTC')))->format(DATE_ATOM);}
}
