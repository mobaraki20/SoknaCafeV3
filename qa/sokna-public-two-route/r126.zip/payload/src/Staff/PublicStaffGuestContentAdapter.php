<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Staff;
final class PublicStaffGuestContentAdapter
{
    public function brandIdentity(string $scope='draft'): array{return ['version'=>'public-projection'];}
}
