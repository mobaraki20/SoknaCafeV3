<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Staff;
final class PublicStaffAuthAdapter
{
    public function hasCapability(string $capability,array $user): bool
    {
        $caps=array_map('strval',(array)($user['capabilities']??[]));
        return in_array('*',$caps,true)||in_array($capability,$caps,true);
    }
}
