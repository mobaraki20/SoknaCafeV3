<?php
declare(strict_types=1);

namespace Sokna\PublicEdge\Core;

final class PublicFontRuntime
{
    private const MIN_BYTES = 80000;
    private const MAX_BYTES = 180000;
    private const RETRY_SECONDS = 21600;
    private const VERSION = '33.003';
    private const SHA256 = '4e3fa217d38fdafc1fea4414ceb58ca5e662cf0ab5fa735a8c8c20e8b42cad92';
    private const URLS = [
        'https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/fonts/webfonts/Vazirmatn%5Bwght%5D.woff2',
        'https://raw.githubusercontent.com/rastikerdar/vazirmatn/v33.003/fonts/webfonts/Vazirmatn%5Bwght%5D.woff2',
    ];

    public static function version(): string { return self::VERSION; }
    public static function expectedSha256(): string { return self::SHA256; }

    public static function storageRoot(string $componentRoot): string
    {
        $componentRoot = rtrim($componentRoot, "\\/");
        $configPath = trim((string)(getenv('SOKNA_PUBLIC_CONFIG') ?: ($componentRoot . '/config.php')));
        if (is_file($configPath) && is_readable($configPath)) {
            try {
                $cfg = require $configPath;
                if (is_array($cfg)) {
                    $candidate = trim((string)($cfg['app']['storage_dir'] ?? ''));
                    if ($candidate !== '') return rtrim(str_replace('\\','/',$candidate), '/');
                }
            } catch (\Throwable) {
            }
        }
        return $componentRoot . '/storage';
    }

    public static function fontPath(string $componentRoot): string
    {
        return self::storageRoot($componentRoot) . '/ui-fonts/Vazirmatn-Variable.woff2';
    }

    public static function statusPath(string $componentRoot): string
    {
        return dirname(self::fontPath($componentRoot)) . '/font-install-status.json';
    }

    public static function valid(string $path): bool
    {
        if (!is_file($path)) return false;
        $size = @filesize($path);
        if (!is_int($size) || $size < self::MIN_BYTES || $size > self::MAX_BYTES) return false;
        $handle = @fopen($path, 'rb');
        if ($handle === false) return false;
        $magic = fread($handle, 4);
        fclose($handle);
        if ($magic !== 'wOF2') return false;
        $hash = @hash_file('sha256', $path);
        return is_string($hash) && hash_equals(self::SHA256, $hash);
    }

    public static function ready(string $componentRoot): bool
    {
        return self::valid(self::fontPath($componentRoot));
    }

    public static function installUploaded(string $componentRoot, string $uploadedPath): bool
    {
        if (!self::valid($uploadedPath)) return false;
        $target = self::fontPath($componentRoot);
        $dir = dirname($target);
        if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) return false;
        @chmod($dir, 0700);
        $temp = $target . '.upload-' . bin2hex(random_bytes(5));
        if (!@copy($uploadedPath, $temp) || !self::valid($temp)) { @unlink($temp); return false; }
        if (is_file($target)) @unlink($target);
        if (!@rename($temp, $target)) { @unlink($temp); return false; }
        @chmod($target, 0600);
        @file_put_contents(self::statusPath($componentRoot), json_encode([
            'ok'=>true,'checked_at'=>gmdate('c'),'source'=>'verified-upload','font'=>'Vazirmatn','version'=>self::VERSION,'sha256'=>self::SHA256,
        ], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT), LOCK_EX);
        @chmod(self::statusPath($componentRoot),0600);
        return true;
    }

    public static function ensure(string $componentRoot, bool $force = false): bool
    {
        $target = self::fontPath($componentRoot);
        if (self::valid($target)) return true;

        $dir = dirname($target);
        $status = self::statusPath($componentRoot);
        if (!$force && is_file($status) && (time() - (int)@filemtime($status)) < self::RETRY_SECONDS) return false;
        if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) return false;
        @chmod($dir, 0700);

        $ok = false;
        $source = '';
        foreach (self::URLS as $url) {
            $data = self::fetch($url);
            if ($data === false) continue;
            $temp = $target . '.tmp-' . bin2hex(random_bytes(5));
            $written = @file_put_contents($temp, $data, LOCK_EX);
            if ($written === strlen($data) && self::valid($temp)) {
                if (is_file($target)) @unlink($target);
                if (@rename($temp, $target)) {
                    @chmod($target, 0600);
                    $ok = true;
                    $source = $url;
                    break;
                }
            }
            @unlink($temp);
        }

        @file_put_contents($status, json_encode([
            'ok' => $ok,
            'checked_at' => gmdate('c'),
            'source' => $source === '' ? 'unavailable' : $source,
            'font' => 'Vazirmatn',
            'version' => self::VERSION,
            'sha256' => self::SHA256,
        ], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT), LOCK_EX);
        @chmod($status, 0600);
        return $ok;
    }

    private static function fetch(string $url): string|false
    {
        $context = stream_context_create([
            'http' => [
                'timeout' => 3,
                'follow_location' => 1,
                'max_redirects' => 3,
                'user_agent' => 'SOKNA Public Edge font runtime',
            ],
            'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
        ]);
        $data = @file_get_contents($url, false, $context);
        if (!is_string($data) && function_exists('curl_init')) {
            $ch = curl_init($url);
            if ($ch !== false) {
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_MAXREDIRS => 3,
                    CURLOPT_CONNECTTIMEOUT => 3,
                    CURLOPT_TIMEOUT => 5,
                    CURLOPT_USERAGENT => 'SOKNA Public Edge font runtime',
                    CURLOPT_SSL_VERIFYPEER => true,
                    CURLOPT_SSL_VERIFYHOST => 2,
                ]);
                $raw = curl_exec($ch);
                $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
                curl_close($ch);
                if (is_string($raw) && $code >= 200 && $code < 300) $data = $raw;
            }
        }
        if (!is_string($data)) return false;
        $size = strlen($data);
        if ($size < self::MIN_BYTES || $size > self::MAX_BYTES || substr($data,0,4) !== 'wOF2') return false;
        return hash_equals(self::SHA256, hash('sha256',$data)) ? $data : false;
    }
}
