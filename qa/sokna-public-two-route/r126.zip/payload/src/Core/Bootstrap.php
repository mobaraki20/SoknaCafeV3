<?php
declare(strict_types=1);

namespace Sokna\PublicEdge\Core;

use PDO;
use Sokna\PublicEdge\Auth\AuthProjectionService;
use Sokna\PublicEdge\Auth\AuthSecurityAudit;
use Sokna\PublicEdge\Auth\AuthThrottle;
use Sokna\PublicEdge\Auth\PublicLoginService;
use Sokna\PublicEdge\Auth\PublicSessionStore;
use Sokna\PublicEdge\Auth\UserUiPreferenceService;
use Sokna\PublicEdge\Connectivity\ConnectivityService;
use Sokna\PublicEdge\Deferred\DeferredService;
use Sokna\PublicEdge\Guest\GuestAvailabilityService;
use Sokna\PublicEdge\Guest\GuestCompatibilityService;
use Sokna\PublicEdge\Guest\GuestMediaStore;
use Sokna\PublicEdge\Guest\GuestPageRenderer;
use Sokna\PublicEdge\Guest\GuestPublishService;
use Sokna\PublicEdge\Guest\GuestRuntimeService;
use Sokna\PublicEdge\Guest\GuestThemeCssService;
use Sokna\PublicEdge\Health\PublicHealthService;
use Sokna\PublicEdge\Realtime\RealtimeService;
use Sokna\PublicEdge\Remote\RemoteReadModelService;
use Sokna\PublicEdge\Remote\InstallationProjectionService;
use Sokna\PublicEdge\Remote\RemoteStaffPageRenderer;
use Sokna\PublicEdge\Staff\PublicStaffAuthAdapter;
use Sokna\PublicEdge\Staff\PublicStaffTimeAdapter;
use Sokna\PublicEdge\Staff\PublicStaffGuestContentAdapter;
use Sokna\PublicEdge\Security\SignedLocalRequestVerifier;
use Sokna\PublicEdge\Emergency\EmergencyAccessService;
use Sokna\PublicEdge\Emergency\PublicUpdateService;
use Sokna\PublicEdge\Update\RoutinePublicUpdateService;
use Sokna\PublicEdge\Emergency\PairingSecretStore;
use Sokna\PublicEdge\Emergency\PublicTakeoverService;
use Sokna\PublicEdge\Authority\AuthorityEpochService;
use Sokna\PublicEdge\Deployment\DeploymentIdentity;
use Sokna\PublicEdge\Deployment\PwaIdentity;
use Sokna\PublicEdge\Deployment\DeploymentRebindService;

final class Bootstrap
{
    private ?PDO $database = null;
    private ?Migrations $migrations = null;
    private ?AuthProjectionService $authProjectionService = null;
    private ?AuthThrottle $authThrottle = null;
    private ?AuthSecurityAudit $authSecurityAudit = null;
    private ?PublicSessionStore $publicSessions = null;
    private ?UserUiPreferenceService $uiPreferenceService = null;
    private ?PublicLoginService $publicLoginService = null;
    private ?SignedLocalRequestVerifier $signedLocalRequestVerifier = null;
    private ?ConnectivityService $connectivityService = null;
    private ?RealtimeService $realtimeService = null;
    private ?DeferredService $deferredService = null;
    private ?PublicHealthService $healthService = null;
    private ?GuestMediaStore $guestMediaStore = null;
    private ?GuestPublishService $guestPublishService = null;
    private ?GuestAvailabilityService $guestAvailabilityService = null;
    private ?GuestRuntimeService $guestRuntimeService = null;
    private ?GuestThemeCssService $guestThemeCssService = null;
    private ?GuestCompatibilityService $guestCompatibilityService = null;
    private ?GuestPageRenderer $guestPageRenderer = null;
    private ?RemoteReadModelService $remoteReadModelService = null;
    private ?InstallationProjectionService $installationProjectionService = null;
    private ?RemoteStaffPageRenderer $remoteStaffPageRenderer = null;
    private ?PublicStaffAuthAdapter $staffAuthAdapter = null;
    private ?PublicStaffTimeAdapter $staffTimeAdapter = null;
    private ?PublicStaffGuestContentAdapter $staffGuestContentAdapter = null;
    private ?EmergencyAccessService $emergencyAccessService = null;
    private ?PublicUpdateService $publicUpdateService = null;
    private ?RoutinePublicUpdateService $routinePublicUpdateService = null;
    private ?PairingSecretStore $pairingSecretStore = null;
    private ?PublicTakeoverService $publicTakeoverService = null;
    private ?AuthorityEpochService $authorityEpochService = null;
    private ?DeploymentIdentity $deploymentIdentity = null;
    private ?PwaIdentity $pwaIdentity = null;
    private ?DeploymentRebindService $deploymentRebindService = null;

    private function __construct(private readonly Config $config)
    {
    }

    public static function fromArray(array $values): self
    {
        date_default_timezone_set('UTC'); // Public infrastructure SQL is UTC; UI explicitly projects Tehran.
        return new self(Config::fromArray($values));
    }

    public function config(): Config
    {
        return $this->config;
    }

    public function deploymentIdentity(): DeploymentIdentity
    {
        return $this->deploymentIdentity ??= new DeploymentIdentity($this->config);
    }

    public function pwaIdentity(): PwaIdentity
    {
        return $this->pwaIdentity ??= new PwaIdentity(dirname(__DIR__,2));
    }

    public function deploymentRebind(): DeploymentRebindService
    {
        return $this->deploymentRebindService ??= new DeploymentRebindService(dirname(__DIR__,2),$this->storageRoot(),$this->deploymentIdentity(),$this->pairingSecrets());
    }

    public function database(): PDO
    {
        return $this->database ??= Database::connect($this->config);
    }

    public function migrations(): Migrations
    {
        $directory = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'database' . DIRECTORY_SEPARATOR . 'migrations';
        return $this->migrations ??= new Migrations($this->database(), $directory);
    }

    public function authProjections(): AuthProjectionService
    {
        return $this->authProjectionService ??= new AuthProjectionService($this->database());
    }

    public function authThrottle(): AuthThrottle
    {
        return $this->authThrottle ??= new AuthThrottle(
            $this->database(),
            max(2, (int)$this->config->get('auth.failure_limit', 5)),
            max(60, (int)$this->config->get('auth.failure_window_seconds', 900)),
            max(60, (int)$this->config->get('auth.block_seconds', 900)),
        );
    }

    public function authAudit(): AuthSecurityAudit
    {
        return $this->authSecurityAudit ??= new AuthSecurityAudit($this->database());
    }

    public function uiPreferences(): UserUiPreferenceService
    {
        return $this->uiPreferenceService ??= new UserUiPreferenceService($this->database());
    }

    public function publicSessions(): PublicSessionStore
    {
        return $this->publicSessions ??= new PublicSessionStore(
            $this->database(),
            max(900, (int)$this->config->get('auth.session_ttl_seconds', 28800)),
        );
    }

    public function loginService(): PublicLoginService
    {
        return $this->publicLoginService ??= new PublicLoginService(
            $this->database(),
            $this->authThrottle(),
            $this->publicSessions(),
            $this->authAudit(),
        );
    }

    public function signedLocalRequests(): SignedLocalRequestVerifier
    {
        $secrets = $this->config->get('relay.installation_secrets', []);
        if (!is_array($secrets)) $secrets = [];
        return $this->signedLocalRequestVerifier ??= new SignedLocalRequestVerifier(
            $this->database(),
            $secrets,
            max(30, (int)$this->config->get('relay.clock_skew_seconds', 300)),
            $this->config->string('relay.secret_encryption_key_base64'),
        );
    }

    public function connectivity(): ConnectivityService
    {
        return $this->connectivityService ??= new ConnectivityService($this->database());
    }

    public function realtime(): RealtimeService
    {
        return $this->realtimeService ??= new RealtimeService($this->database(), $this->connectivity(), $this->remoteReadModels());
    }

    public function deferred(): DeferredService
    {
        return $this->deferredService ??= new DeferredService($this->database());
    }

    public function health(): PublicHealthService
    {
        return $this->healthService ??= new PublicHealthService($this->database(),dirname(__DIR__,2),$this->storageRoot(),$this->deploymentIdentity());
    }

    public function guestMedia(): GuestMediaStore
    {
        $storage = trim($this->config->string('app.storage_dir'));
        if ($storage === '') $storage = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'storage';
        return $this->guestMediaStore ??= new GuestMediaStore($storage);
    }

    public function guestPublish(): GuestPublishService
    {
        return $this->guestPublishService ??= new GuestPublishService($this->database(), $this->guestMedia());
    }

    public function guestAvailability(): GuestAvailabilityService
    {
        return $this->guestAvailabilityService ??= new GuestAvailabilityService($this->database());
    }

    public function guestRuntime(): GuestRuntimeService
    {
        return $this->guestRuntimeService ??= new GuestRuntimeService($this->database());
    }

    public function guestThemeCss(): GuestThemeCssService
    {
        return $this->guestThemeCssService ??= new GuestThemeCssService($this->guestRuntime());
    }

    public function guestCompatibility(): GuestCompatibilityService
    {
        return $this->guestCompatibilityService ??= new GuestCompatibilityService(
            $this->guestRuntime(),
            $this->realtime(),
            $this->remoteReadModels(),
        );
    }

    public function guestRenderer(): GuestPageRenderer
    {
        return $this->guestPageRenderer ??= new GuestPageRenderer($this->guestRuntime(),$this->deploymentIdentity()->basePath());
    }

    public function remoteReadModels(): RemoteReadModelService
    {
        return $this->remoteReadModelService ??= new RemoteReadModelService(
            $this->database(),
            $this->connectivity(),
        );
    }

    public function installationProjection(): InstallationProjectionService
    {
        return $this->installationProjectionService ??= new InstallationProjectionService($this->database());
    }

    public function auth(): PublicStaffAuthAdapter
    {
        return $this->staffAuthAdapter ??= new PublicStaffAuthAdapter();
    }

    public function time(): PublicStaffTimeAdapter
    {
        $timezone='Asia/Tehran';
        return $this->staffTimeAdapter ??= new PublicStaffTimeAdapter($timezone!==''?$timezone:'Asia/Tehran');
    }

    public function guestContent(): PublicStaffGuestContentAdapter
    {
        return $this->staffGuestContentAdapter ??= new PublicStaffGuestContentAdapter();
    }

    public function emergencyAccess(): EmergencyAccessService
    {
        return $this->emergencyAccessService ??= new EmergencyAccessService($this->storageRoot());
    }

    public function publicUpdates(): PublicUpdateService
    {
        return $this->publicUpdateService ??= new PublicUpdateService(dirname(__DIR__,2),$this->storageRoot(),dirname(__DIR__,2).'/resources/update-trust-v1.json',function():bool{try{return (int)$this->database()->query('SELECT 1')->fetchColumn()===1;}catch(\Throwable){return false;}});
    }

    public function routinePublicUpdates(): RoutinePublicUpdateService
    {
        return $this->routinePublicUpdateService ??= new RoutinePublicUpdateService(dirname(__DIR__,2),$this->storageRoot(),dirname(__DIR__,2).'/resources/update-trust-v1.json',function():bool{try{return (int)$this->database()->query('SELECT 1')->fetchColumn()===1;}catch(\Throwable){return false;}},fn():array=>$this->migrations()->migrate(),null,fn():array=>$this->migrations()->pendingVersions());
    }

    public function pairingSecrets(): PairingSecretStore
    {
        return $this->pairingSecretStore ??= new PairingSecretStore($this->database(),$this->config->requiredString('relay.secret_encryption_key_base64'));
    }

    public function takeover(): PublicTakeoverService
    {
        return $this->publicTakeoverService ??= new PublicTakeoverService($this->database(),$this->pairingSecrets(),$this->emergencyAccess());
    }

    public function authorityEpoch(): AuthorityEpochService
    {
        return $this->authorityEpochService ??= new AuthorityEpochService($this->database(),$this->pairingSecrets(),$this->emergencyAccess());
    }

    private function storageRoot(): string
    {
        $storage=trim($this->config->string('app.storage_dir'));return $storage!==''?$storage:dirname(__DIR__,2).'/storage';
    }

    public function remoteStaffRenderer(): RemoteStaffPageRenderer
    {
        return $this->remoteStaffPageRenderer ??= new RemoteStaffPageRenderer($this,$this->deploymentIdentity()->basePath());
    }
}
