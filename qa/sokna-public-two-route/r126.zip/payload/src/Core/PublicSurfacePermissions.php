<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Core;

final class PublicSurfacePermissions
{
    /**
     * Repair only web-visible mutable directories/files. Runtime/config/storage
     * remain untouched and retain their private permissions.
     */
    public static function repair(string $componentRoot): array
    {
        $root=rtrim($componentRoot,"\\/");
        $dirs=['assets','assets/brand','assets/scds','assets/staff-app','setup'];
        $files=[
            'assets/favicon.ico','assets/favicon-16.png','assets/favicon-32.png','assets/favicon-180.png','assets/favicon-192.png',
            'assets/brand/Sokna-AppIcon-256.png','assets/brand/Sokna-AppIcon-512.png','assets/brand/Sokna-AppIcon-Maskable-192.png','assets/brand/Sokna-AppIcon-Maskable-512.png',
            'assets/scds/guest.css','assets/scds/guest.js','assets/scds/remote-staff.css','assets/scds/remote-staff.js','assets/scds/staff-sw.js','assets/staff-app/public-device.js','assets/staff-app/offline-bootstrap.js',
            'setup/index.php','setup/api.php','setup/setup.css','setup/setup.js','font.php',
        ];
        $changed=[];$errors=[];
        foreach($dirs as $rel){$p=$root.'/'.$rel;if(!is_dir($p))continue;$mode=fileperms($p)&0777;if($mode!==0755){if(@chmod($p,0755))$changed[]=$rel;else $errors[]=$rel;}}
        foreach($files as $rel){$p=$root.'/'.$rel;if(!is_file($p))continue;$mode=fileperms($p)&0777;if($mode!==0644){if(@chmod($p,0644))$changed[]=$rel;else $errors[]=$rel;}}
        return ['ok'=>$errors===[],'changed'=>$changed,'errors'=>$errors];
    }
}
