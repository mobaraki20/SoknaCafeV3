<?php
declare(strict_types=1);

namespace Sokna\PublicEdge\Recovery;

use RuntimeException;
use Throwable;

/**
 * Stable, DB-independent recovery owner for the Public Edge routine updater.
 *
 * This class deliberately does not depend on Bootstrap, Database, the normal
 * front controller, or src/Emergency/PublicUpdateService.php. It is installed
 * once and future routine deltas are forbidden from replacing it.
 */
final class StableRecoveryService
{
    private const ROUTINE_STATE_FORMAT='sokna-public-routine-update-state-v2';
    private const ROUTINE_RECOVERY_V2='sokna-public-routine-recovery-v2';
    private const ROUTINE_RECOVERY_V3='sokna-public-routine-recovery-v3-differential';
    private const EMERGENCY_RECOVERY_V1='sokna-public-recovery-point-v1';
    private const OLD_STABLE_PREFIXES=['emergency.php','src/Emergency/','resources/update-trust-v1.json'];
    private const RECOVERY_OWNER_PREFIXES=['recovery.php','src/Recovery/'];

    public function __construct(
        private readonly string $componentRoot,
        private readonly string $storageRoot,
    ){}

    public function snapshot(): array
    {
        $state=$this->readJson($this->routineRoot().'/state.json');
        $journal=is_array($state['activation_journal']??null)?$state['activation_journal']:null;
        $pending=is_array($state['pending_verification']??null)?$state['pending_verification']:null;
        return [
            'format'=>'sokna-stable-recovery-snapshot-v1',
            'generated_at'=>gmdate('c'),
            'current_version'=>$this->currentVersion(),
            'routine_state'=>$this->redactState($state),
            'maintenance_locked'=>is_file($this->maintenanceLockPath()),
            'maintenance'=>$this->redactState($this->readJson($this->maintenanceLockPath())),
            'activation_journal'=>$this->redactState($journal??[]),
            'pending_verification'=>$this->redactState($pending??[]),
            'recommended_recovery_id'=>$this->recommendedRecoveryId($state),
            'recoveries'=>$this->recoveryCatalog(),
            'critical_files'=>$this->criticalFiles(),
        ];
    }

    public function diagnostics(): array
    {
        $snap=$this->snapshot();
        $snap['storage_root']=$this->storageRoot;
        $snap['component_root']=$this->componentRoot;
        $snap['php_version']=PHP_VERSION;
        $snap['sapi']=PHP_SAPI;
        $snap['free_space_bytes']=@disk_free_space($this->storageRoot)?:null;
        return $snap;
    }

    /** @return array<string,mixed> */
    public function recover(string $selector='',string $actor='stable-recovery'): array
    {
        [$owner,$id]=$this->resolveRecoverySelector($selector);
        $from=$this->currentVersion();
        $this->writeJson($this->maintenanceLockPath(),[
            'format'=>'sokna-public-update-lock-v2','version'=>'recovery','actor_hint'=>substr($actor,0,120),'started_at'=>gmdate('c'),'owner'=>'stable-recovery-v1'
        ]);
        try{
            $manifest=$owner==='routine'?$this->restoreRoutine($id):$this->restoreEmergencyV1($id);
            $to=trim((string)($manifest['version']??$this->currentVersion()));
            $this->healthCheck();
            $this->reconcileRoutineState($to,$from,$owner.':'.$id);
            $this->clearMaintenance();
            $this->appendAudit('stable_recovery_success',['owner'=>$owner,'recovery_id'=>$id,'from'=>$from,'to'=>$to]);
            return ['ok'=>true,'owner'=>$owner,'recovery_id'=>$id,'from'=>$from,'to'=>$to,'current_version'=>$this->currentVersion()];
        }catch(Throwable $e){
            $this->appendAudit('stable_recovery_failed',['owner'=>$owner,'recovery_id'=>$id,'from'=>$from,'error'=>get_class($e),'message'=>$e->getMessage()]);
            // Intentionally keep maintenance locked after a failed restore.
            throw $e;
        }
    }

    /** @return array<int,array<string,mixed>> */
    public function recoveryCatalog(): array
    {
        $out=[];
        foreach([
            ['routine',$this->routineRoot().'/recovery-points'],
            ['emergency',$this->emergencyUpdateRoot().'/recovery-points'],
        ] as [$owner,$root]){
            if(!is_dir($root))continue;
            foreach(array_values(array_filter(glob($root.'/*')?:[],'is_dir')) as $dir){
                $m=$this->readJson($dir.'/manifest.json');$format=(string)($m['format']??'');
                $valid=$owner==='routine'?in_array($format,[self::ROUTINE_RECOVERY_V2,self::ROUTINE_RECOVERY_V3],true):$format===self::EMERGENCY_RECOVERY_V1;
                if(!$valid)continue;
                $out[]=['selector'=>$owner.':'.basename($dir),'owner'=>$owner,'id'=>basename($dir),'format'=>$format,'version'=>(string)($m['version']??''),'created_at'=>(string)($m['created_at']??''),'reason'=>(string)($m['reason']??''),'transaction_id'=>(string)($m['transaction_id']??'')];
            }
        }
        usort($out,static fn(array $a,array $b):int=>strcmp((string)$b['created_at'],(string)$a['created_at']));
        return array_slice($out,0,12);
    }

    private function restoreRoutine(string $id): array
    {
        $this->assertRecoveryId($id);$dir=$this->routineRoot().'/recovery-points/'.$id;$m=$this->readJson($dir.'/manifest.json');$format=(string)($m['format']??'');
        if(!in_array($format,[self::ROUTINE_RECOVERY_V2,self::ROUTINE_RECOVERY_V3],true))throw new RuntimeException('Routine recovery point is invalid.');
        if($format===self::ROUTINE_RECOVERY_V2){
            $this->verifyLegacyPayload($dir.'/payload',(array)($m['files']??[]));
            $this->restoreLegacyTree($dir.'/payload');
        }else{
            foreach((array)($m['entries']??[]) as $entry){
                if(!is_array($entry))throw new RuntimeException('Differential recovery manifest is invalid.');
                $rel=$this->safeRelative((string)($entry['path']??''));$this->assertRecoverable($rel);$dst=$this->componentRoot.'/'.$rel;
                if((bool)($entry['existed']??false)){
                    $src=$dir.'/payload/'.$rel;$wantSize=(int)($entry['size']??-1);$wantHash=strtolower((string)($entry['sha256']??''));
                    if(!is_file($src)||(int)filesize($src)!==$wantSize||!preg_match('/^[a-f0-9]{64}$/D',$wantHash)||!hash_equals($wantHash,(string)hash_file('sha256',$src)))throw new RuntimeException('Differential recovery integrity failed for '.$rel);
                    $this->replaceFile($src,$dst,(int)($entry['mode']??420),'routine-v3-restore',$rel);
                }elseif(is_file($dst)||is_link($dst))$this->deleteFile($dst,'routine-v3-remove-new',$rel);
            }
        }
        $this->verifyRecoveryTree($m);
        return $m;
    }

    private function restoreEmergencyV1(string $id): array
    {
        $this->assertRecoveryId($id);$dir=$this->emergencyUpdateRoot().'/recovery-points/'.$id;$m=$this->readJson($dir.'/manifest.json');
        if(($m['format']??'')!==self::EMERGENCY_RECOVERY_V1)throw new RuntimeException('Emergency legacy recovery point is invalid.');
        $this->verifyLegacyPayload($dir.'/payload',(array)($m['files']??[]));
        $this->restoreLegacyTree($dir.'/payload');
        return $m;
    }

    private function restoreLegacyTree(string $source): void
    {
        $incoming=$this->managedFileMap($source,false);$current=$this->managedFileMap($this->componentRoot,false);
        foreach($incoming as $rel=>$hash){
            if($this->recoveryOwner($rel))continue;
            $src=$source.'/'.$rel;$dst=$this->componentRoot.'/'.$rel;$this->replaceFile($src,$dst,is_executable($src)?493:420,'legacy-restore',$rel);
        }
        foreach(array_diff(array_keys($current),array_keys($incoming)) as $rel){
            if($this->recoveryOwner($rel))continue;
            $this->assertRecoverable($rel);$dst=$this->componentRoot.'/'.$rel;if(is_file($dst)||is_link($dst))$this->deleteFile($dst,'legacy-delete',$rel);
        }
    }

    private function verifyLegacyPayload(string $root,array $files): void
    {
        foreach($files as $entry){
            if(!is_array($entry))throw new RuntimeException('Legacy recovery manifest is invalid.');
            $rel=$this->safeRelative((string)($entry['path']??''));$p=$root.'/'.$rel;$wantSize=(int)($entry['size']??-1);$wantHash=strtolower((string)($entry['sha256']??''));
            if(!is_file($p)||(int)filesize($p)!==$wantSize||!preg_match('/^[a-f0-9]{64}$/D',$wantHash)||!hash_equals($wantHash,(string)hash_file('sha256',$p)))throw new RuntimeException('Legacy recovery integrity failed for '.$rel);
        }
    }

    private function verifyRecoveryTree(array $manifest): void
    {
        $want=trim((string)($manifest['managed_tree_sha256']??''));if($want==='')return;
        $actual=$this->treeDigest($this->managedFileMap($this->componentRoot,false));
        if(hash_equals($want,$actual))return;
        // Recovery owner may have been installed after an older recovery point.
        $legacyComparable=$this->treeDigest($this->managedFileMap($this->componentRoot,true));
        if(hash_equals($want,$legacyComparable))return;
        throw new RuntimeException('Recovered managed tree does not match the recovery manifest.');
    }

    private function reconcileRoutineState(string $to,string $from,string $selector): void
    {
        $path=$this->routineRoot().'/state.json';$s=$this->readJson($path);
        if(($s['format']??'')!==self::ROUTINE_STATE_FORMAT)$s=['format'=>self::ROUTINE_STATE_FORMAT,'schema_version'=>2,'history'=>[]];
        $s['active_version']=$to;$s['previous_version']=$from;$s['pending_verification']=null;$s['activation_journal']=null;$s['staged']=null;
        $s['history'][]=['at'=>gmdate('c'),'action'=>'stable_recovery','version'=>$to,'actor_hint'=>'stable-recovery','result'=>'success','recovery_selector'=>$selector,'from'=>$from];
        $s['history']=array_slice((array)$s['history'],-100);$this->writeJson($path,$s);
    }

    private function resolveRecoverySelector(string $selector): array
    {
        $selector=trim($selector);if($selector!==''){
            if(!preg_match('/^(routine|emergency):([0-9]{8}-[0-9]{6}-[a-f0-9]{8})$/D',$selector,$m))throw new RuntimeException('Recovery selector is invalid.');
            return [$m[1],$m[2]];
        }
        $state=$this->readJson($this->routineRoot().'/state.json');$recommended=$this->recommendedRecoveryId($state);
        if($recommended!=='')return ['routine',$recommended];
        $catalog=$this->recoveryCatalog();if($catalog===[])throw new RuntimeException('No recovery point is available.');
        return [(string)$catalog[0]['owner'],(string)$catalog[0]['id']];
    }

    private function recommendedRecoveryId(array $state): string
    {
        foreach([(array)($state['pending_verification']??[]),(array)($state['activation_journal']??[])] as $r){$id=(string)($r['recovery_id']??'');if($this->validRecoveryId($id)&&is_file($this->routineRoot().'/recovery-points/'.$id.'/manifest.json'))return $id;}
        $id=(string)($state['lkg_recovery_id']??'');return $this->validRecoveryId($id)&&is_file($this->routineRoot().'/recovery-points/'.$id.'/manifest.json')?$id:'';
    }

    private function currentVersion(): string{$raw=@file_get_contents($this->componentRoot.'/VERSION.txt');return is_string($raw)&&trim($raw)!==''?trim($raw):'unknown';}
    private function routineRoot(): string{return rtrim($this->storageRoot,"\\/").'/routine-update-v2';}
    private function emergencyUpdateRoot(): string{return rtrim($this->storageRoot,"\\/").'/emergency/update';}
    private function maintenanceLockPath(): string{return $this->routineRoot().'/activation.lock';}
    private function auditPath(): string{return rtrim($this->storageRoot,"\\/").'/recovery/stable-recovery.log';}

    private function criticalFiles(): array
    {
        $out=[];foreach(['VERSION.txt','bootstrap.php','index.php','emergency.php','recovery.php','src/Recovery/StableRecoveryService.php'] as $rel){$p=$this->componentRoot.'/'.$rel;$out[$rel]=['exists'=>is_file($p),'readable'=>is_readable($p),'sha256'=>is_file($p)?(string)@hash_file('sha256',$p):''];}return $out;
    }
    private function healthCheck(): void{foreach(['VERSION.txt','bootstrap.php','index.php','emergency.php','recovery.php','src/Recovery/StableRecoveryService.php'] as $rel)if(!is_file($this->componentRoot.'/'.$rel))throw new RuntimeException('Critical recovery file is missing: '.$rel);}

    /** @return array<string,string> */
    private function managedFileMap(string $root,bool $excludeRecoveryOwner): array
    {
        $out=[];if(!is_dir($root))return $out;$prefixLen=strlen(rtrim($root,"\\/"))+1;$it=new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root,\FilesystemIterator::SKIP_DOTS));
        foreach($it as $f)if($f->isFile()){$rel=str_replace('\\','/',substr($f->getPathname(),$prefixLen));if($this->oldStable($rel)||$this->runtimeExcluded($rel)||$this->sourceExcluded($rel)||($excludeRecoveryOwner&&$this->recoveryOwner($rel)))continue;$out[$this->safeRelative($rel)]=(string)hash_file('sha256',$f->getPathname());}
        ksort($out,SORT_STRING);return $out;
    }
    private function treeDigest(array $map): string{$h=hash_init('sha256');ksort($map,SORT_STRING);foreach($map as $rel=>$digest){hash_update($h,$rel);hash_update($h,"\0");hash_update($h,$digest);hash_update($h,"\n");}return hash_final($h);}

    private function replaceFile(string $src,string $dst,int $mode,string $phase,string $rel): void
    {
        $this->assertRecoverable($rel);$this->mkdir(dirname($dst),0755);$tmp=$dst.'.sokna-recovery-'.bin2hex(random_bytes(4));
        try{$this->copyFile($src,$tmp,$phase.'_prepare',$rel,$mode===493?0755:0644);$this->renameFile($tmp,$dst,$phase,$rel);@chmod($dst,$mode===493?0755:0644);}catch(Throwable $e){@unlink($tmp);throw $e;}
    }
    private function copyFile(string $src,string $dst,string $phase,string $rel,int $mode=0644): void{$this->mkdir(dirname($dst),0755);for($i=1;$i<=4;$i++){clearstatcache(true,$src);if(is_file($src)&&@copy($src,$dst)){@chmod($dst,$mode);return;}if($i<4)usleep(75000*$i);}throw new RuntimeException($phase.' copy failed: '.$rel);}
    private function renameFile(string $src,string $dst,string $phase,string $rel): void{for($i=1;$i<=4;$i++){if(@rename($src,$dst))return;if($i<4)usleep(75000*$i);}throw new RuntimeException($phase.' atomic replace failed: '.$rel);}
    private function deleteFile(string $path,string $phase,string $rel): void{$this->assertRecoverable($rel);for($i=1;$i<=4;$i++){if(!file_exists($path)&&!is_link($path))return;if(@unlink($path))return;if($i<4)usleep(75000*$i);}throw new RuntimeException($phase.' delete failed: '.$rel);}
    private function clearMaintenance(): void{$p=$this->maintenanceLockPath();for($i=1;$i<=4;$i++){if(!is_file($p)&&!is_link($p))return;if(@unlink($p))return;if($i<4)usleep(75000*$i);}throw new RuntimeException('Maintenance lock could not be cleared.');}

    private function appendAudit(string $action,array $details): void
    {
        try{$p=$this->auditPath();$this->mkdir(dirname($p),0700);$safe=[];foreach($details as $k=>$v)$safe[$k]=preg_match('/pass|secret|token|code/i',(string)$k)?'[redacted]':$v;@file_put_contents($p,json_encode(['at'=>gmdate('c'),'action'=>$action,'details'=>$safe],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n",FILE_APPEND|LOCK_EX);@chmod($p,0600);}catch(Throwable){}
    }

    private function readJson(string $path): array{$raw=@file_get_contents($path);if(!is_string($raw)||$raw==='')return [];try{$v=json_decode($raw,true,64,JSON_THROW_ON_ERROR);return is_array($v)?$v:[];}catch(Throwable){return [];}}
    private function writeJson(string $path,array $value): void{$this->mkdir(dirname($path),0700);$raw=json_encode($value,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)."\n";for($i=1;$i<=4;$i++){$tmp=$path.'.tmp-'.bin2hex(random_bytes(4));if(@file_put_contents($tmp,$raw,LOCK_EX)===strlen($raw)&&@rename($tmp,$path)){@chmod($path,0600);return;}@unlink($tmp);if($i<4)usleep(75000*$i);}throw new RuntimeException('Recovery state could not be written.');}
    private function mkdir(string $path,int $mode): void{if(!is_dir($path)&&!@mkdir($path,$mode,true)&&!is_dir($path))throw new RuntimeException('Recovery storage is unavailable.');}

    private function redactState(array $value): array{foreach($value as $k=>$v){if(preg_match('/password|passphrase|secret|token|cookie|authorization|csrf|ciphertext|key/i',(string)$k))$value[$k]='[redacted]';elseif(is_array($v))$value[$k]=$this->redactState($v);}return $value;}
    private function safeRelative(string $rel): string{$rel=str_replace('\\','/',trim($rel));if($rel===''||str_starts_with($rel,'/')||preg_match('#(^|/)\.\.(/|$)#',$rel)||str_contains($rel,"\0"))throw new RuntimeException('Unsafe recovery path.');return $rel;}
    private function oldStable(string $rel): bool{foreach(self::OLD_STABLE_PREFIXES as $p)if($rel===$p||(str_ends_with($p,'/')&&str_starts_with($rel,$p)))return true;return false;}
    private function recoveryOwner(string $rel): bool{foreach(self::RECOVERY_OWNER_PREFIXES as $p)if($rel===$p||(str_ends_with($p,'/')&&str_starts_with($rel,$p)))return true;return false;}
    private function runtimeExcluded(string $rel): bool{return in_array($rel,['config.php','install.lock'],true)||str_starts_with($rel,'storage/');}
    private function sourceExcluded(string $rel): bool{return in_array($rel,['README.md','manifest.json'],true)||str_starts_with($rel,'Q3_P1_')||str_starts_with($rel,'tools/');}
    private function assertRecoverable(string $rel): void{if($this->oldStable($rel)||$this->recoveryOwner($rel)||$this->runtimeExcluded($rel)||$this->sourceExcluded($rel))throw new RuntimeException('Recovery cannot mutate protected path: '.$rel);}
    private function validRecoveryId(string $id): bool{return preg_match('/^[0-9]{8}-[0-9]{6}-[a-f0-9]{8}$/D',$id)===1;}
    private function assertRecoveryId(string $id): void{if(!$this->validRecoveryId($id))throw new RuntimeException('Recovery id is invalid.');}
}
