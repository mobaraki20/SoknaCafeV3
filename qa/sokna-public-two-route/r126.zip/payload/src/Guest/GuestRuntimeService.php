<?php
declare(strict_types=1);

namespace Sokna\PublicEdge\Guest;

use PDO;

final class GuestRuntimeService
{
    public const HEARTBEAT_INTERVAL_SECONDS = 15;
    public const MISSED_HEARTBEATS_BEFORE_STALE = 3;
    public const LIVE_FRESH_SECONDS = self::HEARTBEAT_INTERVAL_SECONDS * self::MISSED_HEARTBEATS_BEFORE_STALE;
    public const PROJECTION_FRESH_SECONDS = 90;

    public function __construct(private readonly PDO $pdo)
    {
    }

    public function bundle(string $installationId): array
    {
        $stmt = $this->pdo->prepare(
            'SELECT i.installation_id,i.display_name,i.active,i.remote_enabled,i.order_intake_enabled,'
            . 'r.revision_id,r.snapshot_json,r.media_manifest_json,r.generated_at,'
            . 'a.payload_json AS availability_json,a.last_sync_at,'
            . 'h.last_seen_at AS heartbeat_at '
            . 'FROM installations i '
            . 'LEFT JOIN guest_active_revisions ar ON ar.installation_id=i.installation_id '
            . 'LEFT JOIN guest_publish_revisions r ON r.installation_id=ar.installation_id AND r.revision_id=ar.revision_id '
            . 'LEFT JOIN guest_availability_state a ON a.installation_id=i.installation_id '
            . 'LEFT JOIN installation_heartbeats h ON h.installation_id=i.installation_id '
            . 'WHERE i.installation_id=? LIMIT 1'
        );
        $stmt->execute([trim($installationId)]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($row) || !(bool)$row['active']) return [];

        $snapshot = json_decode((string)($row['snapshot_json'] ?? ''), true);
        $manifest = json_decode((string)($row['media_manifest_json'] ?? ''), true);
        $availability = json_decode((string)($row['availability_json'] ?? ''), true);
        $row['snapshot'] = is_array($snapshot) ? $snapshot : [];
        $row['media_manifest'] = is_array($manifest) ? $manifest : [];
        $row['availability'] = is_array($availability) ? $availability : [];
        unset($row['snapshot_json'], $row['media_manifest_json'], $row['availability_json']);
        return $row;
    }

    public function actionState(
        array $bundle,
        int $liveFreshSeconds = self::LIVE_FRESH_SECONDS,
        int $projectionFreshSeconds = self::PROJECTION_FRESH_SECONDS,
    ): array {
        $now = time();
        $heartbeat = self::utcEpoch((string)($bundle['heartbeat_at'] ?? ''));
        $availabilityAt = self::utcEpoch((string)($bundle['last_sync_at'] ?? ''));
        $localFresh = $heartbeat >= $now - max(5, $liveFreshSeconds);
        $availabilityFresh = $availabilityAt >= $now - max(30, $projectionFreshSeconds);
        $remoteEnabled = (bool)($bundle['remote_enabled'] ?? false);
        $orderIntakeEnabled = (bool)($bundle['order_intake_enabled'] ?? false);
        $commandReady = $remoteEnabled && $localFresh;
        // Read freshness, command reachability, and new-order intake are separate
        // concerns. Existing-order edits/cancels and waiter calls do not become unsafe
        // merely because new Guest intake is paused. Local remains authoritative.
        $mutationReady = $commandReady;
        $orderReady = $commandReady && $orderIntakeEnabled;
        // `enabled` is retained as the compatibility alias for *new order intake*.
        $enabled = $orderReady;

        return [
            'enabled' => $enabled,
            'mutation_ready' => $mutationReady,
            'command_ready' => $commandReady,
            'order_ready' => $orderReady,
            'remote_enabled' => $remoteEnabled,
            'order_intake_enabled' => $orderIntakeEnabled,
            'heartbeat_fresh' => $localFresh,
            'model_fresh' => $availabilityFresh,
            'local_fresh' => $localFresh,
            'availability_fresh' => $availabilityFresh,
            'heartbeat_at' => (string)($bundle['heartbeat_at'] ?? ''),
            'last_sync_at' => (string)($bundle['last_sync_at'] ?? ''),
        ];
    }

    public function relayReady(array $bundle, bool $requireOrderIntake): bool
    {
        $state = $this->actionState($bundle);
        return ($state['remote_enabled'] ?? false) === true
            && ($state['local_fresh'] ?? false) === true
            && (!$requireOrderIntake || ($state['order_intake_enabled'] ?? false) === true);
    }

    private static function utcEpoch(string $value): int
    {
        $value = trim($value);
        if ($value === '') return 0;
        if (preg_match('/(?:Z|[+\-]\d{2}:?\d{2})$/i', $value)) return strtotime($value) ?: 0;
        return \Sokna\Shared\IranTime::epoch($value,'UTC') ?: 0;
    }
}
