<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Maintenance;

final class PublicMaintenanceKernel
{
    public const PROTOCOL_MAJOR=1;
    public const PROTOCOL_MINOR=4;
    public const KERNEL_CONTRACT='sokna-public-maintenance-kernel-v1';

    public function __construct(
        private readonly string $componentRoot,
        private readonly PublicMaintenanceStorage $storage,
        private readonly ?VaultCredentialStore $credentials=null,
        private readonly ?VaultPolicyStore $policies=null,
    ) {}

    public function health(): array
    {
        $storage=$this->storage->status();
        $credential=$this->credentials?->status()??['ready'=>false,'reason'=>'not_configured'];
        $policy=$this->policies?->status()??['ready'=>false,'reason'=>'not_configured','policy_count'=>0];
        $vaultReady=(bool)$storage['ready']&&(bool)($credential['ready']??false);
        $scopes=array_values(array_map('strval',(array)($credential['scopes']??[])));
        $uploadReady=$vaultReady&&in_array('vault.upload',$scopes,true);
        $inventoryReady=$vaultReady&&in_array('vault.recovery_read',$scopes,true);
        $retentionReady=$vaultReady&&in_array('vault.retention_admin',$scopes,true);
        return [
            'ok'=>(bool)$storage['ready'],
            'component'=>'public-maintenance-kernel',
            'contract'=>self::KERNEL_CONTRACT,
            'protocol_major'=>self::PROTOCOL_MAJOR,
            'protocol_minor'=>self::PROTOCOL_MINOR,
            'public_version'=>$this->version(),
            'storage'=>[
                'ready'=>(bool)$storage['ready'],
                'protection_mode'=>(string)$storage['protection_mode'],
            ],
            'vault'=>[
                'ready'=>$vaultReady,
                'credential_state'=>(string)($credential['reason']??'unknown'),
                'policy_state'=>(string)($policy['reason']??'unknown'),
                'policy_count'=>(int)($policy['policy_count']??0),
            ],
            'capabilities'=>[
                'health'=>true,
                'status'=>true,
                'vault_upload'=>$uploadReady,
                'vault_inventory'=>$inventoryReady,
                'vault_recovery_download'=>$inventoryReady,
                'vault_retention_admin'=>$retentionReady,
                'vault_quota_policy'=>(bool)($policy['ready']??false),
                'release_attestation'=>false, // disabled until external key and stable-authority binding are provisioned
                'update_control'=>false,
            ],
        ];
    }

    public function status(): array
    {
        return $this->health()+['phase'=>'remote_vault_governance_foundation'];
    }

    private function version(): string
    {
        $raw=@file_get_contents(rtrim($this->componentRoot,"\\/").'/VERSION.txt');
        return is_string($raw)&&trim($raw)!==''?trim($raw):'unknown';
    }
}
