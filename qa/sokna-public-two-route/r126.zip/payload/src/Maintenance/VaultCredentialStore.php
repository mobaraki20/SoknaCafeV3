<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Maintenance;

final class VaultCredentialStore
{
    public const FORMAT='sokna-maintenance-vault-credentials-v1';
    private const ALLOWED_SCOPES=['vault.upload','vault.recovery_read','vault.retention_admin'];
    private const P4_PROVISIONABLE_SCOPES=['vault.upload','vault.recovery_read','vault.retention_admin'];

    public function __construct(private readonly string $maintenanceBase) {}

    public function status(): array
    {
        $path=$this->credentialPath();
        if(!is_file($path))return ['ready'=>false,'reason'=>'credentials_missing','path'=>$path];
        try{
            $doc=$this->load();$scopes=[];$active=0;$now=time();
            foreach((array)($doc['tokens']??[]) as $token){
                if(!$this->tokenActive($token,$now))continue;$active++;
                foreach((array)($token['scopes']??[]) as $scope){$scope=trim((string)$scope);if($scope!=='')$scopes[$scope]=true;}
            }
            return ['ready'=>$active>0,'reason'=>$active>0?'ok':'no_active_tokens','token_count'=>$active,'scopes'=>array_values(array_keys($scopes)),'policy'=>$this->policyFrom($doc)];
        }catch(MaintenanceException $e){return ['ready'=>false,'reason'=>$e->errorCode];}
    }

    public function authenticate(string $bearer,string $requiredScope): array
    {
        $bearer=trim($bearer);if($bearer===''||!str_contains($bearer,'.'))throw new MaintenanceException('vault_unauthorized','Vault credential is missing or invalid.',401);
        [$id,$secret]=explode('.',$bearer,2);
        if(!preg_match('/^[A-Za-z0-9_-]{3,80}$/',$id)||strlen($secret)<32||strlen($secret)>512)throw new MaintenanceException('vault_unauthorized','Vault credential is missing or invalid.',401);
        $doc=$this->load();$now=time();
        foreach((array)($doc['tokens']??[]) as $token){
            if(!is_array($token)||(string)($token['id']??'')!==$id)continue;
            if(!$this->tokenActive($token,$now))break;
            $stored=strtolower(trim((string)($token['secret_sha256']??'')));$actual=hash('sha256',$secret);
            if(!preg_match('/^[a-f0-9]{64}$/',$stored)||!hash_equals($stored,$actual))break;
            $scopes=$this->normalizeScopes((array)($token['scopes']??[]),false);
            if(!in_array($requiredScope,$scopes,true))throw new MaintenanceException('vault_scope_forbidden','Vault credential does not grant the required scope.',403,['required_scope'=>$requiredScope]);
            $installation=$this->validateInstallation((string)($token['installation_id']??''));
            return ['credential_id'=>$id,'installation_id'=>$installation,'scopes'=>$scopes,'policy'=>$this->policyFrom($doc),'expires_at'=>(string)($token['expires_at']??'')];
        }
        throw new MaintenanceException('vault_unauthorized','Vault credential is missing or invalid.',401);
    }

    public function provision(string $installationId,array $scopes,int $ttlSeconds,string $label,array $requestedPolicy=[]): array
    {
        $installationId=$this->validateInstallation($installationId);$scopes=$this->normalizeScopes($scopes,true);$ttl=$this->ttlForScopes($scopes,$ttlSeconds);$label=substr(trim($label),0,120);
        return $this->withCredentialLock(function()use($installationId,$scopes,$ttl,$label,$requestedPolicy){
            $doc=$this->loadOrCreate($requestedPolicy);$secret=$this->b64(random_bytes(48));$id='vlt_'.bin2hex(random_bytes(12));$now=time();
            $row=['id'=>$id,'secret_sha256'=>hash('sha256',$secret),'installation_id'=>$installationId,'scopes'=>$scopes,'enabled'=>true,'label'=>$label,'created_at'=>gmdate('c',$now),'expires_at'=>gmdate('c',$now+$ttl)];
            $doc['tokens'][]=$row;$doc['updated_at']=gmdate('c',$now);$this->writeDocument($doc);
            return ['ok'=>true,'credential_id'=>$id,'credential'=>$id.'.'.$secret,'installation_id'=>$installationId,'scopes'=>$scopes,'expires_at'=>$row['expires_at'],'secret_returned_once'=>true];
        });
    }

    public function rotate(string $credentialId,int $graceSeconds=300): array
    {
        $credentialId=$this->validateCredentialId($credentialId);$grace=max(0,min(3600,$graceSeconds));
        return $this->withCredentialLock(function()use($credentialId,$grace){
            $doc=$this->load();$idx=$this->findTokenIndex($doc,$credentialId);$old=$doc['tokens'][$idx];
            if(!$this->tokenActive($old,time()))throw new MaintenanceException('vault_credential_inactive','Credential is not active.',409);
            $secret=$this->b64(random_bytes(48));$id='vlt_'.bin2hex(random_bytes(12));$now=time();$oldExpires=strtotime((string)($old['expires_at']??''));$remaining=$oldExpires===false?86400:max(60,$oldExpires-$now);
            $new=['id'=>$id,'secret_sha256'=>hash('sha256',$secret),'installation_id'=>$this->validateInstallation((string)$old['installation_id']),'scopes'=>$this->normalizeScopes((array)$old['scopes'],false),'enabled'=>true,'label'=>substr((string)($old['label']??''),0,120),'created_at'=>gmdate('c',$now),'expires_at'=>gmdate('c',$now+$remaining),'rotated_from'=>$credentialId];
            $doc['tokens'][$idx]['retire_at']=gmdate('c',$now+$grace);$doc['tokens'][$idx]['rotated_to']=$id;$doc['tokens'][]=$new;$doc['updated_at']=gmdate('c',$now);$this->writeDocument($doc);
            return ['ok'=>true,'credential_id'=>$id,'credential'=>$id.'.'.$secret,'installation_id'=>$new['installation_id'],'scopes'=>$new['scopes'],'expires_at'=>$new['expires_at'],'previous_credential_id'=>$credentialId,'previous_retire_at'=>$doc['tokens'][$idx]['retire_at'],'secret_returned_once'=>true];
        });
    }

    /**
     * Administrator-authorized renewal of ONE active vault.upload token. Unlike
     * rotate(), this starts a fresh bounded TTL, but cannot broaden privileges,
     * change installation or mint a recovery/read token. Caller must enforce
     * HTTPS + authenticated short-lived maintenance administrator session.
     * The plaintext is returned exactly once to be delivered to the Windows
     * Supervisor over the existing authenticated Local web adapter.
     */
    public function renewUpload(string $credentialId,int $ttlSeconds=2592000,int $graceSeconds=300): array
    {
        $credentialId=$this->validateCredentialId($credentialId);
        if($ttlSeconds<3600||$ttlSeconds>15552000)
            throw new MaintenanceException('vault_credential_ttl_invalid','Upload renewal TTL must be between 1 hour and 180 days.',422);
        $ttl=$this->ttlForScopes(['vault.upload'],$ttlSeconds);
        $grace=max(0,min(3600,$graceSeconds));
        return $this->withCredentialLock(function()use($credentialId,$ttl,$grace){
            $doc=$this->load();$idx=$this->findTokenIndex($doc,$credentialId);$old=$doc['tokens'][$idx];$now=time();
            if(!$this->tokenActive($old,$now))throw new MaintenanceException('vault_credential_inactive','Credential is not active.',409);
            $scopes=$this->normalizeScopes((array)($old['scopes']??[]),false);
            if(count($scopes)!==1||$scopes[0]!=='vault.upload')throw new MaintenanceException('vault_scope_forbidden','Only a single-scope upload credential can be renewed.',403);
            $installation=$this->validateInstallation((string)($old['installation_id']??''));
            $id='vlt_'.bin2hex(random_bytes(12));$secret=$this->b64(random_bytes(48));
            $new=['id'=>$id,'secret_sha256'=>hash('sha256',$secret),'installation_id'=>$installation,'scopes'=>['vault.upload'],
                'enabled'=>true,'label'=>substr((string)($old['label']??''),0,120),'created_at'=>gmdate('c',$now),
                'expires_at'=>gmdate('c',$now+$ttl),'renewed_from'=>$credentialId];
            $oldExpires=strtotime((string)$old['expires_at']);
            $retireAt=min($oldExpires,$now+$grace);
            $doc['tokens'][$idx]['retire_at']=gmdate('c',$retireAt);
            $doc['tokens'][$idx]['rotated_to']=$id;
            $doc['tokens'][]=$new;$doc['updated_at']=gmdate('c',$now);$this->writeDocument($doc);
            return ['ok'=>true,'credential_id'=>$id,'credential'=>$id.'.'.$secret,
                'installation_id'=>$installation,'scopes'=>['vault.upload'],'expires_at'=>$new['expires_at'],
                'previous_credential_id'=>$credentialId,'previous_retire_at'=>$doc['tokens'][$idx]['retire_at'],
                'secret_returned_once'=>true];
        });
    }

    public function revoke(string $credentialId): array
    {
        $credentialId=$this->validateCredentialId($credentialId);
        return $this->withCredentialLock(function()use($credentialId){$doc=$this->load();$idx=$this->findTokenIndex($doc,$credentialId);$doc['tokens'][$idx]['enabled']=false;$doc['tokens'][$idx]['revoked_at']=gmdate('c');$doc['updated_at']=gmdate('c');$this->writeDocument($doc);return ['ok'=>true,'credential_id'=>$credentialId,'revoked'=>true];});
    }

    public function inventory(): array
    {
        $doc=$this->load();$rows=[];$now=time();
        foreach((array)$doc['tokens'] as $t){if(!is_array($t))continue;$rows[]=['credential_id'=>(string)($t['id']??''),'installation_id'=>(string)($t['installation_id']??''),'scopes'=>array_values((array)($t['scopes']??[])),'label'=>(string)($t['label']??''),'enabled'=>(bool)($t['enabled']??true),'active'=>$this->tokenActive($t,$now),'created_at'=>(string)($t['created_at']??''),'expires_at'=>(string)($t['expires_at']??''),'retire_at'=>(string)($t['retire_at']??''),'revoked_at'=>(string)($t['revoked_at']??'')];}
        return ['ok'=>true,'tokens'=>$rows,'policy'=>$this->policyFrom($doc)];
    }

    public function credentialPath(): string{return rtrim($this->maintenanceBase,"\\/").'/credentials/v1.json';}

    private function loadOrCreate(array $requestedPolicy): array
    {
        if(is_file($this->credentialPath()))return $this->load();
        $maxArtifact=(int)($requestedPolicy['max_artifact_bytes']??0);$maxChunk=(int)($requestedPolicy['max_chunk_bytes']??0);
        if($maxArtifact<1||$maxArtifact>68719476736||$maxChunk<1||$maxChunk>67108864||$maxChunk>$maxArtifact)throw new MaintenanceException('vault_policy_required','Initial credential provisioning requires valid max_artifact_bytes and max_chunk_bytes policy.',422);
        return ['format'=>self::FORMAT,'policy'=>['max_artifact_bytes'=>$maxArtifact,'max_chunk_bytes'=>$maxChunk],'tokens'=>[],'created_at'=>gmdate('c'),'updated_at'=>gmdate('c')];
    }

    private function load(): array
    {
        $raw=@file_get_contents($this->credentialPath());if(!is_string($raw)||$raw==='')throw new MaintenanceException('vault_credentials_missing','Vault credential file is not provisioned.',503);
        try{$doc=json_decode($raw,true,512,JSON_THROW_ON_ERROR);}catch(\JsonException){throw new MaintenanceException('vault_credentials_invalid','Vault credential file is invalid.',500);}
        if(!is_array($doc)||(string)($doc['format']??'')!==self::FORMAT||!isset($doc['tokens'])||!is_array($doc['tokens']))throw new MaintenanceException('vault_credentials_invalid','Vault credential file format is invalid.',500);
        $this->policyFrom($doc);return $doc;
    }

    private function writeDocument(array $doc): void
    {
        $path=$this->credentialPath();$dir=dirname($path);if(!is_dir($dir)&&!@mkdir($dir,0700,true)&&!is_dir($dir))throw new MaintenanceException('vault_credentials_write_failed','Vault credential directory is unavailable.',500);@chmod($dir,0700);
        $tmp=$path.'.tmp.'.bin2hex(random_bytes(5));$json=json_encode($doc,JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR)."\n";if(@file_put_contents($tmp,$json,LOCK_EX)===false)throw new MaintenanceException('vault_credentials_write_failed','Vault credential state could not be written.',500);@chmod($tmp,0600);if(!@rename($tmp,$path)){@unlink($tmp);throw new MaintenanceException('vault_credentials_write_failed','Vault credential state could not be committed.',500);} @chmod($path,0600);
    }

    private function withCredentialLock(callable $fn): mixed
    {
        $dir=rtrim($this->maintenanceBase,"\\/").'/credentials';if(!is_dir($dir)&&!@mkdir($dir,0700,true)&&!is_dir($dir))throw new MaintenanceException('vault_credentials_write_failed','Vault credential directory is unavailable.',500);$h=@fopen($dir.'/credentials.lock','c+b');if(!$h)throw new MaintenanceException('vault_credentials_write_failed','Vault credential lock is unavailable.',500);try{if(!flock($h,LOCK_EX))throw new MaintenanceException('vault_credentials_write_failed','Vault credential lock failed.',503);return $fn();}finally{@flock($h,LOCK_UN);fclose($h);}
    }

    private function policyFrom(array $doc): array{$p=$doc['policy']??null;if(!is_array($p))throw new MaintenanceException('vault_policy_invalid','Vault policy is missing.',500);$a=(int)($p['max_artifact_bytes']??0);$c=(int)($p['max_chunk_bytes']??0);if($a<1||$a>68719476736||$c<1||$c>67108864||$c>$a)throw new MaintenanceException('vault_policy_invalid','Vault size policy is invalid.',500);return ['max_artifact_bytes'=>$a,'max_chunk_bytes'=>$c];}
    private function normalizeScopes(array $scopes,bool $provisioning): array{$out=[];foreach($scopes as $s){$s=trim((string)$s);if($s==='')continue;if(!in_array($s,self::ALLOWED_SCOPES,true))throw new MaintenanceException('vault_scope_invalid','Vault scope is invalid.',422,['scope'=>$s]);if($provisioning&&!in_array($s,self::P4_PROVISIONABLE_SCOPES,true))throw new MaintenanceException('vault_scope_not_available','Vault scope is reserved and not provisionable in this phase.',409,['scope'=>$s]);$out[$s]=true;}if($out===[])throw new MaintenanceException('vault_scope_invalid','At least one Vault scope is required.',422);if($provisioning&&count($out)!==1)throw new MaintenanceException('vault_scope_combination_forbidden','Provisioned Vault credentials must have exactly one scope.',422);return array_keys($out);}
    private function ttlForScopes(array $scopes,int $requested): int{$short=in_array('vault.recovery_read',$scopes,true)||in_array('vault.retention_admin',$scopes,true);$max=$short?3600:15552000;$min=$short?300:3600;return max($min,min($max,$requested>0?$requested:$max));}
    private function tokenActive(mixed $token,int $now): bool{if(!is_array($token)||($token['enabled']??true)!==true)return false;$expires=trim((string)($token['expires_at']??''));if($expires===''||($ts=strtotime($expires))===false||$ts<=$now)return false;$retire=trim((string)($token['retire_at']??''));if($retire!==''&&(($ts=strtotime($retire))===false||$ts<=$now))return false;return true;}
    private function findTokenIndex(array $doc,string $id): int{foreach((array)$doc['tokens'] as $i=>$t)if(is_array($t)&&(string)($t['id']??'')===$id)return (int)$i;throw new MaintenanceException('vault_credential_not_found','Vault credential was not found.',404);}
    private function validateCredentialId(string $id): string{$id=trim($id);if(!preg_match('/^[A-Za-z0-9_-]{3,80}$/D',$id))throw new MaintenanceException('vault_credential_invalid','Vault credential id is invalid.',422);return $id;}
    private function validateInstallation(string $id): string{$id=trim($id);if(!preg_match('/^[A-Za-z0-9._:-]{1,96}$/D',$id))throw new MaintenanceException('vault_installation_invalid','Installation identity is invalid.',422);return $id;}
    private function b64(string $raw): string{return rtrim(strtr(base64_encode($raw),'+/','-_'),'=');}
}
