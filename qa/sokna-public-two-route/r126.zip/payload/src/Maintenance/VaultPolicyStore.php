<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Maintenance;

final class VaultPolicyStore
{
    public const FORMAT='sokna-remote-backup-vault-policy-v1';
    private const MAX_RETENTION_BUCKETS=10000;

    public function __construct(private readonly string $maintenanceBase) {}

    public function status(): array
    {
        $dir=$this->policyDir();$count=0;
        if(is_dir($dir))$count=count(glob($dir.'/*.json')?:[]);
        return ['ready'=>$count>0,'reason'=>$count>0?'ok':'no_policies','policy_count'=>$count];
    }

    public function get(string $installationId,bool $required=true): ?array
    {
        $installationId=$this->validateInstallation($installationId);$path=$this->policyPath($installationId);
        $raw=@file_get_contents($path);
        if(!is_string($raw)||$raw===''){
            if($required)throw new MaintenanceException('vault_policy_missing','Remote Vault quota/retention policy is not configured for this installation.',503,['installation_id'=>$installationId]);
            return null;
        }
        try{$doc=json_decode($raw,true,128,JSON_THROW_ON_ERROR);}catch(\JsonException){throw new MaintenanceException('vault_policy_invalid','Remote Vault policy is invalid.',500);}
        if(!is_array($doc)||(string)($doc['format']??'')!==self::FORMAT||(string)($doc['installation_id']??'')!==$installationId)throw new MaintenanceException('vault_policy_invalid','Remote Vault policy is invalid.',500);
        return $this->normalizePolicy($installationId,$doc)+(array_filter(['created_at'=>(string)($doc['created_at']??''),'updated_at'=>(string)($doc['updated_at']??''),'updated_by_credential_id'=>(string)($doc['updated_by_credential_id']??'')],fn($v)=>$v!==''));
    }

    public function set(array $principal,array $input): array
    {
        $installationId=$this->validateInstallation((string)($principal['installation_id']??''));$credentialId=trim((string)($principal['credential_id']??''));
        $policy=$this->normalizePolicy($installationId,$input);$path=$this->policyPath($installationId);$existing=$this->get($installationId,false);$now=gmdate('c');
        $doc=$policy+['format'=>self::FORMAT,'created_at'=>(string)($existing['created_at']??$now),'updated_at'=>$now,'updated_by_credential_id'=>$credentialId];
        $this->withLock($installationId,function()use($path,$doc){$this->writeAtomic($path,$doc);});
        return ['ok'=>true,'policy'=>$doc];
    }

    private function normalizePolicy(string $installationId,array $input): array
    {
        $maxRemote=(int)($input['max_remote_bytes']??0);
        if($maxRemote<1)throw new MaintenanceException('vault_policy_invalid','max_remote_bytes must be a positive integer.',422);
        $ret=$input['retention']??null;if(!is_array($ret))throw new MaintenanceException('vault_policy_invalid','Retention policy is required.',422);
        $normalized=[];
        foreach(['recent','daily','weekly','monthly'] as $key){
            if(!array_key_exists($key,$ret))throw new MaintenanceException('vault_policy_invalid','Retention policy must declare recent/daily/weekly/monthly explicitly.',422,['missing'=>$key]);
            $v=(int)$ret[$key];if($v<0||$v>self::MAX_RETENTION_BUCKETS)throw new MaintenanceException('vault_policy_invalid','Retention count is outside supported bounds.',422,['field'=>$key]);$normalized[$key]=$v;
        }
        return ['format'=>self::FORMAT,'installation_id'=>$installationId,'max_remote_bytes'=>$maxRemote,'retention'=>$normalized,'timestamp_authority'=>'server_verified_at_utc','always_keep_latest_verified'=>true];
    }

    private function policyDir(): string{return rtrim($this->maintenanceBase,"\\/").'/remote-backup-vault-v1/policies';}
    private function policyPath(string $installationId): string{return $this->policyDir().'/'.hash('sha256',$installationId).'.json';}
    private function lockPath(string $installationId): string{return $this->policyDir().'/'.hash('sha256',$installationId).'.lock';}

    private function withLock(string $installationId,callable $fn): mixed
    {
        $dir=$this->policyDir();if(!is_dir($dir)&&!@mkdir($dir,0700,true)&&!is_dir($dir))throw new MaintenanceException('vault_policy_write_failed','Remote Vault policy directory is unavailable.',500);@chmod($dir,0700);
        $h=@fopen($this->lockPath($installationId),'c+b');if(!$h)throw new MaintenanceException('vault_policy_write_failed','Remote Vault policy lock is unavailable.',500);
        try{if(!flock($h,LOCK_EX))throw new MaintenanceException('vault_policy_write_failed','Remote Vault policy lock failed.',503);return $fn();}finally{@flock($h,LOCK_UN);fclose($h);}
    }

    private function writeAtomic(string $path,array $doc): void
    {
        $dir=dirname($path);if(!is_dir($dir)&&!@mkdir($dir,0700,true)&&!is_dir($dir))throw new MaintenanceException('vault_policy_write_failed','Remote Vault policy directory is unavailable.',500);@chmod($dir,0700);
        $tmp=$path.'.tmp.'.bin2hex(random_bytes(5));$json=json_encode($doc,JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR)."\n";
        if(@file_put_contents($tmp,$json,LOCK_EX)===false)throw new MaintenanceException('vault_policy_write_failed','Remote Vault policy could not be written.',500);@chmod($tmp,0600);
        if(!@rename($tmp,$path)){@unlink($tmp);throw new MaintenanceException('vault_policy_write_failed','Remote Vault policy could not be committed.',500);}@chmod($path,0600);
    }

    private function validateInstallation(string $id): string{$id=trim($id);if(!preg_match('/^[A-Za-z0-9._:-]{1,96}$/D',$id))throw new MaintenanceException('vault_installation_invalid','Installation identity is invalid.',422);return $id;}
}
