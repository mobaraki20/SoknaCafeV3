<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Maintenance;

final class PublicMaintenanceStorage
{
    private string $componentRoot;
    private string $storageRoot;

    public function __construct(string $componentRoot,string $storageRoot)
    {
        $this->componentRoot=rtrim(str_replace('\\','/',$componentRoot),'/');
        $this->storageRoot=rtrim(str_replace('\\','/',$storageRoot),'/');
        if($this->componentRoot===''||$this->storageRoot==='')throw new MaintenanceException('storage_path_invalid','Maintenance storage path is invalid.',500);
    }

    public function status(): array
    {
        $mode=$this->protectionMode();
        $safe=$mode!=='unsafe_inside_webroot';
        $base=$this->basePath();
        $exists=is_dir($base);
        $parent=$exists?$base:dirname($base);
        $writable=is_dir($parent)&&is_writable($parent);
        return ['safe'=>$safe,'protection_mode'=>$mode,'base_exists'=>$exists,'parent_writable'=>$writable,'ready'=>$safe&&$writable];
    }

    public function basePath(): string{return $this->storageRoot.'/maintenance-v4';}

    public function ensureBase(): string
    {
        $status=$this->status();
        if(!$status['safe'])throw new MaintenanceException('vault_storage_unsafe','Maintenance storage is inside a web-visible application path.',500);
        $base=$this->basePath();
        if(!is_dir($base)&&!@mkdir($base,0700,true)&&!is_dir($base))throw new MaintenanceException('vault_storage_unavailable','Maintenance storage is unavailable.',500);
        @chmod($base,0700);
        return $base;
    }

    private function protectionMode(): string
    {
        $root=$this->componentRoot;$storage=$this->storageRoot;
        if($storage===$root.'/storage'||str_starts_with($storage,$root.'/storage/'))return 'component_storage_denied';
        if($storage===$root||str_starts_with($storage,$root.'/'))return 'unsafe_inside_webroot';
        return 'outside_component_root';
    }
}
