<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Maintenance;

final class RemoteBackupVaultRetentionService
{
    public const RUN_FORMAT='sokna-remote-backup-vault-retention-run-v1';
    public const TOMBSTONE_FORMAT='sokna-remote-backup-vault-retention-tombstone-v1';

    public function __construct(private readonly string $maintenanceBase) {}

    public function isTombstoned(string $backupId): bool{return is_file($this->tombstonePath($backupId));}

    public function quotaStatus(string $installationId,array $policy,?string $excludeBackupId=null): array
    {
        $verified=0;$verifiedCount=0;$inflight=0;$inflightCount=0;
        foreach($this->verifiedRows($installationId) as $row){if($excludeBackupId!==null&&$row['backup_id']===$excludeBackupId)continue;$verified+=(int)$row['artifact_size'];$verifiedCount++;}
        $dir=$this->statesDir();if(is_dir($dir))foreach(glob($dir.'/*.json')?:[] as $path){
            $row=$this->readJsonLoose($path);if($row===null)continue;$meta=(array)($row['metadata']??[]);$id=(string)($row['backup_id']??'');
            if((string)($meta['source_installation_id']??'')!==$installationId||$id===''||$this->isTombstoned($id)||($excludeBackupId!==null&&$id===$excludeBackupId))continue;
            if((string)($row['state']??'')==='REMOTE_VERIFIED')continue;
            $inflight+=(int)($row['expected_size']??0);$inflightCount++;
        }
        $used=$verified+$inflight;$max=(int)($policy['max_remote_bytes']??0);$free=max(0,$max-$used);
        $fsFree=@disk_free_space($this->vaultBase());
        return ['ok'=>true,'installation_id'=>$installationId,'max_remote_bytes'=>$max,'verified_bytes'=>$verified,'verified_count'=>$verifiedCount,'inflight_reserved_bytes'=>$inflight,'inflight_count'=>$inflightCount,'reserved_total_bytes'=>$used,'policy_headroom_bytes'=>$free,'filesystem_free_bytes'=>is_float($fsFree)||is_int($fsFree)?(int)$fsFree:null];
    }

    public function assertCanReserve(string $installationId,array $policy,string $backupId,int $artifactSize): array
    {
        $status=$this->quotaStatus($installationId,$policy,$backupId);$projected=(int)$status['reserved_total_bytes']+$artifactSize;$max=(int)$status['max_remote_bytes'];
        if($projected>$max)throw new MaintenanceException('REMOTE_QUOTA_BLOCKED','Remote Vault policy quota cannot reserve this backup before verification.',507,$status+['requested_reservation_bytes'=>$artifactSize,'projected_reserved_bytes'=>$projected]);
        $fs=$status['filesystem_free_bytes'];if(is_int($fs)&&$fs<$artifactSize)throw new MaintenanceException('REMOTE_QUOTA_BLOCKED','Remote Vault filesystem does not currently have enough free space for this backup.',507,$status+['requested_reservation_bytes'=>$artifactSize,'quota_source'=>'filesystem_free_space']);
        return $status+['requested_reservation_bytes'=>$artifactSize,'projected_reserved_bytes'=>$projected];
    }

    public function plan(string $installationId,array $policy,array $forceKeepBackupIds=[]): array
    {
        $rows=$this->verifiedRows($installationId);usort($rows,fn($a,$b)=>strcmp($b['verified_at'],$a['verified_at']));
        $active=$this->activeDownloadBackupIds($installationId);$keep=[];$reasons=[];
        if($rows!==[]){$keep[$rows[0]['backup_id']]=true;$reasons[$rows[0]['backup_id']][]='latest_verified';}
        foreach($forceKeepBackupIds as $id){$id=trim((string)$id);if($id!==''){$keep[$id]=true;$reasons[$id][]='protected_current_operation';}}
        foreach($active as $id=>$_){$keep[$id]=true;$reasons[$id][]='active_recovery_download';}
        $ret=(array)($policy['retention']??[]);$recent=max(0,(int)($ret['recent']??0));
        foreach(array_slice($rows,0,$recent) as $row){$keep[$row['backup_id']]=true;$reasons[$row['backup_id']][]='recent';}
        $this->keepBuckets($rows,$keep,$reasons,'daily',max(0,(int)($ret['daily']??0)));
        $this->keepBuckets($rows,$keep,$reasons,'weekly',max(0,(int)($ret['weekly']??0)));
        $this->keepBuckets($rows,$keep,$reasons,'monthly',max(0,(int)($ret['monthly']??0)));
        $kept=[];$expired=[];$reclaim=0;
        foreach($rows as $row){$id=$row['backup_id'];if(isset($keep[$id])){$row['keep_reasons']=array_values(array_unique($reasons[$id]??['policy']));$kept[]=$row;}else{$expired[]=$row;$reclaim+=(int)$row['artifact_size'];}}
        return ['ok'=>true,'state'=>'RETENTION_PLAN','installation_id'=>$installationId,'policy'=>$policy,'verified_count'=>count($rows),'kept'=>$kept,'expired_candidates'=>$expired,'reclaimable_bytes'=>$reclaim,'latest_verified_backup_id'=>$rows[0]['backup_id']??null,'server_time_utc'=>gmdate('c')];
    }

    public function apply(string $installationId,array $policy,string $requestId,string $actor='retention_admin',?string $protectedBackupId=null): array
    {
        $requestId=$this->validateRequestId($requestId);$runPath=$this->runPath($installationId,$requestId);
        return $this->withRetentionLock($installationId,function()use($installationId,$policy,$requestId,$actor,$runPath,$protectedBackupId){
            $existing=$this->readJsonLoose($runPath);if($existing!==null)return array_merge($existing,['idempotent'=>true]);
            $plan=$this->plan($installationId,$policy,$protectedBackupId!==null?[$protectedBackupId]:[]);$deleted=[];$skipped=[];
            foreach((array)$plan['expired_candidates'] as $row){
                $id=(string)($row['backup_id']??'');if($id==='')continue;
                $result=$this->expireBackup($installationId,$id,$requestId,$actor,$row);if(($result['deleted']??false)===true)$deleted[]=$result;else$skipped[]=$result;
            }
            $quota=$this->quotaStatus($installationId,$policy);$run=['format'=>self::RUN_FORMAT,'ok'=>true,'state'=>'RETENTION_APPLIED','retention_request_id'=>$requestId,'installation_id'=>$installationId,'actor'=>$actor,'policy'=>$policy,'planned_expired_count'=>count((array)$plan['expired_candidates']),'deleted_count'=>count($deleted),'skipped_count'=>count($skipped),'deleted'=>$deleted,'skipped'=>$skipped,'quota_after'=>$quota,'completed_at'=>gmdate('c'),'idempotent'=>false];
            $this->writeJsonAtomic($runPath,$run);return $run;
        });
    }

    public function autoApplyAfterVerified(string $installationId,array $policy,string $backupId): array
    {
        $requestId='auto_'.substr(hash('sha256',$installationId."\0".$backupId),0,40);
        return $this->apply($installationId,$policy,$requestId,'server_policy_after_verified',$backupId);
    }

    private function expireBackup(string $installationId,string $backupId,string $requestId,string $actor,array $receiptRow): array
    {
        return $this->withBackupLock($backupId,function()use($installationId,$backupId,$requestId,$actor,$receiptRow){
            if(isset($this->activeDownloadBackupIds($installationId)[$backupId]))return ['backup_id'=>$backupId,'deleted'=>false,'reason'=>'active_recovery_download'];
            $rows=$this->verifiedRows($installationId);usort($rows,fn($a,$b)=>strcmp($b['verified_at'],$a['verified_at']));
            if(($rows[0]['backup_id']??null)===$backupId)return ['backup_id'=>$backupId,'deleted'=>false,'reason'=>'latest_verified'];
            $tomb=$this->readJsonLoose($this->tombstonePath($backupId));
            if($tomb===null){$tomb=['format'=>self::TOMBSTONE_FORMAT,'backup_id'=>$backupId,'installation_id'=>$installationId,'expired_by_retention'=>true,'retention_request_id'=>$requestId,'actor'=>$actor,'artifact_size'=>(int)($receiptRow['artifact_size']??0),'artifact_sha256'=>(string)($receiptRow['artifact_sha256']??''),'verified_at'=>(string)($receiptRow['verified_at']??''),'expired_at'=>gmdate('c')];$this->writeJsonAtomic($this->tombstonePath($backupId),$tomb);}
            foreach([$this->receiptPath($backupId),$this->artifactPath($backupId),$this->statePath($backupId),$this->partPath($backupId)] as $path)if(is_file($path)&&!@unlink($path))throw new MaintenanceException('vault_retention_delete_failed','Retention could not remove an expired backup file.',500,['backup_id'=>$backupId,'path_type'=>basename(dirname($path))]);
            $this->deleteDownloadSessionsForBackup($backupId);
            return ['backup_id'=>$backupId,'deleted'=>true,'idempotent'=>$tomb!==null,'expired_at'=>(string)(($tomb??[])['expired_at']??gmdate('c'))];
        });
    }

    private function verifiedRows(string $installationId): array
    {
        $out=[];$dir=$this->receiptsDir();if(!is_dir($dir))return [];
        foreach(glob($dir.'/*.json')?:[] as $path){$r=$this->readJsonLoose($path);if($r===null)continue;$meta=(array)($r['metadata']??[]);$id=(string)($r['backup_id']??'');if($id===''||$this->isTombstoned($id)||(string)($meta['source_installation_id']??'')!==$installationId)continue;$verified=(string)($r['verified_at']??'');if(strtotime($verified)===false)continue;$out[]=['backup_id'=>$id,'remote_receipt_id'=>(string)($r['remote_receipt_id']??''),'artifact_size'=>(int)($r['artifact_size']??0),'artifact_sha256'=>(string)($r['artifact_sha256']??''),'verified_at'=>$verified,'metadata'=>$meta];}
        return $out;
    }

    private function keepBuckets(array $rows,array &$keep,array &$reasons,string $class,int $limit): void
    {
        if($limit<=0)return;$seen=[];$count=0;
        foreach($rows as $row){$ts=strtotime((string)$row['verified_at']);if($ts===false)continue;$bucket=match($class){'daily'=>(new \DateTimeImmutable('@'.$ts))->setTimezone(new \DateTimeZone('Asia/Tehran'))->format('Y-m-d'),'weekly'=>(new \DateTimeImmutable('@'.$ts))->setTimezone(new \DateTimeZone('Asia/Tehran'))->format('o-W'),'monthly'=>(new \DateTimeImmutable('@'.$ts))->setTimezone(new \DateTimeZone('Asia/Tehran'))->format('Y-m'),default=>''};if($bucket===''||isset($seen[$bucket]))continue;$seen[$bucket]=true;$id=$row['backup_id'];$keep[$id]=true;$reasons[$id][]=$class.':'.$bucket;$count++;if($count>=$limit)break;}
    }

    private function activeDownloadBackupIds(string $installationId): array
    {
        $out=[];$dir=$this->downloadsDir();if(!is_dir($dir))return $out;$now=time();
        foreach(glob($dir.'/*.json')?:[] as $path){$r=$this->readJsonLoose($path);if($r===null)continue;$exp=strtotime((string)($r['expires_at']??''));if($exp===false||$exp<$now)continue;if((string)($r['installation_id']??'')!==$installationId)continue;$id=(string)($r['backup_id']??'');if($id!=='')$out[$id]=true;}
        return $out;
    }

    private function deleteDownloadSessionsForBackup(string $backupId): void
    {foreach(glob($this->downloadsDir().'/*.json')?:[] as $path){$r=$this->readJsonLoose($path);if($r!==null&&(string)($r['backup_id']??'')===$backupId)@unlink($path);}}

    private function readJsonLoose(string $path): ?array
    {$raw=@file_get_contents($path);if(!is_string($raw)||$raw==='')return null;try{$r=json_decode($raw,true,512,JSON_THROW_ON_ERROR);}catch(\JsonException){return null;}return is_array($r)?$r:null;}

    private function writeJsonAtomic(string $path,array $value): void
    {$dir=dirname($path);if(!is_dir($dir)&&!@mkdir($dir,0700,true)&&!is_dir($dir))throw new MaintenanceException('vault_storage_unavailable','Vault governance storage is unavailable.',500);@chmod($dir,0700);$tmp=$path.'.tmp.'.bin2hex(random_bytes(5));$json=json_encode($value,JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR)."\n";if(@file_put_contents($tmp,$json,LOCK_EX)===false)throw new MaintenanceException('vault_storage_write_failed','Vault governance state could not be written.',500);@chmod($tmp,0600);if(!@rename($tmp,$path)){@unlink($tmp);throw new MaintenanceException('vault_storage_write_failed','Vault governance state could not be committed.',500);}@chmod($path,0600);}

    private function withRetentionLock(string $installationId,callable $fn): mixed
    {$dir=$this->retentionLocksDir();if(!is_dir($dir)&&!@mkdir($dir,0700,true)&&!is_dir($dir))throw new MaintenanceException('vault_storage_unavailable','Retention lock storage is unavailable.',500);$h=@fopen($dir.'/'.hash('sha256',$installationId).'.lock','c+b');if(!$h)throw new MaintenanceException('vault_storage_unavailable','Retention lock is unavailable.',500);try{if(!flock($h,LOCK_EX))throw new MaintenanceException('vault_lock_failed','Retention lock failed.',503);return $fn();}finally{@flock($h,LOCK_UN);fclose($h);}}
    private function withBackupLock(string $backupId,callable $fn): mixed
    {$dir=$this->locksDir();if(!is_dir($dir)&&!@mkdir($dir,0700,true)&&!is_dir($dir))throw new MaintenanceException('vault_storage_unavailable','Vault lock storage is unavailable.',500);$h=@fopen($dir.'/'.$backupId.'.lock','c+b');if(!$h)throw new MaintenanceException('vault_storage_unavailable','Vault lock is unavailable.',500);try{if(!flock($h,LOCK_EX))throw new MaintenanceException('vault_lock_failed','Vault lock failed.',503);return $fn();}finally{@flock($h,LOCK_UN);fclose($h);}}

    private function validateRequestId(string $id): string{$id=trim($id);if(!preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]{7,127}$/D',$id))throw new MaintenanceException('vault_retention_request_invalid','Retention request id is invalid.',422);return $id;}
    private function vaultBase(): string{return rtrim($this->maintenanceBase,"\\/").'/remote-backup-vault-v1';}
    private function statesDir(): string{return $this->vaultBase().'/states';}
    private function partsDir(): string{return $this->vaultBase().'/incoming';}
    private function artifactsDir(): string{return $this->vaultBase().'/artifacts';}
    private function receiptsDir(): string{return $this->vaultBase().'/receipts';}
    private function locksDir(): string{return $this->vaultBase().'/locks';}
    private function downloadsDir(): string{return $this->vaultBase().'/downloads';}
    private function retentionDir(): string{return $this->vaultBase().'/retention';}
    private function retentionLocksDir(): string{return $this->retentionDir().'/locks';}
    private function runsDir(): string{return $this->retentionDir().'/runs';}
    private function tombstonesDir(): string{return $this->retentionDir().'/tombstones';}
    private function statePath(string $id): string{return $this->statesDir().'/'.$id.'.json';}
    private function partPath(string $id): string{return $this->partsDir().'/'.$id.'.part';}
    private function artifactPath(string $id): string{return $this->artifactsDir().'/'.$id.'.vault';}
    private function receiptPath(string $id): string{return $this->receiptsDir().'/'.$id.'.json';}
    private function tombstonePath(string $id): string{return $this->tombstonesDir().'/'.$id.'.json';}
    private function runPath(string $installationId,string $requestId): string{return $this->runsDir().'/'.hash('sha256',$installationId.'|'.$requestId).'.json';}
}
