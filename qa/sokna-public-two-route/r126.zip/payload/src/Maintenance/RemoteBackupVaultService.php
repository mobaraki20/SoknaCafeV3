<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Maintenance;

final class RemoteBackupVaultService
{
    public const CONTRACT='sokna-remote-backup-vault-v1';
    public const STATE_FORMAT='sokna-remote-backup-vault-state-v1';
    public const RECEIPT_FORMAT='sokna-remote-backup-vault-receipt-v1';

    public function __construct(
        private readonly PublicMaintenanceStorage $storage,
        private readonly ?VaultPolicyStore $policies=null,
        private readonly ?RemoteBackupVaultRetentionService $retention=null,
    ) {}

    public function begin(array $principal,array $meta): array
    {
        $meta=$this->normalizeMetadata($principal,$meta);
        $backupId=$meta['backup_id'];
        return $this->withLock($backupId,function()use($backupId,$meta,$principal){
            if($this->retention?->isTombstoned($backupId))throw new MaintenanceException('vault_backup_expired','Backup id was expired by server retention and cannot be reused.',410,['backup_id'=>$backupId]);
            $receipt=$this->readReceipt($backupId,false);
            if($receipt!==null){
                $this->assertPrincipalInstallation($principal,(array)($receipt['metadata']??[]));
                $this->assertSameArtifact($receipt,$meta);
                return ['ok'=>true,'state'=>'REMOTE_VERIFIED','backup_id'=>$backupId,'upload_session_id'=>(string)($receipt['upload_session_id']??''),'received_bytes'=>(int)$receipt['artifact_size'],'receipt'=>$receipt,'idempotent'=>true];
            }
            $state=$this->readState($backupId,false);
            if($state!==null){
                $this->assertPrincipalInstallation($principal,(array)($state['metadata']??[]));
                $this->assertSameArtifact($state,$meta);
                return $this->stateResponse($state,true);
            }
            if($this->policies!==null&&$this->retention!==null){
                $policy=$this->policies->get((string)$meta['source_installation_id'],true);
                $this->retention->assertCanReserve((string)$meta['source_installation_id'],$policy,$backupId,(int)$meta['artifact_size']);
            }
            $session='upl_'.bin2hex(random_bytes(16));
            $state=[
                'format'=>self::STATE_FORMAT,
                'contract'=>self::CONTRACT,
                'backup_id'=>$backupId,
                'upload_session_id'=>$session,
                'state'=>'REMOTE_UPLOADING',
                'expected_size'=>$meta['artifact_size'],
                'expected_sha256'=>$meta['artifact_sha256'],
                'received_bytes'=>0,
                'metadata'=>$meta,
                'created_at'=>$this->now(),
                'updated_at'=>$this->now(),
            ];
            $this->writeJsonAtomic($this->statePath($backupId),$state);
            $this->ensureEmptyPart($backupId);
            return $this->stateResponse($state,false);
        });
    }

    /** @param resource $input */
    public function appendChunk(array $principal,string $backupId,string $sessionId,int $offset,string $expectedChunkSha,$input): array
    {
        $backupId=$this->validateId($backupId,'backup_id');
        $sessionId=$this->validateSession($sessionId);
        $expectedChunkSha=$this->validateSha($expectedChunkSha,'chunk_sha256');
        if(!is_resource($input))throw new MaintenanceException('vault_chunk_input_invalid','Chunk input is invalid.',400);
        $policy=$principal['policy']??[];$maxChunk=(int)($policy['max_chunk_bytes']??0);
        if($maxChunk<1)throw new MaintenanceException('vault_policy_invalid','Chunk policy is invalid.',500);
        $tmp=$this->tmpPath($backupId);
        $out=@fopen($tmp,'wb');if(!$out)throw new MaintenanceException('vault_storage_unavailable','Could not stage upload chunk.',500);
        $hash=hash_init('sha256');$size=0;
        try{
            while(!feof($input)){
                $buf=fread($input,1024*1024);if($buf===false)throw new MaintenanceException('vault_chunk_read_failed','Could not read upload chunk.',400);
                if($buf==='')continue;
                $size+=strlen($buf);if($size>$maxChunk)throw new MaintenanceException('vault_chunk_too_large','Upload chunk exceeds configured policy.',413,['max_chunk_bytes'=>$maxChunk]);
                hash_update($hash,$buf);if(fwrite($out,$buf)!==strlen($buf))throw new MaintenanceException('vault_storage_write_failed','Could not stage upload chunk.',500);
            }
            fflush($out);if(function_exists('fsync'))@fsync($out);
        }finally{fclose($out);}
        $actualChunkSha=hash_final($hash);
        if(!hash_equals($expectedChunkSha,$actualChunkSha)){@unlink($tmp);throw new MaintenanceException('vault_chunk_hash_mismatch','Upload chunk hash does not match.',422);}
        try{
            return $this->withLock($backupId,function()use($principal,$backupId,$sessionId,$offset,$tmp,$size,$actualChunkSha){
                $receipt=$this->readReceipt($backupId,false);
                if($receipt!==null){
                    $this->assertPrincipalInstallation($principal,(array)($receipt['metadata']??[]));
                    if(!hash_equals((string)($receipt['upload_session_id']??''),$sessionId))
                        throw new MaintenanceException('vault_upload_session_mismatch','Upload session does not match.',409);
                    return ['ok'=>true,'state'=>'REMOTE_VERIFIED','backup_id'=>$backupId,'received_bytes'=>(int)$receipt['artifact_size'],'receipt'=>$receipt,'idempotent'=>true];
                }
                $state=$this->readState($backupId,true);
                $this->assertSession($state,$sessionId);
                $this->assertPrincipalInstallation($principal,(array)($state['metadata']??[]));
                if((string)($state['state']??'')!=='REMOTE_UPLOADING')throw new MaintenanceException('vault_upload_state_invalid','Backup is not accepting chunks.',409);
                $received=(int)($state['received_bytes']??0);
                $expectedSize=(int)($state['expected_size']??0);
                if($offset<0||$offset>$expectedSize)throw new MaintenanceException('vault_offset_invalid','Upload offset is invalid.',409,['expected_offset'=>$received]);
                if($offset>$received)throw new MaintenanceException('vault_offset_mismatch','Upload offset is ahead of durable data.',409,['expected_offset'=>$received]);
                $part=$this->partPath($backupId);
                if($offset<$received){
                    if($offset+$size>$received)throw new MaintenanceException('vault_offset_overlap','Chunk overlaps the current durable boundary.',409,['expected_offset'=>$received]);
                    $existing=$this->hashSegment($part,$offset,$size);
                    if(!hash_equals($existing,$actualChunkSha))throw new MaintenanceException('vault_chunk_replay_conflict','Replayed chunk differs from durable bytes.',409,['expected_offset'=>$received]);
                    return $this->stateResponse($state,true)+['idempotent_chunk_replay'=>true];
                }
                if($received+$size>$expectedSize)throw new MaintenanceException('vault_artifact_size_exceeded','Chunk would exceed declared artifact size.',413);
                $src=@fopen($tmp,'rb');$dst=@fopen($part,'c+b');
                if(!$src||!$dst){if(is_resource($src))fclose($src);if(is_resource($dst))fclose($dst);throw new MaintenanceException('vault_storage_unavailable','Could not open durable upload artifact.',500);}
                try{
                    if(fseek($dst,$received)!==0)throw new MaintenanceException('vault_storage_write_failed','Could not seek durable upload artifact.',500);
                    $copied=stream_copy_to_stream($src,$dst);
                    if($copied!==$size)throw new MaintenanceException('vault_storage_write_failed','Could not append full upload chunk.',500);
                    fflush($dst);if(function_exists('fsync'))@fsync($dst);
                }finally{fclose($src);fclose($dst);}
                $state['received_bytes']=$received+$size;$state['updated_at']=$this->now();
                $this->writeJsonAtomic($this->statePath($backupId),$state);
                return $this->stateResponse($state,false);
            });
        }finally{@unlink($tmp);}
    }

    public function finalize(array $principal,string $backupId,string $sessionId): array
    {
        $backupId=$this->validateId($backupId,'backup_id');$sessionId=$this->validateSession($sessionId);
        return $this->withLock($backupId,function()use($principal,$backupId,$sessionId){
            if($this->retention?->isTombstoned($backupId))throw new MaintenanceException('vault_backup_expired','Backup was expired by server retention.',410,['backup_id'=>$backupId]);
            $receipt=$this->readReceipt($backupId,false);
            if($receipt!==null){
                $this->assertPrincipalInstallation($principal,(array)($receipt['metadata']??[]));
                if(!hash_equals((string)($receipt['upload_session_id']??''),$sessionId))
                    throw new MaintenanceException('vault_upload_session_mismatch','Upload session does not match.',409);
                return ['ok'=>true,'state'=>'REMOTE_VERIFIED','backup_id'=>$backupId,'receipt'=>$receipt,'idempotent'=>true];
            }
            $state=$this->readState($backupId,true);$this->assertSession($state,$sessionId);$this->assertPrincipalInstallation($principal,(array)($state['metadata']??[]));
            $expectedSize=(int)$state['expected_size'];$received=(int)$state['received_bytes'];
            if($received!==$expectedSize)throw new MaintenanceException('vault_upload_incomplete','Backup upload is incomplete.',409,['received_bytes'=>$received,'expected_size'=>$expectedSize]);
            $part=$this->partPath($backupId);$artifact=$this->artifactPath($backupId);
            $candidate=is_file($part)?$part:(is_file($artifact)?$artifact:'');
            if($candidate==='')throw new MaintenanceException('vault_upload_missing','Backup upload artifact is missing.',409);
            $actualSize=(int)filesize($candidate);if($actualSize!==$expectedSize)throw new MaintenanceException('vault_artifact_size_mismatch','Backup artifact size does not match declared size.',422);
            $actualSha=(string)hash_file('sha256',$candidate);if(!hash_equals((string)$state['expected_sha256'],$actualSha))throw new MaintenanceException('vault_artifact_hash_mismatch','Backup artifact hash does not match declared hash.',422);
            if(is_file($artifact)){
                if((int)filesize($artifact)!==$expectedSize||!hash_equals($actualSha,(string)hash_file('sha256',$artifact)))throw new MaintenanceException('vault_artifact_conflict','Verified artifact path already contains different bytes.',409);
                if(is_file($part))@unlink($part);
            }elseif(!@rename($part,$artifact))throw new MaintenanceException('vault_finalize_failed','Could not promote verified backup artifact.',500);
            @chmod($artifact,0600);
            $verifiedAt=$this->now();
            $receipt=[
                'format'=>self::RECEIPT_FORMAT,
                'contract'=>self::CONTRACT,
                'remote_receipt_id'=>'rct_'.substr(hash('sha256',$backupId."\0".$actualSha),0,40),
                'backup_id'=>$backupId,
                'upload_session_id'=>$sessionId,
                'artifact_size'=>$expectedSize,
                'artifact_sha256'=>$actualSha,
                'verified_at'=>$verifiedAt,
                'metadata'=>$state['metadata'],
            ];
            $this->writeJsonAtomic($this->receiptPath($backupId),$receipt);
            $state['state']='REMOTE_VERIFIED';$state['verified_at']=$verifiedAt;$state['updated_at']=$verifiedAt;
            $this->writeJsonAtomic($this->statePath($backupId),$state);
            $retentionResult=null;
            if($this->policies!==null&&$this->retention!==null){
                try{
                    $policy=$this->policies->get((string)($state['metadata']['source_installation_id']??''),true);
                    $retentionResult=$this->retention->autoApplyAfterVerified((string)$state['metadata']['source_installation_id'],$policy,$backupId);
                }catch(MaintenanceException $e){
                    $retentionResult=['ok'=>false,'state'=>'RETENTION_DEGRADED','error'=>$e->errorCode,'context'=>$e->context];
                }
            }
            return ['ok'=>true,'state'=>'REMOTE_VERIFIED','backup_id'=>$backupId,'receipt'=>$receipt,'idempotent'=>false,'retention'=>$retentionResult];
        });
    }

    public function uploadStatus(array $principal,string $backupId): array
    {
        $backupId=$this->validateId($backupId,'backup_id');
        if($this->retention?->isTombstoned($backupId))throw new MaintenanceException('vault_backup_expired','Backup was expired by server retention.',410,['backup_id'=>$backupId]);
        $receipt=$this->readReceipt($backupId,false);
        if($receipt!==null){$this->assertPrincipalInstallation($principal,(array)($receipt['metadata']??[]));return ['ok'=>true,'state'=>'REMOTE_VERIFIED','backup_id'=>$backupId,'receipt'=>$receipt];}
        $state=$this->readState($backupId,true);$this->assertPrincipalInstallation($principal,(array)($state['metadata']??[]));return $this->stateResponse($state,true);
    }

    public function inventory(array $principal,int $limit=50): array
    {
        $limit=max(1,min(100,$limit));$dir=$this->receiptsDir();$rows=[];
        if(is_dir($dir))foreach(glob($dir.'/*.json')?:[] as $path){
            $raw=@file_get_contents($path);if(!is_string($raw))continue;
            try{$receipt=json_decode($raw,true,512,JSON_THROW_ON_ERROR);}catch(\JsonException){continue;}
            if(!is_array($receipt))continue;
            $id=(string)($receipt['backup_id']??'');if($id!==''&&$this->retention?->isTombstoned($id))continue;
            $meta=(array)($receipt['metadata']??[]);
            if((string)($meta['source_installation_id']??'')!==(string)$principal['installation_id'])continue;
            $rows[]=[
                'backup_id'=>(string)($receipt['backup_id']??''),
                'remote_receipt_id'=>(string)($receipt['remote_receipt_id']??''),
                'artifact_size'=>(int)($receipt['artifact_size']??0),
                'artifact_sha256'=>(string)($receipt['artifact_sha256']??''),
                'verified_at'=>(string)($receipt['verified_at']??''),
                'format_version'=>(string)($meta['format_version']??''),
                'source_release'=>(array)($meta['source_release']??[]),
                'protection'=>(array)($meta['protection']??[]),
            ];
        }
        usort($rows,fn($a,$b)=>strcmp((string)$b['verified_at'],(string)$a['verified_at']));
        return ['ok'=>true,'contract'=>self::CONTRACT,'state'=>'INVENTORY','items'=>array_slice($rows,0,$limit),'count'=>min(count($rows),$limit)];
    }


    public function beginDownload(array $principal,string $backupId): array
    {
        $backupId=$this->validateId($backupId,'backup_id');
        if($this->retention?->isTombstoned($backupId))throw new MaintenanceException('vault_backup_expired','Backup was expired by server retention.',410,['backup_id'=>$backupId]);
        return $this->withLock($backupId,function()use($principal,$backupId){
            $receipt=$this->readReceipt($backupId,true);$this->assertPrincipalInstallation($principal,(array)($receipt['metadata']??[]));
            $artifact=$this->artifactPath($backupId);if(!is_file($artifact))throw new MaintenanceException('vault_artifact_missing','Verified backup artifact is missing.',409);
            $expectedSize=(int)($receipt['artifact_size']??0);$expectedSha=$this->validateSha((string)($receipt['artifact_sha256']??''),'artifact_sha256');
            $actualSize=(int)filesize($artifact);if($actualSize!==$expectedSize)throw new MaintenanceException('vault_artifact_size_mismatch','Verified backup artifact size changed.',409);
            $actualSha=(string)hash_file('sha256',$artifact);if(!hash_equals($expectedSha,$actualSha))throw new MaintenanceException('vault_artifact_hash_mismatch','Verified backup artifact integrity check failed.',409);
            $session='dls_'.bin2hex(random_bytes(16));$now=time();$state=[
                'format'=>'sokna-remote-backup-vault-download-v1','backup_id'=>$backupId,'download_session_id'=>$session,
                'credential_id'=>(string)($principal['credential_id']??''),'installation_id'=>(string)($principal['installation_id']??''),
                'artifact_size'=>$expectedSize,'artifact_sha256'=>$expectedSha,'remote_receipt_id'=>(string)($receipt['remote_receipt_id']??''),
                'created_at'=>gmdate('c',$now),'expires_at'=>gmdate('c',$now+900),
            ];
            $this->writeJsonAtomic($this->downloadPath($session),$state);
            return ['ok'=>true,'state'=>'DOWNLOAD_READY','backup_id'=>$backupId,'download_session_id'=>$session,'artifact_size'=>$expectedSize,'artifact_sha256'=>$expectedSha,'remote_receipt_id'=>$state['remote_receipt_id'],'expires_at'=>$state['expires_at']];
        });
    }

    public function downloadStatus(array $principal,string $backupId,string $sessionId): array
    {
        $backupId=$this->validateId($backupId,'backup_id');$sessionId=$this->validateDownloadSession($sessionId);$state=$this->readDownloadState($sessionId);$this->assertDownloadPrincipal($principal,$state,$backupId);
        return ['ok'=>true,'state'=>'DOWNLOAD_READY','backup_id'=>$backupId,'download_session_id'=>$sessionId,'artifact_size'=>(int)$state['artifact_size'],'artifact_sha256'=>(string)$state['artifact_sha256'],'remote_receipt_id'=>(string)$state['remote_receipt_id'],'expires_at'=>(string)$state['expires_at']];
    }

    public function downloadChunkDescriptor(array $principal,string $backupId,string $sessionId,int $offset,int $length): array
    {
        $backupId=$this->validateId($backupId,'backup_id');$sessionId=$this->validateDownloadSession($sessionId);$state=$this->readDownloadState($sessionId);$this->assertDownloadPrincipal($principal,$state,$backupId);
        $size=(int)$state['artifact_size'];$max=(int)(($principal['policy']??[])['max_chunk_bytes']??0);if($max<1)throw new MaintenanceException('vault_policy_invalid','Vault chunk policy is invalid.',500);
        if($offset<0||$offset>=$size)throw new MaintenanceException('vault_download_offset_invalid','Download offset is invalid.',416,['artifact_size'=>$size]);
        if($length<1)$length=min($max,$size-$offset);$length=min($length,$max,$size-$offset);
        $artifact=$this->artifactPath($backupId);if(!is_file($artifact)||(int)filesize($artifact)!==$size)throw new MaintenanceException('vault_artifact_missing','Verified backup artifact is unavailable.',409);
        return ['path'=>$artifact,'offset'=>$offset,'length'=>$length,'artifact_size'=>$size,'artifact_sha256'=>(string)$state['artifact_sha256'],'remote_receipt_id'=>(string)$state['remote_receipt_id'],'download_session_id'=>$sessionId];
    }

    private function normalizeMetadata(array $principal,array $meta): array
    {
        $backupId=$this->validateId((string)($meta['backup_id']??''),'backup_id');
        $size=(int)($meta['artifact_size']??0);$sha=$this->validateSha((string)($meta['artifact_sha256']??''),'artifact_sha256');
        $policy=$principal['policy']??[];$max=(int)($policy['max_artifact_bytes']??0);
        if($size<1||$max<1||$size>$max)throw new MaintenanceException('vault_artifact_size_rejected','Backup artifact size is outside configured policy.',413,['max_artifact_bytes'=>$max]);
        $installation=trim((string)($meta['source_installation_id']??''));
        if($installation===''||$installation!==(string)$principal['installation_id'])throw new MaintenanceException('vault_installation_mismatch','Backup installation identity does not match credential binding.',403);
        $format=trim((string)($meta['format_version']??''));if($format===''||strlen($format)>100)throw new MaintenanceException('vault_metadata_invalid','Backup format version is invalid.',422);
        $business=trim((string)($meta['business_id']??''));if(strlen($business)>160)throw new MaintenanceException('vault_metadata_invalid','Business identity is invalid.',422);
        $created=$this->validateTimestamp((string)($meta['created_at']??''),'created_at');$completed=$this->validateTimestamp((string)($meta['completed_at']??''),'completed_at');
        $release=$meta['source_release']??null;if(!is_array($release))throw new MaintenanceException('vault_metadata_invalid','Source release metadata is missing.',422);
        $version=trim((string)($release['version']??''));$tree=strtolower(trim((string)($release['managed_tree_sha256']??'')));
        if($version===''||strlen($version)>180||!preg_match('/^[a-f0-9]{64}$/',$tree))throw new MaintenanceException('vault_metadata_invalid','Source release metadata is invalid.',422);
        $protection=$meta['protection']??null;if(!is_array($protection)||($protection['encrypted']??false)!==true)throw new MaintenanceException('vault_ciphertext_required','Remote Vault accepts encrypted backup artifacts only.',422);
        $suite=trim((string)($protection['suite']??''));$keyId=trim((string)($protection['key_id']??''));
        if($suite===''||$keyId===''||strlen($suite)>120||strlen($keyId)>160)throw new MaintenanceException('vault_metadata_invalid','Backup protection metadata is invalid.',422);
        return [
            'backup_id'=>$backupId,'artifact_size'=>$size,'artifact_sha256'=>$sha,'format_version'=>$format,
            'source_installation_id'=>$installation,'business_id'=>$business,'source_release'=>['version'=>$version,'managed_tree_sha256'=>$tree,'release_id'=>trim((string)($release['release_id']??''))],
            'created_at'=>$created,'completed_at'=>$completed,
            'protection'=>['encrypted'=>true,'suite'=>$suite,'key_id'=>$keyId],
        ];
    }

    private function assertPrincipalInstallation(array $principal,array $meta): void
    {if((string)($meta['source_installation_id']??'')!==(string)($principal['installation_id']??''))throw new MaintenanceException('vault_scope_forbidden','Credential is not authorized for this backup.',403);}
    private function assertSameArtifact(array $row,array $meta): void
    {if((string)($row['backup_id']??'')!==$meta['backup_id']||(int)($row['artifact_size']??$row['expected_size']??0)!==$meta['artifact_size']||(string)($row['artifact_sha256']??$row['expected_sha256']??'')!==$meta['artifact_sha256']
      ||(string)($row['metadata']['source_installation_id']??'')!==$meta['source_installation_id'])throw new MaintenanceException('vault_backup_identity_conflict','Backup id is already bound to different artifact bytes.',409);}
    private function assertSession(array $state,string $session): void
    {if(!hash_equals((string)($state['upload_session_id']??''),$session))throw new MaintenanceException('vault_upload_session_mismatch','Upload session does not match.',409);}
    private function stateResponse(array $state,bool $idempotent): array
    {return ['ok'=>true,'state'=>(string)$state['state'],'backup_id'=>(string)$state['backup_id'],'upload_session_id'=>(string)$state['upload_session_id'],'received_bytes'=>(int)$state['received_bytes'],'expected_size'=>(int)$state['expected_size'],
      'expected_sha256'=>(string)($state['expected_sha256']??''),
      'source_installation_id'=>(string)($state['metadata']['source_installation_id']??''),
      'idempotent'=>$idempotent];}

    private function validateId(string $v,string $field): string
    {$v=trim($v);if(!preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]{7,127}$/',$v))throw new MaintenanceException('vault_metadata_invalid',"Invalid {$field}.",422);return $v;}
    private function validateSession(string $v): string
    {$v=trim($v);if(!preg_match('/^upl_[a-f0-9]{32}$/',$v))throw new MaintenanceException('vault_upload_session_invalid','Upload session is invalid.',422);return $v;}
    private function validateDownloadSession(string $v): string
    {$v=trim($v);if(!preg_match('/^dls_[a-f0-9]{32}$/',$v))throw new MaintenanceException('vault_download_session_invalid','Download session is invalid.',422);return $v;}
    private function validateSha(string $v,string $field): string
    {$v=strtolower(trim($v));if(!preg_match('/^[a-f0-9]{64}$/',$v))throw new MaintenanceException('vault_metadata_invalid',"Invalid {$field}.",422);return $v;}
    private function validateTimestamp(string $v,string $field): string
    {$v=trim($v);if($v===''||strtotime($v)===false||strlen($v)>80)throw new MaintenanceException('vault_metadata_invalid',"Invalid {$field}.",422);return $v;}

    private function withLock(string $backupId,callable $fn): mixed
    {
        $this->ensureVaultDirs();$lock=@fopen($this->locksDir().'/'.$backupId.'.lock','c+b');if(!$lock)throw new MaintenanceException('vault_storage_unavailable','Could not open Vault lock.',500);
        try{if(!flock($lock,LOCK_EX))throw new MaintenanceException('vault_lock_failed','Could not acquire Vault lock.',503);return $fn();}finally{@flock($lock,LOCK_UN);fclose($lock);}
    }
    private function ensureVaultDirs(): void
    {foreach([$this->vaultBase(),$this->statesDir(),$this->partsDir(),$this->artifactsDir(),$this->receiptsDir(),$this->locksDir(),$this->tmpDir(),$this->downloadsDir()] as $d){if(!is_dir($d)&&!@mkdir($d,0700,true)&&!is_dir($d))throw new MaintenanceException('vault_storage_unavailable','Could not create Vault storage.',500);@chmod($d,0700);}}
    private function ensureEmptyPart(string $id): void{$p=$this->partPath($id);if(!is_file($p)){if(@file_put_contents($p,'',LOCK_EX)===false)throw new MaintenanceException('vault_storage_unavailable','Could not create upload artifact.',500);@chmod($p,0600);}}
    private function readState(string $id,bool $required): ?array{return $this->readJson($this->statePath($id),$required,'vault_upload_not_found');}
    private function readReceipt(string $id,bool $required): ?array{return $this->readJson($this->receiptPath($id),$required,'vault_receipt_not_found');}
    private function readJson(string $path,bool $required,string $missing): ?array
    {$raw=@file_get_contents($path);if(!is_string($raw)){if($required)throw new MaintenanceException($missing,'Vault record was not found.',404);return null;}try{$v=json_decode($raw,true,512,JSON_THROW_ON_ERROR);}catch(\JsonException){throw new MaintenanceException('vault_state_corrupt','Vault state is corrupt.',500);}if(!is_array($v))throw new MaintenanceException('vault_state_corrupt','Vault state is corrupt.',500);return $v;}
    private function writeJsonAtomic(string $path,array $value): void
    {$dir=dirname($path);if(!is_dir($dir)&&!@mkdir($dir,0700,true)&&!is_dir($dir))throw new MaintenanceException('vault_storage_unavailable','Vault storage is unavailable.',500);$tmp=$path.'.tmp.'.bin2hex(random_bytes(6));$json=json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR)."\n";if(@file_put_contents($tmp,$json,LOCK_EX)===false)throw new MaintenanceException('vault_storage_write_failed','Could not persist Vault state.',500);@chmod($tmp,0600);if(!@rename($tmp,$path)){@unlink($tmp);throw new MaintenanceException('vault_storage_write_failed','Could not commit Vault state.',500);} }
    private function hashSegment(string $path,int $offset,int $length): string
    {$h=@fopen($path,'rb');if(!$h)throw new MaintenanceException('vault_storage_unavailable','Could not read durable upload artifact.',500);$ctx=hash_init('sha256');try{if(fseek($h,$offset)!==0)throw new MaintenanceException('vault_storage_unavailable','Could not seek durable upload artifact.',500);$left=$length;while($left>0){$buf=fread($h,min(1024*1024,$left));if($buf===false||$buf==='')throw new MaintenanceException('vault_storage_unavailable','Could not read durable upload artifact.',500);$left-=strlen($buf);hash_update($ctx,$buf);}}finally{fclose($h);}return hash_final($ctx);}

    private function readDownloadState(string $session): array
    {$row=$this->readJson($this->downloadPath($session),true,'vault_download_session_not_found');$expires=strtotime((string)($row['expires_at']??''));if($expires===false||$expires<time()){ @unlink($this->downloadPath($session)); throw new MaintenanceException('vault_download_session_expired','Download session expired.',401); }return $row;}
    private function assertDownloadPrincipal(array $principal,array $state,string $backupId): void
    {if((string)($state['backup_id']??'')!==$backupId||(string)($state['installation_id']??'')!==(string)($principal['installation_id']??'')||(string)($state['credential_id']??'')!==(string)($principal['credential_id']??''))throw new MaintenanceException('vault_scope_forbidden','Credential is not authorized for this download session.',403);}
    private function now(): string{return gmdate('Y-m-d\TH:i:s\Z');}
    private function vaultBase(): string{return rtrim($this->storage->ensureBase(),"\\/").'/remote-backup-vault-v1';}
    private function statesDir(): string{return $this->vaultBase().'/states';}
    private function partsDir(): string{return $this->vaultBase().'/incoming';}
    private function artifactsDir(): string{return $this->vaultBase().'/artifacts';}
    private function receiptsDir(): string{return $this->vaultBase().'/receipts';}
    private function locksDir(): string{return $this->vaultBase().'/locks';}
    private function tmpDir(): string{return $this->vaultBase().'/tmp';}
    private function downloadsDir(): string{return $this->vaultBase().'/downloads';}
    private function statePath(string $id): string{return $this->statesDir().'/'.$id.'.json';}
    private function partPath(string $id): string{return $this->partsDir().'/'.$id.'.part';}
    private function artifactPath(string $id): string{return $this->artifactsDir().'/'.$id.'.vault';}
    private function receiptPath(string $id): string{return $this->receiptsDir().'/'.$id.'.json';}
    private function tmpPath(string $id): string{$this->ensureVaultDirs();return $this->tmpDir().'/'.$id.'.'.bin2hex(random_bytes(8)).'.chunk';}
    private function downloadPath(string $session): string{$this->ensureVaultDirs();return $this->downloadsDir().'/'.$session.'.json';}
}
