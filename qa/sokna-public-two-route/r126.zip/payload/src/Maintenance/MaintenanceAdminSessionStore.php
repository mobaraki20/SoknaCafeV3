<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Maintenance;

final class MaintenanceAdminSessionStore
{
    public const FORMAT='sokna-maintenance-admin-session-v1';
    private const TTL_SECONDS=600;

    public function __construct(private readonly string $maintenanceBase) {}

    public function issue(string $clientFingerprint,string $actorHint): array
    {
        $id='madm_'.bin2hex(random_bytes(12));
        $secret=$this->b64(random_bytes(32));
        $now=time();
        $row=[
            'format'=>self::FORMAT,
            'id'=>$id,
            'secret_sha256'=>hash('sha256',$secret),
            'client_sha256'=>hash('sha256',$clientFingerprint),
            'actor_hint'=>substr(trim($actorHint),0,120),
            'created_at'=>gmdate('c',$now),
            'expires_at'=>gmdate('c',$now+self::TTL_SECONDS),
        ];
        $dir=$this->dir();$this->mkdir($dir);$this->writeAtomic($dir.'/'.$id.'.json',$row);
        return ['ok'=>true,'admin_session'=>$id.'.'.$secret,'expires_at'=>$row['expires_at'],'expires_in_seconds'=>self::TTL_SECONDS];
    }

    public function authenticate(string $token,string $clientFingerprint): array
    {
        $token=trim($token);
        if(!preg_match('/^(madm_[a-f0-9]{24})\.([A-Za-z0-9_-]{40,80})$/D',$token,$m))throw new MaintenanceException('maintenance_admin_unauthorized','Maintenance admin session is invalid.',401);
        $path=$this->dir().'/'.$m[1].'.json';
        $row=$this->read($path);
        if((string)($row['format']??'')!==self::FORMAT)throw new MaintenanceException('maintenance_admin_unauthorized','Maintenance admin session is invalid.',401);
        $expires=strtotime((string)($row['expires_at']??''));
        if($expires===false||$expires<time()){ @unlink($path); throw new MaintenanceException('maintenance_admin_expired','Maintenance admin session expired.',401); }
        $stored=(string)($row['secret_sha256']??'');$actual=hash('sha256',$m[2]);
        if(!preg_match('/^[a-f0-9]{64}$/',$stored)||!hash_equals($stored,$actual))throw new MaintenanceException('maintenance_admin_unauthorized','Maintenance admin session is invalid.',401);
        $client=(string)($row['client_sha256']??'');
        if(!preg_match('/^[a-f0-9]{64}$/',$client)||!hash_equals($client,hash('sha256',$clientFingerprint)))throw new MaintenanceException('maintenance_admin_client_mismatch','Maintenance admin session client binding changed.',401);
        return ['id'=>$m[1],'actor_hint'=>(string)($row['actor_hint']??'maintenance-admin'),'expires_at'=>(string)$row['expires_at']];
    }

    public function revoke(string $token): void
    {
        if(preg_match('/^(madm_[a-f0-9]{24})\./D',trim($token),$m))@unlink($this->dir().'/'.$m[1].'.json');
    }

    private function dir(): string{return rtrim($this->maintenanceBase,"\\/").'/admin-sessions';}
    private function mkdir(string $dir): void{if(!is_dir($dir)&&!@mkdir($dir,0700,true)&&!is_dir($dir))throw new MaintenanceException('maintenance_admin_storage_unavailable','Maintenance admin storage is unavailable.',500);@chmod($dir,0700);}
    private function read(string $path): array{$raw=@file_get_contents($path);if(!is_string($raw))throw new MaintenanceException('maintenance_admin_unauthorized','Maintenance admin session is invalid.',401);try{$v=json_decode($raw,true,32,JSON_THROW_ON_ERROR);}catch(\JsonException){throw new MaintenanceException('maintenance_admin_unauthorized','Maintenance admin session is invalid.',401);}return is_array($v)?$v:[];}
    private function writeAtomic(string $path,array $row): void{$tmp=$path.'.tmp.'.bin2hex(random_bytes(4));$json=json_encode($row,JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR)."\n";if(@file_put_contents($tmp,$json,LOCK_EX)===false)throw new MaintenanceException('maintenance_admin_storage_unavailable','Maintenance admin state could not be written.',500);@chmod($tmp,0600);if(!@rename($tmp,$path)){@unlink($tmp);throw new MaintenanceException('maintenance_admin_storage_unavailable','Maintenance admin state could not be committed.',500);}}
    private function b64(string $raw): string{return rtrim(strtr(base64_encode($raw),'+/','-_'),'=');}
}
