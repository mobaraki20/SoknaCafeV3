<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Maintenance;

use Throwable;

/**
 * F1-S7E5C. Read-only Public Maintenance receipt producer. Disabled by default.
 * It cannot create authority state or private keys. A future stable Public
 * authority owner must write a fresh, externally held installed-state snapshot.
 * No mutation/activation consent is ever issued here.
 */
final class PublicSignedReleaseAttestation
{
    public const FORMAT='sokna-public-kernel-observation-v1';
    private const DOMAIN="SOKNA-PUBLIC-KERNEL-READONLY-CHALLENGE-V1\n";

    public function __construct(
        private readonly string $componentRoot,
        private readonly string $maintenanceStorageRoot,
    ) {}

    /** @param array<string,mixed> $settings @param array<string,string> $server */
    public function attest(array $settings,array $server,?callable $trustedObservation=null): array
    {
        if(($settings['enabled']??false)!==true) $this->reject('release_attestation_disabled');
        if(!extension_loaded('openssl'))$this->reject('release_signer_unavailable');
        $rootReal=realpath($this->componentRoot);
        $storageReal=realpath($this->maintenanceStorageRoot);
        if($rootReal===false||$storageReal===false||$storageReal===$rootReal
            ||str_starts_with($storageReal,$rootReal.'/'))
            $this->reject('release_attestation_storage_unavailable');
        // HTTP_HOST / X-Forwarded-Proto are NOT TLS proofs. Loopback is
        // accepted only for a verified local-to-local engineering fixture.
        $tls=strtolower((string)($server['HTTPS']??''));
        $isTls=($tls!==''&&$tls!=='off')||(int)($server['SERVER_PORT']??0)===443;
        $loopback=PHP_SAPI==='cli-server'
            &&in_array((string)($server['REMOTE_ADDR']??''),['127.0.0.1','::1'],true)
            &&(bool)preg_match('/^127\.0\.0\.1:[0-9]{1,5}$/D',(string)($server['HTTP_HOST']??''));
        if(!$isTls&&!$loopback)$this->reject('release_attestation_https_required');
        $nonce=(string)($server['HTTP_X_SOKNA_NONCE']??'');
        $request=(string)($server['HTTP_X_SOKNA_REQUEST_ID']??'');
        foreach([$nonce,$request] as $value)
            if(!preg_match('/^[0-9a-f]{32}$/D',$value))$this->reject('release_attestation_bad_challenge');
        if($nonce===$request)$this->reject('release_attestation_bad_challenge');

        $keyId=(string)($settings['key_id']??'');
        if(!preg_match('/^[A-Za-z0-9._-]{1,64}$/D',$keyId))$this->reject('release_attestation_key_unavailable');
        $privateFile=$this->externalFile((string)($settings['private_key_file']??''));
        $stateFile=$this->externalFile((string)($settings['authority_snapshot_file']??''));
        if($privateFile===$stateFile)$this->reject('release_attestation_key_unavailable');
        $private=openssl_pkey_get_private('file://'.$privateFile);
        if($private===false)$this->reject('release_attestation_key_unavailable');
        $key=openssl_pkey_get_details($private);
        if(!is_array($key)||($key['type']??null)!==OPENSSL_KEYTYPE_EC||($key['bits']??0)!==256
            ||($key['ec']['curve_name']??'')!=='prime256v1')
            $this->reject('release_attestation_key_invalid');

        $blob=file_get_contents($stateFile);
        if(!is_string($blob)||strlen($blob)>32768||strlen($blob)<32)
            $this->reject('release_attestation_authority_unavailable');
        try{$state=json_decode($blob,true,32,JSON_THROW_ON_ERROR);}catch(Throwable){$this->reject('release_attestation_authority_unavailable');}
        if(!is_array($state)||($state['format']??'')!=='sokna-public-stable-authority-snapshot-v1'
            ||($state['verified']??false)!==true)
            $this->reject('release_attestation_authority_unavailable');
        $now=time();
        if(!is_int($state['captured_unix']??null))
            $this->reject('release_attestation_authority_invalid');
        if($state['captured_unix']<$now-15||$state['captured_unix']>$now+5)
            $this->reject('release_attestation_authority_stale');
        $installed=(string)($state['installation_id']??'');
        $set=(string)($state['active_release_set_id']??'');
        $protocol=(string)($state['protocol_version']??'');
        $epoch=$state['authority_epoch']??null;
        $generation=$state['install_generation']??null;
        $sequence=$state['release_sequence']??null;
        $schema=(string)($state['schema_fingerprint']??'');
        $tree=(string)($state['active_tree_sha256']??'');
        $lifecycle=(string)($state['lifecycle_state']??'');
        $appHealth=(string)($state['app_health']??'');
        if(!preg_match('/^[A-Za-z0-9._:-]{1,128}$/D',$installed)
            ||!preg_match('/^[A-Za-z0-9._:-]{1,192}$/D',$set)
            ||!preg_match('/^[A-Za-z0-9._-]{1,32}$/D',$protocol)
            ||!is_int($epoch)||$epoch<1||!is_int($generation)||$generation<1
            ||!is_int($sequence)||$sequence<1
            ||!preg_match('/^[a-f0-9]{64}$/D',$schema)
            ||!preg_match('/^[a-f0-9]{64}$/D',$tree)
            ||!in_array($lifecycle,['idle','staged','maintenance','recovery'],true)
            ||!in_array($appHealth,['healthy','degraded','unavailable'],true)
            ||($state['mutation_fenced']??false)!==true)
            $this->reject('release_attestation_authority_invalid');
        // Verify against bytes in the current PUBLIC component. The source
        // identity is not by itself sufficient authority; independent epoch
        // and DB-schema claims come from the stable owner's fresh snapshot.
        $identity=$this->sourceIdentity();
        if($identity['release_set_id']!==$set||$identity['tree']!==$tree)
            $this->reject('release_attestation_disk_drift');
        $this->verifyManagedManifest($tree);
        // F1-S7E5D1A: a self-asserted `verified=true` snapshot MUST NOT be
        // enough. Recheck the authenticated stable commit, live Public DB
        // epoch/migration ledger and both updater histories at signing time.
        // Missing owner/keys/DB/qualified adoption always fails closed.
        if($trustedObservation===null)$this->reject('release_attestation_owner_unavailable');
        try{$trusted=$trustedObservation();}
        catch(Throwable){$this->reject('release_attestation_owner_unavailable');}
        if(!is_array($trusted))$this->reject('release_attestation_owner_unavailable');
        foreach(['format','verified','installation_id','authority_epoch',
            'install_generation','active_release_set_id','release_sequence',
            'active_tree_sha256','schema_fingerprint','protocol_version',
            'lifecycle_state','app_health','mutation_fenced'] as $f){
            if(!array_key_exists($f,$trusted)||!array_key_exists($f,$state)
                ||$trusted[$f]!==$state[$f])$this->reject('release_attestation_owner_mismatch');
        }
        if(!is_int($trusted['captured_unix']??null)
            ||abs($now-$trusted['captured_unix'])>5)$this->reject('release_attestation_owner_stale');
        // Separate replay ledger from application state; no Business DB calls.
        $this->burnNonce($nonce,$now);
        $issued=621355968000000000+$now*10000000;
        $fields=[
            'format'=>self::FORMAT,'key_id'=>$keyId,'nonce'=>$nonce,'request_id'=>$request,
            'issued_utc_ticks'=>$issued,'expires_utc_ticks'=>$issued+300000000,
            'installation_id'=>$installed,'authority_epoch'=>$epoch,
            'install_generation'=>$generation,'active_release_set_id'=>$set,
            'release_sequence'=>$sequence,'active_tree_sha256'=>$tree,
            'schema_fingerprint'=>$schema,'protocol_version'=>$protocol,
            'kernel_health'=>'healthy','app_health'=>$appHealth,'lifecycle_state'=>$lifecycle,
            'stage_signed_verified'=>false,'exact_base_verified'=>false,
            'mutation_fenced'=>true,'execution_authorized'=>false,'signature'=>'',
        ];
        $bytes=self::DOMAIN.json_encode($fields,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
        if(!openssl_sign($bytes,$sig,$private,OPENSSL_ALGO_SHA256))
            $this->reject('release_attestation_sign_failed');
        if(strlen($sig)<68||strlen($sig)>72)$this->reject('release_attestation_signature_invalid');
        $fields['signature']=base64_encode($sig);
        return $fields;
    }

    private function sourceIdentity(): array
    {
        $f=$this->componentRoot.'/resources/release-identity-v1.json';
        $data=@file_get_contents($f);
        if(!is_string($data)||strlen($data)>65536)$this->reject('release_attestation_disk_drift');
        try{$v=json_decode($data,true,64,JSON_THROW_ON_ERROR);}catch(Throwable){$this->reject('release_attestation_disk_drift');}
        $ver=trim((string)@file_get_contents($this->componentRoot.'/VERSION.txt'));
        if(!is_array($v)||($v['component']??'')!=='public-edge'||($v['version']??'')!==$ver)
            $this->reject('release_attestation_disk_drift');
        return [
            'release_set_id'=>(string)($v['release_set_id']??''),
            'tree'=>(string)($v['source']['canonical_tree_sha256']??''),
        ];
    }

    private function verifyManagedManifest(string $expectedTree): void
    {
        $bytes=@file_get_contents($this->componentRoot.'/manifest.json');
        if(!is_string($bytes)||strlen($bytes)>1000000)$this->reject('release_attestation_disk_drift');
        try{$manifest=json_decode($bytes,true,64,JSON_THROW_ON_ERROR);}catch(Throwable){$this->reject('release_attestation_disk_drift');}
        if(!is_array($manifest)||($manifest['component']??'')!=='public-edge'
            ||!is_array($manifest['files']??null))$this->reject('release_attestation_disk_drift');
        // Verify all source-owned managed files byte-for-byte, without
        // examining variable config.php / storage / business database.
        $seen=[];$treeLines='';
        foreach($manifest['files'] as $entry){
            if(!is_array($entry))$this->reject('release_attestation_disk_drift');
            $path=(string)($entry['path']??'');
            if($path===''||isset($seen[$path])||str_contains($path,'\\')
                ||str_starts_with($path,'/')||preg_match('#(^|/)\.\.?(/|$)#',$path))
                $this->reject('release_attestation_disk_drift');
            $seen[$path]=true;$full=$this->componentRoot.'/'.$path;
            if(is_link($full)||!is_file($full)||(int)@filesize($full)!==(int)($entry['size']??-1)
                ||!hash_equals((string)($entry['sha256']??''),(string)@hash_file('sha256',$full)))
                $this->reject('release_attestation_disk_drift');
            if(!in_array($path,['manifest.json','resources/build-provenance.json','resources/release-identity-v1.json'],true))
                $treeLines.=$path."\0".(string)$entry['size']."\0".(string)$entry['sha256']."\n";
        }
        if(!hash_equals($expectedTree,hash('sha256',$treeLines)))
            $this->reject('release_attestation_disk_drift');
    }

    private function externalFile(string $path): string
    {
        if($path===''||!str_starts_with($path,'/'))$this->reject('release_attestation_key_unavailable');
        $real=realpath($path);$root=realpath($this->componentRoot);
        if($real===false||$root===false||!is_file($real)||is_link($path)
            ||$real===$root||str_starts_with($real,$root.'/'))
            $this->reject('release_attestation_key_unavailable');
        // Operator-controlled external secret/snapshot must not be world- or
        // group-accessible. No automatic key generation or private artifact.
        $perms=@fileperms($real);
        if($perms===false||($perms&0077)!==0)$this->reject('release_attestation_key_unavailable');
        return $real;
    }

    private function burnNonce(string $nonce,int $now): void
    {
        $dir=$this->maintenanceStorageRoot.'/attestation-replay-v1';
        if(!is_dir($dir)&&!@mkdir($dir,0700,true)&&!is_dir($dir))
            $this->reject('release_attestation_storage_unavailable');
        if(is_link($dir))$this->reject('release_attestation_storage_unavailable');
        $p=$dir.'/'.$nonce.'.nonce';
        $handle=@fopen($p,'x');
        if($handle===false)$this->reject('release_attestation_replay');
        @chmod($p,0600);
        fwrite($handle,(string)$now);fflush($handle);fclose($handle);
        // Bounded cleanup. Older nonce files cannot be replayed since
        // challenges live <=30s; retain ledger 10 minutes.
        $removed=0;
        foreach(new \FilesystemIterator($dir,\FilesystemIterator::SKIP_DOTS) as $node){
            if($removed>=24)break;
            if($node->isFile()&&!$node->isLink()&&$node->getMTime()<$now-600
                &&preg_match('/^[a-f0-9]{32}\.nonce$/D',$node->getFilename())){
                @unlink($node->getPathname());$removed++;
            }
        }
    }
    private function reject(string $reason): never
    {
        throw new MaintenanceException($reason,'Public release attestation is unavailable.',503);
    }
}
