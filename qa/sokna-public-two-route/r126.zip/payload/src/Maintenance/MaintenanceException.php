<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Maintenance;

use RuntimeException;

final class MaintenanceException extends RuntimeException
{
    public function __construct(
        public readonly string $errorCode,
        string $message,
        public readonly int $httpStatus=500,
        public readonly array $context=[]
    ) { parent::__construct($message); }
}
