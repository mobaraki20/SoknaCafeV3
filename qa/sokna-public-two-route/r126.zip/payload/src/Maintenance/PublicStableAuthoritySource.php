<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Maintenance;

use PDO;
use Throwable;

/**
 * F1-S7E5D1: fail-closed, read-only installed-state witness.
 * This does not establish that either updater is integrated with a stable
 * commit owner. Until that independent owner is deployed the witness must
 * not be enabled in the Public attestation HTTP endpoint.
 */
final class PublicStableAuthoritySource
{
    private const DOMAIN="SOKNA-PUBLIC-STABLE-RELEASE-COMMIT-V1\n";
    public function __construct(
        private readonly string $componentRoot,
        private readonly string $stableRoot,
        private readonly string $migrationDirectory,
    ) {}

    /** Caller supplies a *read-only* PDO connection to the real Public DB. */
    public function observe(PDO $db, array $cfg, bool $publish=false): array
    {
        $root=realpath($this->componentRoot);
        $stable=realpath($this->stableRoot);
        if(!$root||!$stable||$stable===$root||str_starts_with($stable,$root.'/')||is_link($this->stableRoot))$this->fail('unstable_storage');
        if(($cfg['owner_integration_qualified']??null)!==true)$this->fail('owner_not_integrated');
        $lockFile=$stable.'/installed-release-owner.lock';
        if(!is_file($lockFile)||is_link($lockFile))$this->fail('lock_missing');
        $lock=fopen($lockFile,'rb');
        if($lock===false)$this->fail('lock_unavailable');
        if(!flock($lock, LOCK_SH|LOCK_NB)){fclose($lock);$this->fail('update_in_progress');}
        try {
            // F1-S7E5D1B: any unresolved, forged or dangling shared-owner WAL
            // fences read-only signed observations. The stable lifecycle owner,
            // not the web endpoint, must prove and clear recovery separately.
            $pending=$stable.'/mutation-wal-v1.json';
            if(is_file($pending)||is_link($pending))$this->fail('mutation_transaction_unresolved');
            $commit=$this->authenticatedRecord($stable.'/release-commit-v1.json',(string)($cfg['commit_hmac_key_file']??''),self::DOMAIN);
            $floor=$this->authenticatedRecord($stable.'/release-floor-v1.json',(string)($cfg['floor_hmac_key_file']??''),"SOKNA-PUBLIC-STABLE-RELEASE-FLOOR-V1\n");
            if(($commit['format']??'')!=='sokna-public-installed-release-commit-v1'
                ||($floor['format']??'')!=='sokna-public-installed-release-floor-v1'
                ||($commit['phase']??'')!=='committed'||($commit['owner_pair_integrated']??null)!==true
                ||($commit['recovery_required']??null)!==false||($commit['pending_external_verification']??null)!==false
                ||($commit['mutation_fenced']??null)!==true)$this->fail('untrusted_commit');
            $sid=(string)($commit['installation_id']??'');$set=(string)($commit['active_release_set_id']??'');
            $tree=(string)($commit['active_tree_sha256']??'');$schema=(string)($commit['schema_fingerprint']??'');
            $version=(string)($commit['version']??'');$protocol=(string)($commit['protocol_version']??'');
            $gen=$commit['install_generation']??null;$seq=$commit['release_sequence']??null;$epoch=$commit['authority_epoch']??null;
            if(!preg_match('/^[A-Za-z0-9._:-]{1,96}$/D',$sid)||!preg_match('/^[A-Za-z0-9._:-]{1,192}$/D',$set)
                ||!preg_match('/^[a-f0-9]{64}$/D',$tree)||!preg_match('/^[a-f0-9]{64}$/D',$schema)
                ||!preg_match('/^[A-Za-z0-9._+-]{1,140}$/D',$version)||!preg_match('/^[A-Za-z0-9._-]{1,32}$/D',$protocol)
                ||!is_int($gen)||$gen<1||!is_int($seq)||$seq<1||!is_int($epoch)||$epoch<1)$this->fail('commit_identity_invalid');
            if(($floor['installation_id']??null)!==$sid||!is_int($floor['install_generation']??null)
                ||!is_int($floor['release_sequence']??null)||!is_int($floor['authority_epoch']??null)
                ||$gen<$floor['install_generation']||$seq<$floor['release_sequence']||$epoch<$floor['authority_epoch'])$this->fail('monotonic_floor_violation');
            if((int)($commit['committed_unix']??0)<1||time()-(int)$commit['committed_unix']<0-5)$this->fail('commit_time_invalid');
            $identity=$this->loadJson($root.'/resources/release-identity-v1.json');
            $v=trim((string)@file_get_contents($root.'/VERSION.txt'));
            if(($identity['component']??'')!=='public-edge'||($identity['version']??'')!==$version||$v!==$version
                ||($identity['release_set_id']??'')!==$set||($identity['source']['canonical_tree_sha256']??'')!==$tree)
                $this->fail('disk_identity_drift');
            $this->assertUpdaterStates($stable,$version,$commit);
            $installation=$this->dbInstallation($db,$sid);
            if((string)($installation['installation_id']??'')!==$sid||(int)($installation['active']??0)!==1
                ||!empty($installation['revoked_at'])||($installation['authority_state']??'')!=='active'
                ||(int)($installation['authority_epoch_required']??1)!==0
                ||(int)($installation['authority_epoch']??0)!==$epoch)$this->fail('db_installation_authority_drift');
            $gotSchema=$this->schemaFingerprint($db);
            if(!hash_equals($schema,$gotSchema))$this->fail('db_migration_schema_drift');
            // Re-read the sealed committed record and disk identity before releasing
            // the lock, rejecting a concurrent uncoordinated replacement as far
            // as the stable lock protocol and file snapshots can observe it.
            $last=$this->authenticatedRecord($stable.'/release-commit-v1.json',(string)($cfg['commit_hmac_key_file']??''),self::DOMAIN);
            if(!hash_equals($this->canonical($commit),$this->canonical($last))||trim((string)@file_get_contents($root.'/VERSION.txt'))!==$version)
                $this->fail('concurrent_authority_change');
            $observation=[
                'format'=>'sokna-public-stable-authority-snapshot-v1','verified'=>true,
                'captured_unix'=>time(),'installation_id'=>$sid,'authority_epoch'=>$epoch,
                'install_generation'=>$gen,'active_release_set_id'=>$set,'release_sequence'=>$seq,
                'active_tree_sha256'=>$tree,'schema_fingerprint'=>$schema,'protocol_version'=>$protocol,
                'lifecycle_state'=>'idle','app_health'=>'healthy','mutation_fenced'=>true,
            ];
            if($publish)$this->publishAtomically($stable.'/authority-snapshot-v1.json',$observation);
            return $observation;
        } finally {flock($lock,LOCK_UN);fclose($lock);}
    }

    /** Publish only to the stable owner's fixed location, with the shared lock held. */
    private function publishAtomically(string $path,array $snapshot): void
    {
        if(is_link($path))$this->fail('snapshot_path_unsafe');
        $parent=dirname($path);
        if(((int)@fileperms($parent)&0077)!==0)$this->fail('snapshot_directory_permissions');
        $temp=$path.'.tmp.'.bin2hex(random_bytes(12));
        $handle=@fopen($temp,'x');
        if(!$handle)$this->fail('snapshot_write_unavailable');
        try {
            @chmod($temp,0600);
            $raw=$this->canonical($snapshot)."\n";
            if(fwrite($handle,$raw)!==strlen($raw)||!fflush($handle))$this->fail('snapshot_write_unavailable');
            if(function_exists('fsync')&&!fsync($handle))$this->fail('snapshot_write_unavailable');
        } finally {fclose($handle);}
        if(!@rename($temp,$path)){@unlink($temp);$this->fail('snapshot_publish_failed');}
    }

    /** Production SQL adapter, no DDL / INSERT / UPDATE / DELETE. */
    private function dbInstallation(PDO $db,string $installationId): array
    {
        try{
            $q=$db->prepare('SELECT installation_id,authority_epoch,authority_state,authority_epoch_required,active,revoked_at FROM installations WHERE installation_id=? LIMIT 2');
            if(!$q||!$q->execute([$installationId]))$this->fail('db_read_failed');
            $rows=$q->fetchAll(PDO::FETCH_ASSOC);
            if(!is_array($rows)||count($rows)!==1)$this->fail('db_installation_missing');
            return $rows[0];
        }catch(Throwable){$this->fail('db_read_failed');}
    }

    private function schemaFingerprint(PDO $db): string
    {
        $dir=realpath($this->migrationDirectory);$root=realpath($this->componentRoot);
        if(!$dir||!$root||!str_starts_with($dir,$root.'/'))$this->fail('migration_catalog_missing');
        $catalog=[];
        foreach(scandir($dir)?:[] as $file){
            if(!preg_match('/^(\d{4}_[a-z0-9_]+)\.sql$/D',$file,$m))continue;
            $p=$dir.'/'.$file;
            if(is_link($p)||!is_file($p))$this->fail('migration_catalog_invalid');
            $catalog[$m[1]]=hash_file('sha256',$p);
        }
        ksort($catalog,SORT_STRING);
        if(!$catalog)$this->fail('migration_catalog_missing');
        try{$rows=$db->query('SELECT version FROM schema_migrations ORDER BY version')->fetchAll(PDO::FETCH_COLUMN);}catch(Throwable){$this->fail('migration_ledger_unavailable');}
        if(!is_array($rows)||count($rows)!==count($catalog)||array_values(array_map('strval',$rows))!==array_keys($catalog))
            $this->fail('migration_ledger_drift');
        return hash('sha256',"SOKNA-PUBLIC-SCHEMA-CATALOG-V1\n".$this->canonical($catalog));
    }

    private function assertUpdaterStates(string $stable,string $version,array $commit): void
    {
        $paths=(array)($commit['updater_state_paths']??[]);
        if(array_keys($paths)!==['routine','emergency'])$this->fail('owner_state_missing');
        foreach(['routine','emergency'] as $owner){
            $path=$paths[$owner];
            if(!is_string($path)||!str_starts_with($path,$stable.'/')||!is_file($path)||is_link($path))$this->fail('owner_state_missing');
            $state=$this->loadJson($path);
            if(!in_array((string)($state['active_version']??''),[$version],true))$this->fail('owner_version_conflict');
            if($owner==='routine'&&(!empty($state['pending_verification'])||!empty($state['activation_journal'])))$this->fail('owner_pending_activation');
            if(!empty($state['recovery_required']))$this->fail('owner_recovery_required');
        }
    }

    private function authenticatedRecord(string $path,string $keyPath,string $domain): array
    {
        $record=$this->loadJson($path);
        if(!is_string($record['mac']??null)||!preg_match('/^[a-f0-9]{64}$/D',$record['mac']))$this->fail('commit_mac_missing');
        $mac=$record['mac'];unset($record['mac']);
        $key=$this->secret($keyPath);
        if(!hash_equals($mac,hash_hmac('sha256',$domain.$this->canonical($record),$key)))$this->fail('commit_mac_invalid');
        return $record;
    }
    private function secret(string $path): string
    {
        $root=realpath($this->componentRoot);$real=realpath($path);
        if(!$root||!$real||!str_starts_with($path,'/')||str_starts_with($real,$root.'/')||is_link($path)
            ||!is_file($real)||((int)@fileperms($real)&0077)!==0)$this->fail('owner_key_unavailable');
        $k=@file_get_contents($real);
        if(!is_string($k)||strlen($k)<32||strlen($k)>512)$this->fail('owner_key_unavailable');
        return $k;
    }
    private function loadJson(string $path): array
    {
        if(is_link($path)||!is_file($path)||@filesize($path)>131072)$this->fail('source_unavailable');
        $raw=@file_get_contents($path);
        if(!is_string($raw)||strlen($raw)<2)$this->fail('source_unavailable');
        try{$v=json_decode($raw,true,24,JSON_THROW_ON_ERROR);}catch(Throwable){$this->fail('source_invalid');}
        if(!is_array($v))$this->fail('source_invalid');
        return $v;
    }
    private function canonical(array $v): string{return json_encode($v,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);}
    private function fail(string $code): never{throw new MaintenanceException('stable_authority_'.$code,'Trusted Public installed authority unavailable.',503);}
}
