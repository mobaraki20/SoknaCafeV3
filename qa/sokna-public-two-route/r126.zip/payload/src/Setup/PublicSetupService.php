<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Setup;
use PDO;use Sokna\PublicEdge\Core\Config;use Sokna\PublicEdge\Core\Database;use Sokna\PublicEdge\Core\Migrations;use Sokna\PublicEdge\Emergency\EmergencyAccessService;use Sokna\PublicEdge\Emergency\PairingSecretStore;use Sokna\PublicEdge\Http\PublicPath;use Throwable;
final class PublicSetupService
{
    public function __construct(private readonly string $root){}
    public function status(): array
    {
        $config=$this->root.'/config.php';$lock=$this->root.'/install.lock';$installed=is_file($config)&&is_file($lock);$paired=false;$installation='';
        if($installed){try{$c=require $config;if(is_array($c)){$installation=trim((string)($c['app']['default_installation_id']??''));$paired=$installation!=='';}}catch(Throwable){}}
        $basePath=$this->requestBasePath();if($installed){try{$c=require $config;if(is_array($c))$basePath=PublicPath::normalizeBasePath((string)($c['app']['base_path']??$basePath));}catch(Throwable){}}
        return ['installed'=>$installed,'paired'=>$paired,'installation_id'=>$paired?$installation:'','state'=>$installed?($paired?'paired':'ready_to_pair'):'new','version'=>$this->version(),'base_path'=>$basePath,'base_url'=>$this->baseUrl($basePath)];
    }
    public function preflight(string $storage=''): array
    {
        $storage=$this->normalizeStorage($storage?:$this->root.'/storage');$checks=[];
        $checks[]=$this->check('php_version',version_compare(PHP_VERSION,'8.2.0','>='),PHP_VERSION,'PHP 8.2+');
        foreach(['pdo','pdo_mysql','json','sodium','openssl','session','zip'] as $ext)$checks[]=$this->check('ext_'.$ext,extension_loaded($ext),extension_loaded($ext)?'available':'missing',$ext);
        $checks[]=$this->check('root_write',is_writable($this->root),$this->root,'قابلیت نوشتن فایل تنظیمات');
        $parent=is_dir($storage)?$storage:dirname($storage);$checks[]=$this->check('storage_write',is_dir($parent)&&is_writable($parent),$storage,'مسیر داده قابل نوشتن');
        $https=$this->isHttps();$host=(string)($_SERVER['HTTP_HOST']??'');$local=preg_match('/^(localhost|127\.0\.0\.1)(:\d+)?$/i',$host)===1;$checks[]=$this->check('https',$https||$local,$https?'HTTPS':'HTTP',$local?'محیط محلی':'HTTPS برای محیط عمومی');$basePath=$this->requestBasePath();$checks[]=$this->check('url_path',true,$basePath===''?'/':$basePath,'مسیر نصب وب');
        $ok=!array_filter($checks,fn($x)=>!$x['ok']);return ['ok'=>$ok,'checks'=>$checks,'storage_dir'=>$storage,'base_path'=>$basePath,'base_url'=>$this->baseUrl($basePath)];
    }
    public function testDatabase(array $db,bool $create=false): array
    {
        $db=$this->db($db);$dsn='mysql:host='.$db['host'].';port='.$db['port'].';charset=utf8mb4';
        try{$pdo=new PDO($dsn,$db['user'],$db['pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);if($create){$name=$db['name'];if(!preg_match('/^[A-Za-z0-9_]{1,64}$/D',$name))throw new SetupException('db_name_invalid','نام دیتابیس معتبر نیست.');$pdo->exec('CREATE DATABASE IF NOT EXISTS `'.$name.'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');}
            $pdo=new PDO($dsn.';dbname='.$db['name'],$db['user'],$db['pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);$pdo->query('SELECT 1')->fetchColumn();return ['ok'=>true,'database'=>$db['name']];
        }catch(SetupException $e){throw $e;}catch(Throwable){throw new SetupException('db_unavailable','اتصال به دیتابیس برقرار نشد. اطلاعات دیتابیس و دسترسی کاربر را بررسی کنید.',409);}
    }
    public function install(array $body): array
    {
        if($this->status()['installed'])throw new SetupException('already_installed','Public Edge قبلاً نصب شده است.',409);
        $storage=$this->normalizeStorage((string)($body['storage_dir']??''));$pre=$this->preflight($storage);if(!$pre['ok'])throw new SetupException('preflight_failed','پیش‌نیازهای نصب کامل نیست.',$this->isHttps()?422:409,['checks'=>$pre['checks']]);if(($body['routing_probe_ok']??false)!==true)throw new SetupException('routing_unavailable','مسیرهای وب روی این هاست بازنویسی نمی‌شوند. تنظیمات Rewrite/AllowOverride یا مسیر استقرار را بررسی کنید.',409);
        $db=$this->db((array)($body['db']??[]));$this->testDatabase($db,(bool)($body['create_database']??false));
        $emergency=(string)($body['emergency_password']??'');if(strlen($emergency)<10)throw new SetupException('emergency_password_weak','رمز دسترسی اضطراری حداقل ۱۰ نویسه باشد.');
        if(!is_dir($storage)&&!@mkdir($storage,0700,true)&&!is_dir($storage))throw new SetupException('storage_unavailable','مسیر داده قابل ایجاد نیست.',500);
        $config=['db'=>['host'=>$db['host'],'port'=>$db['port'],'name'=>$db['name'],'charset'=>'utf8mb4','user'=>$db['user'],'pass'=>$db['pass']],
            'app'=>['default_installation_id'=>'','cookie_secure'=>$this->isHttps(),'storage_dir'=>$storage,'base_path'=>$this->requestBasePath(),'base_url'=>$this->baseUrl($this->requestBasePath())],
            'relay'=>['installation_secrets'=>[],'clock_skew_seconds'=>300,'secret_encryption_key_base64'=>base64_encode(random_bytes(SODIUM_CRYPTO_SECRETBOX_KEYBYTES))],
            'auth'=>['session_ttl_seconds'=>28800,'failure_limit'=>5,'failure_window_seconds'=>900,'block_seconds'=>900]];
        $this->writePhp($this->root.'/config.php',$config);
        try{$cfg=Config::fromArray($config);$pdo=Database::connect($cfg);(new Migrations($pdo,$this->root.'/database/migrations'))->migrate();(new EmergencyAccessService($storage))->provisionHash(password_hash($emergency,PASSWORD_DEFAULT),'setup');$code=$this->createPairingCode($storage);$this->writeJson($this->root.'/install.lock',['format'=>'sokna-public-install-lock-v1','version'=>$this->version(),'public_instance_id'=>'public-'.bin2hex(random_bytes(12)),'pwa_app_id'=>'pwa-'.bin2hex(random_bytes(16)),'pwa_app_id_created_at'=>gmdate('c'),'created_at'=>gmdate('c')]);return ['success'=>true,'installed'=>true,'paired'=>false,'pairing_code'=>$code,'base_url'=>$this->baseUrl($this->requestBasePath()),'next'=>'pair'];}
        catch(Throwable $e){@unlink($this->root.'/config.php');@unlink($this->root.'/install.lock');throw new SetupException('install_failed','راه‌اندازی Public Edge کامل نشد.',$e instanceof SetupException?$e->httpStatus:500);}
    }
    public function rotatePairingCode(string $emergencyPassword): array
    {
        $status=$this->status();if(!$status['installed'])throw new SetupException('not_installed','Public Edge هنوز نصب نشده است.',409);if($status['paired'])throw new SetupException('already_paired','Public Edge قبلاً به Local Web متصل شده است.',409);$config=require $this->root.'/config.php';if(!is_array($config))throw new SetupException('config_invalid','تنظیمات Public Edge معتبر نیست.',500);$storage=(string)($config['app']['storage_dir']??'');if(!(new EmergencyAccessService($storage))->verify($emergencyPassword))throw new SetupException('emergency_denied','رمز دسترسی اضطراری صحیح نیست.',401);return ['success'=>true,'pairing_code'=>$this->createPairingCode($storage),'base_url'=>$this->baseUrl($this->requestBasePath())];
    }

    public function pair(array $body): array
    {
        $status=$this->status();if(!$status['installed'])throw new SetupException('not_installed','Public Edge هنوز نصب نشده است.',409);if($status['paired'])throw new SetupException('already_paired','Public Edge قبلاً به Local Web متصل شده است.',409);
        $config=require $this->root.'/config.php';if(!is_array($config))throw new SetupException('config_invalid','تنظیمات Public Edge معتبر نیست.',500);$storage=(string)$config['app']['storage_dir'];
        $code=trim((string)($body['pairing_code']??''));$installation=trim((string)($body['installation_id']??''));$secret=(string)($body['shared_secret']??'');$name=trim((string)($body['display_name']??''));
        if(!preg_match('/^[A-Za-z0-9._:-]{8,96}$/D',$installation)||strlen($secret)<32)throw new SetupException('pairing_invalid','اطلاعات اتصال معتبر نیست.',422);$this->verifyPairingCode($storage,$code);
        $cfg=Config::fromArray($config);$pdo=Database::connect($cfg);$pdo->prepare("INSERT INTO installations(installation_id,display_name,active,remote_enabled,order_intake_enabled,authority_epoch,authority_state,authority_epoch_required) VALUES(?,?,1,1,1,1,'active',0) ON DUPLICATE KEY UPDATE display_name=VALUES(display_name),active=1,remote_enabled=1,order_intake_enabled=1,authority_epoch=GREATEST(authority_epoch,1),authority_state='active'")->execute([$installation,$name]);(new PairingSecretStore($pdo,(string)$config['relay']['secret_encryption_key_base64']))->put($installation,$secret);
        $config['app']['default_installation_id']=$installation;$this->writePhp($this->root.'/config.php',$config);@unlink($storage.'/setup/pairing.json');return ['success'=>true,'ok'=>true,'paired'=>true,'installation_id'=>$installation,'authority_epoch'=>1,'base_url'=>$this->baseUrl($this->requestBasePath())];
    }
    private function createPairingCode(string $storage): string{$dir=$storage.'/setup';if(!is_dir($dir)&&!@mkdir($dir,0700,true)&&!is_dir($dir))throw new SetupException('storage_unavailable','فضای موقت اتصال قابل ایجاد نیست.',500);$plain=strtoupper(implode('-',str_split(bin2hex(random_bytes(12)),8)));$this->writeJson($dir.'/pairing.json',['format'=>'sokna-public-pairing-code-v1','hash'=>password_hash($plain,PASSWORD_DEFAULT),'expires_at'=>time()+3600,'attempts'=>0]);return $plain;}
    private function verifyPairingCode(string $storage,string $code): void{$p=$storage.'/setup/pairing.json';$v=$this->readJson($p);if(($v['format']??'')!=='sokna-public-pairing-code-v1'||(int)($v['expires_at']??0)<time()||!password_verify($code,(string)($v['hash']??'')))throw new SetupException('pairing_denied','کد اتصال معتبر نیست یا منقضی شده است.',401);}
    private function db(array $v): array{$host=trim((string)($v['host']??''));$port=trim((string)($v['port']??'3306'));$name=trim((string)($v['name']??''));$user=trim((string)($v['user']??''));$pass=(string)($v['pass']??'');if($host===''||$name===''||$user===''||!ctype_digit($port))throw new SetupException('db_invalid','اطلاعات دیتابیس کامل نیست.');return compact('host','port','name','user','pass');}
    private function normalizeStorage(string $p): string{$p=trim($p);if($p==='')$p=$this->root.'/storage';if(!str_starts_with($p,'/')&&!preg_match('/^[A-Za-z]:[\\\\\/]/',$p))$p=$this->root.'/'.ltrim($p,'/');return rtrim(str_replace('\\','/',$p),'/');}
    private function version(): string{$v=@file_get_contents($this->root.'/VERSION.txt');return is_string($v)?trim($v):'unknown';}
    private function check(string $id,bool $ok,string $current,string $label): array{return ['id'=>$id,'ok'=>$ok,'current'=>$current,'label'=>$label];}
    private function isHttps(): bool{$https=(!empty($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off');$forwarded=strtolower(trim(explode(',',(string)($_SERVER['HTTP_X_FORWARDED_PROTO']??''))[0]??''));return $https||$forwarded==='https';}
    public function requestBasePath(): string{return PublicPath::fromSetupRequest((string)($_SERVER['REQUEST_URI']??'/setup/'));}
    private function baseUrl(string $basePath=''): string{$scheme=$this->isHttps()?'https':'http';$host=(string)($_SERVER['HTTP_HOST']??'localhost');return $scheme.'://'.$host.PublicPath::normalizeBasePath($basePath);}
    private function writePhp(string $p,array $v): void{$this->atomic($p,"<?php\ndeclare(strict_types=1);\nreturn ".var_export($v,true).";\n");@chmod($p,0600);}
    private function writeJson(string $p,array $v): void{$this->atomic($p,json_encode($v,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)."\n");@chmod($p,0600);}
    private function readJson(string $p): array{try{$x=json_decode((string)@file_get_contents($p),true,32,JSON_THROW_ON_ERROR);return is_array($x)?$x:[];}catch(Throwable){return [];}}
    private function atomic(string $p,string $bytes): void{$d=dirname($p);if(!is_dir($d)&&!@mkdir($d,0700,true)&&!is_dir($d))throw new SetupException('write_failed','مسیر قابل نوشتن نیست.',500);$t=$p.'.tmp-'.bin2hex(random_bytes(4));if(file_put_contents($t,$bytes,LOCK_EX)===false||!@rename($t,$p)){@unlink($t);throw new SetupException('write_failed','ذخیره تنظیمات کامل نشد.',500);}}
}
