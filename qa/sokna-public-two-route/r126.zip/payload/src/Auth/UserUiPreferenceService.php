<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Auth;
use PDO;
final class UserUiPreferenceService
{
    private const GROUPS=['daily','operations','guest','management'];
    public function __construct(private readonly PDO $pdo){}
    public function forUserContext(array $user): array{return $this->forIdentity((string)($user['installation_id']??''),(string)($user['projection_id']??''));}
    public function forIdentity(string $installationId,string $projectionId): array
    {
        $installationId=trim($installationId);$projectionId=trim($projectionId);if($installationId===''||$projectionId==='')return [];
        $q=$this->pdo->prepare('SELECT preferences_json FROM public_user_ui_preferences WHERE installation_id=? AND projection_id=? LIMIT 1');$q->execute([$installationId,$projectionId]);$raw=$q->fetchColumn();
        if($raw===false)return [];$decoded=json_decode((string)$raw,true);return is_array($decoded)?$this->normalize($decoded):[];
    }
    public function forInstallation(string $installationId,array $projectionIds): array
    {
        $projectionIds=array_values(array_unique(array_filter(array_map('strval',$projectionIds),static fn(string $v):bool=>trim($v)!=='')));if(trim($installationId)===''||$projectionIds===[])return [];
        $marks=implode(',',array_fill(0,count($projectionIds),'?'));$q=$this->pdo->prepare('SELECT projection_id,preferences_json FROM public_user_ui_preferences WHERE installation_id=? AND projection_id IN ('.$marks.')');$q->execute(array_merge([$installationId],$projectionIds));$out=[];
        foreach($q->fetchAll(PDO::FETCH_ASSOC) as $row){$d=json_decode((string)($row['preferences_json']??''),true);$out[(string)$row['projection_id']]=is_array($d)?$this->normalize($d):[];}return $out;
    }
    public function savePatch(string $installationId,string $projectionId,array $patch): array
    {
        $installationId=trim($installationId);$projectionId=trim($projectionId);if($installationId===''||$projectionId==='')throw new \InvalidArgumentException('identity_required');$current=$this->forIdentity($installationId,$projectionId);$valid=$this->normalize($patch);foreach($valid as $key=>$value)$current[$key]=$value;
        $json=json_encode($current,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);$q=$this->pdo->prepare('INSERT INTO public_user_ui_preferences(installation_id,projection_id,preferences_json) VALUES(?,?,?) ON DUPLICATE KEY UPDATE preferences_json=VALUES(preferences_json),updated_at=CURRENT_TIMESTAMP');$q->execute([$installationId,$projectionId,$json]);return $current;
    }
    private function normalize(array $input): array
    {
        $out=[];$theme=(string)($input['theme']??'');if(in_array($theme,['light','dark','system'],true))$out['theme']=$theme;
        if(array_key_exists('nav_compact',$input)){$compact=filter_var($input['nav_compact'],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE);if($compact!==null)$out['nav_compact']=$compact;}
        if(is_array($input['nav_groups']??null)){$groups=[];foreach($input['nav_groups'] as $g){$g=(string)$g;if(in_array($g,self::GROUPS,true)&&!in_array($g,$groups,true))$groups[]=$g;}$out['nav_groups']=$groups;}
        $sort=(string)($input['hall_sort']??'');if(in_array($sort,['number','time'],true))$out['hall_sort']=$sort;
        $density=(string)($input['hall_density']??'');if(in_array($density,['normal','compact','overview'],true))$out['hall_density']=$density;
        return $out;
    }
}
