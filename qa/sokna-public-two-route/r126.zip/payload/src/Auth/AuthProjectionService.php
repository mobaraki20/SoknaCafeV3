<?php
declare(strict_types=1);

namespace Sokna\PublicEdge\Auth;

use PDO;
use RuntimeException;
use Throwable;

final class AuthProjectionService
{
    public function __construct(private readonly PDO $pdo){}

    /**
     * Apply one authoritative Local projection set for an installation.
     * Existing sessions survive an identical projection refresh, but are revoked
     * whenever identity/password/capabilities/areas/version/active state changes.
     */
    public function sync(string $installationId,array $rows): int
    {
        $installationId=trim($installationId);
        if($installationId==='')throw new RuntimeException('installation_id is required');

        $this->pdo->beginTransaction();
        try{
            $existing=[];
            $q=$this->pdo->prepare('SELECT projection_id,username,display_name,role,password_hash,capabilities_json,preparation_areas_json,lan_base_url,lan_token,lan_token_expires_at,projection_version,active FROM auth_projections WHERE installation_id=? FOR UPDATE');
            $q->execute([$installationId]);
            foreach($q->fetchAll(PDO::FETCH_ASSOC) as $row)$existing[(string)$row['projection_id']]=$row;

            $this->pdo->prepare('UPDATE auth_projections SET active=0 WHERE installation_id=?')->execute([$installationId]);
            $seen=[];$count=0;
            foreach($rows as $row){
                if(!is_array($row))continue;
                $projectionId=trim((string)($row['projection_id']??''));$username=trim((string)($row['username']??''));
                $displayName=trim((string)($row['display_name']??$username));$role=trim((string)($row['role']??''));
                $passwordHash=(string)($row['password_hash']??'');
                if($projectionId===''||$username===''||$passwordHash==='')continue;
                $capList=is_array($row['capabilities']??null)?array_values(array_map('strval',$row['capabilities'])):[];sort($capList,SORT_STRING);
                $areaList=is_array($row['preparation_areas']??null)?array_values(array_map('strval',$row['preparation_areas'])):[];sort($areaList,SORT_STRING);
                $capabilities=json_encode($capList,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
                $areas=json_encode($areaList,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
                $lanBase=trim((string)($row['lan_base_url']??''));$lanToken=trim((string)($row['lan_token']??''));$lanExpires=trim((string)($row['lan_token_expires_at']??''));$lanExpiresSql=$lanExpires!==''?(($ts=strtotime($lanExpires))!==false?gmdate('Y-m-d H:i:s',$ts):null):null;
                $version=max(1,(int)($row['projection_version']??1));$active=!empty($row['active'])?1:0;

                $before=$existing[$projectionId]??null;
                $changed=!is_array($before)
                    ||(string)$before['username']!==$username
                    ||(string)$before['display_name']!==$displayName
                    ||(string)$before['role']!==$role
                    ||!hash_equals((string)$before['password_hash'],$passwordHash)
                    ||self::canonicalListJson((string)$before['capabilities_json'])!==$capabilities
                    ||self::canonicalListJson((string)$before['preparation_areas_json'])!==$areas
                    ||(int)$before['projection_version']!==$version
                    ||(int)$before['active']!==$active;

                $stmt=$this->pdo->prepare(
                    'INSERT INTO auth_projections(installation_id,projection_id,username,display_name,role,password_hash,capabilities_json,preparation_areas_json,lan_base_url,lan_token,lan_token_expires_at,projection_version,active) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) '
                    .'ON DUPLICATE KEY UPDATE username=VALUES(username),display_name=VALUES(display_name),role=VALUES(role),password_hash=VALUES(password_hash),capabilities_json=VALUES(capabilities_json),preparation_areas_json=VALUES(preparation_areas_json),lan_base_url=VALUES(lan_base_url),lan_token=VALUES(lan_token),lan_token_expires_at=VALUES(lan_token_expires_at),projection_version=VALUES(projection_version),active=VALUES(active)'
                );
                $stmt->execute([$installationId,$projectionId,$username,$displayName,$role,$passwordHash,$capabilities,$areas,$lanBase!==''?$lanBase:null,$lanToken!==''?$lanToken:null,$lanExpiresSql,$version,$active]);
                if($changed)$this->pdo->prepare('DELETE FROM public_sessions WHERE installation_id=? AND projection_id=?')->execute([$installationId,$projectionId]);
                $seen[$projectionId]=true;$count++;
            }

            foreach($existing as $projectionId=>$before){
                if(!isset($seen[$projectionId]))$this->pdo->prepare('DELETE FROM public_sessions WHERE installation_id=? AND projection_id=?')->execute([$installationId,$projectionId]);
            }
            $this->pdo->commit();return $count;
        }catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    private static function canonicalListJson(string $json): string
    {
        $v=json_decode($json,true);$list=is_array($v)?array_values(array_map('strval',$v)):[];sort($list,SORT_STRING);
        return json_encode($list,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
    }
}
