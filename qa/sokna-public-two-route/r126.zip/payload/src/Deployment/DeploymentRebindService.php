<?php
declare(strict_types=1);

namespace Sokna\PublicEdge\Deployment;

use Sokna\PublicEdge\Emergency\PairingSecretStore;
use Sokna\PublicEdge\Emergency\PublicUpdateException;
use Throwable;

/**
 * Safe deployment-origin rebinding for one existing Public instance.
 *
 * The workflow deliberately behaves like a guarded blue/green switchover:
 * prepare -> commit -> verify -> finalize, with an explicit rollback copy and
 * a separately retired old-binding grace surface. Domain/origin is deployment
 * configuration, never product identity, and Host/X-Forwarded-* are never
 * allowed to mutate the binding.
 */
final class DeploymentRebindService
{
    private const CONTRACT='sokna-deployment-rebind-v2';
    private const STATE_TTL=1200;

    public function __construct(
        private readonly string $root,
        private readonly string $storageRoot,
        private readonly DeploymentIdentity $identity,
        private readonly PairingSecretStore $secrets,
    ) {}

    public function probe(string $installationId,string $nonce,string $probeBaseUrl): array
    {
        $nonce=trim($nonce);$probeBaseUrl=DeploymentIdentity::canonicalBaseUrl($probeBaseUrl);
        if(!preg_match('/^[A-Za-z0-9_-]{16,128}$/D',$nonce))throw new PublicUpdateException('deployment_probe_nonce_invalid','Deployment probe nonce is invalid.',422);
        if($probeBaseUrl==='')throw new PublicUpdateException('deployment_target_invalid','Deployment target URL is invalid.',422);
        $secret=$this->secrets->secret($installationId);
        if($secret==='')throw new PublicUpdateException('deployment_pairing_secret_missing','Pairing secret is unavailable.',409);
        $instance=$this->publicInstanceId();
        if($instance==='')throw new PublicUpdateException('deployment_instance_identity_missing','Public instance identity is unavailable.',409);
        $proof=hash_hmac('sha256',implode("\n",['sokna-deployment-probe-v1',$nonce,$instance,$installationId,$probeBaseUrl]),$secret);
        $candidatePath=$this->pathFromBase($probeBaseUrl);
        $pwa=new PwaIdentity($this->root);
        return [
            'ok'=>true,'contract'=>self::CONTRACT,'action'=>'probe','public_instance_id'=>$instance,
            'installation_id'=>$installationId,'probe_base_url'=>$probeBaseUrl,'proof'=>$proof,
            'deployment'=>$this->identity->snapshot(),'version'=>$this->version(),
            'candidate'=>[
                'base_path'=>$candidatePath,
                'pwa_app_id'=>$pwa->appId(),
                'manifest_id'=>$pwa->manifestIdPath(),
                'staff_worker_present'=>is_file($this->root.'/assets/scds/staff-sw.js'),
                'staff_runtime_present'=>is_file($this->root.'/assets/staff-app/public-device.js'),
                'transition_contract'=>'sokna-pwa-origin-transition-v1',
            ],
        ];
    }

    public function prepare(string $installationId,array $body): array
    { return $this->locked(fn():array=>$this->prepareLocked($installationId,$body)); }

    private function prepareLocked(string $installationId,array $body): array
    {
        $target=$this->requiredTarget((string)($body['target_base_url']??''));
        $targetInstance=trim((string)($body['target_public_instance_id']??''));
        $instance=$this->publicInstanceId();
        if($instance===''||$targetInstance===''||!hash_equals($instance,$targetInstance))throw new PublicUpdateException('deployment_target_instance_mismatch','Target URL is not the same Public instance.',409);
        $current=$this->identity->configuredBaseUrl();
        if($current==='')throw new PublicUpdateException('deployment_current_binding_invalid','Current Public binding is invalid.',409);
        if(hash_equals($current,$target))throw new PublicUpdateException('deployment_target_unchanged','Target binding is already active.',409);
        $this->assertNoOpenRebind();
        $raw=$this->configBytes();$rawConfig=$this->configArrayFromBytes($raw);
        $targetPath=$this->pathFromBase($target);$policy=$this->transitionPolicy($current,$target);
        $id='rebind-'.bin2hex(random_bytes(12));
        $state=[
            'format'=>self::CONTRACT,'id'=>$id,'phase'=>'prepared','installation_id'=>$installationId,
            'public_instance_id'=>$instance,'current_base_url'=>$current,'current_base_path'=>$this->identity->basePath(),
            'target_base_url'=>$target,'target_base_path'=>$targetPath,
            'prepared_config_sha256'=>hash('sha256',$raw),'prepared_at'=>gmdate('c'),'expires_at'=>time()+self::STATE_TTL,
            ...$policy,
            'old_origin_grace_state'=>'pending',
        ];
        $candidate=$rawConfig;$candidate['app']=is_array($candidate['app']??null)?$candidate['app']:[];
        $candidate['app']['base_url']=$target;$candidate['app']['base_path']=$targetPath;
        $this->serializeConfig($candidate);
        $this->writeState($id,$state);
        return $this->stateResponse($state);
    }

    public function commit(string $installationId,string $id): array
    { return $this->locked(fn():array=>$this->commitLocked($installationId,$id)); }

    private function commitLocked(string $installationId,string $id): array
    {
        $state=$this->requiredState($id,$installationId);
        if(($state['phase']??'')==='committed')return $this->stateResponse($state);
        if(($state['phase']??'')!=='prepared')throw new PublicUpdateException('deployment_rebind_state_invalid','Rebind is not in prepared state.',409);
        if((int)($state['expires_at']??0)<time())throw new PublicUpdateException('deployment_rebind_expired','Prepared rebind expired before commit.',409);
        $before=$this->configBytes();
        if(!hash_equals((string)$state['prepared_config_sha256'],hash('sha256',$before)))throw new PublicUpdateException('deployment_config_drift','Public config changed after rebind prepare.',409);
        $config=$this->configArrayFromBytes($before);$config['app']=is_array($config['app']??null)?$config['app']:[];
        $config['app']['base_url']=(string)$state['target_base_url'];$config['app']['base_path']=(string)$state['target_base_path'];
        $targetParts=parse_url((string)$state['target_base_url']);if(is_array($targetParts)&&strtolower((string)($targetParts['scheme']??''))==='https')$config['app']['cookie_secure']=true;
        $backup=$this->stateDir().'/'.$id.'.config.rollback.php';
        $this->writeSecretFile($backup,$before);
        try{$after=$this->serializeConfig($config);$this->atomicWrite($this->root.'/config.php',$after,0600);}catch(Throwable $e){@unlink($backup);throw $e;}
        $state['phase']='committed';$state['committed_at']=gmdate('c');$state['committed_config_sha256']=hash('sha256',$after);$state['rollback_file']=basename($backup);$state['old_origin_grace_state']='active';
        $this->writeState($id,$state);
        return $this->stateResponse($state);
    }

    public function rollback(string $installationId,string $id): array
    { return $this->locked(fn():array=>$this->rollbackLocked($installationId,$id)); }

    private function rollbackLocked(string $installationId,string $id): array
    {
        $state=$this->requiredState($id,$installationId);
        if(($state['phase']??'')==='rolled_back')return $this->stateResponse($state);
        if(($state['phase']??'')==='prepared'){$state['phase']='rolled_back';$state['rolled_back_at']=gmdate('c');$state['old_origin_grace_state']='cancelled';$this->writeState($id,$state);return $this->stateResponse($state);}
        if(($state['phase']??'')!=='committed')throw new PublicUpdateException('deployment_rebind_state_invalid','Committed rebind is not rollback-eligible.',409);
        $current=$this->configBytes();$expected=(string)($state['committed_config_sha256']??'');
        if($expected===''||!hash_equals($expected,hash('sha256',$current)))throw new PublicUpdateException('deployment_rollback_config_drift','Public config changed after rebind commit; blind rollback refused.',409);
        $backup=$this->stateDir().'/'.basename((string)($state['rollback_file']??''));
        $bytes=is_file($backup)?file_get_contents($backup):false;if(!is_string($bytes)||$bytes==='')throw new PublicUpdateException('deployment_rollback_missing','Rollback copy is unavailable.',500);
        if(!hash_equals((string)$state['prepared_config_sha256'],hash('sha256',$bytes)))throw new PublicUpdateException('deployment_rollback_corrupt','Rollback copy failed integrity check.',500);
        $this->atomicWrite($this->root.'/config.php',$bytes,0600);
        $state['phase']='rolled_back';$state['rolled_back_at']=gmdate('c');$state['old_origin_grace_state']='cancelled';$this->writeState($id,$state);@unlink($backup);
        return $this->stateResponse($state);
    }

    public function finalize(string $installationId,string $id): array
    { return $this->locked(fn():array=>$this->finalizeLocked($installationId,$id)); }

    private function finalizeLocked(string $installationId,string $id): array
    {
        $state=$this->requiredState($id,$installationId);
        if(($state['phase']??'')==='finalized')return $this->stateResponse($state);
        if(($state['phase']??'')!=='committed')throw new PublicUpdateException('deployment_rebind_state_invalid','Only a committed rebind can be finalized.',409);
        $current=$this->configBytes();$expected=(string)($state['committed_config_sha256']??'');
        if($expected===''||!hash_equals($expected,hash('sha256',$current)))throw new PublicUpdateException('deployment_finalize_config_drift','Public config changed before rebind finalize.',409);
        $backup=$this->stateDir().'/'.basename((string)($state['rollback_file']??''));@unlink($backup);
        $state['phase']='finalized';$state['finalized_at']=gmdate('c');unset($state['rollback_file']);$this->writeState($id,$state);
        return $this->stateResponse($state);
    }

    public function status(string $installationId,string $id): array{return $this->stateResponse($this->requiredState($id,$installationId));}

    public function transitionStatus(string $installationId): array
    {
        $state=$this->latestState($installationId);
        if($state===null)return ['ok'=>true,'contract'=>self::CONTRACT,'active'=>false,'old_origin_grace_state'=>'none'];
        return ['active'=>(string)($state['old_origin_grace_state']??'')==='active']+$this->stateResponse($state);
    }

    public function closeTransition(string $installationId,string $id): array
    {
        return $this->locked(function() use($installationId,$id): array {
            $state=$this->requiredState($id,$installationId);
            if(($state['phase']??'')!=='finalized')throw new PublicUpdateException('deployment_transition_not_finalized','Old binding can be retired only after the rebind is finalized.',409);
            if(($state['old_origin_grace_state']??'')==='retired')return $this->stateResponse($state);
            if(($state['old_origin_grace_state']??'')!=='active')throw new PublicUpdateException('deployment_transition_not_active','Old binding grace is not active.',409);
            $state['old_origin_grace_state']='retired';$state['old_origin_retired_at']=gmdate('c');$this->writeState($id,$state);
            return $this->stateResponse($state);
        });
    }

    /**
     * Safe browser launcher for an old Public binding that still points at this
     * exact instance during the operator-controlled grace period. Host is used
     * only to match a previously persisted old binding; it never mutates config.
     */
    public function browserTransitionResponse(string $method,string $requestUri,string $hostHeader,string $accept=''): ?array
    {
        if(strtoupper($method)!=='GET'||!str_contains(strtolower($accept),'text/html'))return null;
        $state=$this->latestActiveTransition();if($state===null)return null;
        $configured=$this->identity->configuredBaseUrl();if($configured===''||!hash_equals($configured,(string)($state['target_base_url']??'')))return null;
        $old=(string)($state['current_base_url']??'');$target=(string)($state['target_base_url']??'');$kind=(string)($state['transition_kind']??'');
        $oldHost=$this->hostPort($old);$requestHost=strtolower(trim($hostHeader));if($oldHost===''||$requestHost==='')return null;
        if(!hash_equals($oldHost,$requestHost))return null;
        $path=(string)(parse_url($requestUri,PHP_URL_PATH)?:'/');$oldPath=$this->pathFromBase($old);$targetPath=$this->pathFromBase($target);
        if($kind==='same_origin'){
            if(!$this->pathInside($path,$oldPath)||$this->pathInside($path,$targetPath))return null;
        }
        $suffix=$this->pathSuffix($path,$oldPath);$destination=rtrim($target,'/').($suffix===''?'/':$suffix);
        $query=(string)(parse_url($requestUri,PHP_URL_QUERY)?:'');if($query!=='')$destination.='?'.$query;
        if(str_starts_with($suffix,'/staff'))$destination.=(str_contains($destination,'?')?'&':'?').'origin_transition='.rawurlencode((string)$state['id']);
        if($kind==='same_origin')return ['status'=>302,'headers'=>['Location'=>$destination,'Cache-Control'=>'no-store','X-Sokna-Origin-Transition'=>'same-origin'],'body'=>''];
        $safe=htmlspecialchars($destination,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
        $html='<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#0f6b66"><title>انتقال آدرس سکنا</title><body style="font-family:system-ui,sans-serif;background:#f6f5f0;color:#1f2d29;margin:0;padding:32px"><main style="max-width:560px;margin:8vh auto;background:#fff;border:1px solid #dfe5e1;border-radius:18px;padding:28px;box-shadow:0 10px 30px rgba(0,0,0,.06)"><h1 style="font-size:1.45rem;margin-top:0">آدرس سامانه سکنا تغییر کرده است</h1><p>این نسخه قدیمی برای دوره انتقال هنوز در دسترس است. برای ادامه، آدرس جدید را باز کنید. ممکن است لازم باشد دوباره وارد حساب شوید و اپ/اعلان را روی آدرس جدید فعال کنید.</p><p><a href="'.$safe.'" style="display:inline-block;background:#0f6b66;color:white;text-decoration:none;padding:11px 18px;border-radius:10px;font-weight:700">ادامه در آدرس جدید</a></p><small style="color:#60716b">اگر آدرس جدید باز نشد، این صفحه را نبندید و وضعیت اتصال را با مدیر سامانه بررسی کنید.</small></main></body></html>';
        return ['status'=>200,'headers'=>['Content-Type'=>'text/html; charset=utf-8','Cache-Control'=>'no-store','Referrer-Policy'=>'no-referrer','X-Frame-Options'=>'DENY','X-Sokna-Origin-Transition'=>'cross-origin','Content-Security-Policy'=>"default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'"],'body'=>$html];
    }

    private function locked(callable $callback): array
    {
        $path=$this->stateDir().'/.lock';$h=@fopen($path,'c+');if(!is_resource($h))throw new PublicUpdateException('deployment_rebind_lock_failed','Rebind lock is unavailable.',500);
        if(!@flock($h,LOCK_EX)){fclose($h);throw new PublicUpdateException('deployment_rebind_lock_failed','Rebind lock could not be acquired.',500);}
        try{return $callback();}finally{@flock($h,LOCK_UN);fclose($h);}
    }

    private function assertNoOpenRebind(): void
    {
        foreach(glob($this->stateDir().'/rebind-*.json')?:[] as $path){
            try{$v=json_decode((string)file_get_contents($path),true,48,JSON_THROW_ON_ERROR);}catch(Throwable){continue;}
            if(!is_array($v)||($v['format']??'')!==self::CONTRACT)continue;$phase=(string)($v['phase']??'');
            if($phase==='committed')throw new PublicUpdateException('deployment_rebind_in_progress','Another committed rebind must be finalized or rolled back first.',409);
            if($phase==='prepared'&&(int)($v['expires_at']??0)>=time())throw new PublicUpdateException('deployment_rebind_in_progress','Another prepared rebind is still active.',409);
            if($phase==='finalized'&&($v['old_origin_grace_state']??'')==='active')throw new PublicUpdateException('deployment_transition_grace_open','Retire the previous old-binding grace before starting another Public URL change.',409);
        }
    }

    private function transitionPolicy(string $current,string $target): array
    {
        $currentOrigin=$this->origin($current);$targetOrigin=$this->origin($target);$same=$currentOrigin!==''&&$targetOrigin!==''&&hash_equals($currentOrigin,$targetOrigin);
        $currentPath=$this->pathFromBase($current);$targetPath=$this->pathFromBase($target);
        return [
            'current_origin'=>$currentOrigin,'target_origin'=>$targetOrigin,'transition_kind'=>$same?'same_origin':'cross_origin',
            'pwa_reinstall_required'=>!$same,
            'reauthentication_required'=>!$same||!$this->cookiePathCoversTarget($currentPath,$targetPath),
            'push_resubscribe_required'=>true,
            'service_worker_reconcile_required'=>true,
            'old_origin_grace_state'=>'pending',
        ];
    }

    private function stateResponse(array $state): array
    {
        return [
            'ok'=>true,'contract'=>self::CONTRACT,'rebind_id'=>(string)$state['id'],'phase'=>(string)$state['phase'],
            'current_base_url'=>(string)$state['current_base_url'],'target_base_url'=>(string)$state['target_base_url'],
            'current_origin'=>(string)($state['current_origin']??$this->origin((string)$state['current_base_url'])),
            'target_origin'=>(string)($state['target_origin']??$this->origin((string)$state['target_base_url'])),
            'transition_kind'=>(string)($state['transition_kind']??''),
            'pwa_reinstall_required'=>(bool)($state['pwa_reinstall_required']??false),
            'reauthentication_required'=>(bool)($state['reauthentication_required']??false),
            'push_resubscribe_required'=>(bool)($state['push_resubscribe_required']??true),
            'service_worker_reconcile_required'=>(bool)($state['service_worker_reconcile_required']??true),
            'old_origin_grace_state'=>(string)($state['old_origin_grace_state']??'none'),
            'expires_at'=>(int)($state['expires_at']??0)>0?gmdate('c',(int)$state['expires_at']):null,
            'finalized_at'=>(string)($state['finalized_at']??''),
            'old_origin_retired_at'=>(string)($state['old_origin_retired_at']??''),
        ];
    }

    private function latestState(string $installationId): ?array
    {
        $rows=[];foreach(glob($this->stateDir().'/rebind-*.json')?:[] as $path){try{$v=json_decode((string)file_get_contents($path),true,48,JSON_THROW_ON_ERROR);}catch(Throwable){continue;}if(!is_array($v)||($v['format']??'')!==self::CONTRACT||!hash_equals((string)($v['installation_id']??''),$installationId))continue;$rows[]=$v;}
        usort($rows,static fn(array $a,array $b):int=>strcmp((string)($b['prepared_at']??''),(string)($a['prepared_at']??'')));return $rows[0]??null;
    }

    private function latestActiveTransition(): ?array
    {
        $rows=[];foreach(glob($this->stateDir().'/rebind-*.json')?:[] as $path){try{$v=json_decode((string)file_get_contents($path),true,48,JSON_THROW_ON_ERROR);}catch(Throwable){continue;}if(!is_array($v)||($v['format']??'')!==self::CONTRACT||($v['old_origin_grace_state']??'')!=='active'||!in_array((string)($v['phase']??''),['committed','finalized'],true))continue;$rows[]=$v;}
        usort($rows,static fn(array $a,array $b):int=>strcmp((string)($b['prepared_at']??''),(string)($a['prepared_at']??'')));return $rows[0]??null;
    }

    private function requiredTarget(string $value): string{$v=DeploymentIdentity::canonicalBaseUrl($value);if($v==='')throw new PublicUpdateException('deployment_target_invalid','Target Public URL is invalid.',422);$p=parse_url($v);$scheme=strtolower((string)($p['scheme']??''));$host=strtolower(trim((string)($p['host']??''),'[]'));if($scheme!=='https'&&!in_array($host,['127.0.0.1','localhost','::1'],true))throw new PublicUpdateException('deployment_target_https_required','Remote Public target must use HTTPS.',422);return $v;}
    private function pathFromBase(string $base): string{$p=parse_url($base);return \Sokna\PublicEdge\Http\PublicPath::normalizeBasePath(is_array($p)?(string)($p['path']??''):'');}
    private function origin(string $base): string{$p=parse_url($base);if(!is_array($p))return '';$scheme=strtolower((string)($p['scheme']??''));$host=strtolower(trim((string)($p['host']??''),'[]'));if($scheme===''||$host==='')return '';$port=isset($p['port'])?(int)$p['port']:null;$authority=str_contains($host,':')?'['.$host.']':$host;if($port!==null&&!(($scheme==='https'&&$port===443)||($scheme==='http'&&$port===80)))$authority.=':'.$port;return $scheme.'://'.$authority;}
    private function hostPort(string $base): string{$p=parse_url($base);if(!is_array($p))return '';$host=strtolower(trim((string)($p['host']??''),'[]'));if($host==='')return '';$scheme=strtolower((string)($p['scheme']??''));$port=isset($p['port'])?(int)$p['port']:null;$out=str_contains($host,':')?'['.$host.']':$host;if($port!==null&&!(($scheme==='https'&&$port===443)||($scheme==='http'&&$port===80)))$out.=':'.$port;return $out;}
    private function cookiePathCoversTarget(string $currentPath,string $targetPath): bool{$cookie=$currentPath===''?'/':rtrim($currentPath,'/').'/';$request=$targetPath===''?'/':rtrim($targetPath,'/').'/';return str_starts_with($request,$cookie);}
    private function pathInside(string $requestPath,string $basePath): bool{$base=$basePath===''?'/':rtrim($basePath,'/').'/';$request='/'.ltrim($requestPath,'/');if($base==='/')return true;return $request===rtrim($base,'/')||str_starts_with($request,$base);}
    private function pathSuffix(string $requestPath,string $basePath): string{$request='/'.ltrim($requestPath,'/');if($basePath==='')return $request;$base=rtrim($basePath,'/');if($request===$base)return '/';return str_starts_with($request,$base.'/')?substr($request,strlen($base)): '/';}
    private function publicInstanceId(): string{try{$j=json_decode((string)@file_get_contents($this->root.'/install.lock'),true,16,JSON_THROW_ON_ERROR);return is_array($j)?trim((string)($j['public_instance_id']??'')):'';}catch(Throwable){return '';}}
    private function version(): string{$v=@file_get_contents($this->root.'/VERSION.txt');return is_string($v)?trim($v):'unknown';}
    private function configBytes(): string{$b=@file_get_contents($this->root.'/config.php');if(!is_string($b)||$b==='')throw new PublicUpdateException('deployment_config_unavailable','Public config is unavailable.',500);return $b;}
    private function configArrayFromBytes(string $bytes): array{$tmp=$this->stateDir().'/.parse-'.bin2hex(random_bytes(5)).'.php';$this->writeSecretFile($tmp,$bytes);try{$v=require $tmp;}finally{@unlink($tmp);}if(!is_array($v))throw new PublicUpdateException('deployment_config_invalid','Public config is invalid.',500);return $v;}
    private function serializeConfig(array $config): string{return "<?php\ndeclare(strict_types=1);\nreturn ".var_export($config,true).";\n";}
    private function stateDir(): string{$d=rtrim($this->storageRoot,'/\\').'/deployment-rebind';if(!is_dir($d)&&!@mkdir($d,0700,true)&&!is_dir($d))throw new PublicUpdateException('deployment_rebind_storage_unavailable','Rebind storage is unavailable.',500);return $d;}
    private function statePath(string $id): string{if(preg_match('/^rebind-[a-f0-9]{24}$/D',$id)!==1)throw new PublicUpdateException('deployment_rebind_id_invalid','Rebind identifier is invalid.',422);return $this->stateDir().'/'.$id.'.json';}
    private function writeState(string $id,array $state): void{$this->atomicWrite($this->statePath($id),json_encode($state,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)."\n",0600);}
    private function requiredState(string $id,string $installationId): array{$p=$this->statePath(trim($id));try{$v=json_decode((string)@file_get_contents($p),true,48,JSON_THROW_ON_ERROR);}catch(Throwable){$v=null;}if(!is_array($v)||($v['format']??'')!==self::CONTRACT)throw new PublicUpdateException('deployment_rebind_not_found','Rebind state was not found.',404);if(!hash_equals((string)($v['installation_id']??''),$installationId))throw new PublicUpdateException('deployment_rebind_owner_mismatch','Rebind state belongs to another installation.',403);return $v;}
    private function writeSecretFile(string $path,string $bytes): void{$d=dirname($path);if(!is_dir($d)&&!@mkdir($d,0700,true)&&!is_dir($d))throw new PublicUpdateException('deployment_write_failed','Rebind storage cannot be created.',500);if(file_put_contents($path,$bytes,LOCK_EX)===false)throw new PublicUpdateException('deployment_write_failed','Rebind file could not be written.',500);@chmod($path,0600);}
    private function atomicWrite(string $path,string $bytes,int $mode): void{$d=dirname($path);if(!is_dir($d)||!is_writable($d))throw new PublicUpdateException('deployment_write_failed','Deployment configuration directory is not writable.',500);$tmp=$path.'.tmp-'.bin2hex(random_bytes(5));if(file_put_contents($tmp,$bytes,LOCK_EX)===false){@unlink($tmp);throw new PublicUpdateException('deployment_write_failed','Deployment configuration could not be staged.',500);}@chmod($tmp,$mode);if(!@rename($tmp,$path)){@unlink($tmp);throw new PublicUpdateException('deployment_write_failed','Deployment configuration could not be committed atomically.',500);}@chmod($path,$mode);}
}
