<?php
declare(strict_types=1);

namespace Sokna\PublicEdge\Deployment;

use RuntimeException;
use Throwable;

/**
 * Stable Staff PWA identity.
 *
 * The opaque app id belongs to the Public installation and is deliberately
 * independent of deployment domain and base path. Existing installations that
 * predate this field deterministically derive it from public_instance_id once,
 * then persist it into install.lock without depending on URL/Host headers.
 */
final class PwaIdentity
{
    public const THEME_COLOR = '#0f6b66';
    public const BACKGROUND_COLOR = '#f6f5f0';

    public function __construct(private readonly string $componentRoot)
    {
    }

    public function appId(): string
    {
        $path=$this->componentRoot.'/install.lock';
        $lock=$this->read($path);
        $current=trim((string)($lock['pwa_app_id']??''));
        if($this->valid($current))return $current;

        $instance=trim((string)($lock['public_instance_id']??''));
        if($instance==='')throw new RuntimeException('Public installation identity is unavailable.');
        // Deterministic upgrade identity prevents concurrent first requests from
        // inventing different app ids and is still URL/domain independent.
        $id='pwa-'.substr(hash('sha256',"sokna-staff-pwa-app-id-v1\0".$instance),0,32);
        $lock['pwa_app_id']=$id;
        $lock['pwa_app_id_created_at']=$lock['pwa_app_id_created_at']??gmdate('c');
        $this->persist($path,$lock);
        return $id;
    }

    public function manifestIdPath(): string
    {
        return '/.sokna-pwa/staff/'.rawurlencode($this->appId());
    }

    /** @return array<string,mixed> */
    private function read(string $path): array
    {
        try{$value=json_decode((string)@file_get_contents($path),true,32,JSON_THROW_ON_ERROR);}catch(Throwable){$value=null;}
        if(!is_array($value)||($value['format']??'')!=='sokna-public-install-lock-v1')throw new RuntimeException('Public install.lock is invalid.');
        return $value;
    }

    private function valid(string $value): bool
    {
        return preg_match('/^pwa-[a-f0-9]{32}$/D',$value)===1;
    }

    /** @param array<string,mixed> $value */
    private function persist(string $path,array $value): void
    {
        $bytes=json_encode($value,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)."\n";
        $tmp=$path.'.pwa-'.bin2hex(random_bytes(5)).'.tmp';
        if(file_put_contents($tmp,$bytes,LOCK_EX)===false){@unlink($tmp);throw new RuntimeException('PWA identity could not be persisted.');}
        @chmod($tmp,0600);
        if(!@rename($tmp,$path)){@unlink($tmp);throw new RuntimeException('PWA identity could not be committed.');}
        @chmod($path,0600);
    }
}
