<?php
declare(strict_types=1);

namespace Sokna\PublicEdge\Deployment;

use Sokna\PublicEdge\Core\Config;
use Sokna\PublicEdge\Http\PublicPath;

/**
 * Product-level deployment binding.
 *
 * Domain/origin identity is configuration, never source code.  Runtime routing
 * keeps the configured base_path for compatibility, while this object exposes
 * one canonical, validated view of base_url + base_path and reports any drift.
 * It deliberately never mutates configuration from Host/X-Forwarded-* headers.
 */
final class DeploymentIdentity
{
    public function __construct(private readonly Config $config)
    {
    }

    public function configuredBaseUrl(): string
    {
        return self::canonicalBaseUrl($this->config->string('app.base_url', ''));
    }

    public function basePath(): string
    {
        return PublicPath::normalizeBasePath($this->config->string('app.base_path', ''));
    }

    public function origin(): string
    {
        $url = $this->configuredBaseUrl();
        if ($url === '') return '';
        $parts = parse_url($url);
        if (!is_array($parts)) return '';
        $scheme = strtolower((string)($parts['scheme'] ?? ''));
        $host = strtolower(trim((string)($parts['host'] ?? ''), '[]'));
        if ($scheme === '' || $host === '') return '';
        $authority = str_contains($host, ':') ? '[' . $host . ']' : $host;
        if (isset($parts['port'])) $authority .= ':' . (int)$parts['port'];
        return $scheme . '://' . $authority;
    }


    public function bindingFingerprint(): string
    {
        $base=$this->configuredBaseUrl();
        return $base===''?'':hash('sha256','sokna-public-binding-v1\n'.$base);
    }

    /** @return array<string,mixed> */
    public function snapshot(): array
    {
        $baseUrl = $this->configuredBaseUrl();
        $basePath = $this->basePath();
        $urlPath = '';
        if ($baseUrl !== '') {
            $parts = parse_url($baseUrl);
            if (is_array($parts)) $urlPath = PublicPath::normalizeBasePath((string)($parts['path'] ?? ''));
        }
        return [
            'contract' => 'sokna-deployment-binding-v1',
            'configured' => $baseUrl !== '',
            'base_url' => $baseUrl,
            'origin' => $this->origin(),
            'base_path' => $basePath,
            'url_path' => $urlPath,
            'coherent' => $baseUrl === '' || hash_equals($basePath, $urlPath),
            'host_header_is_authority' => false,
            'binding_fingerprint' => $this->bindingFingerprint(),
            'pwa' => [
                'service_worker_origin_bound' => true,
                'push_subscription_origin_bound' => true,
                'cross_origin_state_migrates_automatically' => false,
                'reauthentication_required_after_origin_change' => true,
                'manifest_id_source' => 'persisted_pwa_app_id',
                'same_origin_base_path_preserves_logical_app_id' => true,
            ],
        ];
    }

    public static function canonicalBaseUrl(string $value): string
    {
        $value = rtrim(trim($value), '/');
        if ($value === '') return '';
        $parts = parse_url($value);
        if (!is_array($parts)) return '';
        $scheme = strtolower((string)($parts['scheme'] ?? ''));
        $host = strtolower(trim((string)($parts['host'] ?? ''), '[]'));
        if (!in_array($scheme, ['http', 'https'], true) || $host === '') return '';
        if (!empty($parts['user']) || !empty($parts['pass']) || !empty($parts['query']) || !empty($parts['fragment'])) return '';
        $port = isset($parts['port']) ? (int)$parts['port'] : null;
        if ($port !== null && ($port < 1 || $port > 65535)) return '';
        $path = PublicPath::normalizeBasePath((string)($parts['path'] ?? ''));
        if (str_contains(rawurldecode($path), '..') || str_contains($path, '\\')) return '';
        $authority = str_contains($host, ':') ? '[' . $host . ']' : $host;
        if ($port !== null) $authority .= ':' . $port;
        return $scheme . '://' . $authority . $path;
    }
}
