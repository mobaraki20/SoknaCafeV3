<?php
declare(strict_types=1);

namespace Sokna\PublicEdge\Remote;

use PDO;
use RuntimeException;

final class InstallationProjectionService
{
    public function __construct(private readonly PDO $pdo) {}

    public function sync(string $installationId, array $body): array
    {
        $installationId=trim($installationId);
        if($installationId==='' || preg_match('/^[A-Za-z0-9._:-]{1,96}$/D',$installationId)!==1){
            throw new RuntimeException('invalid installation id');
        }
        $revoked=$this->pdo->prepare('SELECT revoked_at FROM installations WHERE installation_id=? LIMIT 1');$revoked->execute([$installationId]);$rv=$revoked->fetchColumn();if($rv!==false&&$rv!==null&&trim((string)$rv)!=='')throw new RuntimeException('installation revoked');
        $display=trim((string)($body['display_name']??''));
        $remote=!array_key_exists('remote_enabled',$body) || !empty($body['remote_enabled']);
        $orders=!array_key_exists('order_intake_enabled',$body) || !empty($body['order_intake_enabled']);
        $q=$this->pdo->prepare(
            'INSERT INTO installations(installation_id,display_name,active,remote_enabled,order_intake_enabled) VALUES(?,?,1,?,?) '.
            "ON DUPLICATE KEY UPDATE display_name=VALUES(display_name),active=1,remote_enabled=IF(authority_state='active',VALUES(remote_enabled),0),order_intake_enabled=IF(authority_state='active',VALUES(order_intake_enabled),0)"
        );
        $q->execute([$installationId,$display!==''?$display:null,$remote?1:0,$orders?1:0]);
        $effective=$this->pdo->prepare('SELECT remote_enabled,order_intake_enabled,authority_state,authority_epoch FROM installations WHERE installation_id=? LIMIT 1');$effective->execute([$installationId]);$state=$effective->fetch(PDO::FETCH_ASSOC)?:[];
        return ['status'=>200,'body'=>['ok'=>true,'installation_id'=>$installationId,'remote_enabled'=>(bool)($state['remote_enabled']??false),'order_intake_enabled'=>(bool)($state['order_intake_enabled']??false),'authority_state'=>(string)($state['authority_state']??'active'),'authority_epoch'=>(int)($state['authority_epoch']??1)]];
    }
}
