<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Http;
use Sokna\PublicEdge\Core\Bootstrap;
use Sokna\PublicEdge\Emergency\PublicUpdateException;
final class AuthorityEpochHttpAdapter
{
    public function __construct(private readonly Bootstrap $core){}
    public function fence(string $installationId,string $method,string $path,string $timestamp,string $nonce,string $signature,string $rawBody): array
    {
        $v=$this->core->signedLocalRequests()->verify($installationId,$method,$path,$timestamp,$nonce,$rawBody,$signature);
        if(($v['ok']??false)!==true)return ['status'=>(int)$v['status'],'body'=>['ok'=>false,'error'=>(string)$v['error']]];
        $body=json_decode($rawBody,true);if(!is_array($body))return ['status'=>400,'body'=>['ok'=>false,'error'=>'invalid_json']];
        try{return $this->core->authorityEpoch()->fenceRestore((string)$v['installation_id'],(int)($v['authority_epoch']??$body['authority_epoch']??0));}
        catch(PublicUpdateException $e){return ['status'=>$e->httpStatus,'body'=>['ok'=>false,'error'=>$e->errorCode]];}
    }

    public function activate(string $installationId,string $method,string $path,string $timestamp,string $nonce,string $signature,string $rawBody): array
    {
        $v=$this->core->signedLocalRequests()->verify($installationId,$method,$path,$timestamp,$nonce,$rawBody,$signature);
        if(($v['ok']??false)!==true)return ['status'=>(int)$v['status'],'body'=>['ok'=>false,'error'=>(string)$v['error']]];
        $body=json_decode($rawBody,true);if(!is_array($body))return ['status'=>400,'body'=>['ok'=>false,'error'=>'invalid_json']];
        try{return $this->core->authorityEpoch()->activate((string)$v['installation_id'],(int)($body['authority_epoch']??0));}
        catch(PublicUpdateException $e){return ['status'=>$e->httpStatus,'body'=>['ok'=>false,'error'=>$e->errorCode]];}
    }
}
