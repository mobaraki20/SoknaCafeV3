<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Http;

/** Read-only range aggregation from Local-authoritative daily projection.
 * No invented business events; detailed modules unavailable for unprojected ranges.
 */
final class PublicReportArchiveRange
{
    public static function aggregate(array $projection,string $from,string $to): ?array
    {
        if(!preg_match('/^\d{4}-\d{2}-\d{2}$/D',$from)||!preg_match('/^\d{4}-\d{2}-\d{2}$/D',$to))return null;
        $a=\DateTimeImmutable::createFromFormat('!Y-m-d',$from);$b=\DateTimeImmutable::createFromFormat('!Y-m-d',$to);
        if(!$a||!$b||$a->format('Y-m-d')!==$from||$b->format('Y-m-d')!==$to||$a>$b||$a->diff($b)->days>365)return null;
        $archive=$projection['archive']??null;
        if(!is_array($archive)||!is_array($archive['summary']??null)||!is_array($archive['sales']??null))return null;
        $first=(string)($archive['from']??'');$last=(string)($archive['to']??'');
        if($first===''||$last===''||$from<$first||$to>$last)return null;
        $between=static fn(array $r):bool=>isset($r['date'])&&is_string($r['date'])&&$r['date']>=$from&&$r['date']<=$to;
        $summary=['net_sales'=>0,'completed_settlements'=>0,'reversals'=>0,'avg_ticket'=>0,
            'order_count'=>0,'cancelled_orders'=>0,'guest_orders'=>0,'staff_orders'=>0,
            'net_expenses'=>0,'waiter_calls'=>0,'completed_waiter_calls'=>0];
        $completedSales=0;
        foreach($archive['summary'] as $r){if(!is_array($r)||!$between($r))continue;
            foreach($summary as $key=>$_)if($key!=='avg_ticket')$summary[$key]+=(int)($r[$key]??0);
            $completedSales+=(int)($r['completed_sales']??0);
        }
        $summary['avg_ticket']=$summary['completed_settlements']>0?(int)round($completedSales/$summary['completed_settlements']):0;
        $daily=[];foreach($archive['sales'] as $r){if(!is_array($r)||!$between($r))continue;
            $daily[]=['business_date'=>(string)$r['date'],'settlement_count'=>(int)($r['settlement_count']??0),'net_sales'=>(int)($r['net_sales']??0)];
        }usort($daily,static fn($x,$y)=>strcmp($x['business_date'],$y['business_date']));
        $destinationMap=[];foreach((array)($archive['destinations']??[]) as $r){if(!is_array($r)||!$between($r))continue;
            $key=(string)($r['destination']??'');if($key==='')continue;
            $destinationMap[$key]['destination']=$key;
            $destinationMap[$key]['settlement_count']=($destinationMap[$key]['settlement_count']??0)+(int)($r['settlement_count']??0);
            $destinationMap[$key]['net_sales']=($destinationMap[$key]['net_sales']??0)+(int)($r['net_sales']??0);
        }
        $itemMap=[];foreach((array)($archive['items']??[]) as $r){if(!is_array($r)||!$between($r))continue;
            $key=(string)($r['item_name']??'');if($key==='')continue;
            $itemMap[$key]['item_name']=$key;$itemMap[$key]['quantity']=($itemMap[$key]['quantity']??0)+(float)($r['quantity']??0);
            $itemMap[$key]['net_sales']=($itemMap[$key]['net_sales']??0)+(int)($r['net_sales']??0);
        }
        $destinations=array_values($destinationMap);usort($destinations,static fn($x,$y)=>$y['net_sales']<=>$x['net_sales']);
        $top=array_values($itemMap);usort($top,static fn($x,$y)=>$y['net_sales']<=>$x['net_sales']);
        return ['range'=>['from'=>$from,'to'=>$to],'summary'=>$summary,'daily'=>$daily,
            'destinations'=>$destinations,'top_items'=>array_slice($top,0,20),'available_sections'=>['overview','trends'],
            'generated_at'=>(string)($projection['generated_at']??''),
            'coverage'=>['message'=>'خلاصه، مقصد تسویه و روند این بازه از آرشیو روزانهٔ همگام‌شده محاسبه شده‌اند؛ تحلیل‌های تفصیلی خارج از بازهٔ اصلی هنوز در Public موجود نیستند.']];
    }
}
