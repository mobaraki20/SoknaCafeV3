<?php
declare(strict_types=1);
namespace Sokna\PublicEdge\Http;

use Sokna\PublicEdge\Core\Bootstrap;
use Sokna\PublicEdge\Emergency\PublicUpdateException;

final class EmergencyLocalHttpAdapter
{
    public function __construct(private readonly Bootstrap $core){}

    public function handle(string $installationId,string $method,string $path,string $timestamp,string $nonce,string $signature,string $rawBody): array
    {
        $v=$this->core->signedLocalRequests()->verify($installationId,$method,$path,$timestamp,$nonce,$rawBody,$signature);
        if(($v['ok']??false)!==true)return ['status'=>(int)$v['status'],'body'=>['ok'=>false,'error'=>(string)$v['error']]];
        $body=json_decode($rawBody,true);if(!is_array($body))return ['status'=>400,'body'=>['ok'=>false,'error'=>'invalid_json']];
        try{
            if($path==='/api/v1/local/emergency/access'){
                $r=$this->core->emergencyAccess()->provisionHash((string)($body['password_hash']??''),'local:'.$installationId);
                return ['status'=>200,'body'=>['ok'=>true]+$r];
            }
            if($path==='/api/v1/local/diagnostics'){
                return ['status'=>200,'body'=>[
                    'ok'=>true,
                    'health'=>$this->core->health()->status()['body']??[],
                    'connectivity'=>$this->core->connectivity()->status($installationId,45),
                    'relay'=>$this->core->realtime()->diagnostics($installationId),
                    'update'=>$this->core->publicUpdates()->snapshot(),
                    'routine_update'=>$this->core->routinePublicUpdates()->snapshot(),
                    'managed_inventory'=>$this->core->routinePublicUpdates()->managedInventory(),
                    'protocols'=>['public_multi_baseline_exact_v1'=>(method_exists($this->core->routinePublicUpdates(),'supportsStrictMultiBaselineV1') && $this->core->routinePublicUpdates()->supportsStrictMultiBaselineV1()===true),'legacy_full_v1'=>true,'routine_delta_v2'=>true,'relay_probe_v1'=>true,'transport_exchange_v2'=>true,'projection_model_v2'=>true],
                    'recent_logs'=>$this->core->emergencyAccess()->recentAudit(40),
                ]];
            }
            if($path==='/api/v1/local/diagnostics/relay-probe/start'){
                return $this->core->realtime()->enqueueDiagnosticProbe(
                    $installationId,
                    (string)($body['request_id']??''),
                    (string)($body['correlation_id']??''),
                );
            }
            if($path==='/api/v1/local/diagnostics/relay-probe/result'){
                return $this->core->realtime()->diagnosticProbeResult($installationId,(string)($body['request_id']??''));
            }

            $legacy=$this->core->publicUpdates();
            $routine=$this->core->routinePublicUpdates();
            $actor='local:'.$installationId;

            // Compatibility status: H134 and older Local clients still see the
            // legacy update snapshot while H135+ can discover v2 explicitly.
            if($path==='/api/v1/local/update/status'){
                $reconcile=$routine->reconcileExternalEmergencyActivation($actor);
                return ['status'=>200,'body'=>[
                    'ok'=>true,
                    'update'=>$legacy->snapshot(),
                    'routine_update'=>$routine->snapshot(),
                    'routine_reconcile'=>$reconcile,
                    'protocols'=>['public_multi_baseline_exact_v1'=>(method_exists($this->core->routinePublicUpdates(),'supportsStrictMultiBaselineV1') && $this->core->routinePublicUpdates()->supportsStrictMultiBaselineV1()===true),'legacy_full_v1'=>true,'routine_delta_v2'=>true,'transport_exchange_v2'=>true,'projection_model_v2'=>true],
                ]];
            }

            // Legacy full-snapshot bridge/fallback. Never removed: existing
            // Local H134 can install the one-time .35 bridge through this path.
            if($path==='/api/v1/local/update/stage'){
                $b64=(string)($body['package_base64']??'');
                if(strlen($b64)>100663296)return ['status'=>413,'body'=>['ok'=>false,'error'=>'package_too_large']];
                $bytes=base64_decode($b64,true);if(!is_string($bytes)||$bytes==='')return ['status'=>422,'body'=>['ok'=>false,'error'=>'invalid_package']];
                $want=strtolower((string)($body['sha256']??''));
                if(!preg_match('/^[a-f0-9]{64}$/D',$want)||!hash_equals($want,hash('sha256',$bytes)))return ['status'=>422,'body'=>['ok'=>false,'error'=>'package_hash_mismatch']];
                $tmp=$legacy->incomingDir().'/local-'.bin2hex(random_bytes(8)).'.zip';
                file_put_contents($tmp,$bytes,LOCK_EX);
                try{$staged=$legacy->stageUploadedZip($tmp,$actor);}finally{@unlink($tmp);}
                return ['status'=>200,'body'=>['ok'=>true,'staged'=>$staged,'protocol'=>'legacy_full_v1']];
            }
            if($path==='/api/v1/local/update/activate')return ['status'=>200,'body'=>['ok'=>true,'update'=>$legacy->activateStaged($actor),'protocol'=>'legacy_full_v1']];
            if($path==='/api/v1/local/update/repair')return ['status'=>200,'body'=>['ok'=>true,'update'=>$legacy->repairStaged($actor),'protocol'=>'legacy_full_v1']];
            if($path==='/api/v1/local/update/rollback')return ['status'=>200,'body'=>['ok'=>true,'update'=>$legacy->rollback($actor),'protocol'=>'legacy_full_v1']];

            // Universal v3 transport must be served by the NEW guarded owner. An old
            // PHP-FPM/OPcache worker understands v2 but would ignore supported_baselines.
            // There is no fallback to v2 when this route is absent or old-owned.
            $v3Routes=[
                '/api/v1/local/update/v3/upload/start'=>'/api/v1/local/update/v2/upload/start',
                '/api/v1/local/update/v3/upload/chunk'=>'/api/v1/local/update/v2/upload/chunk',
                '/api/v1/local/update/v3/upload/finish'=>'/api/v1/local/update/v2/upload/finish',
                '/api/v1/local/update/v3/activate'=>'/api/v1/local/update/v2/activate',
                '/api/v1/local/update/v3/commit'=>'/api/v1/local/update/v2/commit',
                '/api/v1/local/update/v3/rollback'=>'/api/v1/local/update/v2/rollback',
            ];
            $strictV3=isset($v3Routes[$path]);
            if($strictV3){
                if(!method_exists($routine,'supportsStrictMultiBaselineV1')
                   ||$routine->supportsStrictMultiBaselineV1()!==true)
                    return ['status'=>409,'body'=>['ok'=>false,'error'=>'public_foundation_owner_not_ready']];
                $path=$v3Routes[$path];
            }

            // Routine delta v2: bounded resumable transfer + baseline lock +
            // two-phase activation. Local must verify /health then commit.
            if($path==='/api/v1/local/update/v2/upload/start'){
                $r=$routine->beginUpload((string)($body['sha256']??''),(int)($body['size_bytes']??0),$actor);
                return ['status'=>200,'body'=>['ok'=>true,'upload'=>$r,'protocol'=>'routine_delta_v2']];
            }
            if($path==='/api/v1/local/update/v2/upload/chunk'){
                $r=$routine->appendUploadChunk((string)($body['upload_id']??''),(int)($body['offset']??-1),(string)($body['chunk_base64']??''),(string)($body['chunk_sha256']??''));
                return ['status'=>200,'body'=>['ok'=>true,'upload'=>$r,'protocol'=>'routine_delta_v2']];
            }
            if($path==='/api/v1/local/update/v2/upload/finish'){
                $staged=$routine->finishUpload((string)($body['upload_id']??''),$actor,$strictV3);
                return ['status'=>200,'body'=>['ok'=>true,'staged'=>$staged,'routine_update'=>$routine->snapshot(),'protocol'=>'routine_delta_v2']];
            }
            if($path==='/api/v1/local/update/v2/activate'){
                if(!$strictV3 && (($routine->snapshot()['staged']['strict_multibaseline_v1']??false)===true))
                    return ['status'=>409,'body'=>['ok'=>false,'error'=>'public_update_v3_required']];
                return ['status'=>200,'body'=>['ok'=>true,'routine_update'=>$routine->activateStaged($actor),'verification_required'=>true,'protocol'=>'routine_delta_v2']];
            }
            if($path==='/api/v1/local/update/v2/commit'){
                if(!$strictV3 && (($routine->snapshot()['pending_verification']['strict_multibaseline_v1']??false)===true))
                    return ['status'=>409,'body'=>['ok'=>false,'error'=>'public_update_v3_required']];
                return ['status'=>200,'body'=>['ok'=>true,'routine_update'=>$routine->commitActivation($actor),'protocol'=>'routine_delta_v2']];
            }
            if($path==='/api/v1/local/update/v2/rollback')return ['status'=>200,'body'=>['ok'=>true,'routine_update'=>$routine->rollback($actor),'protocol'=>'routine_delta_v2']];

            return ['status'=>404,'body'=>['ok'=>false,'error'=>'route_not_found']];
        }catch(PublicUpdateException $e){
            return ['status'=>$e->httpStatus,'body'=>['ok'=>false,'error'=>$e->errorCode,'context'=>$e->context]];
        }
    }
}
