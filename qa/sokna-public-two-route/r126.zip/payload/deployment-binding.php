<?php
declare(strict_types=1);
use Sokna\PublicEdge\Emergency\PublicUpdateException;

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require __DIR__.'/bootstrap.php';
try{
    $config=require __DIR__.'/config.php';if(!is_array($config))throw new RuntimeException('config invalid');
    $core=sokna_public_bootstrap($config);$raw=(string)file_get_contents('php://input');
    $installation=trim((string)($_SERVER['HTTP_X_SOKNA_INSTALLATION']??''));$timestamp=trim((string)($_SERVER['HTTP_X_SOKNA_TIMESTAMP']??''));$nonce=trim((string)($_SERVER['HTTP_X_SOKNA_NONCE']??''));$signature=trim((string)($_SERVER['HTTP_X_SOKNA_SIGNATURE']??''));
    $verify=$core->signedLocalRequests()->verify($installation,'POST','/deployment-binding.php',$timestamp,$nonce,$raw,$signature);
    if(($verify['ok']??false)!==true){http_response_code((int)($verify['status']??401));echo json_encode(['ok'=>false,'error'=>(string)($verify['error']??'unauthorized')],JSON_UNESCAPED_SLASHES);exit;}
    $body=json_decode($raw,true);if(!is_array($body)){http_response_code(400);echo json_encode(['ok'=>false,'error'=>'invalid_json']);exit;}
    $action=trim((string)($body['action']??''));$service=$core->deploymentRebind();$installation=(string)$verify['installation_id'];
    $result=match($action){
        'probe'=>$service->probe($installation,(string)($body['probe_nonce']??''),(string)($body['probe_base_url']??'')),
        'prepare'=>$service->prepare($installation,$body),
        'commit'=>$service->commit($installation,(string)($body['rebind_id']??'')),
        'rollback'=>$service->rollback($installation,(string)($body['rebind_id']??'')),
        'finalize'=>$service->finalize($installation,(string)($body['rebind_id']??'')),
        'status'=>$service->status($installation,(string)($body['rebind_id']??'')),
        'transition_status'=>$service->transitionStatus($installation),
        'transition_close'=>$service->closeTransition($installation,(string)($body['rebind_id']??'')),
        default=>throw new PublicUpdateException('deployment_rebind_action_invalid','Deployment rebind action is invalid.',422),
    };
    echo json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
}catch(PublicUpdateException $e){http_response_code($e->httpStatus);echo json_encode(['ok'=>false,'error'=>$e->errorCode,'message'=>$e->getMessage()],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);}catch(Throwable){http_response_code(500);echo json_encode(['ok'=>false,'error'=>'deployment_rebind_failed']);}
