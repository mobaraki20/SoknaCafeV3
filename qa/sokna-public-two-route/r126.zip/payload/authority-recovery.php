<?php
declare(strict_types=1);
use Sokna\PublicEdge\Emergency\PublicUpdateException;
$root=__DIR__;
require_once $root.'/bootstrap.php';

header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('X-Frame-Options: DENY');
$config=is_file($root.'/config.php')?(require $root.'/config.php'):[];
if(!is_array($config)){http_response_code(503);exit('Public configuration unavailable.');}
$core=sokna_public_bootstrap($config);
$access=$core->emergencyAccess();
$service=$core->authorityEpoch();
$action=(string)($_GET['action']??'');
$method=strtoupper((string)($_SERVER['REQUEST_METHOD']??'GET'));

function ar_https(): bool {
    if(!empty($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off')return true;
    return strtolower(trim(explode(',',(string)($_SERVER['HTTP_X_FORWARDED_PROTO']??''))[0]??''))==='https';
}
function ar_json(array $body,int $status=200): never {http_response_code($status);header('Content-Type: application/json; charset=utf-8');echo json_encode($body,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function ar_client_key(): string {return (string)($_SERVER['REMOTE_ADDR']??'unknown').'|'.substr((string)($_SERVER['HTTP_USER_AGENT']??''),0,180);}
function ar_e(string $v): string {return htmlspecialchars($v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}

// One-time authority re-enrollment is intentionally a mutable recovery surface.
// The stable /emergency.php owner remains byte-immutable across routine releases.
if($method==='POST'&&$action==='reenroll'){
    $raw=(string)file_get_contents('php://input');$body=json_decode($raw,true);
    if(!is_array($body))ar_json(['ok'=>false,'error'=>'invalid_json'],400);
    try{
        $result=$service->complete((string)($body['new_installation_id']??''),(string)($body['enrollment_code']??''),(string)($body['new_shared_secret']??''),(string)($body['display_name']??''));
        ar_json($result,200);
    }catch(PublicUpdateException $e){ar_json(['ok'=>false,'error'=>$e->errorCode],$e->httpStatus);}
    catch(Throwable){ar_json(['ok'=>false,'error'=>'authority_recovery_failed'],500);}
}

session_name('sokna_public_authority_recovery');
session_set_cookie_params(['httponly'=>true,'secure'=>ar_https(),'samesite'=>'Strict','path'=>'/']);
session_start();
$_SESSION['csrf']=$_SESSION['csrf']??bin2hex(random_bytes(24));
$now=time();if((int)($_SESSION['last_seen']??0)>0&&$now-(int)$_SESSION['last_seen']>900){$_SESSION=[];session_regenerate_id(true);$_SESSION['csrf']=bin2hex(random_bytes(24));}
$_SESSION['last_seen']=$now;
$notice='';$error='';$oneTime='';
if($method==='POST'){
    $csrf=(string)($_POST['csrf']??'');
    if(!hash_equals((string)($_SESSION['csrf']??''),$csrf)){$error='نشست بازیابی معتبر نیست.';}
    elseif($action==='login'){
        $status=$access->loginStatus(ar_client_key());
        if(!$status['allowed']){$error='ورود موقتاً قفل است.';}
        elseif($access->verify((string)($_POST['password']??''))){$access->recordLoginSuccess(ar_client_key());$_SESSION['authority_recovery_authenticated']=true;session_regenerate_id(true);$_SESSION['csrf']=bin2hex(random_bytes(24));$notice='ورود امن انجام شد.';}
        else{$next=$access->recordLoginFailure(ar_client_key());$access->audit('authority_recovery_login_failed',null,$access->clientActorHint(ar_client_key()),[]);$error=$next['allowed']?'رمز اضطراری صحیح نیست.':'ورود موقتاً قفل شد.';}
    }elseif($action==='logout'){$_SESSION=[];session_destroy();header('Location: authority-recovery.php');exit;}
    elseif($action==='offer'){
        if(($_SESSION['authority_recovery_authenticated']??false)!==true){$error='ابتدا وارد شوید.';}
        elseif(trim((string)($_POST['confirmation']??''))!=='RECOVER'){$error='عبارت تأیید صحیح نیست.';}
        else try{$offer=$service->createOffer(trim((string)($_POST['installation_id']??'')),1800,$access->clientActorHint(ar_client_key()));$oneTime=(string)($offer['enrollment_code']??'');$notice='کد بازیابی نسل ساخته شد. Public تا ثبت نسل جدید و همگام‌سازی کامل مسدود می‌ماند.';}catch(PublicUpdateException $e){$error=$e->errorCode;}catch(Throwable){$error='authority_recovery_failed';}
    }
}
$authenticated=($_SESSION['authority_recovery_authenticated']??false)===true;
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>بازیابی نسل Public Edge</title><style>body{font-family:Tahoma,"Segoe UI",sans-serif;background:#f4f1ea;color:#222;margin:0}.wrap{max-width:720px;margin:40px auto;padding:20px}.card{background:#fff;border:1px solid #ddd5c8;border-radius:16px;padding:22px;margin:14px 0}.muted{color:#6a6a65;line-height:1.8}.alert{padding:12px;border-radius:10px;margin:12px 0}.ok{background:#eaf6f0}.bad{background:#fff0ed}.code{direction:ltr;text-align:left;background:#151b18;color:#fff;padding:14px;border-radius:10px;font:16px monospace;word-break:break-all}label{display:block;margin:12px 0}input{box-sizing:border-box;width:100%;padding:11px;border:1px solid #ccc;border-radius:9px;margin-top:6px}button{padding:10px 14px;border:0;border-radius:9px;background:#0b6b56;color:#fff;font-weight:700;cursor:pointer}.danger{background:#9d382f}.row{display:flex;gap:10px;flex-wrap:wrap}</style></head><body><main class="wrap"><section class="card"><h1>بازیابی نسل اتصال Public</h1><p class="muted">این صفحه فقط برای restore و بازیابی authority است. کنسول اضطراری پایدار <code>/emergency.php</code> تغییر نمی‌کند.</p><?php if($notice!==''):?><div class="alert ok"><?=ar_e($notice)?></div><?php endif;?><?php if($error!==''):?><div class="alert bad"><?=ar_e($error)?></div><?php endif;?><?php if(!$authenticated):?><form method="post" action="?action=login"><input type="hidden" name="csrf" value="<?=ar_e((string)$_SESSION['csrf'])?>"><label>رمز اضطراری Public<input type="password" name="password" autocomplete="current-password" required></label><button type="submit">ورود</button></form><?php else:?><form method="post" action="?action=offer"><input type="hidden" name="csrf" value="<?=ar_e((string)$_SESSION['csrf'])?>"><label>شناسه نصب بازیابی‌شده<input type="text" name="installation_id" dir="ltr" required></label><label>برای تأیید، RECOVER را بنویسید<input type="text" name="confirmation" autocomplete="off" required></label><button class="danger" type="submit">ساخت کد بازیابی نسل</button></form><?php if($oneTime!==''):?><p class="muted">کد فقط همین بار نمایش داده می‌شود و ۳۰ دقیقه اعتبار دارد. آن را در Local → اتصال‌ها → وب عمومی وارد کنید.</p><div class="code"><?=ar_e($oneTime)?></div><?php endif;?><form method="post" action="?action=logout" style="margin-top:18px"><input type="hidden" name="csrf" value="<?=ar_e((string)$_SESSION['csrf'])?>"><button type="submit">خروج امن</button></form><?php endif;?></section></main></body></html>
