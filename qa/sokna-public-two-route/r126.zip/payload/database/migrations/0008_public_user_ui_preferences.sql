-- Public Staff account-scoped UI preferences. These are UX state only, never business authority.
CREATE TABLE IF NOT EXISTS public_user_ui_preferences (
    installation_id VARCHAR(96) NOT NULL,
    projection_id VARCHAR(96) NOT NULL,
    preferences_json JSON NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (installation_id,projection_id),
    CONSTRAINT fk_public_ui_pref_projection FOREIGN KEY (installation_id,projection_id) REFERENCES auth_projections(installation_id,projection_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
