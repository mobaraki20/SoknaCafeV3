-- H242 / P2A — monotonic Local projection event cursor + bounded forensic log.
-- Public remains a projection/read-model host; business authority stays Local.

CREATE TABLE IF NOT EXISTS remote_projection_cursors (
  installation_id VARCHAR(96) NOT NULL PRIMARY KEY,
  last_sequence BIGINT UNSIGNED NOT NULL DEFAULT 0,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_remote_projection_cursor_installation FOREIGN KEY(installation_id) REFERENCES installations(installation_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS remote_projection_events (
  installation_id VARCHAR(96) NOT NULL,
  sequence_id BIGINT UNSIGNED NOT NULL,
  event_type VARCHAR(96) NOT NULL,
  aggregate_type VARCHAR(48) NOT NULL,
  aggregate_id VARCHAR(96) NOT NULL,
  model_keys VARCHAR(255) NOT NULL,
  occurred_at DATETIME(6) NULL,
  received_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(installation_id,sequence_id),
  INDEX idx_remote_projection_events_received(installation_id,received_at),
  CONSTRAINT fk_remote_projection_event_installation FOREIGN KEY(installation_id) REFERENCES installations(installation_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
