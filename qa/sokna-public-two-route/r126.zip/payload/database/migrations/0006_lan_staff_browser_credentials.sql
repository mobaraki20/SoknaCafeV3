ALTER TABLE auth_projections
  ADD COLUMN lan_base_url VARCHAR(255) NULL AFTER preparation_areas_json,
  ADD COLUMN lan_token TEXT NULL AFTER lan_base_url,
  ADD COLUMN lan_token_expires_at DATETIME NULL AFTER lan_token;
