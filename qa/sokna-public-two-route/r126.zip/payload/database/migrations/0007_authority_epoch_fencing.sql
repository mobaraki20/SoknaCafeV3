-- H338B / A14 — Public authority epoch fencing for restore/re-enrollment.
ALTER TABLE installations
  ADD COLUMN authority_epoch BIGINT UNSIGNED NOT NULL DEFAULT 1 AFTER order_intake_enabled,
  ADD COLUMN authority_state VARCHAR(24) NOT NULL DEFAULT 'active' AFTER authority_epoch,
  ADD COLUMN authority_epoch_required TINYINT(1) NOT NULL DEFAULT 0 AFTER authority_state,
  ADD COLUMN authority_changed_at DATETIME(6) NULL AFTER authority_epoch_required;

CREATE TABLE IF NOT EXISTS installation_authority_reenrollments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  installation_id VARCHAR(96) NOT NULL,
  from_epoch BIGINT UNSIGNED NOT NULL,
  to_epoch BIGINT UNSIGNED NOT NULL,
  code_hash VARCHAR(255) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  expires_at DATETIME NOT NULL,
  completed_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_authority_reenroll_pending(installation_id,status,expires_at),
  CONSTRAINT fk_authority_reenroll_installation FOREIGN KEY(installation_id) REFERENCES installations(installation_id) ON DELETE CASCADE,
  CONSTRAINT ck_authority_reenroll_status CHECK (status IN ('pending','completed','cancelled','expired'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE realtime_requests ADD COLUMN authority_epoch BIGINT UNSIGNED NOT NULL DEFAULT 1 AFTER installation_id, ADD INDEX idx_realtime_authority(installation_id,authority_epoch,state,id);
ALTER TABLE deferred_work ADD COLUMN authority_epoch BIGINT UNSIGNED NOT NULL DEFAULT 1 AFTER installation_id, ADD INDEX idx_deferred_authority(installation_id,authority_epoch,state,created_at);
ALTER TABLE remote_projection_cursors ADD COLUMN authority_epoch BIGINT UNSIGNED NOT NULL DEFAULT 1 AFTER installation_id;
ALTER TABLE remote_projection_model_cursors ADD COLUMN authority_epoch BIGINT UNSIGNED NOT NULL DEFAULT 1 AFTER installation_id;
ALTER TABLE remote_projection_events ADD COLUMN authority_epoch BIGINT UNSIGNED NOT NULL DEFAULT 1 AFTER installation_id;
