-- H289 — resilient transport v2 per-model monotonic projection cursor.
CREATE TABLE IF NOT EXISTS remote_projection_model_cursors (
    installation_id VARCHAR(96) NOT NULL,
    model_key VARCHAR(64) NOT NULL,
    last_sequence BIGINT UNSIGNED NOT NULL DEFAULT 0,
    source_version CHAR(64) NULL,
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (installation_id,model_key),
    CONSTRAINT fk_h289_projection_model_cursor_installation FOREIGN KEY(installation_id) REFERENCES installations(installation_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
