(()=>{'use strict';
let cfg=window.__SOKNA_UI_PREFERENCES__;
if(!cfg){
  const node=document.getElementById('sokna-ui-preferences-config');
  if(node){
    try{
      const decoded=JSON.parse(node.textContent||'{}');
      if(decoded&&typeof decoded==='object'&&typeof decoded.endpoint==='string'&&decoded.endpoint){
        cfg=decoded;window.__SOKNA_UI_PREFERENCES__=cfg;
        const keys={theme:'sokna.theme',nav_compact:'sokna.nav.compact.v1',nav_groups:'sokna.nav.groups.v1',hall_sort:'sokna.hall.sort',hall_density:'sokna.hall.density'};
        const owner=String(cfg.owner||''),ownerKey='sokna.ui.preferences.owner.v1';
        const prior=localStorage.getItem(ownerKey)||'';
        if(prior&&owner&&prior!==owner)Object.values(keys).forEach(k=>localStorage.removeItem(k));
        const values=cfg.values&&typeof cfg.values==='object'?cfg.values:{};
        for(const [k,v] of Object.entries(values)){
          if(!keys[k])continue;
          const stored=k==='nav_compact'?(v?'1':'0'):k==='nav_groups'?JSON.stringify(v):String(v);
          localStorage.setItem(keys[k],stored);
        }
        if(owner)localStorage.setItem(ownerKey,owner);
      }
    }catch(_){/* Malformed configuration must not execute arbitrary code or leak identity. */}
  }
}
if(!cfg||!cfg.endpoint)return;
const keys={theme:'sokna.theme',nav_compact:'sokna.nav.compact.v1',nav_groups:'sokna.nav.groups.v1',hall_sort:'sokna.hall.sort',hall_density:'sokna.hall.density'};
const valid={theme:v=>['light','dark','system'].includes(v),nav_compact:v=>typeof v==='boolean',nav_groups:v=>Array.isArray(v)&&v.every(x=>['daily','operations','guest','management'].includes(String(x))),hall_sort:v=>['number','time'].includes(v),hall_density:v=>['normal','compact','overview'].includes(v)};
const fromStore=key=>{try{const raw=localStorage.getItem(keys[key]);if(raw==null)return undefined;if(key==='nav_compact')return raw==='1';if(key==='nav_groups'){const v=JSON.parse(raw);return valid[key](v)?v:undefined}return valid[key](raw)?raw:undefined}catch{return undefined}};
const canonical=(cfg.values&&typeof cfg.values==='object')?cfg.values:{};const seed={};for(const key of Object.keys(keys)){if(Object.prototype.hasOwnProperty.call(canonical,key))continue;const v=fromStore(key);if(v!==undefined)seed[key]=v}
let queue={},timer=0,inflight=false,retryFailures=0,stopped=false;
const MAX_FAILURES=4;
const flush=async()=>{
  if(inflight||stopped||!Object.keys(queue).length)return;
  const patch=queue;queue={};inflight=true;
  try{
    const body={preferences:patch};if(cfg.csrf)body.csrf_token=cfg.csrf;
    const r=await fetch(cfg.endpoint,{method:'POST',credentials:'same-origin',cache:'no-store',keepalive:true,headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify(body)});
    if(!r.ok){const error=new Error('preference_save_failed');error.authBlocked=r.status===401||r.status===403;throw error;}
    const j=await r.json();if(!j?.preferences||typeof j.preferences!=='object')throw new Error('preference_receipt_invalid');
    cfg.values=j.preferences;retryFailures=0;
  }catch(error){
    queue={...patch,...queue};retryFailures++;
    if(error?.authBlocked||retryFailures>=MAX_FAILURES){
      stopped=true;
      document.dispatchEvent(new CustomEvent('sokna:ui-preferences-sync-failed',{detail:{reason:error?.authBlocked?'session_expired':'retry_exhausted',pending:true}}));
    }
  }finally{
    inflight=false;
    if(!stopped&&Object.keys(queue).length){
      const delay=retryFailures?Math.min(16000,1200*Math.pow(2,retryFailures-1)):0;
      timer=setTimeout(flush,delay);
    }
  }
};
const schedule=patch=>{
  queue={...queue,...patch};retryFailures=0;stopped=false;
  clearTimeout(timer);timer=setTimeout(flush,250);
};
if(Object.keys(seed).length)schedule(seed);
document.addEventListener('sokna:ui-preference-intent',e=>{const d=e.detail||{},key=String(d.key||'');if(!valid[key]||!valid[key](d.value))return;schedule({[key]:d.value})});
addEventListener('pagehide',()=>{if(stopped||!Object.keys(queue).length)return;const body={preferences:queue};if(cfg.csrf)body.csrf_token=cfg.csrf;try{navigator.sendBeacon?.(cfg.endpoint,new Blob([JSON.stringify(body)],{type:'application/json'}))}catch(_){}});
})();
