<?php
declare(strict_types=1);
// Public-host compatibility endpoint for the byte-identical canonical Local tokens.css.
require dirname(__DIR__,2).'/font.php';
