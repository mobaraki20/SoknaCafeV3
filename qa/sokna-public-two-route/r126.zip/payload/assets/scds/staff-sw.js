'use strict';
const OFFLINE_CACHE_PREFIX='sokna-staff-offline-v3:';
const scopeUrl=()=>new URL(self.registration.scope);
const staffUrl=()=>scopeUrl().href;
const baseUrl=()=>new URL('../',self.registration.scope).href;
const appUrl=path=>new URL(String(path||'').replace(/^\//,''),baseUrl()).href;
const iconUrl=size=>new URL(`icon-${size}.png`,self.registration.scope).href;
const staffScopePath=()=>scopeUrl().pathname;
const cacheName=()=>OFFLINE_CACHE_PREFIX+encodeURIComponent(scopeUrl().origin+scopeUrl().pathname);
// CacheStorage is shared by every /public/ and /hpublic/ app on the same origin.
// Only retire previous-generation caches belonging to this exact staff scope.
const ownedOfflineCache=name=>/^sokna-staff-offline-v[0-9]+:/.test(name)&&name.endsWith(':'+encodeURIComponent(scopeUrl().origin+scopeUrl().pathname));
const NAV_NETWORK_BUDGET_MS=8000,ASSET_NETWORK_BUDGET_MS=4000;
async function fetchWithBudget(request,budgetMs){
  const controller=typeof AbortController!=='undefined'?new AbortController():null;
  if(!controller)return fetch(request);
  const timer=setTimeout(()=>controller.abort('network_budget'),Math.max(250,Number(budgetMs||0)));
  try{return await fetch(request,{signal:controller.signal})}finally{clearTimeout(timer)}
}
const templateUrl=view=>new URL(`offline-bootstrap?view=${encodeURIComponent(view)}`,self.registration.scope).href;
const OFFLINE_ASSETS=[
  'assets/scds/tokens.css','assets/scds/components.css','assets/scds/remote-staff.css','assets/product-ui.css','assets/ui-sprite.svg',
  'assets/product-boot.js','assets/product-theme.js','assets/locale.js','assets/staff-app/runtime.js','assets/staff-app/public-hall-transport.js',
  'assets/staff-app/sellable-picker.js','assets/settlement-tender.js','assets/ui-dialogs.js','assets/product-shell.js','assets/product-interactions.js',
  'assets/jalali-fields.js','assets/scds/scds.js','assets/order-line-ui.js','assets/staff-app/order-draft-workspace.js','assets/hall-settlement-v32.js',
  'assets/staff-app/hall-workspace.js','assets/staff-app/preparation-workspace.js','assets/staff-app/offline-bootstrap.js'
];
const OFFLINE_ASSET_URLS=new Set(OFFLINE_ASSETS.map(appUrl));
const offlineShell=()=>new Response(`<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#0f6b66"><meta name="color-scheme" content="light dark"><title>سکنا — بدون اتصال</title><style>:root{color-scheme:light dark;--bg:#f5f6f3;--card:#fff;--text:#20352b;--muted:#66736d;--line:#dfe5e1;--accent:#0f6b66}@media(prefers-color-scheme:dark){:root{--bg:#111916;--card:#17211d;--text:#eef5f1;--muted:#a8b4ae;--line:#2c3832;--accent:#63b8ad}}*{box-sizing:border-box}html{background:var(--bg);font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}body{margin:0;min-height:100dvh;display:grid;place-items:center;padding:max(18px,env(safe-area-inset-top)) max(18px,env(safe-area-inset-right)) max(18px,env(safe-area-inset-bottom)) max(18px,env(safe-area-inset-left));background:radial-gradient(circle at 80% 8%,color-mix(in srgb,var(--accent) 12%,transparent),transparent 24rem),var(--bg);color:var(--text)}main{inline-size:min(430px,100%);display:grid;gap:18px;padding:22px;border:1px solid var(--line);border-radius:22px;background:var(--card);box-shadow:0 18px 50px #0002}.mark{inline-size:48px;block-size:48px;display:grid;place-items:center;border-radius:15px;background:color-mix(in srgb,var(--accent) 13%,var(--card));color:var(--accent);font-weight:900;font-size:20px}.state{display:inline-flex;align-items:center;gap:7px;color:var(--muted);font-size:13px}.state:before{content:"";inline-size:8px;block-size:8px;border-radius:50%;background:#d58a25}h1{margin:0;font-size:20px;line-height:1.5}p{margin:5px 0 0;color:var(--muted);font-size:14px;line-height:1.9}.actions{display:grid;grid-template-columns:1fr;gap:8px}.b{min-block-size:46px;display:grid;place-items:center;padding:0 16px;border-radius:13px;background:var(--accent);color:#fff;text-decoration:none;font-weight:800}.hint{padding-top:13px;border-top:1px solid var(--line);color:var(--muted);font-size:12px;line-height:1.8}@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important}}</style></head><body><main><div class="mark" aria-hidden="true">س</div><div><span class="state">اتصال Public در دسترس نیست</span><h1>سکنا فعلاً به شبکه نرسید</h1><p>اگر این دستگاه قبلاً در شبکه کافه آماده شده باشد، مسیر عملیاتی امن به‌صورت خودکار امتحان می‌شود. در غیر این صورت بعد از برگشت اتصال دوباره تلاش کنید.</p></div><div class="actions"><a class="b" href="${staffUrl()}">تلاش دوباره</a></div><div class="hint">اطلاعات حساس یا نشست ورود در این صفحه ذخیره نشده است.</div></main></body></html>`,{status:503,headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'}});
function viewForNavigation(url){const scope=scopeUrl(),relative=url.pathname.slice(scope.pathname.length).replace(/^\/+|\/+$/g,'');if(relative==='operator')return 'operator';if(relative==='preparation')return 'preparation';return 'home'}
async function warmOffline(){
  const cache=await caches.open(cacheName());
  for(const view of ['home','operator','preparation']){
    try{const r=await fetch(templateUrl(view),{credentials:'include',cache:'no-store',headers:{'X-Sokna-Offline-Warm':'1'}});if(r.ok&&String(r.headers.get('X-Sokna-Offline-Template')||'')==='1')await cache.put(templateUrl(view),r.clone())}catch{}
  }
  for(const url of OFFLINE_ASSET_URLS){try{const r=await fetch(url,{credentials:'same-origin',cache:'reload'});if(r.ok)await cache.put(url,r.clone())}catch{}}
}
async function purgeOffline(){try{await caches.delete(cacheName())}catch{}}
self.addEventListener('install',event=>{event.waitUntil(Promise.resolve())});
self.addEventListener('activate',event=>{event.waitUntil((async()=>{const names=await caches.keys();await Promise.all(names.filter(n=>ownedOfflineCache(n)&&n!==cacheName()).map(n=>caches.delete(n)));await self.clients.claim()})())});
self.addEventListener('message',event=>{const type=String(event.data?.type||'');if(type==='sokna:warm-offline')event.waitUntil(warmOffline());else if(type==='sokna:purge-offline')event.waitUntil(purgeOffline());else if(type==='sokna:activate-update')event.waitUntil(self.skipWaiting())});
self.addEventListener('fetch',event=>{
  const request=event.request;if(request.method!=='GET')return;const url=new URL(request.url);
  if(request.mode==='navigate'&&url.origin===self.location.origin&&url.pathname.startsWith(staffScopePath())){
    event.respondWith((async()=>{try{const live=await fetchWithBudget(request,NAV_NETWORK_BUDGET_MS);return live}catch{}const cache=await caches.open(cacheName()),cached=await cache.match(templateUrl(viewForNavigation(url)));return cached||offlineShell()})());return;
  }
  if(url.origin===self.location.origin&&OFFLINE_ASSET_URLS.has(url.href)){
    event.respondWith((async()=>{try{const live=await fetchWithBudget(request,ASSET_NETWORK_BUDGET_MS);if(live.ok){const cache=await caches.open(cacheName());await cache.put(url.href,live.clone());return live}const cache=await caches.open(cacheName()),cached=await cache.match(url.href);return cached||live}catch{const cache=await caches.open(cacheName());const cached=await cache.match(url.href);return cached||Response.error()}})());
  }
});
function notificationTarget(raw){
  const scope=scopeUrl(),fallback=staffUrl(),value=String(raw||'').trim();if(!value)return fallback;
  let parsed;try{parsed=new URL(value,self.location.origin)}catch{return fallback}if(parsed.origin!==self.location.origin)return fallback;
  if(parsed.pathname.startsWith(scope.pathname))return parsed.href;
  let route=parsed.pathname.replace(/^\/+|\/+$/g,'').split('/')[0];
  if(route==='waiter')route='preparation';
  const allowed=new Set(['operator','preparation','operations','subscribers','reports','notifications','account']);
  if(!allowed.has(route))return fallback;
  return new URL(route+'/'+parsed.pathname.replace(/^\/+[^/]+\/?/,''),scope).href+(parsed.search||'')+(parsed.hash||'');
}
self.addEventListener('push',event=>{
  let payload={};try{payload=event.data?event.data.json():{}}catch{payload={body:event.data?event.data.text():''}}
  const n=payload&&typeof payload.notification==='object'?payload.notification:payload,title=String(n?.title||'سکنا'),body=String(n?.body||'اعلان جدید برای شما ثبت شده است.');
  const rawActions=Array.isArray(n?.actions)?n.actions:[],maxActions=typeof Notification!=='undefined'&&Number.isFinite(Notification.maxActions)?Math.max(0,Notification.maxActions):2,actions=rawActions.slice(0,Math.min(2,maxActions)).map(x=>({action:String(x?.action||'open').replace(/[^a-z0-9_-]/gi,'').slice(0,32)||'open',title:String(x?.title||'مشاهده').slice(0,40),url:notificationTarget(x?.url||n?.url)})),actionTargets=Object.fromEntries(actions.map(x=>[x.action,x.url]));
  const options={body,dir:'rtl',lang:'fa',icon:iconUrl('192'),badge:iconUrl('192'),data:{url:notificationTarget(n?.url),actions:actionTargets},actions:actions.map(({action,title})=>({action,title})),tag:String(payload?.idempotency_key||n?.tag||'sokna-staff'),renotify:false};
  event.waitUntil(self.registration.showNotification(title,options));
});
self.addEventListener('notificationclick',event=>{
  event.notification.close();const action=String(event.action||''),actionTargets=event.notification?.data?.actions||{},target=notificationTarget(action&&actionTargets[action]?actionTargets[action]:event.notification?.data?.url),scopePath=staffScopePath();
  event.waitUntil((async()=>{const list=await self.clients.matchAll({type:'window',includeUncontrolled:true});for(const client of list){let current;try{current=new URL(client.url)}catch{continue}if(current.origin!==self.location.origin||!current.pathname.startsWith(scopePath))continue;if('navigate'in client)await client.navigate(target);await client.focus();return}if(self.clients.openWindow)await self.clients.openWindow(target)})());
});
