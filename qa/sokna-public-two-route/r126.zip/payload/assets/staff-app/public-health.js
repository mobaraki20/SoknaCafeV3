(()=>{
'use strict';
const root=document.querySelector('[data-public-health]');if(!root)return;
const api=root.dataset.healthApi||'/api/staff/connectivity',probeApi=root.dataset.healthProbe||'/api/staff/health/probe',systemApi=root.dataset.healthSystemApi||'/api/staff/health/system';
// The Staff adapter already enforces the reports.read capability and installation scope.
const suffix='/api/staff/connectivity';
const salesApi=api.endsWith(suffix)?api.slice(0,-suffix.length)+'/staff/reports-adapter?action=sales_support':'';

const tabs=[...root.querySelectorAll('[data-health-tab]')],panels=[...root.querySelectorAll('[data-health-panel]')];function setTab(key){tabs.forEach(t=>{const on=t.dataset.healthTab===key;t.classList.toggle('is-active',on);t.setAttribute('aria-selected',on?'true':'false')});panels.forEach(p=>p.hidden=p.dataset.healthPanel!==key);for(const el of root.querySelectorAll('[data-health-download],[data-health-probe-button]'))el.hidden=key!=='technical';}tabs.forEach(t=>t.addEventListener('click',()=>setTab(t.dataset.healthTab||'health')));
const q=s=>root.querySelector(s),fa=v=>window.SoknaLocale?.integer?window.SoknaLocale.integer(Number(v||0)):String(v??0),dt=v=>{if(!v)return '—';try{return window.SoknaLocale?.instantDateTime?window.SoknaLocale.instantDateTime(v):String(v)}catch{return String(v)}},esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const kinds={"diagnostics.ping":"آزمون سلامت","table_draft.create":"ثبت موقت","table_draft.edit":"ویرایش ثبت موقت","table_draft.finalize":"ثبت سفارش","settlement.commit":"تسویه","settlement.review":"بررسی تسویه","preparation.mutate":"آماده‌سازی","order.edit":"ویرایش سفارش","order.append":"افزودن اقلام","order.cancel":"لغو سفارش","guest_order.submit":"سفارش مهمان"};
const kindLabel=k=>kinds[k]||k||'—';
const stateLabels={queued:'در صف',claimed:'در حال پردازش',committed:'موفق',rejected:'رد شده',expired:'منقضی',cancelled:'لغو شده',unknown_review:'نیازمند بررسی',stale:'قدیمی'};
const stateLabel=v=>stateLabels[String(v||'')]||String(v||'—');
let lastConnectivity=null,lastSystem=null;const hashHint=v=>{const x=String(v||'').trim();return x.length>=16?`${x.slice(0,8)}…${x.slice(-8)}`:(x||'—')};
const runtimeLabels={observed_recently:'اخیراً اجرا شده',running:'در حال اجرا',healthy:'سالم',stale:'مدتی است مشاهده نشده',unavailable:'در دسترس نیست',unknown:'نامشخص'};
const runtimeLabel=v=>runtimeLabels[String(v||'')]||String(v||'—').replaceAll('_',' ');
function age(value){if(!value)return '—';const raw=String(value),t=Date.parse(raw.includes('T')?raw:raw.replace(' ','T')+'Z');if(!Number.isFinite(t))return '—';const s=Math.max(0,Math.floor((Date.parse(window.SoknaLocale.nowInstant())-t)/1000));if(s<60)return `${fa(s)} ثانیه`;if(s<3600)return `${fa(Math.floor(s/60))} دقیقه`;return `${fa(Math.floor(s/3600))} ساعت`;}
function secondsAge(value){const n=Number(value);if(!Number.isFinite(n))return '—';if(n<60)return `${fa(n)} ثانیه`;if(n<3600)return `${fa(Math.floor(n/60))} دقیقه`;return `${fa(Math.floor(n/3600))} ساعت`;}
function setMetric(key,value,helper=''){const a=q(`[data-health-metric="${key}"]`),b=q(`[data-health-helper="${key}"]`);if(a)a.textContent=value;if(b)b.textContent=helper||'—'}
function empty(box,text){box.innerHTML=`<div class="sc-public-health__empty">${esc(text)}</div>`}
function render(data){
  lastConnectivity=data;
  const c=data.connectivity||{},r=data.relay||{},state=String(data.state||'heartbeat_only'),summary=q('[data-health-summary]'),hbAge=data.heartbeat_age_seconds;
  const active=Number(r.queued||0)+Number(r.claimed||0)+Number(r.claimed_stale||0);
  const overdue=Number(r.expired_due||0);
  const connected=c.local_fresh===true&&data.operation_route_available===true;
  const problem=!connected||data.relay_stalled===true||overdue>0;
  summary.className='sc-public-health__operator-status '+(problem?'is-warning':active>0?'is-busy':'is-ok');
  if(!connected)summary.textContent='ارتباط با سامانهٔ کافه نیازمند بررسی است؛ پیش از ثبت عملیات جدید، وضعیت اتصال را بررسی کنید.';
  else if(data.relay_stalled===true||overdue>0)summary.textContent='برخی درخواست‌ها نیازمند رسیدگی‌اند. جزئیات در بخش «درخواست‌ها» است.';
  else if(active>0)summary.textContent=`ارتباط برقرار است؛ ${fa(active)} درخواست در حال انتقال یا پردازش است.`;
  else summary.textContent='ارتباط با سامانهٔ کافه برقرار است و درخواست معطلی وجود ندارد.';

  setMetric('heartbeat',connected?'متصل':'نیازمند بررسی',c.last_seen_at?`آخرین ارتباط ${age(c.last_seen_at)} پیش`:'هنوز ارتباط تأیید نشده');
  setMetric('runtime',runtimeLabel(c.runtime_status),c.local_version?`نسخه Local: ${c.local_version}`:'نسخه Local نامشخص');
  setMetric('queue',`${fa(active)} درخواست`,overdue>0?`${fa(overdue)} درخواست دیرکرده`:(active?'در حال پردازش':'درخواستی منتظر نمانده است'));
  const lastBusinessAt=r.last_terminal_at||null;
  setMetric('roundtrip',lastBusinessAt?'ثبت‌شده':'ثبت نشده',lastBusinessAt?`آخرین نتیجه ${age(lastBusinessAt)} پیش`:'بعد از اولین درخواست، زمان آن نمایش داده می‌شود');

  const kindsBox=q('[data-health-queue-kinds]'),rows=(Array.isArray(r.queue_by_kind)?r.queue_by_kind:[]).filter(x=>Number(x.queued||0)+Number(x.claimed||0)+Number(x.claimed_stale||0)+Number(x.expired_due||0)>0);
  if(!rows.length)empty(kindsBox,'صف فعال یا lease معوقی وجود ندارد.');else kindsBox.innerHTML=rows.map(x=>`<div class="sc-public-health__row"><strong>${esc(kindLabel(x.kind))}</strong><span><small>در صف</small><br>${esc(fa(x.queued||0))}</span><span><small>در حال پردازش</small><br>${esc(fa(x.claimed||0))}</span><span><small>پردازش قدیمی</small><br>${esc(fa(x.claimed_stale||0))}</span><span><small>منقضی</small><br>${esc(fa(x.expired_due||0))}</span></div>`).join('');
  const pending=q('[data-health-pending]'),ps=Array.isArray(r.pending_samples)?r.pending_samples:[];
  if(!ps.length)empty(pending,'درخواست معطلی در صف وجود ندارد.');else pending.innerHTML=ps.map(x=>`<div class="sc-public-health__row sc-public-health__row--event"><strong>${esc(kindLabel(x.kind))}<br><small>${esc(String(x.request_id||'').slice(0,28))}</small></strong><span>${esc(stateLabel(x.state))}</span><span>${esc(age(x.created_at))}</span><span><small>${esc(x.error_code||'بدون خطا')}</small></span></div>`).join('');
  const events=q('[data-health-events]'),ev=Array.isArray(r.recent_terminal)?r.recent_terminal:[];
  if(!ev.length)empty(events,'رخداد نهایی ثبت نشده است.');else events.innerHTML=ev.map(x=>`<div class="sc-public-health__row sc-public-health__row--event"><strong>${esc(kindLabel(x.kind))}<br><small>${esc(String(x.request_id||'').slice(0,28))}</small></strong><span>${esc(stateLabel(x.state))}</span><span>${esc(age(x.updated_at))}</span><span><small>${esc(x.error_code||'موفق')}</small></span></div>`).join('');
  const fail=q('[data-health-failure]'),f=r.last_failure;
  if(!f)empty(fail,'شکست نهاییِ حل‌نشده‌ای در آخرین رخداد مشاهده نمی‌شود.');else fail.innerHTML=`<div class="sc-public-health__row sc-public-health__row--event"><strong>${esc(kindLabel(f.kind))}<br><small>${esc(String(f.request_id||'').slice(0,32))}</small></strong><span>${esc(stateLabel(f.state))}</span><span>${esc(dt(f.updated_at))}</span><span><small>${esc(f.error_code||'بدون کد')}</small></span></div>`;
}
function systemMetric(key,value,helper=''){const a=q(`[data-system-metric="${key}"]`),b=q(`[data-system-helper="${key}"]`);if(a)a.textContent=value;if(b)b.textContent=helper||'—'}
function renderSystem(data){lastSystem=data;const h=data?.health||{},r=data?.routine_update||{};systemMetric('version',String(h.version||r.current_version||'—'),`نسخهٔ پروتکل ${h.update_protocol||r.protocol||'—'}`);systemMetric('database',h.database==='ready'?'آماده':'نیازمند بررسی',`${fa(h.applied_migrations||0)}/${fa(h.catalog_migrations||0)} مهاجرت · ${fa(h.pending_migrations||0)} در انتظار`);systemMetric('tree',hashHint(r.managed_tree_sha256),r.managed_tree_matches_expected===false?'اختلاف با هویت ثبت‌شده نسخه؛ قبل از به‌روزرسانی بررسی شود':(r.managed_tree_matches_expected===true?'مطابق هویت ثبت‌شده نسخه':'شناسه کامل در گزارش فنی ذخیره می‌شود'));const clear=!r.staged&&!r.pending_verification&&!r.activation_journal&&!r.interrupted_activation;systemMetric('lifecycle',clear?'پاک':'نیازمند بررسی',clear?'به‌روزرسانی معلقی وجود ندارد':'جزئیات در گزارش فنی')}
async function loadSystem(signal){const res=await fetch(systemApi,{credentials:'same-origin',cache:'no-store',signal}),j=await res.json();if(!res.ok||!j.ok)throw new Error(j.error||'system_health_load_failed');renderSystem(j);return j}
function salesUnavailable(reason){return {format:'sokna-support-sales-reconciliation-v1',source:'public_synced_local_reports_projection',status:'unavailable',reason,days:[],captured_at:window.SoknaLocale.nowInstant(),query_completed:false};}
async function readSalesEvidence(){
 if(!salesApi)return salesUnavailable('sales_adapter_url_unavailable');
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),3000);
 try{
  const response=await fetch(salesApi,{credentials:'same-origin',cache:'no-store',signal:controller.signal});
  if(!response.ok)return salesUnavailable(response.status===403?'reports_permission_unavailable':'reports_model_unavailable');
  const j=await response.json();
  if(j?.success!==true||j?.sales_reconciliation_evidence?.format!=='sokna-support-sales-reconciliation-v1')
   return salesUnavailable('invalid_sales_evidence_response');
  return j.sales_reconciliation_evidence;
 }catch{return salesUnavailable('sales_evidence_request_failed');}
 finally{clearTimeout(timer);}
}
function downloadReport(salesEvidence){const report={format:'sokna-public-operator-support-v1',generated_at:window.SoknaLocale.nowInstant(),connectivity:lastConnectivity,system:lastSystem,sales_reconciliation_evidence:salesEvidence},blob=new Blob([JSON.stringify(report,null,2)+'\n'],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`sokna-public-support-${Date.now()}.json`;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000)}
async function load(signal){const res=await fetch(api,{credentials:'same-origin',cache:'no-store',signal}),j=await res.json();if(!res.ok||!j.ok)throw new Error(j.error||'health_load_failed');render(j);return j}
async function probe(button){button.disabled=true;const started=performance.now();try{const s=await fetch(probeApi,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:'{}'}),j=await s.json();if(!s.ok||!j.ok)throw new Error(j.error||'probe_start_failed');const id=j.request_id;for(let i=0;i<80;i++){await new Promise(r=>setTimeout(r,250));const res=await fetch(`${probeApi}?request_id=${encodeURIComponent(id)}`,{credentials:'same-origin',cache:'no-store'}),p=await res.json();if(res.ok&&p.ok&&p.terminal){const ms=Math.round(performance.now()-started);window.SoknaUI?.toast?.(p.state==='committed'?`مسیر برگشت در ${fa(ms)} میلی‌ثانیه تأیید شد.`:`آزمون با وضعیت ${stateLabel(p.state)} پایان یافت.`,p.state==='committed'?'success':'warning','آزمایش مسیر برگشت');await load();return}}throw new Error('probe_timeout')}catch(e){window.SoknaUI?.toast?.(e?.message==='probe_timeout'?'آزمون در بازه انتظار کامل نشد؛ اگر در صف باشد همین صفحه وضعیتش را نشان می‌دهد.':String(e?.message||'آزمون انجام نشد.'),'warning','سلامت ارتباط');await load().catch(()=>{})}finally{button.disabled=false}}
q('[data-health-refresh]')?.addEventListener('click',()=>Promise.allSettled([load(),loadSystem()]));q('[data-health-probe-button]')?.addEventListener('click',e=>probe(e.currentTarget));q('[data-health-download]')?.addEventListener('click',async e=>{const button=e.currentTarget;if(button.disabled)return;button.disabled=true;const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),3000);try{await Promise.allSettled([lastConnectivity?Promise.resolve():load(ctl.signal),lastSystem?Promise.resolve():loadSystem(ctl.signal)]);downloadReport(await readSalesEvidence())}finally{clearTimeout(timer);button.disabled=false}});load().catch(()=>{const s=q('[data-health-summary]');if(s){s.className='sc-alert sc-alert--danger';s.textContent='خواندن وضعیت سلامت Public انجام نشد.'}});loadSystem().catch(()=>{});setInterval(()=>load().catch(()=>{}),10000);
})();
