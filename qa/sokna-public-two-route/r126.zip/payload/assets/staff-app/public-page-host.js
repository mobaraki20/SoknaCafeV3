(()=>{'use strict';
const base=(document.body?.dataset.appBase||'').replace(/\/$/,'');const u=p=>base+'/'+String(p||'').replace(/^\//,'');
const status=document.querySelector('[data-public-connectivity]');
let indicator=null,indicatorPopover=null;
function createConnectivityIndicator(){if(!status||indicator)return;const notify=document.querySelector('.sc-shell__notify');if(!notify)return;indicator=document.createElement('button');indicator.type='button';indicator.className='sc-public-connectivity-trigger';indicator.dataset.state='warning';indicator.setAttribute('aria-label','وضعیت اتصال به سیستم کافه: در حال بررسی');indicator.setAttribute('aria-expanded','false');indicator.setAttribute('aria-haspopup','dialog');indicator.title='وضعیت اتصال به سیستم کافه';indicator.innerHTML='<span class="sc-connectivity-dot" aria-hidden="true"></span>';notify.insertAdjacentElement('afterend',indicator);indicatorPopover=document.createElement('div');indicatorPopover.className='sc-public-connectivity-details';indicatorPopover.id='sc-public-connectivity-details';indicatorPopover.hidden=true;indicatorPopover.setAttribute('role','dialog');indicatorPopover.setAttribute('aria-label','جزئیات وضعیت ارتباط');indicatorPopover.tabIndex=-1;document.body.append(indicatorPopover);indicator.setAttribute('aria-controls',indicatorPopover.id);
 const placeConnectivityDetails=()=>{if(indicatorPopover.hidden)return;const r=indicator.getBoundingClientRect();const maxWidth=Math.max(200,window.innerWidth-20);const width=Math.min(350,maxWidth);const x=Math.min(Math.max(10,r.right-width),window.innerWidth-width-10);const y=Math.min(r.bottom+8,Math.max(10,window.innerHeight-110));indicatorPopover.style.left=Math.round(x)+'px';indicatorPopover.style.right='auto';indicatorPopover.style.top=Math.round(y)+'px';indicatorPopover.style.width=width+'px'};
 indicator.addEventListener('click',()=>{const open=indicatorPopover.hidden;indicatorPopover.hidden=!open;indicator.setAttribute('aria-expanded',open?'true':'false');if(open){placeConnectivityDetails();indicatorPopover.focus({preventScroll:true})}});
 window.addEventListener('resize',placeConnectivityDetails,{passive:true});window.addEventListener('scroll',placeConnectivityDetails,{passive:true,capture:true});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!indicatorPopover.hidden){indicatorPopover.hidden=true;indicator.setAttribute('aria-expanded','false');indicator.focus()}});document.addEventListener('click',e=>{if(indicatorPopover.hidden||indicator.contains(e.target)||indicatorPopover.contains(e.target))return;indicatorPopover.hidden=true;indicator.setAttribute('aria-expanded','false')})}

const nf=new Intl.NumberFormat('fa-IR');
const dt=v=>window.SoknaLocale.dateTime(v);
const unsafeSelector='[data-order-finalize],[data-order-save],[data-order-acceptance-save],[data-preparation-action],[data-hall-mutation-action],[data-account-item-edit-save],[data-item-adjust-apply],[data-discount-apply],[data-discount-remove],[data-account-print-preparation],[data-account-print-customer],[data-table-move-confirm],[data-settle-submit],[data-late-commit],[data-settle-retry],[data-settle-detach]';
let readStale=true,mutationReady=false,transportProofObserved=false,transportPublicReady=false,transportLanReady=false;
function syncReadState(stale){readStale=!!stale;document.body.classList.toggle('rs-local-stale',readStale);document.body.dataset.publicLocalState=readStale?'stale':'fresh'}
function syncUnsafeActions(ready){mutationReady=ready===true;document.body.classList.toggle('rs-mutation-unavailable',!mutationReady);document.body.dataset.publicMutationState=mutationReady?'ready':'unavailable';document.querySelectorAll(unsafeSelector).forEach(el=>{if(!mutationReady){if(el.getAttribute('aria-disabled')!=='true'){el.setAttribute('aria-disabled','true');el.dataset.runtimeMutationAriaDisabled='1'}if(el.matches('a')&&!el.hasAttribute('tabindex')){el.tabIndex=-1;el.dataset.runtimeMutationTabindex='1'}}else{if(el.dataset.runtimeMutationAriaDisabled==='1'){el.removeAttribute('aria-disabled');delete el.dataset.runtimeMutationAriaDisabled}if(el.dataset.runtimeMutationTabindex==='1'){el.removeAttribute('tabindex');delete el.dataset.runtimeMutationTabindex}}})}
function guardUnavailableMutation(event){if(mutationReady)return;const direct=event.submitter?.matches?.(unsafeSelector)?event.submitter:event.target?.closest?.(unsafeSelector);const formFallback=event.type==='submit'&&!direct?event.target?.querySelector?.(unsafeSelector):null;if(!direct&&!formFallback)return;event.preventDefault();event.stopImmediatePropagation();setConnectivity('warning','مسیر ثبت عملیات هنوز آماده نیست؛ اطلاعات فرم حفظ شده است.','',false);if(indicator&&indicatorPopover?.hidden)indicator.click()}
const observeUnsafe=new MutationObserver(()=>syncUnsafeActions(mutationReady));
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const activeRequests=new Set();let connectivityInFlight=null,healthFailures=0,lastHealthOkAt=0;
async function json(url,opt={}){const {timeoutMs=6500,signal:externalSignal=null,...fetchOpt}=opt,controller=new AbortController(),timer=setTimeout(()=>controller.abort('deadline'),Math.max(250,Number(timeoutMs||6500)));let forward=null;activeRequests.add(controller);if(externalSignal){forward=()=>controller.abort('external');if(externalSignal.aborted)forward();else externalSignal.addEventListener('abort',forward,{once:true})}try{let r;try{r=await fetch(url,{credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json','Content-Type':'application/json',...(fetchOpt.headers||{})},...fetchOpt,signal:controller.signal})}catch(e){throw Object.assign(new Error(controller.signal.aborted?'پاسخ شبکه در مهلت تعیین‌شده نرسید.':'ارتباط با وب عمومی برقرار نشد.'),{code:controller.signal.aborted?'request_timeout':'request_failed'})}let j={};try{j=await r.json()}catch(e){if(controller.signal.aborted)throw Object.assign(new Error('پاسخ شبکه در مهلت تعیین‌شده کامل نشد.'),{code:'request_timeout',status:r.status})}if(!r.ok||j.ok===false||j.success===false)throw Object.assign(new Error(j.message||j.error||'دریافت اطلاعات انجام نشد.'),{code:j.error||'request_failed',status:r.status});return j}finally{clearTimeout(timer);activeRequests.delete(controller);if(externalSignal&&forward)externalSignal.removeEventListener('abort',forward)}}
function abortActiveRequests(){for(const c of [...activeRequests]){try{c.abort('page_lifecycle')}catch{}}}

function setConnectivity(kind,text,lastSync='',ready=null){if(ready!==null)syncUnsafeActions(ready===true);if(!status)return;status.className='sc-alert sc-public-connectivity '+(kind==='ok'?'sc-alert--success':kind==='error'?'sc-alert--danger':'sc-alert--warning');status.replaceChildren();const strong=document.createElement('strong');strong.textContent=kind==='ok'?'اتصال با سیستم کافه برقرار است':kind==='warning'?'وضعیت اتصال در حال بررسی است':'ارتباط زنده با سیستم کافه در دسترس نیست';const small=document.createElement('small');small.textContent=text+(lastSync?` · آخرین همگام‌سازی: ${dt(lastSync)}`:'');status.append(strong,small);status.dataset.connectivityState=kind;
 createConnectivityIndicator();if(indicator){indicator.dataset.state=kind;indicator.setAttribute('aria-label',strong.textContent);indicator.title=strong.textContent;if(indicatorPopover){indicatorPopover.replaceChildren(strong.cloneNode(true),small.cloneNode(true));}}
 // Connectivity details always live behind the header dot on mobile and desktop.
 // Unsafe writes remain blocked and expose this explanation on interaction.
 status.hidden=Boolean(indicator);
}
function healthRouteCanMutate(routeReady){return transportLanReady||(routeReady===true&&(!transportProofObserved||transportPublicReady))}
function combinedReadStale(j){return !!j.stale||(!!pageRoot&&(readRecoveryNeeded||[...pageReadModels.values()].some(Boolean)))}
function updateMeta(j){syncReadState(combinedReadStale(j));if(Object.prototype.hasOwnProperty.call(j,'mutation_ready'))syncUnsafeActions(j.mutation_ready===true);if(j.stale){setConnectivity('warning',mutationReady?'اطلاعات نمایش‌داده‌شده آخرین نسخه همگام‌شده است؛ عملیات هنگام ثبت دوباره توسط سیستم کافه بررسی می‌شود.':'اطلاعات نمایش‌داده‌شده آخرین نسخه همگام‌شده است و مسیر ثبت عملیات هنوز آماده نیست.',String(j.last_sync_at||''));return}if(status&&!status.dataset.connectivityState)setConnectivity('warning','اطلاعات تازه است؛ تأیید مسیر کامل ارتباط در حال انجام است.',String(j.last_sync_at||''));}
async function checkConnectivity(){
 if(!status)return;
 if(connectivityInFlight)return connectivityInFlight;
 connectivityInFlight=(async()=>{
  try{
   const j=await json(u('/api/staff/connectivity'),{timeoutMs:5000});
   healthFailures=0;lastHealthOkAt=Date.now();
   const c=j.connectivity||{},relay=j.relay||{},age=Number(j.relay_probe_age_seconds);
   const localFresh=c.local_fresh===true;
   const routeReady=j.operation_route_available===true;
   const last=String(c.last_seen_at||'');
   if(j.state==='ok'&&j.relay_round_trip_fresh===true){
    setConnectivity(routeReady?'ok':'warning',routeReady?'Heartbeat تازه است و مسیر رفت‌وبرگشت اخیراً تأیید شده است.':'Heartbeat و مسیر رفت‌وبرگشت تازه‌اند، اما ثبت عملیات فعلاً آماده نیست.',last,healthRouteCanMutate(routeReady));return;
   }
   if(localFresh){
    const detail=Number.isFinite(age)&&age>=0?` · آخرین آزمون کامل ${age<60?nf.format(Math.round(age))+' ثانیه':nf.format(Math.round(age/60))+' دقیقه'} قبل`:'';
    const pending=Number(relay.queued||0)+Number(relay.claimed||0)+Number(relay.claimed_stale||0);
    const tail=pending>0?` · ${nf.format(pending)} درخواست در جریان`:'';
    setConnectivity('warning',`Heartbeat تازه است؛ نتیجهٔ رفت‌وبرگشتیِ همین لحظه تأیید نشده است${detail}${tail}.`,last,healthRouteCanMutate(routeReady));return;
   }
   setConnectivity('error',last?'Heartbeat تازهٔ سیستم کافه دریافت نشده؛ آخرین اطلاعات ممکن است قدیمی باشد.':'هنوز همگام‌سازی معتبری دریافت نشده است.',last,healthRouteCanMutate(false));
  }catch(e){
   healthFailures+=1;
   if(healthFailures===1){setConnectivity('warning','دریافت وضعیت ارتباط لحظه‌ای ناموفق بود؛ در حال بررسی مجدد.','',healthRouteCanMutate(false));}
   else setConnectivity('error','وضعیت زندهٔ ارتباط با سیستم کافه قابل تأیید نیست.','',healthRouteCanMutate(false));
  }finally{connectivityInFlight=null}
 })();return connectivityInFlight;
}
const pageRoot=document.querySelector('[data-public-page-host]');
let readRefreshFlight=null,lastReadRefreshAt=0,readRecoveryNeeded=true,readFormDirty=false;
const pageReadModels=new Map();
function safeReadRefresh(){
 if(!pageRoot||document.hidden||readFormDirty)return false;
 const active=document.activeElement;
 return !(active&&pageRoot.contains(active)&&active.matches?.('input,textarea,select,[contenteditable="true"]'));
}
function readErrorBanner(){
 if(!pageRoot)return null;
 let banner=pageRoot.querySelector('[data-public-error]');
 if(!banner){banner=document.createElement('div');banner.className='sc-alert sc-alert--warning';banner.dataset.publicError='';banner.setAttribute('role','status');pageRoot.prepend(banner)}
 return banner;
}
function reportReadState(){
 const stale=[...pageReadModels.values()].some(v=>v===true);
 syncReadState(stale||readRecoveryNeeded);
 if(stale){const banner=readErrorBanner();if(banner){banner.hidden=false;banner.textContent='بخشی از اطلاعات این صفحه هنوز با لوکال همگام نشده است؛ داده‌ها ممکن است قدیمی باشند.'}}
}
// Missing data shape must not paint an apparently empty page after a transient
// successful HTTP response. Empty arrays are valid *only when explicitly sent*.
function validPageReadModel(model,p){
 if(!p||typeof p!=='object'||Array.isArray(p))return false;
 if(model==='inventory')return Array.isArray(p.items);
 if(model==='deferred_context')return Array.isArray(p.subscribers)&&Array.isArray(p.supply_groups);
 if(model==='notifications')return Array.isArray(p.items);
 if(model==='reports')return !!(p.dashboard&&typeof p.dashboard==='object'&&p.archive&&typeof p.archive==='object');
 return true;
}
async function read(model){
 const j=await json(u('/api/staff/read')+'?model='+encodeURIComponent(model),{timeoutMs:6500});
 if(!validPageReadModel(model,j.payload))throw new Error('دادهٔ این بخش هنوز به‌طور کامل دریافت نشده است؛ نمایش قبلی حفظ شده است.');
 pageReadModels.set(model,j.stale!==false);
 updateMeta(j);
 return j.payload;
}
async function renderOnce(){
 if(!pageRoot)return;
 const P=window.SoknaStaffDataPanels;if(!P)return;
 const view=pageRoot.dataset.publicPageHost;
 try{
  if(view==='operations'){
   // Do not turn a failed deferred-context read into an apparently empty supply list.
   const [inv,ctx]=await Promise.all([read('inventory'),read('deferred_context')]);
   const a=pageRoot.querySelector('[data-public-inventory]'),b=pageRoot.querySelector('[data-public-supply]');
   if(a)P.renderInventoryPanel(a,inv);
   if(b)P.renderSupplyCards(b,Array.isArray(ctx.supply_groups)?ctx.supply_groups:[]);
  }else if(view==='subscribers'){
   const p=await read('deferred_context');P.renderCustomersPanel(pageRoot.querySelector('[data-public-customers]'),p);
  }else if(view==='reports'){
   const p=await read('reports');P.renderReportSummary(pageRoot.querySelector('[data-public-reports]'),p);
  }else if(view==='notifications'){
   const p=await read('notifications');P.renderNotificationsPanel(pageRoot.querySelector('[data-public-notifications]'),p,{linkResolver:v=>v});
  }
  readRecoveryNeeded=[...pageReadModels.values()].some(v=>v===true);
  reportReadState();
  if(!readRecoveryNeeded){const banner=readErrorBanner();if(banner)banner.hidden=true}
  else reportReadState();
 }catch(e){
  readRecoveryNeeded=true;
  const banner=readErrorBanner();if(banner){banner.hidden=false;banner.textContent=e.message||'دریافت اطلاعات انجام نشد؛ پس از بازگشت ارتباط دوباره بررسی می‌شود.'}
  // Never clear the last successfully rendered content after a transient read failure.
  syncReadState(true);
 }
}
function render(){
 if(readRefreshFlight)return readRefreshFlight;
 if(!safeReadRefresh()&&lastReadRefreshAt>0)return Promise.resolve();
 readRefreshFlight=renderOnce().finally(()=>{lastReadRefreshAt=Date.now();readRefreshFlight=null});
 return readRefreshFlight;
}
function refreshReadIfNeeded(force=false){
 if(!safeReadRefresh()||readRefreshFlight)return;
 const elapsed=Date.now()-lastReadRefreshAt;
 if(elapsed<(force?2000:10000))return;
 if(force||readRecoveryNeeded||elapsed>=30000)void render();
}
// Current R93 Staff dashboard is server-rendered. The legacy [data-public-page-host]
// path above may not exist there: recover it independently, without touching writes.
let dashboardRecoveryFlight=null,lastDashboardRecoveryAt=0,dashboardRecoveryDone=false;
function recoverServerDashboard(){
 if(dashboardRecoveryDone||dashboardRecoveryFlight||document.hidden||readFormDirty)return;
 if(!document.querySelector('[data-projection-stale-banner]'))return;
 // Older R94 candidate included a separate controller. Do not run both.
 if(document.querySelector('script[src*="dashboard-recovery.js"]'))return;
 if(Date.now()-lastDashboardRecoveryAt<12000)return;
 lastDashboardRecoveryAt=Date.now();
 const controller=new AbortController();const timeout=window.setTimeout(()=>controller.abort(),7500);
 dashboardRecoveryFlight=(async()=>{
  try{
   const response=await fetch(location.href,{method:'GET',credentials:'same-origin',cache:'no-store',redirect:'follow',headers:{Accept:'text/html'},signal:controller.signal});
   if(!response.ok||!(response.headers.get('content-type')||'').includes('text/html'))return;
   const page=new DOMParser().parseFromString(await response.text(),'text/html');
   if(page.querySelector('.sc-dashboard')&&!page.querySelector('[data-projection-stale-banner]')&&document.querySelector('[data-projection-stale-banner]')){
    dashboardRecoveryDone=true;window.location.reload();
   }
  }catch(_){/* Leave stale warning visible while read-model publication is unavailable. */}
 })().finally(()=>{window.clearTimeout(timeout);dashboardRecoveryFlight=null});
}
function boot(){createConnectivityIndicator();observeUnsafe.observe(document.body,{subtree:true,childList:true});document.addEventListener('click',guardUnavailableMutation,true);document.addEventListener('submit',guardUnavailableMutation,true);syncReadState(true);syncUnsafeActions(false);checkConnectivity();render();recoverServerDashboard();window.setInterval(()=>{if(document.visibilityState==='visible'){checkConnectivity();refreshReadIfNeeded();recoverServerDashboard()}},10000)}
window.addEventListener('pagehide',abortActiveRequests);document.addEventListener('visibilitychange',()=>{if(document.hidden)abortActiveRequests();else{checkConnectivity();refreshReadIfNeeded(true);recoverServerDashboard()}});window.addEventListener('online',()=>{checkConnectivity();refreshReadIfNeeded(true);recoverServerDashboard()});if(pageRoot){pageRoot.addEventListener('input',()=>{readFormDirty=true},true);pageRoot.addEventListener('change',e=>{if(e.target.closest?.('form'))readFormDirty=true},true);}
document.addEventListener('sokna:staff-read-meta',e=>{if(e.detail)updateMeta({stale:!!e.detail.stale,last_sync_at:String(e.detail.last_sync_at||''),mutation_ready:e.detail.mutation_ready})});document.addEventListener('sokna:staff-mutation-readiness',e=>{const d=e.detail||{};transportProofObserved=true;transportPublicReady=d.public_ready===true;transportLanReady=d.lan_ready===true;syncUnsafeActions(d.ready===true)});if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();
