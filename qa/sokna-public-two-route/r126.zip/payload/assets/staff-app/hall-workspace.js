(()=>{'use strict';
const root=document.querySelector('[data-operator-workspace]');if(!root)return;
const transport=window.SoknaStaffRuntime?.adapter?.('hall')||window.SoknaHallTransport||null,autoLoad=root.dataset.autoLoad!=='0';
const appPath=v=>(window.SoknaURL?.path?window.SoknaURL.path(v):v),assetPath=v=>(window.SoknaAssets?.path?window.SoknaAssets.path(v):appPath(v)),api=root.dataset.api||appPath('/operator/api.php'),orderApi=root.dataset.orderApi||appPath('/staff/api.php'),financeApi=root.dataset.financeApi||appPath('/finance/api.php'),subscriberApi=root.dataset.subscriberApi||appPath('/subscribers/api.php'),csrf=root.dataset.csrf||'',canOrder=root.dataset.canOrder==='1',canCashier=root.dataset.canCashier==='1',canSupervise=root.dataset.canSupervise==='1',featureTableMove=root.dataset.featureTableMove!=='0',featureCommittedAdjust=root.dataset.featureCommittedAdjust!=='0',featureReprint=root.dataset.featureReprint!=='0',featureDiscount=root.dataset.featureDiscount!=='0',featureSettlement=root.dataset.featureSettlement!=='0',featureWaiterResponse=root.dataset.featureWaiterResponse!=='0';
const mutationsAllowed=()=>!transport?.canMutate||transport.canMutate();
// Transfer is committed in Local before Public's read model catches up.
let tableMovePending=null;
let tableMoveUncertainSessionId=0;
let tableMoveUncertainTransfer=null;
let tableMoveSubmitting=false;
// A committed move can outlive a Public projection refresh or a page reload.
// Store table/session IDs only (no account contents) and scope to this API endpoint.
const tableMoveStorageKey='sokna.hall.move-state.v1:'+api;
const validMoveState=v=>v&&typeof v==='object'&&['committed','unknown'].includes(v.phase)&&
 [v.sourceTableId,v.targetTableId].every(n=>Number.isSafeInteger(n)&&n>0)&&
 Number.isSafeInteger(v.sourceSessionId)&&v.sourceSessionId>=0&&
 (v.sourceSessionId>0||(Number.isSafeInteger(v.sourceDraftId)&&v.sourceDraftId>0))&&
 v.sourceTableId!==v.targetTableId&&Number.isSafeInteger(v.savedAt)&&v.savedAt>0&&
 typeof v.requestId==='string'&&/^hall-move-[a-zA-Z0-9-]{8,90}$/.test(v.requestId)&&
 (v.phase!=='committed'||(v.sourceSessionId>0?
   (Number.isSafeInteger(v.newSessionId)&&v.newSessionId>0):
   (v.newSessionId===0&&v.movedDraftId===v.sourceDraftId)));
const storeMoveState=v=>{try{if(v)localStorage.setItem(tableMoveStorageKey,JSON.stringify(v));else localStorage.removeItem(tableMoveStorageKey)}catch{}};
const readMoveState=()=>{try{const raw=localStorage.getItem(tableMoveStorageKey);if(!raw)return null;const saved=JSON.parse(raw);if(validMoveState(saved)&&Date.now()-saved.savedAt>=0&&Date.now()-saved.savedAt<86400000)return saved;localStorage.removeItem(tableMoveStorageKey)}catch{}return null};
const applyMoveState=v=>{tableMovePending=v?.phase==='committed'?v:null;tableMoveUncertainTransfer=v?.phase==='unknown'?v:null;tableMoveUncertainSessionId=tableMoveUncertainTransfer?.sourceSessionId||0};
const rememberMoveState=v=>{applyMoveState(v);storeMoveState(v)};
applyMoveState(readMoveState());

let lastMutationReady=mutationsAllowed();
// A committed command is not yet a published read-model. Preserve this visible
// pending state until a model confirms the status; do not send it twice.
const waiterStatusPending=new Map();
const syncHallMutationReadiness=()=>{const next=mutationsAllowed();if(next===lastMutationReady)return;lastMutationReady=next;syncHallFreshnessStatus();renderAttention();renderTables();renderOrderAcceptance();if(account?.table&&!root.querySelector('dialog[open]'))renderAccount();};
document.addEventListener('sokna:staff-mutation-readiness',syncHallMutationReadiness);
const L=window.SoknaLocale||{time:v=>String(v??''),integer:v=>new Intl.NumberFormat('fa-IR').format(Number(v||0)),moneyNumber:v=>new Intl.NumberFormat('fa-IR').format(Number(v||0)),money:v=>`${new Intl.NumberFormat('fa-IR').format(Number(v||0))} تومان`,humanDigits:v=>String(v??'').replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[Number(d)])},moneyNumber=v=>L.moneyNumber?L.moneyNumber(v):L.integer(v),money=v=>L.money(v),human=v=>L.humanDigits?L.humanDigits(v):String(v??'').replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
const numericValue=v=>{if(typeof L.numericValue==='function')return Number(L.numericValue(v,{decimal:true})||0);const x=String(v??'').replace(/[۰-۹]/g,d=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))).replace(/[٠-٩]/g,d=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))).replace(/[^\d.-]/g,'');return Number(x||0)};
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uiIcon=name=>`<svg class="sc-ui-icon" aria-hidden="true" focusable="false"><use href="${assetPath('/assets/ui-sprite.svg')}#icon-${name}"></use></svg>`;
const LineUI=window.SoknaOrderLineUI;if(!LineUI)throw new Error('Shared order line UI is unavailable.');
const hallView=root.querySelector('[data-hall-view]'),orderView=root.querySelector('[data-order-view]'),accountPane=root.querySelector('[data-account-pane]'),status=root.querySelector('[data-status]');
const initialParams=new URLSearchParams(location.search),initialView=initialParams.get('view')||'';const pref=(key,fallback)=>{try{return localStorage.getItem(key)||fallback}catch{return fallback}},savePref=(key,value)=>{try{localStorage.setItem(key,value)}catch{}const map={'sokna.hall.sort':'hall_sort','sokna.hall.density':'hall_density'},prefKey=map[key];if(prefKey)document.dispatchEvent(new CustomEvent('sokna:ui-preference-intent',{detail:{key:prefKey,value}}))};let snap=null,zone='all',selectedTableId=Number(initialParams.get('table_id')||0),account=null,financeAccount=null,financeError='',orderController=null,hallScrollTop=0,orderExitTarget=0,orderAcceptance={cafe:true,kitchen:true,bar:true},printQuickPreferences={preparation:true,direct:true,itemized:true,subscriber:true,accommodation:true},accountEditingItemId=0,accountAdjustmentDrafts=new Map(),accountAdjustmentReasons=new Map(),accountAdjustmentNotes=new Map(),accountAdjustmentModes=new Map(),accountServiceDistributionDrafts=new Map(),accountItemNoteDrafts=new Map(),accountEditFeedback=null,accountBillScrollTop=0,totalsMode='all',discountOpen=false,discountDraftType='percent',discountDraftValue='',hallSort=['number','time','priority'].includes(pref('sokna.hall.sort','number'))?pref('sokna.hall.sort','number'):'number',hallDensity=['normal','compact','overview'].includes(pref('sokna.hall.density','normal'))?pref('sokna.hall.density','normal'):'normal',lastHallLoadAt=0,settlementRecoveryBySession=new Map(),lastTableDomSignature='',hallTouchUntil=0,hallTouchRenderTimer=null;
const adjustmentReasons=[['customer','درخواست مشتری'],['entry','اشتباه ثبت'],['quantity','اصلاح تعداد'],['other','سایر']];
const adjustmentReason=id=>String(accountAdjustmentReasons.get(Number(id))||'customer');
const adjustmentReasonLabel=id=>adjustmentReasons.find(([key])=>key===adjustmentReason(id))?.[1]||'درخواست مشتری';
const request=async(url,opt={})=>{if(transport?.request)return transport.request(url,opt,{api,orderApi,financeApi,subscriberApi,csrf});let r;try{r=await fetch(url,{credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json','Content-Type':'application/json',...(opt.headers||{})},...opt})}catch(e){const m=window.SoknaUI?.errorText?.(e,'ارتباط با سامانه برقرار نشد. دوباره تلاش کنید.')||'ارتباط با سامانه برقرار نشد. دوباره تلاش کنید.';if(!m)return {success:false,aborted:true};const failure=new Error(m);if(String(opt.method||'GET').toUpperCase()!=='GET')failure.unknown_outcome=true;throw failure}let j={};try{j=await r.json()}catch{const failure=new Error('پاسخ سامانه قابل خواندن نیست. نتیجه عملیات را بررسی کنید.');if(String(opt.method||'GET').toUpperCase()!=='GET')failure.unknown_outcome=true;throw failure}if(!r.ok||j.success===false){const failure=new Error(j.message||'عملیات انجام نشد.');failure.code=String(j.code||j.error_code||'');failure.http_status=r.status;failure.definitive_response=true;throw failure}return j};
const mutate=p=>{if(transport?.mutate)return transport.mutate(p);return request(api,{method:'POST',body:JSON.stringify({...p,csrf_token:csrf})})};
const financeMutate=p=>{if(transport?.financeMutate)return transport.financeMutate(p);return request(financeApi,{method:'POST',body:JSON.stringify({...p,csrf_token:csrf})})};
const clientRequestId=prefix=>{const c=globalThis.crypto||null;if(c&&typeof c.randomUUID==='function')return `${prefix}-${c.randomUUID()}`;let tail='';if(c&&typeof c.getRandomValues==='function'){const a=new Uint32Array(2);c.getRandomValues(a);tail=Array.from(a,x=>x.toString(16).padStart(8,'0')).join('')}else tail=`${Date.now().toString(36)}${Math.random().toString(36).slice(2,12)}`;return `${prefix}-${tail}`};
const setStatus=(m,t='neutral')=>{status.textContent=m;status.dataset.tone=t;delete status.dataset.hallFreshness};
// Keep connection feedback current when the transport changes readiness between polls.
// Do not mask action failures or another explicitly displayed operational message.
function syncHallFreshnessStatus(){
 if(!snap?.remote_stale){if(status.dataset.hallFreshness==='1')setStatus('');return}
 if(status.dataset.hallFreshness!=='1'&&String(status.textContent||'').trim())return;
 setStatus(mutationsAllowed()?'اطلاعات سالن از آخرین همگام‌سازی است؛ نتیجهٔ عملیات هنگام ثبت در سیستم اصلی کافه بررسی می‌شود.':'اطلاعات سالن قدیمی است؛ ثبت تغییرات تا برقراری ارتباط غیرفعال است.','warning');
 status.dataset.hallFreshness='1';
}const toast=(m,tone='success',title='')=>window.SoknaUI?.toast?.(m,{tone,title});const actionError=(err,title='عملیات انجام نشد')=>{setStatus('');toast(err?.message||'عملیات انجام نشد.','danger',title)};
const ageMinutes=s=>{const n=typeof L.localWallAgeMinutes==='function'?L.localWallAgeMinutes(s):null;return Number.isFinite(n)?Number(n):null};
const duration=s=>{const mins=ageMinutes(s);return mins===null?'تازه باز شده':normalCardDuration(mins)};
const normalCardDuration=mins=>{mins=Math.max(0,Math.round(Number(mins)||0));if(mins<60)return `${L.integer(mins)} دقیقه`;const h=Math.floor(mins/60),m=mins%60;if(h<24)return m?`${L.integer(h)} ساعت و ${L.integer(m)} دقیقه`:`${L.integer(h)} ساعت`;const d=Math.floor(h/24),rh=h%24;return rh?`${L.integer(d)} روز و ${L.integer(rh)} ساعت`:`${L.integer(d)} روز`};
const digitalElapsed=mins=>{mins=Math.max(0,Math.round(Number(mins)||0));const h=Math.floor(mins/60),m=mins%60;return `${L.integer(h)}:${L.integer(String(m).padStart(2,'0'))}`};
const compactCardDuration=mins=>{mins=Math.max(0,Math.round(Number(mins)||0));const h=Math.floor(mins/60);if(h<24)return digitalElapsed(mins);const d=Math.floor(h/24),rh=h%24;return rh?`${L.integer(d)} روز و ${L.integer(rh)} ساعت`:`${L.integer(d)} روز`};
const overviewCardDuration=mins=>{mins=Math.max(0,Math.round(Number(mins)||0));const h=Math.floor(mins/60);if(h<24)return digitalElapsed(mins);return `${L.integer(Math.floor(h/24))} روز`};
const tableCardDuration=t=>{const mins=ageMinutes(t.started_at||t.draft_created_at||t.draft_updated_at);if(!Number.isFinite(mins))return 'تازه باز شده';return hallDensity==='normal'?normalCardDuration(mins):(hallDensity==='compact'?compactCardDuration(mins):overviewCardDuration(mins))};
const tableStateLabel=(st,density=hallDensity)=>{if(density==='overview'||density==='compact')return st.short||st.label||'';if(st.key==='overdue')return 'طولانی';if(st.key==='aging')return 'توجه';if(st.key==='pending')return st.short||st.label||'';return st.label||''};
const hallClockIcon=()=>`<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>`;

const ago=s=>{const mins=ageMinutes(s);if(mins===null)return '—';if(mins<1)return 'همین حالا';if(mins<60)return `${L.integer(mins)} دقیقه پیش`;const h=Math.floor(mins/60);return `${L.integer(h)} ساعت پیش`};
function zoneOf(t){return String(t.zone_label||'').trim()}
function acceptanceState(a=orderAcceptance){if(!a.cafe)return {key:'off',label:'متوقف',tone:'danger',hint:'ثبت سفارش تازه مهمان متوقف است.'};if(!a.kitchen||!a.bar){const paused=[!a.kitchen?'آشپزخانه':'',!a.bar?'بار':''].filter(Boolean).join(' و ');return {key:'limited',label:'محدود',tone:'warning',hint:`${paused} سفارش تازه نمی‌پذیرد.`}}return {key:'on',label:'فعال',tone:'success',hint:'همه بخش‌ها سفارش تازه می‌پذیرند.'}}
function renderOrderAcceptance(){if(!canSupervise)return;const button=root.querySelector('[data-order-acceptance-open]'),badge=root.querySelector('[data-order-acceptance-badge]');if(!button||!badge)return;const st=acceptanceState();badge.textContent=st.label;badge.dataset.tone=st.tone;badge.className=`sc-badge sc-badge--${st.tone}`;button.title=st.hint;button.dataset.acceptanceState=st.key}
function syncAcceptanceDialogState(dialog=root.querySelector('[data-order-acceptance-dialog]')){if(!dialog)return;const cafe=Boolean(dialog.querySelector('[name="cafe"]')?.checked),children=dialog.querySelector('[data-order-acceptance-children]');children?.classList.toggle('is-paused',!cafe);children?.setAttribute('data-parent-state',cafe?'active':'paused');const note=dialog.querySelector('[data-order-acceptance-note]');if(note)note.textContent=cafe?'می‌توانید پذیرش آشپزخانه و بار را جداگانه تنظیم کنید.':'تنظیم آشپزخانه و بار حفظ می‌شود و پس از فعال‌کردن دوباره سفارش‌گیری اعمال خواهد شد.'}function fillAcceptanceDialog(){const dialog=root.querySelector('[data-order-acceptance-dialog]');if(!dialog)return;for(const scope of ['cafe','kitchen','bar']){const input=dialog.querySelector(`[name="${scope}"]`);if(input)input.checked=Boolean(orderAcceptance[scope])}syncAcceptanceDialogState(dialog);const feedback=dialog.querySelector('[data-order-acceptance-feedback]');if(feedback){feedback.hidden=true;feedback.textContent='';feedback.className='sc-alert'}}
async function saveOrderAcceptance(form){const payload={action:'order_acceptance_update'};for(const scope of ['cafe','kitchen','bar'])payload[scope]=Boolean(form.elements[scope]?.checked);const j=await mutate(payload);orderAcceptance={...orderAcceptance,...(j.order_acceptance||payload)};renderOrderAcceptance();if(snap)snap.order_acceptance={...orderAcceptance};const dialog=root.querySelector('[data-order-acceptance-dialog]');dialog?.close();if(j.public_sync_pending){const id=String(j.public_sync?.support_id||'');toast(`تنظیم در سیستم اصلی کافه ذخیره شد، اما وب عمومی هنوز تأیید نکرده${id?` · کد پیگیری ${id}`:''}. از «اتصال‌ها» وضعیت را بررسی کن.`,'warning','همگام‌سازی وب عمومی عقب است')}else if(j.public_sync?.degraded){toast('پذیرش سفارش در وب عمومی به‌روز شد؛ همگام‌سازی تصاویر ممکن است هنوز در حال تکمیل باشد.','warning','تنظیم ذخیره شد')}else toast('پذیرش سفارش آنلاین در سیستم اصلی کافه و وب عمومی به‌روز شد.','success')}
function filtered(){return (snap?.tables||[]).filter(t=>zone==='all'||zoneOf(t)===zone)}
function tableNumberValue(t){const raw=String(t?.table_number??t?.id??'');const fa=raw.replace(/[۰-۹]/g,d=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))).replace(/[٠-٩]/g,d=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))),m=fa.match(/\d+(?:\.\d+)?/);return m?Number(m[0]):Number(t?.id||0)}
// Priority is purely a display preference: it never mutates orders or waiter calls.
function hallPriority(t){const calls=Number(t.active_waiter_count||0),pending=Number(t.pending_order_count||0);if(calls>0)return 0;if(String(t.occupancy_kind||'')==='pending_guest'||pending>0)return 1;if(t.has_draft||Number(t.draft_id||0)>0)return 2;if(tableTimeWarning(t))return 3;return 4}
function sortTables(rows,{open=false}={}){const out=[...rows];if(open&&hallSort==='priority')return out.sort((a,b)=>hallPriority(a)-hallPriority(b)||tableNumberValue(a)-tableNumberValue(b)||Number(a.id||0)-Number(b.id||0));if(open&&hallSort==='time')return out.sort((a,b)=>{const aa=ageMinutes(a.started_at||a.draft_created_at||a.draft_updated_at),bb=ageMinutes(b.started_at||b.draft_created_at||b.draft_updated_at),av=Number.isFinite(aa)?aa:-1,bv=Number.isFinite(bb)?bb:-1;return bv-av||tableNumberValue(a)-tableNumberValue(b)});return out.sort((a,b)=>tableNumberValue(a)-tableNumberValue(b)||Number(a.id||0)-Number(b.id||0))}
function syncHallDisplayControls(){root.dataset.hallDensity=hallDensity;const sort=root.querySelector('[data-hall-sort]');if(sort)sort.value=hallSort;root.querySelectorAll('[data-hall-density]').forEach(b=>{const on=String(b.dataset.hallDensity)===hallDensity;b.classList.toggle('is-active',on);b.setAttribute('aria-pressed',on?'true':'false')})}
function updateUrl(){if(!/^https?:/i.test(String(location.href||'')))return;const u=new URL(location.href);if(selectedTableId)u.searchParams.set('table_id',String(selectedTableId));else u.searchParams.delete('table_id');history.replaceState(history.state,'',u.pathname+u.search+u.hash)}
// R106 mobile-only account overlay and unified Back handling. The desktop rail is unchanged.
const mobileHall=()=>Boolean(window.matchMedia?.('(max-width:820px)').matches);
let mobileView='hall',mobileHandlingBack=false,completedMoveSource=0;
function markMobileStep(view,{replace=false}={}){
  if(!mobileHall()||!/^https?:/i.test(String(location.href||'')))return;
  mobileView=view;
  const state={...(history.state&&typeof history.state==='object'?history.state:{}),soknaHallMobile:view};
  if(replace)history.replaceState(state,'',location.href);else history.pushState(state,'',location.href);
}
function showMobileAccount({record=true}={}){
  if(!mobileHall())return;
  root.classList.add('is-mobile-account-open');
  root.querySelector('.sc-hall-account')?.setAttribute('role','dialog');
  root.querySelector('.sc-hall-account')?.setAttribute('aria-modal','true');
  root.querySelector('.sc-hall-account')?.setAttribute('aria-label','حساب میز انتخاب‌شده');
  if(record&&!mobileHandlingBack)markMobileStep('account');else mobileView='account';
  requestAnimationFrame(()=>accountPane.querySelector('[data-account-close]')?.focus({preventScroll:true}));
}
function hideMobileAccount({record=true}={}){
  root.classList.remove('is-mobile-account-open');
  root.querySelector('.sc-hall-account')?.removeAttribute('aria-modal');
  root.querySelector('.sc-hall-account')?.removeAttribute('role');
  if(mobileHall()){
    mobileView='hall';
    if(record&&!mobileHandlingBack)markMobileStep('hall',{replace:true});
    requestAnimationFrame(()=>{
      const sc=root.querySelector('[data-hall-scroll]');
      if(sc)sc.scrollTop=hallScrollTop;
      root.querySelector('[data-hall-scroll] [data-table-id].is-selected')?.focus?.({preventScroll:true});
    });
  }
}
function closeSelectedAccount({record=true}={}){
  hideMobileAccount({record});selectedTableId=0;account=null;financeAccount=null;financeError='';
  accountEditingItemId=0;accountAdjustmentDrafts.clear();accountAdjustmentReasons.clear();accountAdjustmentNotes.clear();
  accountAdjustmentModes.clear();accountServiceDistributionDrafts.clear();accountItemNoteDrafts.clear();
  accountEditFeedback=null;accountBillScrollTop=0;discountOpen=false;
  updateUrl();renderTables();renderAttention();renderAccountEmpty();
}
async function mobileStepBack(){
  if(mobileHandlingBack||!mobileHall())return;
  mobileHandlingBack=true;
  try{
    // Settlement is a <div role=dialog>, not a native <dialog>.
    // Back must close the topmost settlement before the underlying account.
    if(root.querySelector('[data-settlement-mount] .sui-settlement-overlay')){
      window.SoknaHallSettlement?.close?.();
      const stillOpen=Boolean(root.querySelector('[data-settlement-mount] .sui-settlement-overlay'));
      markMobileStep('account',{replace:!stillOpen});
      return;
    }
    const dialog=[...root.querySelectorAll('dialog[open]')].at(-1);
    if(dialog){dialog.close();return}
    if(!orderView.hidden){
      const result=await orderController?.requestBack?.();
      if(result===false){markMobileStep('order',{replace:false});return}
      if(result==='menu'){mobileView='order';markMobileStep('order',{replace:true});return}
      if(root.classList.contains('is-mobile-account-open'))mobileView='account';else mobileView='hall';
      markMobileStep(mobileView,{replace:true});return;
    }
    if(root.classList.contains('is-mobile-account-open')){closeSelectedAccount({record:false});markMobileStep('hall',{replace:true})}
  }finally{mobileHandlingBack=false}
}
window.addEventListener('popstate',()=>{if(!mobileHall()||!hallView.closest('[data-operator-workspace]'))return;void mobileStepBack()});
function syncHallSelectionState(){
 root.dataset.hallSelection=selectedTableId>0?'selected':'empty';
 // Selecting a table must NOT destroy/rebuild the unrelated table buttons.
 root.querySelectorAll('[data-open-tables] [data-table-id],[data-pending-tables] [data-table-id],[data-free-tables] [data-table-id]').forEach(b=>{
  const selected=Number(b.dataset.tableId||0)===selectedTableId;
  b.classList.toggle('is-selected',selected);
  if(selected)b.setAttribute('aria-current','true');else b.removeAttribute('aria-current');
 });
}
function renderZones(){const box=root.querySelector('[data-zone-tabs]');const zones=[...new Set((snap?.tables||[]).map(zoneOf).filter(Boolean))];if(zone!=='all'&&!zones.includes(zone))zone='all';box.replaceChildren();box.hidden=zones.length<=1;if(zones.length<=1)return;const add=(value,label)=>{const b=document.createElement('button');b.type='button';b.className=value===zone?'is-active':'';b.textContent=label;b.addEventListener('click',()=>{const sc=root.querySelector('[data-hall-scroll]');if(sc)hallScrollTop=sc.scrollTop;zone=value;renderTables()});box.append(b)};add('all','همه');zones.forEach(z=>add(z,z))}
function tableOperationalState(t){const calls=Number(t.active_waiter_count||0),pending=Number(t.pending_order_count||0),hasDraft=Boolean(t.has_draft||Number(t.draft_id)>0),pendingGuest=String(t.occupancy_kind||'')==='pending_guest',hasConfirmedAccount=Number(t.session_id||0)>0||String(t.occupancy_kind||'')==='account';if(pendingGuest)return {key:'pending-guest',label:'منتظر تأیید',short:'منتظر تأیید',hint:'سفارش مهمان هنوز تأیید یا رد نشده است'};if(pending>0&&!hasConfirmedAccount)return {key:'pending',label:pending>1?`سفارش منتظر · ${L.integer(pending)}`:'سفارش منتظر',short:pending>1?`منتظر · ${L.integer(pending)}`:'منتظر',hint:'نیازمند بررسی'};if(hasDraft)return {key:'draft',label:'موقت',short:'موقت',hint:'سفارش ذخیره شده و هنوز به آماده‌سازی ارسال نشده است'};if(String(t.session_status||'')==='pending')return {key:'session-pending',label:'در انتظار شروع',short:'انتظار',hint:'نشست هنوز فعال نشده'};return {key:'open',label:'',short:'',hint:'در سرویس'}}
function tableTimeWarning(t){const mins=ageMinutes(t.started_at);if(Number.isFinite(mins)&&mins>=120)return {key:'overdue',label:'حضور طولانی',short:'طولانی'};if(Number.isFinite(mins)&&mins>=60)return {key:'aging',label:'زمان حضور نیازمند توجه',short:'توجه'};return null}
function tableCard(t,open){
 const b=document.createElement('button');b.type='button';b.dataset.tableId=String(t.id);b.className=open?'sc-hall-open-table sui-table-card':'sc-hall-free-table sui-free-card';if(Number(t.id)===selectedTableId)b.classList.add('is-selected');
 if(open){const st=tableOperationalState(t),exception=st.key!=='open',draft=Boolean(t.has_draft||Number(t.draft_id)>0),session=Number(t.session_id)>0,pendingOnly=String(t.occupancy_kind||'')==='pending_guest',timeText=tableCardDuration(t),timeWarning=tableTimeWarning(t),accountAmount=Number(t.account_total||0),pendingAmount=Number(t.pending_order_total||0),amount=pendingOnly?pendingAmount:(session?accountAmount:Number(t.draft_total||0)),stateText=tableStateLabel(st),pendingMeta=!pendingOnly&&pendingAmount>0?`<small class="sc-hall-pending-meta">منتظر تأیید: ${money(pendingAmount)}</small>`:'';b.dataset.tableState=st.key;if(timeWarning)b.dataset.timeState=timeWarning.key;if(st.key==='call')b.classList.add('has-call');else if(st.key==='draft')b.classList.add('has-draft');else if(['pending','pending-guest','session-pending','aging','overdue'].includes(st.key))b.classList.add('has-pending');b.setAttribute('aria-label',`میز ${L.integer(t.table_number||t.id)}، ${pendingOnly?'سفارش مهمان منتظر تأیید':(exception?st.label:'در سرویس')}، ${timeText}، ${pendingOnly?'جمع سفارش تأییدنشده':draft&&!session?'جمع سفارش موقت':'جمع حساب ثبت‌شده'} ${money(amount)}`);b.innerHTML=`<span class="sc-hall-open-table__accent"></span><span class="sc-hall-open-table__number sui-table-number"><small>میز</small><strong>${L.integer(t.table_number||t.id)}</strong></span><span class="sc-hall-open-table__main sui-table-main">${exception?`<span class="sc-hall-table-state sui-status" title="${esc(st.label)}"><i></i>${esc(stateText)}</span>`:''}<span class="sc-hall-table-time">${hallClockIcon()}<b>${esc(timeText)}</b>${timeWarning?`<em class="sc-hall-time-warning" title="هشدار مدت حضور">${esc(timeWarning.short||timeWarning.label)}</em>`:''}</span>${pendingOnly&&hallDensity==='normal'?`<small class="sc-hall-draft-meta">${L.integer(t.pending_item_count||0)} قلم · ${L.integer(t.pending_quantity_count||0)} عدد</small>`:(draft&&hallDensity==='normal'?`<small class="sc-hall-draft-meta">${L.integer(t.draft_item_count||0)} قلم · ${L.integer(t.draft_quantity_count||0)} عدد · ارسال‌نشده</small>`:pendingMeta)}</span><span class="sc-hall-table-amount sui-money"><strong>${moneyNumber(amount)}</strong><small>تومان</small></span>`}
 else{b.dataset.tableState='free';b.setAttribute('aria-label',`میز ${L.integer(t.table_number||t.id)}، آزاد، آماده ثبت سفارش`);b.innerHTML=`<strong>${L.integer(t.table_number||t.id)}</strong>`}
 // Badge shares the exact source arrays used by the attention inbox, not the account-state calculation.
 const needsCall=(snap?.waiter_calls||[]).some(c=>Number(c.table_id)===Number(t.id));
 const needsOrder=(snap?.attention_orders||[]).some(o=>Number(o.table_id)===Number(t.id));
 if(needsCall||needsOrder){b.classList.add('has-attention');const badge=document.createElement('span');badge.className='sc-hall-attention-mark'+(needsCall?' is-call':'');badge.setAttribute('aria-hidden','true');if(mobileHall())badge.innerHTML=needsCall?uiIcon('bell'):uiIcon('ticket');else badge.textContent='!';b.append(badge);b.setAttribute('aria-label',b.getAttribute('aria-label')+(needsCall&&needsOrder?'، سفارش جدید و فراخوان باز':needsCall?'، فراخوان باز':'، سفارش منتظر رسیدگی'))}
 if((tableMovePending&&[tableMovePending.sourceTableId,tableMovePending.targetTableId].includes(Number(t.id)))||(tableMoveUncertainTransfer&&[tableMoveUncertainTransfer.sourceTableId,tableMoveUncertainTransfer.targetTableId].includes(Number(t.id)))){
  b.disabled=true;b.dataset.tableMoveSync='1';const label=tableMoveUncertainTransfer?'نتیجه انتقال نامشخص است؛ ابتدا حساب‌ها را بررسی کن':'انتقال ثبت شد؛ منتظر همگام‌سازی وضعیت میز';b.title=label;
  b.setAttribute('aria-label',`میز ${L.integer(t.table_number||t.id)}، ${label}`);
  const note=document.createElement('small');note.className='sc-hall-move-sync sc-badge';note.textContent=tableMoveUncertainTransfer?'نیازمند بررسی':'در حال همگام‌سازی';b.append(note)
 }
 b.addEventListener('click',()=>selectTable(t));return b
}
function renderTables(){if(!snap)return;
if(window.matchMedia('(max-width:820px)').matches&&Date.now()<hallTouchUntil){
 if(hallTouchRenderTimer===null)hallTouchRenderTimer=setTimeout(()=>{hallTouchRenderTimer=null;renderTables()},Math.max(80,hallTouchUntil-Date.now()+40));
 return;
}syncHallSelectionState();renderZones();syncHallDisplayControls();const rows=filtered(),isPending=t=>String(t.occupancy_kind||'')==='pending_guest',isWorking=t=>String(t.occupancy_kind||'')?(!['free','pending_guest','call','waiter_call'].includes(String(t.occupancy_kind))):(Number(t.session_id)>0||Boolean(t.has_draft||Number(t.draft_id)>0)),pending=sortTables(rows.filter(isPending),{open:true}),open=sortTables(rows.filter(isWorking),{open:true}),free=sortTables(rows.filter(t=>!isPending(t)&&!isWorking(t)));const pendingSection=root.querySelector('[data-hall-pending-section]'),freeSection=root.querySelector('[data-hall-free-section]'),openSection=root.querySelector('[data-hall-open-section]');if(pendingSection)pendingSection.hidden=pending.length===0;if(freeSection)freeSection.hidden=initialView==='open';if(openSection)openSection.hidden=false;const os=root.querySelector('[data-open-summary]'),fs=root.querySelector('[data-free-summary]');if(os)os.textContent=L.integer((snap.tables||[]).filter(isWorking).length);if(fs)fs.textContent=L.integer((snap.tables||[]).filter(t=>!isPending(t)&&!isWorking(t)).length);const pc=root.querySelector('[data-pending-count]');if(pc)pc.textContent=L.integer(pending.length);root.querySelector('[data-open-count]').textContent=L.integer(open.length);root.querySelector('[data-free-count]').textContent=L.integer(free.length);root.dataset.hallAutoDense='0';const pg=root.querySelector('[data-pending-tables]'),og=root.querySelector('[data-open-tables]'),fg=root.querySelector('[data-free-tables]');const tableDomSignature=JSON.stringify([zone,hallDensity,hallSort,Math.floor(Date.now()/60000),pending,open,free,tableMovePending?.sourceSessionId||0,tableMovePending?.targetTableId||0,tableMoveUncertainTransfer?.sourceSessionId||0,tableMoveUncertainTransfer?.targetTableId||0,(snap?.attention_orders||[]).map(x=>[x.id,x.table_id]),(snap?.waiter_calls||[]).map(x=>[x.id,x.table_id,x.status])]);
if(tableDomSignature===lastTableDomSignature)return;
lastTableDomSignature=tableDomSignature;
const mobileViewport=window.matchMedia('(max-width:820px)').matches;
const beforeDocumentScroll=mobileViewport?window.scrollY:0;
const active=document.activeElement,activeTable=active?.closest?.('[data-table-id]');
if(pg)pg.replaceChildren(...pending.map(t=>tableCard(t,true)));og.replaceChildren(...open.map(t=>tableCard(t,true)));fg.replaceChildren(...free.map(t=>tableCard(t,false)));
if(mobileViewport&&Math.abs(window.scrollY-beforeDocumentScroll)>2)window.scrollTo({top:beforeDocumentScroll,behavior:'instant'});
if(activeTable){const id=activeTable.getAttribute('data-table-id');const replacement=id?root.querySelector(`[data-table-id="${CSS.escape(id)}"]`):null;if(replacement&&document.activeElement===document.body)replacement.focus({preventScroll:true})}if(!open.length){const e=document.createElement('div');e.className='sc-empty';e.textContent='در این بخش حساب تأییدشده یا سفارش موقتی وجود ندارد.';og.append(e)}if(!free.length){const e=document.createElement('div');e.className='sc-hall-free-empty';e.textContent='در حال حاضر میز آزادی وجود ندارد.';fg.append(e)}const sc=root.querySelector('[data-hall-scroll]');if(sc){if(!window.matchMedia('(max-width:820px)').matches)sc.scrollTop=hallScrollTop;sc.onscroll=()=>{hallScrollTop=sc.scrollTop}}}
function actionButton(label,fn,kind='secondary',mutation=false){const b=document.createElement('button');b.type='button';b.className=`sc-button${kind==='primary'?'':kind==='danger'?' sc-button--danger':' sc-button--secondary'}`;if(mutation)b.dataset.hallMutationAction='1';b.textContent=label;b.addEventListener('click',async()=>{b.disabled=true;try{await fn()}catch(e){actionError(e)}finally{b.disabled=mutation&&!mutationsAllowed()}});if(mutation&&!mutationsAllowed())b.disabled=true;return b}
function attentionTable(tableId){return (snap?.tables||[]).find(t=>Number(t.id)===Number(tableId))||null}
async function reviewAttentionTable(tableId,orderId=0){const t=attentionTable(tableId);if(!t)return;if(Number(t.id)!==Number(selectedTableId))await selectTable(t);else await loadAccount(Number(t.id));requestAnimationFrame(()=>{const card=orderId?accountPane.querySelector(`[data-pending-review-id="${Number(orderId)}"]`):null;(card||accountPane)?.focus?.({preventScroll:true});card?.scrollIntoView?.({block:'nearest',behavior:'smooth'})})}
async function setPendingOrderStatus(order,status){
 if(!canOrder||!mutationsAllowed())return;
 const id=Number(order.id||0),tableId=Number(order.table_id||selectedTableId||0);
 if(id<1||tableId<1||!['accounted','cancelled'].includes(status))return;
 // Fresh server read; never approve a button left behind after another actor changed an order.
 const latest=await request(`${api}?action=account&table_id=${encodeURIComponent(tableId)}`);
 const pending=(latest.pending_orders||[]).find(o=>Number(o.id)===id&&['pending_approval','new'].includes(o.status));
 if(!pending||!Array.isArray(pending.items)||!pending.items.length){toast('سفارش تغییر کرده یا جزئیات آن در دسترس نیست. دوباره بررسی کنید.','warning','سفارش منتظر');await load();return}
 if(status==='cancelled'){const ok=await SoknaUI.confirm('رد سفارش',`سفارش ${L.integer(pending.order_number||id)} با ${L.integer(pending.items.length)} قلم رد شود؟`,true);if(!ok)return}
 await mutate({action:'order_status',order_id:id,status});await load()
}
async function setWaiterCallStatus(call,status){
 const id=Number(call.id);if(id<1||waiterStatusPending.has(id))return;
 waiterStatusPending.set(id,{status,phase:'sending'});renderAttention();
 try{const result=await mutate({action:'waiter_status',call_id:id,status});
  waiterStatusPending.set(id,{status,phase:'committed'});
  if(root.dataset.staffUiMode==='public')toast('درخواست در کافه ثبت شد؛ در انتظار نمایش وضعیت جدید در پابلیک.','warning','فراخوان مهمان');
  try{await load();}catch(refreshError){setStatus('درخواست ثبت شد؛ نمایش آن هنوز به‌روز نشده است.','warning');renderAttention();}
  return result;
 }catch(e){waiterStatusPending.delete(id);renderAttention();throw e;}
}
let attentionOpen=false,attentionFilter='all';
const attentionOverlay=root.querySelector('[data-attention-overlay]'),attentionOpenButton=root.querySelector('[data-attention-open]');
const closeAttentionDrawer=()=>{if(!attentionOpen)return;attentionOpen=false;if(attentionOverlay)attentionOverlay.hidden=true;attentionOpenButton?.setAttribute('aria-expanded','false');attentionOpenButton?.focus({preventScroll:true})};
const openAttentionDrawer=()=>{if(!attentionOverlay||attentionOverlay.hidden===false)return;attentionOpen=true;attentionOverlay.hidden=false;attentionOpenButton?.setAttribute('aria-expanded','true');attentionOverlay.querySelector('[data-attention-close]:not(.sc-hall-attention-shade)')?.focus({preventScroll:true})};
attentionOpenButton?.addEventListener('click',openAttentionDrawer);
attentionOverlay?.querySelectorAll('[data-attention-close]').forEach(button=>button.addEventListener('click',closeAttentionDrawer));
attentionOverlay?.querySelectorAll('[data-attention-filter]').forEach(button=>button.addEventListener('click',()=>{attentionFilter=button.dataset.attentionFilter||'all';renderAttention()}));
attentionOverlay?.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();closeAttentionDrawer();return}if(e.key!=='Tab')return;const tabbable=[...attentionOverlay.querySelectorAll('button:not([disabled])')].filter(x=>x.getClientRects().length);if(!tabbable.length)return;const first=tabbable[0],last=tabbable[tabbable.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}});
function renderAttention(){
 const section=root.querySelector('[data-attention-section]'),box=root.querySelector('[data-attention-list]'),caption=root.querySelector('[data-attention-caption]');
 const orders=(snap?.attention_orders||[]).map(o=>{const itemCount=Number(o.item_count??(o.items||[]).length),quantityCount=Number(o.quantity_count??(o.items||[]).reduce((n,x)=>n+Number(x.quantity||0),0));return {kind:'order',tableId:Number(o.table_id||0),tone:'info',title:`${human(o.table_name)} · سفارش ${L.integer(o.order_number)}`,meta:`${L.integer(itemCount)} قلم · ${L.integer(quantityCount)} عدد · ${money(o.total_amount)} · ${ago(o.created_at)}`,data:o}});
 const currentCalls=(snap?.waiter_calls||[]);
 for(const [id,entry] of waiterStatusPending){const call=currentCalls.find(c=>Number(c.id)===id);if(!call||String(call.status)===entry.status)waiterStatusPending.delete(id);}
 const calls=currentCalls.map(c=>({kind:'call',tableId:Number(c.table_id||0),tone:c.status==='accepted'?'warning':'danger',title:`${human(c.table_name)} · فراخوان مهمان`,meta:c.status==='accepted'?(c.accepted_by?`پذیرفته‌شده توسط ${c.accepted_by}`:'پذیرفته‌شده؛ منتظر رسیدگی'):`${ago(c.created_at)} بدون پاسخ`,data:c}));
 const attentionRank=x=>x.kind==='call'?(x.data?.status==='accepted'?2:0):1;
 const attentionStamp=x=>{const v=Date.parse(String(x.data?.created_at||''));return Number.isFinite(v)?v:0};
 const items=[...calls,...orders].sort((a,b)=>attentionRank(a)-attentionRank(b)||attentionStamp(a)-attentionStamp(b)||Number(b.tableId===selectedTableId)-Number(a.tableId===selectedTableId)||a.tableId-b.tableId||Number(a.data?.id||0)-Number(b.data?.id||0));
 const count=items.length,tableCount=new Set(items.map(item=>item.tableId)).size,orderCount=orders.length,callCount=calls.length;
 section.hidden=count===0;
 if(count===0&&attentionOpen)closeAttentionDrawer();
 root.querySelector('[data-attention-count]').textContent=L.integer(count);
 if(caption)caption.textContent=`${L.integer(tableCount)} میز`;
 for(const [attr,value] of [['attention-order-count',orderCount],['attention-call-count',callCount],['attention-all-count',count],['attention-order-filter-count',orderCount],['attention-call-filter-count',callCount]]){const el=root.querySelector(`[data-${attr}]`);if(el)el.textContent=L.integer(value)}
 const summary=root.querySelector('[data-attention-drawer-summary]');if(summary)summary.textContent=`${L.integer(tableCount)} میز · ${L.integer(count)} درخواست باز`;
 for(const b of root.querySelectorAll('[data-attention-filter]'))b.setAttribute('aria-pressed',String(b.dataset.attentionFilter===attentionFilter));
 const visibleItems=attentionFilter==='all'?items:items.filter(item=>item.kind===attentionFilter);
 // The poll runs every few seconds. Preserve the live DOM and keyboard focus when
 // neither the visible data nor the available actions have changed.
 const signature=JSON.stringify([attentionFilter,selectedTableId,Boolean(snap?.permissions?.orders_floor),Boolean(featureWaiterResponse),Boolean(mutationsAllowed()),items.map(item=>[item.kind,item.tableId,item.tone,item.title,item.meta,item.data?.id??item.data?.order_id??item.data?.call_id??null,item.data?.status??null,waiterStatusPending.get(Number(item.data?.id))?.phase||''])]);
 if(box.dataset.attentionSignature===signature)return;
 const focused=document.activeElement;
 const priorRow=focused?.closest?.('[data-attention-key]');
 const focusedKey=priorRow&&box.contains(priorRow)?priorRow.dataset.attentionKey:null;
 const focusedAction=focusedKey?String(focused?.dataset?.attentionAction||''):'';
 const priorScrollTop=box.scrollTop,priorScrollLeft=box.scrollLeft;
 box.replaceChildren();
 const grouped=new Map();
 for(const item of visibleItems){if(!grouped.has(item.tableId))grouped.set(item.tableId,[]);grouped.get(item.tableId).push(item)}
 if(!visibleItems.length){const empty=document.createElement('div');empty.className='sc-hall-attention-empty';empty.textContent='در این بخش درخواست بازی وجود ندارد.';box.append(empty)}
 for(const [tableId,groupItems] of grouped){
  const group=document.createElement('section');group.className='sc-hall-attention-group';
  const heading=document.createElement('header');heading.className='sc-hall-attention-group__header';
  const title=document.createElement('strong');const table=(snap?.tables||[]).find(t=>Number(t.id)===tableId);
  title.textContent=`میز ${L.integer(table?.table_number||tableId)}`;
  const detail=document.createElement('small');detail.textContent=`${L.integer(groupItems.length)} درخواست`;
  heading.append(title,detail);group.append(heading);box.append(group);
  for(const [itemIndex,item] of groupItems.entries()){
  const row=document.createElement('article');row.className=`sc-attention-item ${item.tone==='danger'?'is-danger':item.tone==='warning'?'is-warning':'is-info'}${item.tableId===selectedTableId?' is-context':''}`;
  row.tabIndex=-1;row.dataset.attentionPriority=String(attentionRank(item));
  row.dataset.attentionKey=`${item.kind}:${item.tableId}:${item.data?.id??item.data?.call_id??item.data?.order_id??item.data?.order_number??itemIndex}`;
  const icon=document.createElement('span');icon.className='sc-attention-item__icon';icon.textContent=item.kind==='call'?'!':'▤';
  const copy=document.createElement('div');copy.className='sc-attention-item__copy';copy.innerHTML=`<strong>${esc(item.title)}</strong><small>${esc(item.meta)}</small>`;
  const acts=document.createElement('div');acts.className='sc-attention-item__actions';
  const addAction=(key,label,fn,kind='secondary',mutation=false)=>{const invoke=()=>{if(key==='order-review'||key==='call-review')closeAttentionDrawer();return fn()};const btn=actionButton(label,invoke,kind,mutation);btn.dataset.attentionAction=key;acts.append(btn)};
  if(snap.permissions?.orders_floor){
   if(item.kind==='order'){
    const o=item.data;
    addAction('order-review','بررسی سفارش',()=>reviewAttentionTable(item.tableId,Number(o.id)),'primary',true);
   }else{
    const c=item.data;
    if(featureWaiterResponse){
      const pending=waiterStatusPending.get(Number(c.id));
      if(pending){const waiting=document.createElement('span');waiting.className='sc-badge sc-badge--warning';waiting.setAttribute('role','status');waiting.textContent=pending.phase==='sending'?'در حال ثبت…':'ثبت شد · در انتظار همگام‌سازی';acts.append(waiting);}
      if(!pending&&c.status==='new')addAction('call-accept','پذیرفتم',()=>setWaiterCallStatus(c,'accepted'),'primary',true);
      if(!pending)addAction('call-complete','انجام شد',()=>setWaiterCallStatus(c,'completed'),c.status==='accepted'?'primary':'secondary',true);
    }
    addAction('call-review','بررسی',()=>reviewAttentionTable(item.tableId),'secondary');
   }
  }
  row.append(icon,copy,acts);group.append(row)
 }
 }
 box.dataset.attentionSignature=signature;
 box.scrollTop=priorScrollTop;box.scrollLeft=priorScrollLeft;
 if(focusedKey){const row=[...box.querySelectorAll('[data-attention-key]')].find(x=>x.dataset.attentionKey===focusedKey);const replacement=focusedAction?[...row?.querySelectorAll('button')||[]].find(x=>x.dataset.attentionAction===focusedAction&&!x.disabled):null;(replacement||row)?.focus({preventScroll:true})}
}
function renderTotals(){const b=root.querySelector('[data-item-totals]'),tabs=root.querySelector('[data-item-total-tabs]');b.replaceChildren();const rows=Array.isArray(snap?.item_totals)?snap.item_totals:[],areas=[...new Set(rows.map(r=>String(r.area||'other')))];if(totalsMode!=='all'&&!areas.includes(totalsMode))totalsMode='all';if(tabs){tabs.replaceChildren();const labels={kitchen:'آشپزخانه',bar:'بار',other:'سایر'};for(const key of ['all',...areas]){const bt=document.createElement('button');bt.type='button';bt.textContent=key==='all'?'همه':(labels[key]||key);bt.className=totalsMode===key?'is-active':'';bt.dataset.itemTotalMode=key;bt.addEventListener('click',()=>{totalsMode=key;renderTotals()});tabs.append(bt)}}const visible=totalsMode==='all'?rows:rows.filter(r=>String(r.area||'other')===totalsMode);if(!visible.length){const tr=document.createElement('tr');const td=document.createElement('td');td.colSpan=3;td.textContent='قلمی در این بخش وجود ندارد.';tr.append(td);b.append(tr);return}for(const r of visible){const tr=document.createElement('tr');[['آیتم',r.name],['تعداد',L.integer(r.quantity)],['جمع',money(r.line_total)]].forEach(([label,val])=>{const td=document.createElement('td');td.dataset.label=label;td.textContent=val;tr.append(td)});b.append(tr)}}
function renderAccountEmpty(message='یک میز در سرویس را انتخاب کنید تا حساب همان میز اینجا باز شود.',canRetry=false){syncHallSelectionState();accountPane.innerHTML=`<div class="sc-hall-account__empty"><span class="sc-hall-account__empty-icon" aria-hidden="true">▧</span><strong>حساب میز</strong><p>${esc(message)}</p>${canRetry?'<button class="sc-button sc-button--secondary" type="button" data-account-retry>بررسی دوباره حساب</button>':''}</div>`;accountPane.querySelector('[data-account-retry]')?.addEventListener('click',()=>{if(Number(selectedTableId)>0)void loadAccount(Number(selectedTableId))})}
function roundState(status){const s=String(status||'accounted');if(s==='accounted')return 'ثبت‌شده';if(s==='pending_approval'||s==='new')return 'منتظر تأیید';if(s==='cancelled')return 'لغوشده';return 'ثبت‌شده'}
function accountLine(l,editable=false){
 const changed=Number(l.ordered_quantity||l.quantity)!==Number(l.quantity),id=Number(l.order_item_id||0),actual=Number(l.quantity||0),currentMode=String(l.fulfillment_mode||'dine_in')==='takeaway'?'takeaway':'dine_in',hasNote=Boolean(String(l.note||'').trim()),takeaway=currentMode==='takeaway',originalQuantity=Number(l.ordered_quantity||l.quantity),priceChanged=Boolean(l.price_changed)&&Number.isFinite(Number(l.current_price))&&Number(l.current_price)!==Number(l.unit_price),badges=[takeaway?LineUI.badge('بیرون‌بر'):'',hasNote?LineUI.badge('یادداشت','is-note'):'',changed?LineUI.badge('اصلاح‌شده','is-warning'):'',changed?`<small class="sc-order-line__original">ابتدا ${L.integer(originalQuantity)}</small>`:'',].filter(Boolean).join(''),feedback=accountEditFeedback?.id===id?`<div class="sc-hall-item-feedback" data-tone="${esc(accountEditFeedback.tone||'success')}">${esc(accountEditFeedback.message||'')}</div>`:'',actionHtml=editable?`<button type="button" class="sc-icon-button sc-account-line-edit-button" data-account-line-edit="${id}" aria-label="ویرایش ${esc(l.name)}" title="ویرایش">${uiIcon('edit')}</button>`:'';
 return LineUI.renderLine({rootAttrs:{'data-account-line':id,'data-price-changed':priceChanged?'1':'0'},toggleAttrs:{'aria-disabled':'true','tabindex':'-1'},name:l.name,badges,quantity:actual,amount:moneyNumber(Number(l.line_total||0)),actionHtml,feedbackHtml:feedback,classes:'sc-account-order-line'});
}
function accountEditorLine(id){return (account?.lines||[]).find(x=>Number(x.order_item_id||0)===Number(id))||null}
function accountEditorGroup(id){
 const anchor=accountEditorLine(id);if(!anchor)return null;
 const anchorOrderId=Number(anchor.order_id||0),anchorOrderNumber=Number(anchor.order_number||0),anchorItemId=Number(anchor.item_id||0),anchorName=String(anchor.name||''),anchorPrice=Number(anchor.unit_price||0),anchorNote=String(anchor.note||''),anchorStation=String(anchor.preparation_station||'');
 const lines=(account?.lines||[]).filter(x=>{const sameOrder=anchorOrderId>0?Number(x.order_id||0)===anchorOrderId:Number(x.order_number||0)===anchorOrderNumber;if(!sameOrder)return false;const itemId=Number(x.item_id||0),sameItem=anchorItemId>0?itemId===anchorItemId:(itemId===0&&String(x.name||'')===anchorName);if(!sameItem||Number(x.unit_price||0)!==anchorPrice||String(x.note||'')!==anchorNote)return false;const station=String(x.preparation_station||'');return !anchorStation||!station||station===anchorStation});
 const distribution={dine_in:0,takeaway:0};let total=0;for(const row of lines){const q=Math.max(0,Number(row.quantity||0)),mode=String(row.fulfillment_mode||'dine_in')==='takeaway'?'takeaway':'dine_in';distribution[mode]+=q;total+=q}return {anchor,lines,total,distribution,note:anchorNote}
}
const serviceDistributionEqual=(a,b)=>Number(a?.dine_in||0)===Number(b?.dine_in||0)&&Number(a?.takeaway||0)===Number(b?.takeaway||0);
function reconcileServiceDistribution(dist,total,preferred='dine_in'){
 const out={dine_in:Math.max(0,Number(dist?.dine_in||0)),takeaway:Math.max(0,Number(dist?.takeaway||0))},target=Math.max(0,Math.min(99,Number(total||0))),other=preferred==='takeaway'?'dine_in':'takeaway';let sum=out.dine_in+out.takeaway;
 if(sum<target)out[preferred]+=target-sum;else if(sum>target){let remove=sum-target,cut=Math.min(out[preferred],remove);out[preferred]-=cut;remove-=cut;if(remove>0)out[other]=Math.max(0,out[other]-remove)}return out
}
function transferServiceDistribution(dist,total,mode,delta){const target=Math.max(0,Math.min(99,Number(total||0))),other=mode==='takeaway'?'dine_in':'takeaway',out=reconcileServiceDistribution(dist,target,mode);if(delta>0&&out[other]>0){out[mode]++;out[other]--}else if(delta<0&&out[mode]>0){out[mode]--;out[other]++}return out}
function closeAccountItemEditor(){const d=root.querySelector('[data-account-item-edit-dialog]');if(d?.open)d.close();accountEditingItemId=0}
function renderAccountItemEditor(){
 const d=root.querySelector('[data-account-item-edit-dialog]'),body=d?.querySelector('[data-account-item-edit-body]'),title=d?.querySelector('[data-account-item-edit-title]'),save=d?.querySelector('[data-account-item-edit-save]');if(!d||!body)return;
 const id=Number(accountEditingItemId||0),group=accountEditorGroup(id);if(!group){closeAccountItemEditor();return}const line=group.anchor,actual=Number(group.total||0),draft=accountAdjustmentDrafts.has(id)?Number(accountAdjustmentDrafts.get(id)):actual,currentDist=group.distribution,preferredMode=String(line.fulfillment_mode||'dine_in')==='takeaway'?'takeaway':'dine_in',targetDist=accountServiceDistributionDrafts.has(id)?reconcileServiceDistribution(accountServiceDistributionDrafts.get(id),draft,preferredMode):reconcileServiceDistribution(currentDist,draft,preferredMode),currentNote=human(group.note),targetNote=accountItemNoteDrafts.has(id)?String(accountItemNoteDrafts.get(id)):currentNote,qtyChanged=draft!==actual,serviceChanged=!serviceDistributionEqual(targetDist,currentDist),noteChanged=targetNote.trim()!==currentNote.trim(),changed=qtyChanged||serviceChanged||noteChanged,reasonKey=adjustmentReason(id),reasonButtons=adjustmentReasons.map(([key,label])=>`<button type="button" class="sc-order-adjust-reason ${reasonKey===key?'is-selected':''}" data-modal-adjust-reason="${key}" aria-pressed="${reasonKey===key?'true':'false'}">${label}</button>`).join(''),reasonNote=human(accountAdjustmentNotes.get(id)||''),unitPrice=Number(line.unit_price||0),currentPrice=Number(line.current_price||0),priceChanged=Boolean(line.price_changed)&&Number.isFinite(currentPrice)&&currentPrice!==unitPrice,maxQuantity=priceChanged?actual:99,currentTotal=Math.max(0,unitPrice*actual),nextTotal=Math.max(0,unitPrice*draft),delta=nextTotal-currentTotal,impactTone=delta<0?'is-decrease':delta>0?'is-increase':'is-neutral',impactLabel=delta<0?`− ${money(Math.abs(delta))}`:delta>0?`+ ${money(delta)}`:'بدون تغییر مبلغ';
 if(title)title.textContent='ویرایش آیتم حساب';
 const serviceRow=(mode,label)=>`<div class="sc-account-service-split__row"><div><strong>${label}</strong><small>${mode==='dine_in'?'سرو داخل کافه':'بسته‌بندی بیرون‌بر'}</small></div>${LineUI.stepper({value:targetDist[mode],min:0,max:draft,label:`تعداد ${label}`,minus:{'data-modal-service-mode':mode,'data-modal-service-delta':'-1'},plus:{'data-modal-service-mode':mode,'data-modal-service-delta':'1'}})}</div>`;
 const priceLock=priceChanged?`<div class="sc-account-price-snapshot-lock" role="note"><div><strong>قیمت این آیتم تغییر کرده است.</strong><span><b>قیمت زمان ثبت</b> ${money(unitPrice)} · <b>قیمت فعلی</b> ${money(currentPrice)}</span><p>تعداد ثبت‌شده با قیمت زمان ثبت حفظ می‌شود. برای افزایش، مقدار تازه باید با قیمت فعلی به‌عنوان سفارش جدید اضافه شود.</p></div><button class="sc-button sc-button--secondary" type="button" data-price-add-order>افزودن سفارش با قیمت فعلی</button></div>`:'';
 body.innerHTML=`<div class="sc-account-item-editor__summary"><div><strong>${esc(line.name)}</strong><small>${priceChanged?`قیمت زمان ثبت ${money(unitPrice)}`:`قیمت واحد ${money(unitPrice)}`}</small></div><span>${L.integer(actual)} عدد ثبت‌شده</span></div>${priceLock}<section class="sc-account-item-editor__section is-quick"><div class="sc-account-item-editor__section-head"><strong>تعداد</strong><small>${priceChanged?'افزایش این ردیف مجاز نیست':`${L.integer(actual)} ثبت‌شده`}</small></div>${LineUI.stepper({value:draft,min:0,max:maxQuantity,label:`تعداد ${line.name}`,minus:{'data-modal-item-delta':'-1'},plus:{'data-modal-item-delta':'1'}})}</section><div class="sc-account-item-impact ${impactTone}" aria-live="polite"><div><span>مبلغ فعلی این آیتم</span><strong>${money(currentTotal)}</strong></div><div><span>مبلغ پس از تغییر</span><strong>${money(nextTotal)}</strong></div><div class="is-delta"><span>اثر روی حساب</span><strong>${impactLabel}</strong></div></div>${draft===0?'<div class="sc-account-item-remove-warning" role="status"><strong>این آیتم از حساب حذف می‌شود.</strong><span>پس از ثبت، تعداد این آیتم صفر خواهد شد.</span></div>':''}${qtyChanged?`<section class="sc-account-item-editor__section is-reason"><div class="sc-account-item-editor__section-head"><strong>دلیل اصلاح تعداد</strong><small>${L.integer(actual)} ← ${L.integer(draft)}</small></div><div class="sc-order-adjust-reasons" role="group" aria-label="دلیل اصلاح">${reasonButtons}</div>${reasonKey==='other'?`<input class="sc-control sc-order-adjust-note" type="text" maxlength="160" value="${esc(reasonNote)}" data-modal-adjust-note placeholder="توضیح کوتاه دلیل (اختیاری)">`:''}</section>`:''}<section class="sc-account-item-editor__section is-service"><div class="sc-account-item-editor__section-head"><strong>نحوه سرو</strong><small>جمع: ${L.integer(draft)}</small></div><div class="sc-account-service-split" role="group" aria-label="تفکیک تعداد داخل کافه و بیرون‌بر">${serviceRow('dine_in','داخل کافه')}${serviceRow('takeaway','بیرون‌بر')}</div><p class="sc-account-service-split__hint">تعداد هر دو ردیف با هم برابر تعداد کل آیتم است.</p></section><details class="sc-account-item-editor__section sc-disclosure is-note" ${currentNote?'open':''}><summary>یادداشت آماده‌سازی${currentNote?' · دارد':''}</summary><div class="sc-account-item-editor__note"><input class="sc-control" type="text" maxlength="500" value="${esc(targetNote)}" data-modal-item-note placeholder="مثلاً بدون شکر"></div></details>`;
 if(save){save.disabled=!changed;save.textContent=draft===0?'حذف آیتم از حساب':'ثبت تغییرات';save.classList.toggle('sc-button--danger',draft===0)};
 body.querySelector('[data-price-add-order]')?.addEventListener('click',()=>{closeAccountItemEditor();openOrder(Number(selectedTableId||account?.table?.id||0),'account')});
 body.querySelectorAll('[data-modal-item-delta]').forEach(b=>b.addEventListener('click',()=>{const step=Number(b.dataset.modalItemDelta||0),current=accountAdjustmentDrafts.has(id)?Number(accountAdjustmentDrafts.get(id)):actual,next=Math.max(0,Math.min(maxQuantity,current+step)),dist=accountServiceDistributionDrafts.has(id)?accountServiceDistributionDrafts.get(id):currentDist;accountAdjustmentDrafts.set(id,next);accountServiceDistributionDrafts.set(id,reconcileServiceDistribution(dist,next,preferredMode));accountEditFeedback=null;renderAccountItemEditor()}));
 body.querySelectorAll('[data-modal-service-mode]').forEach(b=>b.addEventListener('click',()=>{const mode=String(b.dataset.modalServiceMode||'dine_in'),step=Number(b.dataset.modalServiceDelta||0),dist=accountServiceDistributionDrafts.has(id)?accountServiceDistributionDrafts.get(id):currentDist;accountServiceDistributionDrafts.set(id,transferServiceDistribution(dist,draft,mode,step));accountEditFeedback=null;renderAccountItemEditor()}));
 body.querySelector('[data-modal-item-note]')?.addEventListener('input',e=>{e.target.value=human(e.target.value);accountItemNoteDrafts.set(id,e.target.value);const latestDist=accountServiceDistributionDrafts.has(id)?reconcileServiceDistribution(accountServiceDistributionDrafts.get(id),Number(accountAdjustmentDrafts.get(id)??actual),preferredMode):currentDist;if(save)save.disabled=(Number(accountAdjustmentDrafts.get(id)??actual)===actual)&&serviceDistributionEqual(latestDist,currentDist)&&e.target.value.trim()===currentNote.trim()});
 body.querySelectorAll('[data-modal-adjust-reason]').forEach(b=>b.addEventListener('click',()=>{accountAdjustmentReasons.set(id,String(b.dataset.modalAdjustReason||'customer'));if(String(b.dataset.modalAdjustReason||'')!=='other')accountAdjustmentNotes.delete(id);renderAccountItemEditor()}));body.querySelector('[data-modal-adjust-note]')?.addEventListener('input',e=>{e.target.value=human(e.target.value);accountAdjustmentNotes.set(id,e.target.value)});
}
function openAccountItemEditor(id){const group=accountEditorGroup(id);if(!group)return;const line=group.anchor,preferredMode=String(line.fulfillment_mode||'dine_in')==='takeaway'?'takeaway':'dine_in';accountEditingItemId=Number(id);accountAdjustmentDrafts.set(id,Number(group.total||0));accountServiceDistributionDrafts.set(id,reconcileServiceDistribution(group.distribution,group.total,preferredMode));accountItemNoteDrafts.set(id,human(group.note));accountEditFeedback=null;renderAccountItemEditor();const d=root.querySelector('[data-account-item-edit-dialog]');if(!window.SoknaUI?.showDialog?.(d,{focusTitle:true}))d?.showModal?.()}
function accountRound(r,index,total){const latest=index===total-1,items=Array.isArray(r.items)?r.items:[],state=roundState(r.status),time=L.time(r.created_at),registered=String(r.status||'accounted')==='accounted'?'ثبت‌شده':state;return `<section class="sc-hall-order-round${latest?' is-latest':''}" data-order-round="${Number(r.order_id||0)}" data-round-state="${esc(String(r.status||'accounted'))}"><header class="sc-hall-round-divider"><span aria-hidden="true"></span><strong>نوبت ${L.integer(r.round_index||index+1)}</strong><small>${esc(registered)} · ${esc(time)}</small><span aria-hidden="true"></span></header>${r.customer_note?`<div class="sc-hall-round-note">${esc(r.customer_note)}</div>`:''}<div class="sc-hall-round-lines">${items.map(l=>accountLine(l,canOrder&&featureCommittedAdjust&&String(r.status||'accounted')==='accounted')).join('')}</div></section>`}
function pendingAccountSummary(){
 const pending=Array.isArray(account?.pending_orders)?account.pending_orders:[];if(!pending.length)return '';
 const sum=pending.reduce((n,o)=>n+Number(o.total_amount||0),0);
 const cards=pending.map(o=>{
  const lines=Array.isArray(o.items)?o.items:[];
  const rows=lines.map(l=>`<li class="sc-pending-review-line"><span><strong>${esc(l.name)}</strong>${l.note?`<small>${esc(l.note)}</small>`:''}${l.fulfillment_mode==='takeaway'?'<small>بیرون‌بر</small>':''}</span><b>${L.integer(l.quantity||0)} × ${money(l.unit_price)}</b><b>${money(l.line_total)}</b></li>`).join('');
  const oid=Number(o.id||0),tid=Number(account.table?.id||0);
  return `<section class="sc-pending-review-card" data-pending-review-id="${oid}" tabindex="-1"><header><strong>سفارش ${L.integer(o.order_number||oid)}</strong><span class="sc-badge sc-badge--warning">منتظر تأیید</span><b>${money(o.total_amount)}</b></header><ul class="sc-pending-review-lines">${rows||'<li>اقلام سفارش در دسترس نیست؛ تأیید غیرفعال است.</li>'}</ul>${o.note?`<p class="sc-pending-review-note">یادداشت: ${esc(o.note)}</p>`:''}<footer><button type="button" class="sc-button" data-pending-approve="${oid}" data-pending-table="${tid}" ${!canOrder||!mutationsAllowed()||!lines.length?'disabled':''}>تأیید همین سفارش</button><button type="button" class="sc-button sc-button--secondary" data-pending-reject="${oid}" data-pending-table="${tid}" ${!canOrder||!mutationsAllowed()||!lines.length?'disabled':''}>رد سفارش</button></footer></section>`;
 }).join('');
 return `<section class="sc-hall-pending-account" data-pending-account-summary><header class="sc-pending-review-heading"><span class="sc-badge sc-badge--warning">${L.integer(pending.length)} سفارش منتظر</span><strong>پیش از تأیید، اقلام را بررسی کنید</strong><b>${money(sum)}</b></header>${cards}</section>`
}
function accountPriceChangeSummary(){const changes=Array.isArray(account?.price_changes)?account.price_changes:[];if(!changes.length)return '';const names=[...new Set(changes.map(x=>String(x.name||'')))];return `<section class="sc-hall-account-price-change" data-account-price-change><div><strong>قیمت ${L.integer(names.length)} عنوان محصول پس از ثبت حساب تغییر کرده است.</strong><small>اقلام موجود با قیمت زمان ثبت باقی می‌مانند.</small></div><button type="button" class="sc-button sc-button--secondary" data-price-details>جزئیات تغییر قیمت</button></section>`}
function openAccountPriceChanges(){const priceRows=Array.isArray(account?.price_changes)?account.price_changes:[];if(!priceRows.length)return;
 const grouped=new Map();for(const row of priceRows){const name=String(row.name||''),recorded=Number(row.recorded_price||0),current=Number(row.current_price||0),key=JSON.stringify([name,recorded,current]),prior=grouped.get(key);if(prior){prior.quantity+=Math.max(0,Number(row.quantity||0))}else{grouped.set(key,{name,recorded_price:recorded,current_price:current,quantity:Math.max(0,Number(row.quantity||0))})}}
 const changes=[...grouped.values()];const dialog=document.createElement('dialog');dialog.className='sc-price-review-dialog';dialog.setAttribute('aria-label','تغییر قیمت اقلام حساب');dialog.innerHTML=`<div class="sc-price-review-head"><strong>تغییرات قیمت · میز ${L.integer(account?.table?.table_number||account?.table?.id||0)}</strong><button type="button" class="sc-icon-button" data-price-close aria-label="بستن">×</button></div><p class="sc-price-review-note">قیمت سفارش ثبت‌شده تغییر نمی‌کند. سفارش جدید با قیمت فعلی ثبت می‌شود.</p><div class="sc-price-review-rows">${changes.map(x=>`<div class="sc-price-review-row"><strong>${esc(x.name)}</strong><small>${L.integer(x.quantity||0)} عدد</small><span>هنگام ثبت: <b>${money(x.recorded_price)}</b></span><span>اکنون: <b>${money(x.current_price)}</b></span></div>`).join('')}</div><button type="button" class="sc-button" data-price-close>بستن</button>`;document.body.append(dialog);dialog.addEventListener('close',()=>dialog.remove(),{once:true});dialog.querySelectorAll('[data-price-close]').forEach(btn=>btn.addEventListener('click',()=>dialog.close()));if(window.SoknaUI?.showDialog){window.SoknaUI.showDialog(dialog,{focusTitle:true})}else dialog.showModal()}

function accountNotices(){const html=accountPriceChangeSummary();return html?`<div class="sc-hall-account-notices">${html}</div>`:''}
function accountRounds(){const rounds=Array.isArray(account?.order_rounds)?account.order_rounds:[];if(rounds.length)return rounds.map((r,i)=>accountRound(r,i,rounds.length)).join('');return account?.lines?.length?`<div class="sc-hall-bill-flat-fallback">${account.lines.map(accountLine).join('')}</div>`:'<div class="sc-empty">هنوز قلم تأییدشده‌ای وارد حساب نشده است.</div>'}
let moveStatusChecking=false,lastMoveStatusCheckAt=0;
// One read-only check per recovery window, never during a normal Hall refresh.
async function reconcileUnknownTableMove(){
 const pending=tableMoveUncertainTransfer;
 if(!pending||moveStatusChecking||Date.now()-lastMoveStatusCheckAt<12000)return;
 lastMoveStatusCheckAt=Date.now();moveStatusChecking=true;
 try{
  const query={request_id:pending.requestId,table_id:pending.sourceTableId,target_table_id:pending.targetTableId,expected_session_id:pending.sourceSessionId,expected_draft_id:pending.sourceDraftId||0,expected_draft_version:pending.sourceDraftVersion||0};
  const result=transport?.moveStatus?await transport.moveStatus(query):await request(`${api}?${new URLSearchParams({action:'table_move_status',...query})}`);
  // Another tab or request may have changed the pending operation while GET was in flight.
  if(!tableMoveUncertainTransfer||tableMoveUncertainTransfer.requestId!==pending.requestId)return;
  if(result?.state!=='committed')return; // absent/rejected/invalid are NEVER guessed into success.
  const proof=result.result||{};
  if(Number(proof.source_table_id)!==pending.sourceTableId||
     Number(proof.target_table_id)!==pending.targetTableId||
     Number(proof.source_session_id)!==pending.sourceSessionId||
     (pending.sourceSessionId>0?Number(proof.new_session_id||0)<1:
       Number(proof.new_session_id)!==0||Number(proof.moved_draft_id||0)!==pending.sourceDraftId)||
     String(proof.request_id||'')!==pending.requestId)return;
  rememberMoveState({...pending,phase:'committed',newSessionId:Number(proof.new_session_id),movedDraftId:Number(proof.moved_draft_id||0)});
  selectedTableId=pending.targetTableId;account=null;financeAccount=null;financeError='';updateUrl();
  setStatus('رسید انتقال تأیید شد؛ منتظر نمایش نشست جدید میز مقصد هستیم.','warning');
  await load();
 }catch(e){
  // A failed GET cannot safely release the guard or trigger a new POST.
  if(tableMoveUncertainTransfer?.requestId===pending.requestId)
   setStatus('استعلام نتیجهٔ انتقال فعلاً در دسترس نیست؛ انتقال دیگری ثبت نکن.','warning');
 }finally{moveStatusChecking=false}
}
function moveTargets(t){const locked=[...(tableMovePending?[tableMovePending.sourceTableId,tableMovePending.targetTableId]:[]),...(tableMoveUncertainTransfer?[tableMoveUncertainTransfer.sourceTableId,tableMoveUncertainTransfer.targetTableId]:[])];return (snap?.tables||[]).filter(x=>Number(x.id)!==Number(t.id)&&x.transfer_eligible===true&&!locked.includes(Number(x.id)))}
function chooseMoveTarget(t,targets){const d=root.querySelector('[data-table-move-dialog]'),grid=d?.querySelector('[data-table-move-grid]'),title=d?.querySelector('[data-table-move-title]'),copy=d?.querySelector('[data-table-move-copy]'),context=d?.querySelector('[data-table-move-context]'),confirm=d?.querySelector('[data-table-move-confirm]');if(!d||!grid||!confirm)return Promise.resolve(null);const sourceAmount=Number(t.session_id?financeAccount?.remaining_total??t.account_total??0:t.draft_total??0),sourceZone=String(t.zone_label||'').trim();title&&(title.textContent='انتقال حساب به میز دیگر');copy&&(copy.textContent='یک میز آزاد را انتخاب کنید؛ انتقال فقط پس از تأیید نهایی انجام می‌شود.');if(context)context.innerHTML=`<div><span>مبدأ</span><strong>میز ${L.integer(t.table_number||t.id)}</strong>${sourceZone?`<small>${esc(sourceZone)}</small>`:''}</div><div><span>مانده حساب</span><strong>${money(sourceAmount)}</strong></div><div><span>میزهای آزاد</span><strong>${L.integer(targets.length)}</strong></div>`;grid.replaceChildren();grid.dataset.moveCount=String(targets.length);grid.classList.toggle('is-many',targets.length>15);grid.classList.toggle('is-crowded',targets.length>20);d.dataset.moveCount=String(targets.length);let selected=0;const updateSelection=id=>{selected=Number(id||0);grid.querySelectorAll('[data-move-target]').forEach(btn=>{const on=Number(btn.dataset.moveTarget||0)===selected;btn.classList.toggle('is-selected',on);btn.setAttribute('aria-pressed',on?'true':'false')});const target=targets.find(x=>Number(x.id)===selected);confirm.disabled=!target||!mutationsAllowed();confirm.textContent=target?`انتقال به میز ${L.integer(target.table_number||target.id)}`:'انتخاب میز مقصد'};for(const x of targets){const b=document.createElement('button');b.type='button';b.className='sc-table-move-card';b.dataset.moveTarget=String(x.id);b.setAttribute('aria-pressed','false');b.setAttribute('aria-label',`انتخاب میز ${L.integer(x.table_number||x.id)}${x.zone_label?`، ${x.zone_label}`:''}`);b.innerHTML=`<small>میز آزاد</small><strong>${L.integer(x.table_number||x.id)}</strong><span>${x.zone_label?esc(x.zone_label):'بدون بخش'}</span>`;b.addEventListener('click',()=>updateSelection(x.id));grid.append(b)}return new Promise(resolve=>{let done=false;const readiness=()=>updateSelection(selected);const finish=value=>{if(done)return;done=true;d.removeEventListener('close',closed);document.removeEventListener('sokna:staff-mutation-readiness',readiness);if(d.open)d.close();resolve(value)};const closed=()=>{if(!done){done=true;document.removeEventListener('sokna:staff-mutation-readiness',readiness);resolve(null)}};d.addEventListener('close',closed,{once:true});document.addEventListener('sokna:staff-mutation-readiness',readiness);confirm.onclick=()=>selected&&mutationsAllowed()&&finish(selected);d.querySelectorAll('[data-table-move-close]').forEach(b=>b.onclick=()=>finish(null));if(!window.SoknaUI?.showDialog?.(d,{focusTitle:true}))d.showModal()})}
async function moveTable(t){
 const sid=Number(t.session_id||0),draftId=Number(t.draft_id||0),draftVersion=Number(t.draft_version||0);
 if(!sid&&(!draftId||!draftVersion)){setStatus('ثبت موقت این میز نیاز به تازه‌سازی دارد.','warning');return}
 if(Number(t.pending_order_count||0)>0){setStatus('ابتدا سفارش‌های منتظر تأیید این میز را تعیین تکلیف کن.','warning');toast('تا زمان تأیید یا رد سفارش‌های معلق، تغییر میز مجاز نیست.','warning','تغییر میز');return}
 if(tableMoveSubmitting||(tableMovePending&&[tableMovePending.sourceTableId,tableMovePending.targetTableId].includes(Number(t.id)))||(tableMoveUncertainTransfer&&[tableMoveUncertainTransfer.sourceTableId,tableMoveUncertainTransfer.targetTableId].includes(Number(t.id)))||(tableMoveUncertainSessionId>0&&tableMoveUncertainSessionId===sid)){setStatus('نتیجه انتقال قبلی هنوز در حال بررسی است. ابتدا وضعیت حساب را تازه کن؛ انتقال دیگری ثبت نکن.','warning');return}
 if(!mutationsAllowed()){setStatus('ارتباط ثبت عملیات آماده نیست؛ انتقال میز ارسال نشد.','warning');return}
 const targets=moveTargets(t);
 if(!targets.length){setStatus('میز آزادی برای انتقال وجود ندارد.','warning');toast('فعلاً میز آزادی برای انتقال حساب وجود ندارد.','warning','انتقال میز');return}
 const picked=await chooseMoveTarget(t,targets);if(!picked)return;
 const target=targets.find(x=>Number(x.id)===Number(picked));if(!target)return;
 if(tableMoveSubmitting)return;
 if(!mutationsAllowed()){setStatus('ارتباط ثبت عملیات قطع شد؛ انتقال میز ارسال نشد.','warning');return}
 const requestId=clientRequestId('hall-move');
 const moveIdentity={sourceTableId:Number(t.id),sourceSessionId:sid,sourceDraftId:draftId,sourceDraftVersion:draftVersion,targetTableId:Number(target.id),requestId,savedAt:Date.now()};
 let result;tableMoveSubmitting=true;
 try{
  result=await mutate({action:'table_move',table_id:Number(t.id),target_table_id:Number(target.id),expected_session_id:sid,expected_draft_id:draftId,expected_draft_version:draftVersion,request_id:requestId});
 }catch(e){
  if(e?.unknown_outcome===true||String(e?.code||'')==='request_pending'||(!e?.definitive_response&&!e?.code)){
   rememberMoveState({...moveIdentity,phase:'unknown'});
   setStatus('نتیجه انتقال میز هنوز قطعی نیست. پیش از درخواست مجدد، وضعیت میز مبدأ و مقصد را تازه کن.','warning');
   toast('نتیجه انتقال نامشخص است؛ انتقال دیگری ثبت نکن.','warning','تغییر میز');return {state:'unknown'};
  }
  throw e;
 }finally{tableMoveSubmitting=false}
 const targetId=Number(result?.target_table_id||0),newSessionId=Number(result?.new_session_id||0),movedDraftId=Number(result?.moved_draft_id||0);
 if(targetId!==Number(target.id)||(sid>0?newSessionId<1:(newSessionId!==0||movedDraftId!==draftId))){
  // Never treat an incomplete/malformed ACK as a confirmed move.
  rememberMoveState({...moveIdentity,phase:'unknown'});
  setStatus('پاسخ انتقال کامل نیست؛ وضعیت واقعی میزها را بررسی کن و دوباره انتقال نفرست.','warning');
  toast('پاسخ انتقال کامل نیست؛ نتیجه انتقال نیازمند بررسی است.','warning','تغییر میز');
  return {state:'unknown'};
 }
 // Do not present an old Public projection as a fresh account after a committed transfer.
 rememberMoveState({...moveIdentity,phase:'committed',targetTableId:targetId,newSessionId,movedDraftId});
 completedMoveSource=Number(t.table_number||t.id);selectedTableId=targetId;account=null;financeAccount=null;financeError='';updateUrl();
  showMobileAccount({record:true});
 await load();
 if(tableMovePending){setStatus('انتقال در لوکال ثبت شد؛ نمایش حساب میز مقصد منتظر همگام‌سازی پابلیک است.','warning');toast('انتقال ثبت شد؛ منتظر به‌روزرسانی نمایش میز مقصد هستیم.','warning','تغییر میز')}
 else toast(result.message||'حساب به میز جدید منتقل شد.','success','تغییر میز');
 return {state:'committed',targetTableId:targetId};
}


function stageOrderItem(button){const id=Number(button?.dataset.itemId||0),actual=Number(button?.dataset.itemActual||0),delta=Number(button?.dataset.itemStageDelta||0);if(id<1)return;const current=accountAdjustmentDrafts.has(id)?Number(accountAdjustmentDrafts.get(id)):actual,next=Math.max(0,Math.min(99,current+delta));accountAdjustmentDrafts.set(id,next);accountEditFeedback=null;renderAccountItemEditor()}
async function commitOrderItemAdjustment(button){
 const orderItemId=Number(button?.dataset.itemAdjustApply||0),group=accountEditorGroup(orderItemId),line=group?.anchor,current=Number(group?.total??button?.dataset.itemActual??0),name=String(line?.name||button?.dataset.itemName||'قلم سفارش'),next=accountAdjustmentDrafts.has(orderItemId)?Number(accountAdjustmentDrafts.get(orderItemId)):current,preferredMode=String(line?.fulfillment_mode||'dine_in')==='takeaway'?'takeaway':'dine_in',currentDist=group?.distribution||{dine_in:current,takeaway:0},nextDist=accountServiceDistributionDrafts.has(orderItemId)?reconcileServiceDistribution(accountServiceDistributionDrafts.get(orderItemId),next,preferredMode):reconcileServiceDistribution(currentDist,next,preferredMode),currentNote=human(String(group?.note||line?.note||'')),nextNote=accountItemNoteDrafts.has(orderItemId)?String(accountItemNoteDrafts.get(orderItemId)).trim():currentNote.trim();
 if(orderItemId<1||(next===current&&serviceDistributionEqual(nextDist,currentDist)&&nextNote===currentNote.trim()))return;
 const key=adjustmentReason(orderItemId),label=adjustmentReasonLabel(orderItemId),extra=String(accountAdjustmentNotes.get(orderItemId)||'').trim(),reason=(key==='other'&&extra)?`${label} — ${extra}`:label;
 const result=await mutate({action:'order_item_adjust',order_item_id:orderItemId,quantity:next,fulfillment_quantities:{dine_in:Number(nextDist.dine_in||0),takeaway:Number(nextDist.takeaway||0)},item_note:nextNote,reason,request_id:clientRequestId('order-adjust')});
 accountAdjustmentDrafts.delete(orderItemId);accountAdjustmentReasons.delete(orderItemId);accountAdjustmentNotes.delete(orderItemId);accountAdjustmentModes.delete(orderItemId);accountServiceDistributionDrafts.delete(orderItemId);accountItemNoteDrafts.delete(orderItemId);const feedbackId=Number(result.display_order_item_id||orderItemId);accountEditingItemId=next>0?feedbackId:0;
 let tone='success',message='اصلاح سفارش ثبت شد.';if(result.preparation_ack_required){tone='warning';message='اصلاح ثبت شد؛ بخش آماده‌سازی باید تغییر را تأیید کند.'}else if(Number(result.correction_print_job_id||0)>0){if(String(result.correction_print_status||'')==='blocked'){tone='warning';message='اصلاح ثبت شد؛ اصلاحیه چاپ ثبت شده اما مقصد چاپ آماده نیست.'}else message='اصلاح ثبت شد؛ اصلاحیه آماده‌سازی در صف چاپ قرار گرفت.'}
 accountEditFeedback=next>0?{id:feedbackId,tone,message}:null;closeAccountItemEditor();await load()
}
async function reprintPreparationRound(orderId){if(orderId<1)return;const result=await mutate({action:'order_reprint',order_id:orderId,request_id:clientRequestId('prep-reprint')});const status=String(result.status||'');if(status==='pending'||status==='reserved'||status==='claimed'||status==='started'){toast('چاپ مجدد در صف چاپ قرار گرفت.','success','فیش آماده‌سازی');return}if(status==='blocked'){toast('درخواست ثبت شد اما مقصد چاپ آماده نیست؛ وضعیت چاپ را بررسی کن.','warning','فیش آماده‌سازی');return}toast('وضعیت درخواست چاپ: '+(status||'ثبت‌شده'),'info','فیش آماده‌سازی')}
async function reprintPreparationFromMenu(){const rounds=(Array.isArray(account?.order_rounds)?account.order_rounds:[]).filter(r=>Number(r.order_id)>0&&String(r.status||'accounted')==='accounted');if(!rounds.length){toast('فیش آماده‌سازی قابل چاپی برای این حساب وجود ندارد.','warning','چاپ مجدد');return}let orderId=Number(rounds[rounds.length-1].order_id);if(rounds.length>1){const picked=await SoknaUI.choose('فیش آماده‌سازی',rounds.slice().reverse().map(r=>({label:`نوبت ${L.integer(r.round_index||1)} · سفارش ${L.integer(r.order_number||r.order_id)}`,value:String(r.order_id)})),{message:'کدام نوبت دوباره چاپ شود؟'});if(picked===null)return;orderId=Number(picked||0)}await reprintPreparationRound(orderId)}
async function reprintCustomerReceiptFromMenu(){const receipts=Array.isArray(financeAccount?.receipts)?financeAccount.receipts:[];if(!receipts.length){toast('هنوز فیش مشتری ثبت‌شده‌ای برای چاپ مجدد وجود ندارد.','warning','چاپ مجدد');return}let settlementId=Number(receipts[0].id||0);if(receipts.length>1){const picked=await SoknaUI.choose('فیش مشتری',receipts.map(r=>({label:`${r.invoice_number||'فیش مشتری'} · ${money(r.total||0)}`,value:String(r.id)})),{message:'کدام سند دوباره چاپ شود؟'});if(picked===null)return;settlementId=Number(picked||0)}if(settlementId<1)return;const j=await financeMutate({action:'receipt_reprint',settlement_id:settlementId,request_id:clientRequestId('receipt-reprint')});const st=String(j.result?.status||'');if(st==='blocked')toast('درخواست ثبت شد اما مقصد چاپ آماده نیست؛ وضعیت چاپ را بررسی کن.','warning','فیش مشتری');else toast('فیش مشتری برای چاپ مجدد ارسال شد.','success','فیش مشتری')}
function closePrintMenu(){const menu=accountPane.querySelector('[data-account-print-menu]'),toggle=accountPane.querySelector('[data-account-print-toggle]');if(menu)menu.hidden=true;if(toggle)toggle.setAttribute('aria-expanded','false')}
let accountLoadSeq=0,hallLoadSeq=0;
async function loadFinanceAccount(sessionId,loadSeq=accountLoadSeq){
    financeAccount=null;financeError='';
    if(!canCashier||sessionId<1)return;
    const pending=Array.isArray(account?.pending_orders)?account.pending_orders.length:Number(account?.table?.pending_order_count||0);
    if(pending>0){financeError='ابتدا سفارش تازه را تأیید یا رد کنید.';return;}
    if(!(account?.lines||[]).length){financeError='هنوز حساب تأییدشده‌ای برای تسویه وجود ندارد.';return;}
    try{
        const j=await request(`${financeApi}?action=account&session_id=${encodeURIComponent(sessionId)}`);
        if(loadSeq!==accountLoadSeq||Number(account?.table?.id)!==Number(selectedTableId)||Number(account?.table?.session_id)!==sessionId)return;
        financeAccount=j.account||null;
    }catch(e){
        if(loadSeq===accountLoadSeq&&Number(account?.table?.id)===Number(selectedTableId)&&Number(account?.table?.session_id)===sessionId)financeError=e.message||'حساب مالی آماده نیست.';
    }
}
const discountDialog=root.querySelector('[data-hall-discount-dialog]'),discountForm=root.querySelector('[data-hall-discount-form]');let discountPreviewTimer=0,discountPreviewSeq=0,discountPreviewValid=false;
function discountPreview(){if(!discountDialog||!financeAccount)return;const type=String(discountDraftType||'percent'),input=discountDialog.querySelector('[data-discount-value]');let value=numericValue(input?.value||discountDraftValue||0);if(!Number.isFinite(value))value=0;value=type==='percent'?Math.max(0,Math.min(100,value)):Math.max(0,Math.trunc(value));const base=Math.max(0,Number(financeAccount.subtotal??financeAccount.remaining_subtotal??0)),quickAmount=type==='percent'?Math.round(base*value/100):value,label=discountDialog.querySelector('[data-discount-input-label]'),apply=discountDialog.querySelector('[data-discount-apply]'),baseEl=discountDialog.querySelector('[data-discount-base]'),amountEl=discountDialog.querySelector('[data-discount-amount]'),taxEl=discountDialog.querySelector('[data-discount-tax]'),taxRow=discountDialog.querySelector('[data-discount-tax-row]'),netEl=discountDialog.querySelector('[data-discount-net]'),statusEl=discountDialog.querySelector('[data-discount-preview-status]');discountDialog.querySelectorAll('[data-discount-type]').forEach(b=>{const on=String(b.dataset.discountType)===type;b.classList.toggle('is-active',on);b.setAttribute('aria-pressed',on?'true':'false')});if(label)label.textContent=type==='percent'?'درصد تخفیف':'مبلغ تخفیف';if(input){input.placeholder=type==='percent'?'مثلاً ۱۰':'مبلغ به تومان';if(type==='percent')delete input.dataset.moneyInput;else input.dataset.moneyInput='1';L.humanizeNumericInput?.(input)}if(baseEl)baseEl.textContent=money(base);if(amountEl)amountEl.textContent=value>0?`− ${money(quickAmount)}`:'—';if(taxRow)taxRow.hidden=true;if(taxEl)taxEl.textContent='—';if(netEl)netEl.textContent=value>0?'در حال محاسبه…':'—';if(statusEl){statusEl.hidden=value<=0;statusEl.textContent=value>0?'در حال محاسبه مبلغ نهایی…':''}discountPreviewValid=false;if(apply)apply.disabled=true;clearTimeout(discountPreviewTimer);const seq=++discountPreviewSeq;if(value<=0)return;discountPreviewTimer=setTimeout(async()=>{try{const j=await financeMutate({action:'discount_preview',session_id:Number(financeAccount.session?.id||0),discount_type:type,discount_value:value}),r=j.result||{};if(seq!==discountPreviewSeq)return;if(baseEl)baseEl.textContent=money(Number(r.subtotal??base));if(amountEl)amountEl.textContent=`− ${money(Number(r.discount_amount??quickAmount))}`;if(taxRow)taxRow.hidden=false;if(taxEl)taxEl.textContent=money(Number(r.tax||0));if(netEl)netEl.textContent=money(Number(r.total||0));if(statusEl){statusEl.hidden=true;statusEl.textContent=''}discountPreviewValid=true;if(apply)apply.disabled=false}catch(e){if(seq!==discountPreviewSeq)return;if(netEl)netEl.textContent='—';if(statusEl){statusEl.hidden=false;statusEl.textContent=e?.message||'محاسبه مبلغ نهایی انجام نشد.'}discountPreviewValid=false;if(apply)apply.disabled=true}},160)}
function openDiscountDialog(){if(!discountDialog||!financeAccount)return;const currentType=String(financeAccount.session?.discount_type||''),currentValue=Number(financeAccount.session?.discount_value||0),hasCurrent=Boolean(currentType&&currentValue>0);discountDraftType=currentType||'percent';discountDraftValue=hasCurrent?String(currentValue):'';const input=discountDialog.querySelector('[data-discount-value]'),current=discountDialog.querySelector('[data-discount-current]'),currentLabel=discountDialog.querySelector('[data-discount-current-label]');if(input)input.value=human(discountDraftValue);if(current)current.hidden=!hasCurrent;if(currentLabel&&hasCurrent)currentLabel.textContent=currentType==='percent'?`${L.integer(currentValue)}٪`:`${money(currentValue)}`;discountPreview();if(!window.SoknaUI?.showDialog?.(discountDialog,{initialFocus:'[data-discount-value]'}))discountDialog.showModal()}
function closeDiscountDialog(){clearTimeout(discountPreviewTimer);discountPreviewSeq++;discountPreviewValid=false;if(discountDialog?.open)discountDialog.close()}
async function applyHallDiscount(){if(!financeAccount||!discountDialog)return;if(!discountPreviewValid)throw new Error('ابتدا مبلغ نهایی تخفیف باید با موفقیت محاسبه شود.');const s=financeAccount.session,type=String(discountDraftType||'percent'),input=discountDialog.querySelector('[data-discount-value]');let value=numericValue(input?.value||0);if(!Number.isFinite(value))value=0;if(type==='percent')value=Math.max(0,Math.min(100,value));else value=Math.max(0,Math.trunc(value));if(value<=0)throw new Error('مقدار تخفیف را وارد کن.');await financeMutate({action:'discount',session_id:Number(s.id),discount_type:type,discount_value:value});discountDraftType=type;discountDraftValue=String(value);closeDiscountDialog();await loadAccount(selectedTableId);toast('تخفیف حساب اعمال شد.','success')}
async function removeHallDiscount(){if(!financeAccount)return;await financeMutate({action:'discount',session_id:Number(financeAccount.session.id),discount_type:null,discount_value:0});discountDraftType='percent';discountDraftValue='';closeDiscountDialog();await loadAccount(selectedTableId);toast('تخفیف حساب حذف شد.','success')}
async function chooseSubscriber(){const q=await SoknaUI.prompt('حساب مشتری',{label:'نام یا موبایل مشتری'});if(!q)return 0;const j=await request(`${subscriberApi}?action=search&q=${encodeURIComponent(q)}`);const rows=Array.isArray(j.rows)?j.rows:[];if(!rows.length)throw new Error('مشتری پیدا نشد.');const picked=await SoknaUI.choose('انتخاب مشتری',rows.slice(0,8).map(r=>({label:`${r.name}${r.mobile?` · ${r.mobile}`:''}${r.balance!=null?` · مانده ${money(r.balance)}`:''}`,value:String(r.id)})),{message:'مشتری موردنظر را انتخاب کنید.'});return Number(picked||0)}
async function settleHallAccount(){if(!financeAccount||!featureSettlement)return;const sessionId=Number(financeAccount.session?.id||0);if(transport?.settleAccount&&mutationsAllowed()){await transport.settleAccount(financeAccount,{table:account?.table||null});settlementRecoveryBySession.delete(sessionId);account=null;financeAccount=null;financeError='';selectedTableId=0;updateUrl();await load();return}if(!window.SoknaHallSettlement?.open)throw new Error('پنجره تسویه آماده نیست.');window.SoknaHallSettlement.open(financeAccount,{onLateComplete:async()=>{await loadAccount(selectedTableId);await load()},printPreferences:printQuickPreferences,accommodationEnabled:Boolean(snap?.accommodation_enabled),canManageConnections:Boolean(snap?.can_manage_connections),onRecoveryState:info=>{if(info)settlementRecoveryBySession.set(sessionId,info);else settlementRecoveryBySession.delete(sessionId);renderAccount()},onDetachFollowup:async info=>{await detachAccountForFollowup(info);},onComplete:async({closes})=>{settlementRecoveryBySession.delete(sessionId);account=null;financeAccount=null;financeError='';if(closes){selectedTableId=0;updateUrl()}await load()}})}
async function detachAccountForFollowup(recovery=null){if(!financeAccount||!mutationsAllowed()||!recovery)return;const s=financeAccount.session,defaultReason=String(recovery?.message||'').trim(),reason=defaultReason||await SoknaUI.prompt('آزاد کردن میز و پیگیری حساب',{label:'دلیل یا یادداشت پیگیری',value:'',placeholder:'مثلاً ارتباط اقامتگاه در دسترس نیست'});if(reason===null)return;const ok=await SoknaUI.confirm('آزاد کردن میز و پیگیری حساب','میز همین حالا آزاد می‌شود، اما حساب و مانده آن در بخش مالی باز می‌ماند تا بعداً تعیین تکلیف شود.');if(!ok)return;await financeMutate({action:'settlement_recovery_required',session_id:Number(s.id),destination:String(recovery.destination||''),code:String(recovery.code||'network_failed'),message:String(recovery.message||''),status:Number(recovery.status||0)});await financeMutate({action:'followup_detach',session_id:Number(s.id),reason:String(reason||''),destination:String(recovery?.destination||''),expected_session_id:Number(s.id),expected_remaining_total:Number(financeAccount.remaining_total||0),expected_signature:String(financeAccount.signature||'')});settlementRecoveryBySession.delete(Number(s.id));window.SoknaHallSettlement?.close?.();account=null;financeAccount=null;financeError='';selectedTableId=0;updateUrl();await load();toast('میز آزاد شد و حساب برای پیگیری مالی باز ماند.','success','پیگیری حساب')}
function financeSummary(t){if(!financeAccount)return {label:'جمع سفارش‌های تأییدشده',amount:Number(t.account_total||0),gross:Number(t.account_total||0),discount:0,discountLabel:'',paid:0,tax:0};const a=financeAccount,type=String(a.session?.discount_type||''),value=Number(a.session?.discount_value||0),discount=Number(a.remaining_discount||0),gross=Number(a.remaining_subtotal||0),tax=Number(a.remaining_tax||0),paid=Number(a.paid_total||0),discountLabel=discount>0?(type==='percent'?`${L.integer(value)}٪`:'مبلغ'):'';return {label:'قابل پرداخت',amount:Number(a.remaining_total||0),gross,discount,discountLabel,paid,tax}}
function renderAccount(){const currentBill=accountPane.querySelector('.sc-hall-bill-lines');if(currentBill)accountBillScrollTop=currentBill.scrollTop;if(!account?.table){renderAccountEmpty();return}const t=account.table;if(!Number(t.session_id)){renderAccountEmpty(canOrder?'این میز آزاد است؛ با انتخاب «ثبت سفارش» حساب آن باز می‌شود.':'این میز آزاد است.');if(canOrder){const b=actionButton('ثبت سفارش',()=>openOrder(t.id,'hall-free'),'primary');accountPane.querySelector('.sc-hall-account__empty').append(b)}return}const lastOrder=t.last_order_at?`آخرین سفارش ${ago(t.last_order_at)}`:'هنوز سفارش تأییدشده‌ای ندارد',hasAccounted=Boolean((account.order_rounds||[]).length||(account.lines||[]).length),canMove=canOrder&&featureTableMove&&!tableMovePending&&tableMoveUncertainSessionId!==Number(t.session_id||0)&&Number(t.pending_order_count||0)===0&&moveTargets(t).length>0,financial=financeSummary(t),financeReady=canCashier&&featureSettlement&&Boolean(financeAccount)&&hasAccounted,lockedHint=financeError||'حساب مالی آماده نیست.',prepAvailable=canOrder&&(account.order_rounds||[]).some(r=>Number(r.order_id)>0&&String(r.status||'accounted')==='accounted'),customerAvailable=canCashier&&Array.isArray(financeAccount?.receipts)&&financeAccount.receipts.length>0,showPrint=featureReprint&&(canOrder||canCashier),liveTable=(snap?.tables||[]).find(x=>Number(x.id)===Number(t.id))||t,st=tableOperationalState(liveTable),recovery=settlementRecoveryBySession.get(Number(t.session_id||0))||null,alert='',summary=`<div class="sc-hall-payable sui-account-summary${financial.discount>0?' is-discounted':''}">${financial.discount>0?`<div class="sc-hall-summary-row"><span>جمع کل</span><b>${money(financial.gross)}</b></div><div class="sc-hall-summary-row is-discount"><span>تخفیف ${esc(financial.discountLabel)}</span><b>− ${money(financial.discount)}</b></div>`:''}${financial.tax>0?`<div class="sc-hall-summary-row is-tax"><span>مالیات</span><b>+ ${money(financial.tax)}</b></div>`:''}<div class="sc-hall-summary-row is-payable"><span>${esc(financial.label)}</span><strong>${money(financial.amount)}</strong></div>${financial.paid>0?`<div class="sc-hall-summary-row is-paid"><span>پرداخت‌شده تا این لحظه</span><b>${money(financial.paid)}</b></div>`:''}</div>`,discountType=String(discountDraftType||financeAccount?.session?.discount_type||'percent'),discountValue=Number(financeAccount?.session?.discount_value||0),discountPopover='';accountPane.innerHTML=`<div class="sc-hall-account-card sui-account-panel"><header class="sc-hall-account-head sui-account-head is-selected"><div class="sc-hall-account-number sui-account-table-badge"><small>میز</small><strong>${L.integer(t.table_number||t.id)}</strong></div><div class="sc-hall-account-copy sui-account-identity"><strong class="sc-hall-account-title">حساب میز</strong><div class="sc-hall-account-context sui-account-meta">${String(t.zone_label||'').trim()?`<span>${esc(t.zone_label)}</span><i></i>`:''}<span class="is-emphasis">${esc(duration(t.started_at))}</span></div></div><div class="sc-hall-account-head-actions">${canMove?'<button class="sc-button sc-button--secondary sc-hall-context-action" type="button" data-account-move>تغییر میز</button>':''}${showPrint?`<div class="sc-hall-print-control" data-account-print-control><button class="sc-icon-button sc-hall-print-trigger" type="button" data-account-print-toggle aria-label="چاپ مجدد" aria-haspopup="menu" aria-expanded="false">${uiIcon('print')}</button><div class="sc-hall-print-menu" data-account-print-menu role="menu" hidden><button type="button" role="menuitem" data-account-print-preparation ${prepAvailable?'':'disabled'}><span>فیش آماده‌سازی</span><small>چاپ مجدد فیش ثبت‌شده</small></button><button type="button" role="menuitem" data-account-print-customer ${customerAvailable?'':'disabled'}><span>فیش مشتری</span><small>${customerAvailable?'چاپ مجدد فیش ثبت‌شده':'هنوز فیش مشتری برای این حساب ثبت نشده'}</small></button></div></div>`:''}<button class="sc-icon-button" type="button" data-account-close aria-label="بستن حساب">×</button></div></header>${alert}${accountNotices()}<section class="sc-hall-bill sui-account-content"><div class="sc-hall-bill-head sui-account-section-head"><strong>نوبت‌های سفارش</strong><span>${L.integer((account.lines||[]).length)} قلم · ${L.integer((account.lines||[]).reduce((n,l)=>n+Number(l.quantity||0),0))} عدد${account.order_rounds?.length?` · ${L.integer(account.order_rounds.length)} نوبت`:''}</span></div><div class="sc-order-cart__columns sc-account-columns" aria-hidden="true"><span>آیتم</span><span>تعداد</span><span>مبلغ</span></div><div class="sc-hall-bill-lines">${pendingAccountSummary()}${accountRounds()}</div></section><footer class="sc-hall-checkout sui-account-footer">${summary}${discountPopover}<div class="sc-hall-account-actions sui-account-actions">${canCashier&&featureSettlement?`<button class="sc-button sui-account-action is-primary" type="button" data-account-settle ${financeReady?'':`disabled title="${esc(lockedHint)}"`}>${uiIcon('ticket')}<span>تسویه</span></button>`:''}${canCashier&&featureDiscount?`<button class="sc-button sc-button--secondary sui-account-action ${financial.discount>0?'has-discount':''}" type="button" data-account-discount ${financeReady?'':`disabled title="${esc(lockedHint)}"`}>${uiIcon('tag')}<span>تخفیف</span></button>`:''}${canOrder?`<button class="sc-button sc-button--secondary sui-account-action is-soft" type="button" data-account-order>${uiIcon('add')}<span>افزودن سفارش</span></button>`:''}</div>${financeReady&&recovery?`<div class="sc-hall-settlement-recovery"><div><strong>تسویه نیازمند پیگیری است</strong><small>${esc(recovery.message||'تلاش قبلی کامل نشد.')}</small></div><button class="sc-button sc-button--secondary" type="button" data-account-followup-open>ادامه پیگیری</button></div>`:''}</footer></div>`;accountPane.querySelector('[data-account-close]')?.addEventListener('click',()=>closeSelectedAccount());accountPane.querySelectorAll('[data-pending-approve],[data-pending-reject]').forEach(b=>b.addEventListener('click',e=>{const oid=Number(e.currentTarget.dataset.pendingApprove||e.currentTarget.dataset.pendingReject||0),tid=Number(e.currentTarget.dataset.pendingTable||0),order=(account?.pending_orders||[]).find(o=>Number(o.id)===oid);if(!order||tid!==Number(account?.table?.id||0))return;SoknaUI.busy(e.currentTarget,()=>setPendingOrderStatus({...order,table_id:tid},e.currentTarget.hasAttribute('data-pending-reject')?'cancelled':'accounted')).catch(err=>actionError(err,'تعیین تکلیف سفارش انجام نشد'))}));accountPane.querySelector('[data-price-details]')?.addEventListener('click',openAccountPriceChanges);accountPane.querySelector('[data-account-move]')?.addEventListener('click',e=>SoknaUI.busy(e.currentTarget,()=>moveTable(t)).catch(err=>actionError(err,'تغییر میز انجام نشد')));accountPane.querySelector('[data-account-order]')?.addEventListener('click',()=>openOrder(t.id,'account'));accountPane.querySelectorAll('[data-account-line-edit]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();openAccountItemEditor(Number(b.dataset.accountLineEdit||0))}));accountPane.querySelectorAll('[data-account-line]').forEach(row=>row.addEventListener('dblclick',e=>{if(e.target.closest('button,input,select,textarea,a'))return;const id=Number(row.dataset.accountLine||0);if(id>0&&row.querySelector('[data-account-line-edit]'))openAccountItemEditor(id)}));accountPane.querySelectorAll('[data-item-stage-delta]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();stageOrderItem(e.currentTarget)}));accountPane.querySelectorAll('[data-item-adjust-cancel]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();{const id=Number(e.currentTarget.dataset.itemAdjustCancel||0);accountAdjustmentDrafts.delete(id);accountAdjustmentReasons.delete(id);accountAdjustmentNotes.delete(id);accountAdjustmentModes.delete(id);accountServiceDistributionDrafts.delete(id);accountItemNoteDrafts.delete(id);}accountEditFeedback=null;renderAccount()}));accountPane.querySelectorAll('[data-item-adjust-reason]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();const id=Number(b.dataset.itemId||0),reason=String(b.dataset.itemAdjustReason||'customer');if(id<1)return;accountAdjustmentReasons.set(id,reason);if(reason!=='other')accountAdjustmentNotes.delete(id);renderAccount()}));accountPane.querySelectorAll('[data-item-adjust-note]').forEach(input=>input.addEventListener('input',e=>{e.stopPropagation();const id=Number(e.target.dataset.itemAdjustNote||0);e.target.value=human(e.target.value);if(id>0)accountAdjustmentNotes.set(id,e.target.value)}));accountPane.querySelectorAll('[data-item-adjust-mode]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();const id=Number(b.dataset.itemId||0),mode=String(b.dataset.itemAdjustMode||'dine_in');if(id<1||!['dine_in','takeaway'].includes(mode))return;accountAdjustmentModes.set(id,mode);accountEditFeedback=null;renderAccount()}));accountPane.querySelectorAll('[data-item-prep-note]').forEach(input=>{input.addEventListener('click',e=>e.stopPropagation());input.addEventListener('input',e=>{e.stopPropagation();const id=Number(e.target.dataset.itemPrepNote||0);e.target.value=human(e.target.value);if(id>0)accountItemNoteDrafts.set(id,e.target.value);accountEditFeedback=null})});accountPane.querySelectorAll('[data-item-adjust-note]').forEach(input=>input.addEventListener('click',e=>e.stopPropagation()));accountPane.querySelectorAll('[data-item-adjust-apply]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();SoknaUI.busy(e.currentTarget,()=>commitOrderItemAdjustment(e.currentTarget)).catch(err=>actionError(err,'اصلاح سفارش انجام نشد'))}));const printToggle=accountPane.querySelector('[data-account-print-toggle]'),printMenu=accountPane.querySelector('[data-account-print-menu]');printToggle?.addEventListener('click',e=>{e.stopPropagation();discountOpen=false;const next=Boolean(printMenu?.hidden);if(printMenu)printMenu.hidden=!next;printToggle.setAttribute('aria-expanded',next?'true':'false')});printMenu?.addEventListener('click',e=>e.stopPropagation());accountPane.querySelector('[data-account-print-preparation]')?.addEventListener('click',e=>SoknaUI.busy(e.currentTarget,async()=>{closePrintMenu();await reprintPreparationFromMenu()}));accountPane.querySelector('[data-account-print-customer]')?.addEventListener('click',e=>SoknaUI.busy(e.currentTarget,async()=>{closePrintMenu();await reprintCustomerReceiptFromMenu()}));accountPane.querySelector('[data-account-discount]')?.addEventListener('click',e=>{e.stopPropagation();closePrintMenu();openDiscountDialog()});accountPane.querySelector('[data-account-settle]')?.addEventListener('click',()=>{discountOpen=false;settleHallAccount()});accountPane.querySelector('[data-account-followup-open]')?.addEventListener('click',()=>settleHallAccount());const bill=accountPane.querySelector('.sc-hall-bill-lines');if(bill){bill.scrollTop=accountBillScrollTop;bill.addEventListener('scroll',()=>{accountBillScrollTop=bill.scrollTop},{passive:true})}}
async function loadAccount(id){
    const desired=Number(id);
    if(desired<1||desired!==Number(selectedTableId))return;
    const loadSeq=++accountLoadSeq;
    const previousTableId=Number(account?.table?.id||0);
    if(previousTableId&&previousTableId!==desired){
        accountEditingItemId=0;accountAdjustmentDrafts.clear();accountAdjustmentReasons.clear();accountAdjustmentNotes.clear();accountAdjustmentModes.clear();accountServiceDistributionDrafts.clear();accountItemNoteDrafts.clear();accountEditFeedback=null;accountBillScrollTop=0;
        account=null;financeAccount=null;financeError='';renderAccountEmpty('در حال دریافت حساب میز…');
    }
    accountPane.setAttribute('aria-busy','true');
    try{
        const latest=await request(`${api}?action=account&table_id=${encodeURIComponent(desired)}`);
        if(loadSeq!==accountLoadSeq||desired!==Number(selectedTableId))return;
        if(Number(latest?.table?.id)!==desired)throw new Error('پاسخ حساب با میز انتخاب‌شده تطبیق ندارد؛ دوباره تازه‌سازی کنید.');
        account=latest;financeAccount=null;financeError='';
        if(Number(account?.table?.session_id)>0)await loadFinanceAccount(Number(account.table.session_id),loadSeq);
        if(loadSeq!==accountLoadSeq||desired!==Number(selectedTableId))return;
        renderAccount();
    }catch(e){
        if(loadSeq!==accountLoadSeq||desired!==Number(selectedTableId))return;
        account=null;financeAccount=null;financeError='';renderAccountEmpty(e.message||'دریافت حساب ممکن نیست.',true);
    }finally{
        if(loadSeq===accountLoadSeq)accountPane.removeAttribute('aria-busy');
    }
}
async function selectTable(t){if((tableMovePending&&[tableMovePending.sourceTableId,tableMovePending.targetTableId].includes(Number(t.id)))||(tableMoveUncertainTransfer&&[tableMoveUncertainTransfer.sourceTableId,tableMoveUncertainTransfer.targetTableId].includes(Number(t.id)))){setStatus('انتقال ثبت شده است؛ برای نمایش نتیجه همگام‌سازی را بررسی کن.','warning');return}if(Number(t.id)!==Number(selectedTableId))accountBillScrollTop=0;const sc=root.querySelector('[data-hall-scroll]');if(sc)hallScrollTop=sc.scrollTop;if(Boolean(t.has_draft||Number(t.draft_id)>0)&&canOrder){await openOrder(t.id,'hall-draft');return}if(!Number(t.session_id)&&canOrder){await openOrder(t.id,'hall-free');return}selectedTableId=Number(t.id);updateUrl();renderTables();renderAttention();showMobileAccount();await loadAccount(t.id)}
function showHall(tableId=0,clearSelection=false){document.body.classList.remove('sc-shell-order-mode');orderView.hidden=true;hallView.hidden=false;if(tableId){selectedTableId=Number(tableId);updateUrl();renderTables();renderAttention();showMobileAccount();loadAccount(selectedTableId);return}if(clearSelection){hideMobileAccount({record:false});selectedTableId=0;account=null;financeAccount=null;financeError='';updateUrl();renderTables();renderAttention();renderAccountEmpty();return}if(selectedTableId)loadAccount(selectedTableId)}
async function openOrder(tableId=0,origin='global'){if(!canOrder)return;closeAttentionDrawer();
  const wasAccountOpen=Boolean(root.classList.contains('is-mobile-account-open'));
  if(mobileHall()&&!mobileHandlingBack)markMobileStep('order');else mobileView='order';
  if(wasAccountOpen)root.classList.remove('is-mobile-account-open');
  orderExitTarget=origin==='account'?Number(selectedTableId||tableId||0):0;const returnLabel=origin==='account'?'بازگشت به حساب میز':'بازگشت به سالن';hallView.hidden=true;orderView.hidden=false;document.body.classList.add('sc-shell-order-mode');if(!orderController){orderController=window.SoknaOrderWorkspace.mount(orderView.querySelector('[data-order-workspace-host]'),{api:orderApi,csrf,tableId,entryKind:origin,returnLabel,transport:transport?.orderTransport||null,onPaneChange:pane=>{if(mobileHall()&&!mobileHandlingBack)markMobileStep(pane==='cart'?'cart':'order',{replace:pane==='menu'})},onTransferDraft:async info=>{const original=(snap?.tables||[]).find(t=>Number(t.id)===Number(info.sourceTableId));if(!original)return null;const result=await moveTable({...original,draft_id:info.expectedDraftId,draft_version:info.expectedDraftVersion,session_id:Number(original.session_id||0)});if(result?.state==='committed'){orderExitTarget=result.targetTableId;return result}if(result?.state==='unknown'){orderExitTarget=0;return result}return null},onExit:async({reason=''}={})=>{
   document.body.classList.remove('sc-shell-order-mode');orderView.hidden=true;hallView.hidden=false;
   if(reason==='draft_saved'){orderExitTarget=0;selectedTableId=0;account=null;financeAccount=null;financeError='';updateUrl();hideMobileAccount({record:false});}
   else if(orderExitTarget){selectedTableId=Number(orderExitTarget);updateUrl();showMobileAccount({record:false})}
   else{selectedTableId=0;account=null;financeAccount=null;financeError='';updateUrl();hideMobileAccount({record:false})}
   renderAccountEmpty('در حال به‌روزرسانی وضعیت سالن…');await load();
   if(reason==='draft_saved')toast('ثبت موقت ذخیره شد و هنوز ارسال نشده است.','success','ثبت موقت');
   if(mobileHall()&&!mobileHandlingBack)markMobileStep(root.classList.contains('is-mobile-account-open')?'account':'hall',{replace:true});
 },onFinalized:async({tableId:id,result}={})=>{
   selectedTableId=Number(id);updateUrl();document.body.classList.remove('sc-shell-order-mode');orderView.hidden=true;hallView.hidden=false;
   renderTables();renderAttention();renderAccountEmpty('در حال به‌روزرسانی حساب میز…');
   if(mobileHall())showMobileAccount({record:false});
   await load();
   if(account?.table&&Number(account.table.id)===Number(id)&&Number(account.table.session_id)>0){
     if(mobileHall())markMobileStep('account',{replace:true});
     toast(`سفارش ${L.integer(result?.order_number||0)} در حساب میز ثبت شد.`, 'success','ثبت سفارش');
   }else setStatus('سفارش تأیید شد، اما حساب هنوز تازه نشده است. وضعیت میز را بررسی کن.','warning');
 }})}else{if(typeof orderController.open==='function')await orderController.open(tableId,{kind:origin,returnLabel});else{orderController.setEntryContext({kind:origin,returnLabel});await orderController.setTable(tableId)}}}
async function load(){
    const loadSeq=++hallLoadSeq;
    root.setAttribute('aria-busy','true');setStatus('');
    try{
        const incomingSnapshot=await request(`${api}?action=snapshot`);
        if(loadSeq!==hallLoadSeq)return;
        snap=incomingSnapshot;
        // A successful command and a published projection are distinct events.
        // Check the exact new session id; target-table occupancy alone is not proof.
        const targetReadback=tableMovePending?(snap?.tables||[]).find(x=>Number(x.id)===tableMovePending.targetTableId):null;
        const sourceReadback=tableMovePending?(snap?.tables||[]).find(x=>Number(x.id)===tableMovePending.sourceTableId):null;
        if(tableMovePending&&sourceReadback&&targetReadback&&
           (tableMovePending.sourceSessionId>0?
             (Number(sourceReadback.session_id||0)!==tableMovePending.sourceSessionId&&
              Number(targetReadback.session_id||0)===tableMovePending.newSessionId):
             (Number(sourceReadback.draft_id||0)!==tableMovePending.sourceDraftId&&
              Number(targetReadback.draft_id||0)===tableMovePending.movedDraftId))){
            rememberMoveState(null);
            if(completedMoveSource){toast(`حساب از میز ${L.integer(completedMoveSource)} منتقل شد.`, 'success','انتقال میز');completedMoveSource=0}
        }
        // An unknown POST result cannot be inferred from a stale snapshot.
        // Keep it explicit across refreshes; never resend using a new request ID.
        if(tableMoveUncertainTransfer){
            void reconcileUnknownTableMove();
            const source=(snap?.tables||[]).find(x=>Number(x.id)===tableMoveUncertainTransfer.sourceTableId);
            const target=(snap?.tables||[]).find(x=>Number(x.id)===tableMoveUncertainTransfer.targetTableId);
            if(source&&target){
                // Only an explicit committed ACK can prove the outcome; an unknown
                // outcome remains flagged even when a projection changes.
                setStatus('نتیجه تغییر میز نامشخص است؛ با رسید عملیات یا بررسی مستقیم حساب آن را تعیین تکلیف کن.','warning');
            }
        }
        lastHallLoadAt=Date.now();syncHallFreshnessStatus();if(snap?.order_acceptance)orderAcceptance={...orderAcceptance,...snap.order_acceptance};if(snap?.print_quick_preferences)printQuickPreferences={...printQuickPreferences,...snap.print_quick_preferences};renderOrderAcceptance();renderTables();renderAttention();renderTotals();
        if(tableMovePending||(tableMoveUncertainTransfer&&[tableMoveUncertainTransfer.sourceTableId,tableMoveUncertainTransfer.targetTableId].includes(Number(selectedTableId)))){
            account=null;financeAccount=null;financeError='';
            renderAccountEmpty(tableMovePending?
                'انتقال ثبت شد؛ حساب میز مقصد هنوز در اطلاعات همگام‌شده نمایش داده نشده است. لطفاً منتظر تازه‌شدن اطلاعات بمانید.':
                'نتیجه انتقال هنوز مشخص نیست. برای جلوگیری از انتقال دوباره، حساب میز مبدأ و مقصد باید بررسی شود.');
            setStatus(tableMovePending?'انتقال ثبت شد؛ نمایش سالن هنوز در حال همگام‌سازی است.':
                'نتیجه انتقال نامشخص است؛ انتقال جدید نفرست.','warning');
            return;
        }
        const selected=(snap?.tables||[]).find(t=>Number(t.id)===Number(selectedTableId));if(selectedTableId&&selected){await loadAccount(selectedTableId)}else if(selectedTableId){selectedTableId=0;account=null;financeAccount=null;financeError='';updateUrl();renderAccountEmpty()}else{account=null;financeAccount=null;financeError='';renderAccountEmpty()}
    }catch(e){if(loadSeq===hallLoadSeq)setStatus(e.message,'danger')}
    finally{if(loadSeq===hallLoadSeq)root.removeAttribute('aria-busy')}
}
const hallTools=root.querySelector('[data-hall-tools]'),hallToolsToggle=root.querySelector('[data-hall-tools-toggle]'),hallToolsMenu=root.querySelector('[data-hall-tools-menu]'),hallSortControl=root.querySelector('[data-hall-sort]');syncHallDisplayControls();hallSortControl?.addEventListener('change',()=>{hallSort=['number','time','priority'].includes(hallSortControl.value)?hallSortControl.value:'number';savePref('sokna.hall.sort',hallSort);renderTables()});root.querySelectorAll('[data-hall-density]').forEach(b=>b.addEventListener('click',()=>{const next=String(b.dataset.hallDensity||'normal');if(!['normal','compact','overview'].includes(next))return;hallDensity=next;savePref('sokna.hall.density',hallDensity);syncHallDisplayControls();renderTables()}));const closeHallTools=()=>{if(hallToolsMenu)hallToolsMenu.hidden=true;if(hallToolsToggle)hallToolsToggle.setAttribute('aria-expanded','false')};hallToolsToggle?.addEventListener('click',()=>{const open=Boolean(hallToolsMenu?.hidden);if(hallToolsMenu)hallToolsMenu.hidden=!open;hallToolsToggle.setAttribute('aria-expanded',open?'true':'false')});hallToolsMenu?.addEventListener('click',()=>closeHallTools());root.querySelector('[data-refresh]')?.addEventListener('click',()=>load());document.addEventListener('click',e=>{if(!e.target.closest('[data-hall-tools]'))closeHallTools();if(!e.target.closest('[data-account-print-control]'))closePrintMenu()});document.addEventListener('keydown',e=>{if(e.key==='Escape')closePrintMenu()});
discountDialog?.querySelectorAll('[data-hall-discount-close]').forEach(b=>b.addEventListener('click',()=>closeDiscountDialog()));discountDialog?.querySelectorAll('[data-discount-type]').forEach(b=>b.addEventListener('click',()=>{discountDraftType=String(b.dataset.discountType||'percent');discountDraftValue='';const input=discountDialog.querySelector('[data-discount-value]');if(input)input.value='';discountPreview();queueMicrotask(()=>input?.focus({preventScroll:true}))}));discountDialog?.querySelector('[data-discount-value]')?.addEventListener('input',e=>{e.target.value=human(e.target.value);discountDraftValue=e.target.value;discountPreview()});discountForm?.addEventListener('submit',e=>{e.preventDefault();const apply=discountDialog?.querySelector('[data-discount-apply]');if(apply)SoknaUI.busy(apply,applyHallDiscount).catch(err=>actionError(err,'تخفیف اعمال نشد'))});discountDialog?.querySelector('[data-discount-remove]')?.addEventListener('click',e=>SoknaUI.busy(e.currentTarget,removeHallDiscount).catch(err=>actionError(err,'حذف تخفیف انجام نشد')));
root.querySelector('[data-item-totals-open]')?.addEventListener('click',()=>{const d=root.querySelector('[data-item-totals-dialog]');if(!window.SoknaUI?.showDialog?.(d,{focusTitle:true}))d?.showModal?.()});
if(canSupervise){const acceptanceDialog=root.querySelector('[data-order-acceptance-dialog]'),acceptanceForm=root.querySelector('[data-order-acceptance-form]');root.querySelector('[data-order-acceptance-open]')?.addEventListener('click',()=>{fillAcceptanceDialog();if(!window.SoknaUI?.showDialog?.(acceptanceDialog,{focusTitle:true}))acceptanceDialog?.showModal?.()});root.querySelectorAll('[data-order-acceptance-close]').forEach(b=>b.addEventListener('click',()=>acceptanceDialog?.close()));acceptanceForm?.addEventListener('submit',e=>{e.preventDefault();const save=acceptanceForm.querySelector('[data-order-acceptance-save]');SoknaUI.busy(save,()=>saveOrderAcceptance(acceptanceForm)).catch(err=>actionError(err,'پذیرش آنلاین ذخیره نشد'))})}
const accountEditDialog=root.querySelector('[data-account-item-edit-dialog]');root.querySelectorAll('[data-account-item-edit-close]').forEach(b=>b.addEventListener('click',()=>closeAccountItemEditor()));root.querySelector('[data-account-item-edit-save]')?.addEventListener('click',e=>{const id=Number(accountEditingItemId||0);if(id<1)return;const proxy={dataset:{itemAdjustApply:String(id),itemActual:String(accountEditorGroup(id)?.total||0),itemName:String(accountEditorLine(id)?.name||'قلم سفارش')}};SoknaUI.busy(e.currentTarget,()=>commitOrderItemAdjustment(proxy)).catch(err=>actionError(err,'اصلاح سفارش انجام نشد'))});accountEditDialog?.addEventListener('close',()=>{accountEditingItemId=0});const cafeAcceptance=root.querySelector('[data-order-acceptance-dialog] [name="cafe"]');cafeAcceptance?.addEventListener('change',()=>syncAcceptanceDialogState());
document.querySelectorAll('[data-global-order],[data-staff-order],[data-mobile-new-order]').forEach(globalOrder=>{if(!canOrder)return;globalOrder.addEventListener('click',e=>{e.preventDefault();if(!orderView.hidden)return;openOrder(0,'global')})});
const hallScrollEl=root.querySelector('[data-hall-scroll]');
if(hallScrollEl){
 const protect=()=>{hallTouchUntil=Date.now()+600};
 hallScrollEl.addEventListener('touchstart',protect,{passive:true});
 hallScrollEl.addEventListener('touchmove',protect,{passive:true});
 hallScrollEl.addEventListener('touchend',()=>{hallTouchUntil=Date.now()+400},{passive:true});
 hallScrollEl.addEventListener('touchcancel',()=>{hallTouchUntil=0},{passive:true});
}
window.addEventListener('storage',event=>{if(event.key!==tableMoveStorageKey)return;
    // Do not erase an active pending operation based solely on another tab's
    // deletion; each tab must verify exact source + destination session IDs.
    if(event.newValue){const saved=readMoveState();if(saved){applyMoveState(saved);if(snap){renderTables();renderAttention()}refreshVisibleHall()}}
});
const hallHostVisible=()=>!root.closest('[hidden]');if(autoLoad)load().then(()=>{if(initialView==='order'&&canOrder&&orderView.hidden)openOrder(0,'global')});const refreshVisibleHall=()=>{if(document.hidden||!orderView.hidden||!hallHostVisible())return;if(Date.now()-lastHallLoadAt<1200)return;load()};let timer=setInterval(()=>{if(document.hidden||!orderView.hidden||!hallHostVisible())return;load()},8000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)refreshVisibleHall()});window.addEventListener('focus',refreshVisibleHall);window.addEventListener('beforeunload',()=>clearInterval(timer));
window.SoknaSharedHall={refresh:load,showHall,openOrder,isRemote:()=>Boolean(transport)};
})();
