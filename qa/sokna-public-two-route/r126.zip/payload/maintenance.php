<?php
declare(strict_types=1);

$root=__DIR__;
require_once $root.'/src/Core/Config.php';
require_once $root.'/src/Emergency/PublicUpdateException.php';
require_once $root.'/src/Emergency/EmergencyAccessService.php';
require_once $root.'/src/Maintenance/MaintenanceException.php';
require_once $root.'/src/Maintenance/PublicMaintenanceStorage.php';
require_once $root.'/src/Maintenance/MaintenanceAdminSessionStore.php';
require_once $root.'/src/Maintenance/VaultCredentialStore.php';
require_once $root.'/src/Maintenance/VaultPolicyStore.php';
require_once $root.'/src/Maintenance/RemoteBackupVaultRetentionService.php';
require_once $root.'/src/Maintenance/RemoteBackupVaultService.php';
require_once $root.'/src/Maintenance/PublicMaintenanceKernel.php';
require_once $root.'/src/Maintenance/PublicSignedReleaseAttestation.php';
require_once $root.'/src/Maintenance/PublicStableAuthoritySource.php';
require_once $root.'/src/Core/Database.php';

use Sokna\PublicEdge\Core\Config;
use Sokna\PublicEdge\Core\Database;
use Sokna\PublicEdge\Emergency\EmergencyAccessService;
use Sokna\PublicEdge\Emergency\PublicUpdateException;
use Sokna\PublicEdge\Maintenance\MaintenanceAdminSessionStore;
use Sokna\PublicEdge\Maintenance\MaintenanceException;
use Sokna\PublicEdge\Maintenance\PublicMaintenanceKernel;
use Sokna\PublicEdge\Maintenance\PublicSignedReleaseAttestation;
use Sokna\PublicEdge\Maintenance\PublicStableAuthoritySource;
use Sokna\PublicEdge\Maintenance\PublicMaintenanceStorage;
use Sokna\PublicEdge\Maintenance\RemoteBackupVaultService;
use Sokna\PublicEdge\Maintenance\VaultCredentialStore;
use Sokna\PublicEdge\Maintenance\VaultPolicyStore;
use Sokna\PublicEdge\Maintenance\RemoteBackupVaultRetentionService;

header('Cache-Control: no-store, max-age=0');header('Pragma: no-cache');header('X-Content-Type-Options: nosniff');header('X-Frame-Options: DENY');header('Referrer-Policy: no-referrer');header("Permissions-Policy: camera=(), microphone=(), geolocation=()");header("Content-Security-Policy: default-src 'none'; frame-ancestors 'none'; base-uri 'none'");

function sokna_maintenance_json(array $body,int $status=200): never{http_response_code($status);header('Content-Type: application/json; charset=utf-8');echo json_encode($body,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);exit;}
function sokna_maintenance_body(): array{$raw=file_get_contents('php://input');if(!is_string($raw)||trim($raw)==='')return [];try{$v=json_decode($raw,true,512,JSON_THROW_ON_ERROR);}catch(JsonException){throw new MaintenanceException('invalid_json','Request JSON is invalid.',400);}if(!is_array($v))throw new MaintenanceException('invalid_json','Request JSON must be an object.',400);return $v;}
function sokna_maintenance_bearer(): string{$h=(string)($_SERVER['HTTP_AUTHORIZATION']??$_SERVER['REDIRECT_HTTP_AUTHORIZATION']??'');if($h===''&&function_exists('getallheaders')){$headers=getallheaders();if(is_array($headers))foreach($headers as $k=>$v)if(strcasecmp((string)$k,'Authorization')===0){$h=(string)$v;break;}}if(!preg_match('/^Bearer\s+(.+)$/i',trim($h),$m))throw new MaintenanceException('vault_unauthorized','Vault bearer credential is required.',401);return trim($m[1]);}
function sokna_maintenance_admin_token(): string{$v=trim((string)($_SERVER['HTTP_X_SOKNA_MAINTENANCE_ADMIN']??''));if($v==='')throw new MaintenanceException('maintenance_admin_unauthorized','Maintenance admin session is required.',401);return $v;}
function sokna_maintenance_https(): bool{return (($_SERVER['HTTPS']??'')!==''&&strtolower((string)$_SERVER['HTTPS'])!=='off')||(int)($_SERVER['SERVER_PORT']??0)===443;}
function sokna_maintenance_localhost(): bool{
    // HTTP is allowed ONLY for a real loopback peer, not merely a spoofed Host header.
    // Forwarded headers are intentionally ignored: proxy trust is not established here.
    $remote=(string)($_SERVER['REMOTE_ADDR']??'');
    if(!in_array($remote,['127.0.0.1','::1'],true))return false;
    $host=strtolower(trim((string)($_SERVER['HTTP_HOST']??'')));
    return (bool)preg_match('/^(?:localhost|127\.0\.0\.1)(?::[0-9]{1,5})?$|^\[::1\](?::[0-9]{1,5})?$/D',$host);
}
function sokna_maintenance_require_secure(): void{if(!sokna_maintenance_https()&&!sokna_maintenance_localhost())throw new MaintenanceException('secure_transport_required','Maintenance credentials require HTTPS.',400);}
function sokna_maintenance_client_key(): string{return (string)($_SERVER['REMOTE_ADDR']??'unknown').'|'.substr((string)($_SERVER['HTTP_USER_AGENT']??''),0,240);}
function sokna_maintenance_stream(array $d): never
{
    $h=@fopen((string)$d['path'],'rb');if(!$h)throw new MaintenanceException('vault_artifact_missing','Verified backup artifact is unavailable.',409);
    $offset=(int)$d['offset'];$length=(int)$d['length'];if(fseek($h,$offset)!==0){fclose($h);throw new MaintenanceException('vault_download_seek_failed','Could not seek backup artifact.',500);}
    http_response_code(206);header('Content-Type: application/octet-stream');header('Content-Length: '.$length);header('Accept-Ranges: bytes');header('Content-Range: bytes '.$offset.'-'.($offset+$length-1).'/'.(int)$d['artifact_size']);header('X-Sokna-Backup-Id: '.(string)($_GET['backup_id']??''));header('X-Sokna-Artifact-SHA256: '.(string)$d['artifact_sha256']);header('X-Sokna-Remote-Receipt: '.(string)$d['remote_receipt_id']);header('Content-Disposition: attachment; filename="sokna-backup-'.preg_replace('/[^A-Za-z0-9._-]/','_',((string)($_GET['backup_id']??'backup'))).'.vault"');
    $left=$length;while($left>0&&!feof($h)){$buf=fread($h,min(1024*1024,$left));if($buf===false||$buf==='')break;$left-=strlen($buf);echo $buf;}fclose($h);if($left!==0)throw new MaintenanceException('vault_download_read_failed','Backup artifact could not be streamed completely.',500);exit;
}

try{
    $configPath=$root.'/config.php';if(!is_file($configPath))throw new MaintenanceException('not_configured','Public Edge is not configured.',503);
    $raw=require $configPath;if(!is_array($raw))throw new MaintenanceException('config_invalid','Public configuration is invalid.',500);
    $cfg=Config::fromArray($raw);$storagePath=trim($cfg->string('app.storage_dir'));if($storagePath==='')$storagePath=$root.'/storage';
    $storage=new PublicMaintenanceStorage($root,$storagePath);$maintenanceBase=$storage->ensureBase();$credentials=new VaultCredentialStore($storage->basePath());$policies=new VaultPolicyStore($maintenanceBase);$retention=new RemoteBackupVaultRetentionService($maintenanceBase);$kernel=new PublicMaintenanceKernel($root,$storage,$credentials,$policies);$vault=new RemoteBackupVaultService($storage,$policies,$retention);$adminSessions=new MaintenanceAdminSessionStore($maintenanceBase);$emergency=new EmergencyAccessService($storagePath);
    $action=(string)($_GET['action']??'health');$method=(string)($_SERVER['REQUEST_METHOD']??'GET');
    if($action==='release-attest'&&$method==='GET'){
        if(count($_GET)!==1)throw new MaintenanceException('release_attestation_invalid_query','Invalid attestation query.',400);
        $settings=$cfg->get('maintenance.release_attestation',[]);
        if(!is_array($settings))$settings=[];
        $signer=new PublicSignedReleaseAttestation($root,$maintenanceBase);
        $observer=function()use($root,$maintenanceBase,$settings,$cfg):array {
            $ownerCfg=$settings['stable_authority']??[];
            if(!is_array($ownerCfg)||($ownerCfg['owner_integration_qualified']??false)!==true)
                throw new MaintenanceException('stable_authority_not_integrated','Stable Public owner integration is not qualified.',503);
            try {
                $db=Database::connect($cfg);
                $proof=new PublicStableAuthoritySource($root,$maintenanceBase,$root.'/database/migrations');
                return $proof->observe($db,$ownerCfg,false);
            } catch(\Throwable) {
                throw new MaintenanceException('stable_authority_unavailable','Trusted Public installed authority is unavailable.',503);
            }
        };
        sokna_maintenance_json($signer->attest($settings,$_SERVER,$observer),200);
    }
    if($action==='health'&&$method==='GET'){$r=$kernel->health();sokna_maintenance_json($r,$r['ok']?200:503);}if($action==='status'&&$method==='GET'){$r=$kernel->status();sokna_maintenance_json($r,$r['ok']?200:503);}

    if($action==='admin-login'&&$method==='POST'){
        sokna_maintenance_require_secure();$b=sokna_maintenance_body();$client=sokna_maintenance_client_key();$gate=$emergency->loginStatus($client);if(!$gate['allowed'])throw new MaintenanceException('maintenance_admin_throttled','Maintenance admin login is temporarily locked.',429,['retry_after'=>$gate['retry_after']]);
        $pass=(string)($b['emergency_password']??'');if(!$emergency->verify($pass)){$next=$emergency->recordLoginFailure($client);throw new MaintenanceException('maintenance_admin_denied','Emergency password is invalid.',401,['remaining'=>$next['remaining'],'retry_after'=>$next['retry_after']]);}
        $emergency->recordLoginSuccess($client);$r=$adminSessions->issue($client,$emergency->clientActorHint($client));$emergency->audit('maintenance_admin_login',null,$emergency->clientActorHint($client),[]);sokna_maintenance_json($r,200);
    }
    if(str_starts_with($action,'vault-credential-')||$action==='admin-logout'){
        sokna_maintenance_require_secure();$adminToken=sokna_maintenance_admin_token();$admin=$adminSessions->authenticate($adminToken,sokna_maintenance_client_key());
        if($action==='vault-credential-list'&&$method==='GET')sokna_maintenance_json($credentials->inventory(),200);
        if($action==='vault-credential-provision'&&$method==='POST'){$b=sokna_maintenance_body();$r=$credentials->provision((string)($b['installation_id']??''),(array)($b['scopes']??[]),(int)($b['ttl_seconds']??0),(string)($b['label']??''),(array)($b['policy']??[]));$emergency->audit('vault_credential_provision',(string)($r['installation_id']??''),(string)$admin['actor_hint'],['credential_id'=>$r['credential_id']??'','scopes'=>$r['scopes']??[],'expires_at'=>$r['expires_at']??'']);sokna_maintenance_json($r,201);}
        if($action==='vault-credential-rotate'&&$method==='POST'){$b=sokna_maintenance_body();$r=$credentials->rotate((string)($b['credential_id']??''),(int)($b['grace_seconds']??300));$emergency->audit('vault_credential_rotate',(string)($r['installation_id']??''),(string)$admin['actor_hint'],['credential_id'=>$r['credential_id']??'','previous_credential_id'=>$r['previous_credential_id']??'','previous_retire_at'=>$r['previous_retire_at']??'']);sokna_maintenance_json($r,201);}
        if($action==='vault-credential-renew-upload'&&$method==='POST'){$b=sokna_maintenance_body();$r=$credentials->renewUpload((string)($b['credential_id']??''),(int)($b['ttl_seconds']??2592000),(int)($b['grace_seconds']??300));$emergency->audit('vault_credential_renew_upload',(string)$r['installation_id'],(string)$admin['actor_hint'],['credential_id'=>$r['credential_id'],'previous_credential_id'=>$r['previous_credential_id'],'expires_at'=>$r['expires_at']]);sokna_maintenance_json($r,201);}
        if($action==='vault-credential-revoke'&&$method==='POST'){$b=sokna_maintenance_body();$r=$credentials->revoke((string)($b['credential_id']??''));$emergency->audit('vault_credential_revoke',null,(string)$admin['actor_hint'],['credential_id'=>$r['credential_id']??'']);sokna_maintenance_json($r,200);}
        if($action==='admin-logout'&&$method==='POST'){$adminSessions->revoke($adminToken);sokna_maintenance_json(['ok'=>true],200);}
    }

    if(str_starts_with($action,'vault-'))sokna_maintenance_require_secure();
    if($action==='vault-policy-status'&&$method==='GET'){$p=$credentials->authenticate(sokna_maintenance_bearer(),'vault.retention_admin');$policy=$policies->get((string)$p['installation_id'],true);sokna_maintenance_json(['ok'=>true,'policy'=>$policy,'quota'=>$retention->quotaStatus((string)$p['installation_id'],$policy)],200);}
    if($action==='vault-policy-set'&&$method==='POST'){$p=$credentials->authenticate(sokna_maintenance_bearer(),'vault.retention_admin');$r=$policies->set($p,sokna_maintenance_body());$emergency->audit('vault_policy_set',(string)$p['installation_id'],'vault:'.(string)$p['credential_id'],['policy'=>$r['policy']??[]]);sokna_maintenance_json($r,200);}
    if($action==='vault-retention-plan'&&$method==='GET'){$p=$credentials->authenticate(sokna_maintenance_bearer(),'vault.retention_admin');$policy=$policies->get((string)$p['installation_id'],true);sokna_maintenance_json($retention->plan((string)$p['installation_id'],$policy),200);}
    if($action==='vault-retention-apply'&&$method==='POST'){$p=$credentials->authenticate(sokna_maintenance_bearer(),'vault.retention_admin');$b=sokna_maintenance_body();$policy=$policies->get((string)$p['installation_id'],true);$r=$retention->apply((string)$p['installation_id'],$policy,(string)($b['retention_request_id']??''),'vault:'.(string)$p['credential_id']);$emergency->audit('vault_retention_apply',(string)$p['installation_id'],'vault:'.(string)$p['credential_id'],['retention_request_id'=>$r['retention_request_id']??'','deleted_count'=>$r['deleted_count']??0,'skipped_count'=>$r['skipped_count']??0]);sokna_maintenance_json($r,200);}
    if($action==='vault-upload-begin'&&$method==='POST'){$p=$credentials->authenticate(sokna_maintenance_bearer(),'vault.upload');sokna_maintenance_json($vault->begin($p,sokna_maintenance_body()),202);}
    if($action==='vault-upload-chunk'&&$method==='PUT'){$p=$credentials->authenticate(sokna_maintenance_bearer(),'vault.upload');$id=(string)($_GET['backup_id']??'');$session=(string)($_SERVER['HTTP_X_SOKNA_UPLOAD_SESSION']??'');$offset=(int)($_SERVER['HTTP_X_SOKNA_CHUNK_OFFSET']??-1);$sha=(string)($_SERVER['HTTP_X_SOKNA_CHUNK_SHA256']??'');$in=fopen('php://input','rb');if(!$in)throw new MaintenanceException('vault_chunk_input_invalid','Chunk input is unavailable.',400);try{$r=$vault->appendChunk($p,$id,$session,$offset,$sha,$in);}finally{fclose($in);}sokna_maintenance_json($r,202);}
    if($action==='vault-upload-finalize'&&$method==='POST'){$p=$credentials->authenticate(sokna_maintenance_bearer(),'vault.upload');$b=sokna_maintenance_body();sokna_maintenance_json($vault->finalize($p,(string)($b['backup_id']??''),(string)($b['upload_session_id']??'')),200);}
    if($action==='vault-upload-status'&&$method==='GET'){$p=$credentials->authenticate(sokna_maintenance_bearer(),'vault.upload');sokna_maintenance_json($vault->uploadStatus($p,(string)($_GET['backup_id']??'')),200);}
    if($action==='vault-inventory'&&$method==='GET'){$p=$credentials->authenticate(sokna_maintenance_bearer(),'vault.recovery_read');sokna_maintenance_json($vault->inventory($p,(int)($_GET['limit']??50)),200);}
    if($action==='vault-download-begin'&&$method==='POST'){$p=$credentials->authenticate(sokna_maintenance_bearer(),'vault.recovery_read');$b=sokna_maintenance_body();sokna_maintenance_json($vault->beginDownload($p,(string)($b['backup_id']??'')),200);}
    if($action==='vault-download-status'&&$method==='GET'){$p=$credentials->authenticate(sokna_maintenance_bearer(),'vault.recovery_read');sokna_maintenance_json($vault->downloadStatus($p,(string)($_GET['backup_id']??''),(string)($_GET['download_session_id']??'')),200);}
    if($action==='vault-download-chunk'&&$method==='GET'){$p=$credentials->authenticate(sokna_maintenance_bearer(),'vault.recovery_read');$d=$vault->downloadChunkDescriptor($p,(string)($_GET['backup_id']??''),(string)($_GET['download_session_id']??''),(int)($_GET['offset']??-1),(int)($_GET['length']??0));sokna_maintenance_stream($d);}
    throw new MaintenanceException('not_found','Maintenance action not found.',404);
}catch(MaintenanceException $e){$body=['ok'=>false,'error'=>$e->errorCode];if($e->context!==[])$body['context']=$e->context;sokna_maintenance_json($body,$e->httpStatus);}catch(PublicUpdateException $e){sokna_maintenance_json(['ok'=>false,'error'=>$e->errorCode],$e->httpStatus);}catch(Throwable){sokna_maintenance_json(['ok'=>false,'error'=>'maintenance_unavailable'],500);}
