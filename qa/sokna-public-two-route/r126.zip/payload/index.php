<?php
declare(strict_types=1);

use Sokna\PublicEdge\Core\SafeErrors;
use Sokna\PublicEdge\Http\PublicHttpKernel;
use Sokna\PublicEdge\Http\PublicPath;
if (function_exists('header_remove')) header_remove('X-Powered-By');
require_once __DIR__ . '/src/Core/PublicSurfacePermissions.php';
\Sokna\PublicEdge\Core\PublicSurfacePermissions::repair(__DIR__);
require_once __DIR__ . '/src/Core/PublicFontRuntime.php';
\Sokna\PublicEdge\Core\PublicFontRuntime::ensure(__DIR__);

// Routine update v2 activation gate. Emergency remains a separate direct
// entrypoint and never depends on this front controller. During the two-phase
// activation window only health and signed update endpoints stay reachable;
// ordinary Guest/Staff/Setup traffic gets a short 503 until Local verifies the
// target runtime and commits (or rolls back) the activation.
$componentRoot = __DIR__;
$configPath = trim((string)(getenv('SOKNA_PUBLIC_CONFIG') ?: ($componentRoot . '/config.php')));
$__soknaRequestPath = (string)(parse_url((string)($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?: '/');
$__soknaStorage = $componentRoot . '/storage';
if (is_file($configPath) && is_readable($configPath)) {
    try { $__soknaCfg = require $configPath; if (is_array($__soknaCfg)) { $__candidate = trim((string)($__soknaCfg['app']['storage_dir'] ?? '')); if ($__candidate !== '') $__soknaStorage = $__candidate; } } catch (\Throwable) {}
}
$__soknaUpdateLock = rtrim($__soknaStorage, "\\/") . '/routine-update-v2/activation.lock';
$__soknaMaintenanceAllowed = preg_match('~(?:^|/)health/?$~D', $__soknaRequestPath) === 1 || str_contains($__soknaRequestPath, '/api/v1/local/update/');
if (is_file($__soknaUpdateLock) && !$__soknaMaintenanceAllowed) {
    http_response_code(503); header('Retry-After: 3'); header('Cache-Control: no-store'); header('X-Sokna-Update-Maintenance: routine-v2');
    $accept = strtolower((string)($_SERVER['HTTP_ACCEPT'] ?? ''));
    if (str_contains($accept,'application/json') || str_contains($__soknaRequestPath,'/api/')) { header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok'=>false,'error'=>'public_update_maintenance','message'=>'وب عمومی در حال اعمال به‌روزرسانی است.'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); }
    else { header('Content-Type: text/html; charset=utf-8'); echo '<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>به‌روزرسانی سکنا</title><body style="font-family:system-ui,sans-serif;padding:40px;max-width:640px;margin:auto"><h1>به‌روزرسانی وب عمومی</h1><p>نسخه جدید در حال بررسی است. چند لحظه دیگر دوباره تلاش کنید.</p></body></html>'; }
    exit;
}

// Shared-hosting guard: route the exact Setup surface from REQUEST_URI.
// Do not derive this decision from SCRIPT_NAME: on LiteSpeed/cPanel an
// inherited rewrite may preserve the original SCRIPT_NAME or replace it with
// the front controller path. REQUEST_URI is the stable contract we need.
$__soknaSetupSuffix = null;
if (preg_match('~(?:^|/)setup(?:(/index\\.php|/api\\.php|/setup\\.css|/setup\\.js)|/)?$~D', $__soknaRequestPath, $__soknaSetupMatch) === 1) {
    $__soknaSetupSuffix = (string)($__soknaSetupMatch[1] ?? '');
    if ($__soknaSetupSuffix === '' || $__soknaSetupSuffix === '/index.php') { require __DIR__ . '/setup/index.php'; exit; }
    if ($__soknaSetupSuffix === '/api.php') { require __DIR__ . '/setup/api.php'; exit; }
    if ($__soknaSetupSuffix === '/setup.css' || $__soknaSetupSuffix === '/setup.js') {
        $__soknaSetupFile = __DIR__ . '/setup' . $__soknaSetupSuffix;
        if (!is_file($__soknaSetupFile)) { http_response_code(404); exit; }
        header('Content-Type: ' . (str_ends_with($__soknaSetupFile, '.css') ? 'text/css; charset=utf-8' : 'text/javascript; charset=utf-8'));
        header('Cache-Control: no-store'); readfile($__soknaSetupFile); exit;
    }
}

// The ZIP is extracted directly into the externally visible Public Edge folder.
// Example: public_html/public/index.php => external base path /public.
if (str_ends_with(rtrim($__soknaRequestPath, '/'), '/__sokna_route_probe__')) { http_response_code(204); header('Cache-Control: no-store'); header('X-Sokna-Route-Probe: ok'); exit; }
unset($__soknaRequestPath,$__soknaStorage,$__soknaCfg,$__candidate,$__soknaUpdateLock,$__soknaMaintenanceAllowed,$__soknaSetupSuffix,$__soknaSetupMatch,$__soknaSetupFile);

require_once $componentRoot . '/bootstrap.php';

try {
    $lockPath=$componentRoot . '/install.lock';
    if (!is_file($configPath) || !is_readable($configPath) || !is_file($lockPath)) {
        $accept=strtolower((string)($_SERVER['HTTP_ACCEPT']??''));
        $method=strtoupper((string)($_SERVER['REQUEST_METHOD']??'GET'));
        $base=defined('SOKNA_PUBLIC_BASE_PATH')?PublicPath::normalizeBasePath((string)SOKNA_PUBLIC_BASE_PATH):PublicPath::fromScriptName((string)($_SERVER['SCRIPT_NAME']??''));
        if($method==='GET' && str_contains($accept,'text/html')){header('Location: '.PublicPath::prefix($base,'/setup/'));exit;}
        $result = SafeErrors::response(503, 'public_not_configured');
    } else {
        $config = require $configPath;
        if (!is_array($config)) throw new RuntimeException('Public config must return an array.');
        $core = sokna_public_bootstrap($config);
        $headers = function_exists('getallheaders') ? (array)getallheaders() : [];
        // Old bindings remain a read-only launcher during the explicit grace window.
        // Host is consulted only to match a persisted old binding; it never becomes
        // configuration authority. Machine endpoints are unaffected because the
        // launcher accepts only ordinary HTML GET requests.
        $transition = $core->deploymentRebind()->browserTransitionResponse(
            (string)($_SERVER['REQUEST_METHOD'] ?? 'GET'),
            (string)($_SERVER['REQUEST_URI'] ?? '/'),
            (string)($_SERVER['HTTP_HOST'] ?? ''),
            (string)($_SERVER['HTTP_ACCEPT'] ?? '')
        );
        if (is_array($transition)) {
            $result = $transition;
        } else {
        $kernel = new PublicHttpKernel($core, $componentRoot);
        $result = $kernel->handle(
            (string)($_SERVER['REQUEST_METHOD'] ?? 'GET'),
            (string)($_SERVER['REQUEST_URI'] ?? '/'),
            $_GET,
            (string)file_get_contents('php://input'),
            $headers,
        );
        }
    }
} catch (\Throwable $error) {
    $result = SafeErrors::fromThrowable($error);
}

http_response_code((int)($result['status'] ?? 500));
foreach ((array)($result['headers'] ?? []) as $name => $value) {
    if (!headers_sent()) header((string)$name . ': ' . (string)$value, true);
}
if (isset($result['file_path']) && is_string($result['file_path'])) {
    readfile($result['file_path']);
} else {
    if (!isset($result['headers']['Content-Type']) && !headers_sent()) header('Content-Type: application/json; charset=utf-8');
    $body = $result['body'] ?? '';
    if (is_array($body) || is_object($body)) {
        echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    } else {
        echo (string)$body;
    }
}
