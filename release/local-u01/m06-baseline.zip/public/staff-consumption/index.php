<?php
declare(strict_types=1);
use Sokna\Local\UI\LocalPage;
use Sokna\Local\UI\ProductShell;
use Sokna\Local\UI\WebAction;
$core=require dirname(__DIR__).'/_app.php';
$user=LocalPage::requireAny($core,['staff_consumption_self','staff_consumption_proxy','staff_benefit_manage','staff_account_manage','staff_consumption_reports']);
$csrf=WebAction::csrfToken();
$has=static fn(string $cap):bool=>$core->auth()->hasCapability($cap,$user);
$canSelf=$has('staff_consumption_self');$canProxy=$has('staff_consumption_proxy');$canBenefit=$has('staff_benefit_manage');$canAccount=$has('staff_account_manage');$canReport=$has('staff_consumption_reports');
ProductShell::start($core,$user,'پرسنل','staff-consumption','مصرف روزانه، مزایا، حساب و گزارش‌های پرسنل را در فضاهای کاری جدا مدیریت کن.',true);
?>
<section class="sc-workspace" data-staff-consumption-workspace data-api="staff-consumption/api.php" data-csrf="<?=htmlspecialchars($csrf,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8')?>">
  <div class="sc-toolbar sc-local-nav">
    <div class="sc-tabs" role="tablist" aria-label="حوزه پرسنل" data-dynamic-tabs="1">
      <?php $first=true; ?>
      <?php if($canSelf||$canProxy||$canReport): ?><button class="sc-tab" type="button" role="tab" aria-selected="<?=$first?'true':'false'?>" data-tab="daily">مصرف روزانه</button><?php $first=false; endif; ?>
      <?php if($canBenefit): ?><button class="sc-tab" type="button" role="tab" aria-selected="<?=$first?'true':'false'?>" data-tab="management">مزایا و سیاست‌ها</button><?php $first=false; endif; ?>
      <?php if($canAccount): ?><button class="sc-tab" type="button" role="tab" aria-selected="<?=$first?'true':'false'?>" data-tab="accounts">حساب پرسنل</button><?php $first=false; endif; ?>
      <?php if($canReport): ?><button class="sc-tab" type="button" role="tab" aria-selected="<?=$first?'true':'false'?>" data-tab="reports">گزارش‌ها</button><?php endif; ?>
    </div>
    <button class="sc-button sc-button--secondary" type="button" data-refresh hidden>تازه‌سازی</button>
  </div>
  <div class="sc-alert sc-alert--warning" data-module-notice hidden>مصرف پرسنل غیرفعال است. ثبت مصرف تازه و تغییر مزایا متوقف شده؛ سوابق، حساب‌ها و گزارش‌های قبلی در دسترس‌اند.</div>
  <div class="sc-alert" role="status" aria-live="polite" data-status hidden></div>

  <?php if($canSelf||$canProxy||$canReport): ?>
  <section class="sc-work-panel sc-staff-daily-panel" data-panel="daily" data-tab-scope>
    <div class="sc-segmented sc-staff-daily-nav" role="tablist" aria-label="مصرف روزانه">
      <?php $dailyFirst=true; ?>
      <?php if($canSelf): ?><button type="button" class="<?=$dailyFirst?'is-active':''?>" role="tab" aria-selected="<?=$dailyFirst?'true':'false'?>" data-tab="self">مصرف من</button><?php $dailyFirst=false; endif; ?>
      <?php if($canProxy): ?><button type="button" class="<?=$dailyFirst?'is-active':''?>" role="tab" aria-selected="<?=$dailyFirst?'true':'false'?>" data-tab="proxy">ثبت برای پرسنل</button><?php $dailyFirst=false; endif; ?>
      <?php if($canSelf||$canReport): ?><button type="button" class="<?=$dailyFirst?'is-active':''?>" role="tab" aria-selected="<?=$dailyFirst?'true':'false'?>" data-tab="history">سوابق مصرف</button><?php endif; ?>
    </div>
  <?php if($canSelf): ?>
  <section class="sc-work-panel" data-panel="self" data-consume-panel data-mode="self">
    <div class="sc-section-head"><div><h2>مصرف من</h2><p data-consumer-caption>هویت پرسنلی متصل به حساب شما در حال بررسی است.</p></div><span class="sc-badge" data-quote-state>بدون محاسبه</span></div>
    <div class="sc-workbench">
      <section class="sc-card sc-consumption-picker-card"><div class="sc-card__body sc-consumption-picker" data-consume-picker></div></section>
      <aside class="sc-card sc-cart"><div class="sc-card__head"><h2>سبد مصرف</h2></div><div class="sc-card__body sc-stack"><div data-cart></div><label class="sc-field"><span class="sc-field__label">یادداشت</span><textarea class="sc-control" rows="2" maxlength="500" data-note></textarea></label><?php if($canBenefit): ?><?php include __DIR__.'/runtime-override-fields.php'; ?><?php endif; ?><div class="sc-money-row"><span>ارزش منویی</span><strong data-menu-total>۰ تومان</strong></div><div class="sc-stack" data-quote></div></div><div class="sc-card__foot sc-actions"><button class="sc-button sc-button--secondary" type="button" data-quote-button>محاسبه مزایا</button><button class="sc-button" type="button" data-post-button>ثبت مصرف</button></div></aside>
    </div>
  </section>
  <?php endif; ?>

  <?php if($canProxy): ?>
  <section class="sc-work-panel" data-panel="proxy" data-consume-panel data-mode="proxy" <?=$canSelf?'hidden':''?>>
    <div class="sc-section-head"><div><h2>ثبت برای پرسنل</h2><p>مصرف‌کننده واقعی را انتخاب کنید؛ ثبت‌کننده از حساب واردشده ثبت می‌شود.</p></div><span class="sc-badge" data-quote-state>بدون محاسبه</span></div>
    <div class="sc-toolbar"><label class="sc-field sc-toolbar__field"><span class="sc-field__label">مصرف‌کننده</span><select class="sc-control" data-personnel-select><option value="">انتخاب پرسنل</option></select></label></div>
    <div class="sc-workbench">
      <section class="sc-card sc-consumption-picker-card"><div class="sc-card__body sc-consumption-picker" data-consume-picker></div></section>
      <aside class="sc-card sc-cart"><div class="sc-card__head"><h2>سبد مصرف</h2></div><div class="sc-card__body sc-stack"><div data-cart></div><label class="sc-field"><span class="sc-field__label">یادداشت</span><textarea class="sc-control" rows="2" maxlength="500" data-note></textarea></label><?php if($canBenefit): ?><?php include __DIR__.'/runtime-override-fields.php'; ?><?php endif; ?><div class="sc-money-row"><span>ارزش منویی</span><strong data-menu-total>۰ تومان</strong></div><div class="sc-stack" data-quote></div></div><div class="sc-card__foot sc-actions"><button class="sc-button sc-button--secondary" type="button" data-quote-button>محاسبه مزایا</button><button class="sc-button" type="button" data-post-button>ثبت مصرف</button></div></aside>
    </div>
  </section>
  <?php endif; ?>

  <?php if($canSelf||$canReport): ?>
  <section class="sc-work-panel sc-data-panel sc-staff-history-panel" data-panel="history" <?=($canSelf||$canProxy)?'hidden':''?>>
    <div class="sc-section-head"><div><h2>سوابق مصرف</h2><p>مصرف‌کننده و ثبت‌کننده همیشه جدا نمایش داده می‌شوند.</p></div></div>
    <?php if($canReport): ?><div class="sc-toolbar"><label class="sc-field sc-toolbar__field"><span class="sc-field__label">پرسنل</span><select class="sc-control" data-history-personnel><option value="0">همه پرسنل</option></select></label><button class="sc-button sc-button--secondary" type="button" data-history-load>نمایش</button></div><?php endif; ?>
    <div class="sc-table-wrap"><table class="sc-table sc-table--responsive"><thead><tr><th>سند</th><th>مصرف‌کننده</th><th>ثبت‌کننده</th><th>اقلام</th><th>ارزش منویی</th><th>مزیت</th><th>قابل پرداخت</th><th>هزینه شناخته‌شده</th><th>تاریخ</th></tr></thead><tbody data-history></tbody></table></div>
  </section>
  <?php endif; ?>

  </section>
  <?php endif; ?>

  <?php if($canBenefit): ?>
  <section class="sc-work-panel sc-staff-benefits-panel" data-panel="management" hidden>
    <div class="sc-section-head"><div><h2>مدیریت مزایا</h2><p>قوانین مزایا را تعریف کن، به پرسنل اختصاص بده و برای افراد یا اقلام خاص استثنا تعیین کن. تغییرات جدید روی سوابق قبلی اثر نمی‌گذارند.</p></div></div>
    <div class="sc-segmented sc-staff-benefit-tabs" role="tablist" aria-label="بخش‌های مزایا"><button type="button" class="is-active" role="tab" aria-selected="true" data-benefit-tab="policy">طرح‌ها</button><button type="button" role="tab" aria-selected="false" data-benefit-tab="rule">قوانین</button><button type="button" role="tab" aria-selected="false" data-benefit-tab="profile">اختصاص‌ها</button><button type="button" role="tab" aria-selected="false" data-benefit-tab="override">استثناها</button></div>
    <div class="sc-staff-benefit-workbench" data-benefit-workbench>
      <div class="sc-stack sc-staff-benefit-lists">
        <div class="sc-data-panel" data-benefit-view="policy"><div class="sc-section-head"><div><h3>طرح‌های مزایا</h3><p>طرح‌های پایه و ترتیب اعمال آن‌ها.</p></div><button class="sc-button" type="button" data-benefit-new="policy">طرح جدید</button></div><div class="sc-table-wrap"><table class="sc-table sc-table--responsive"><thead><tr><th>طرح</th><th>ترتیب اعمال</th><th>پیش‌فرض</th><th>تعداد قوانین</th><th><span class="sc-visually-hidden">عملیات</span></th></tr></thead><tbody data-policy-list></tbody></table></div></div>
        <div class="sc-data-panel" data-benefit-view="rule" hidden><div class="sc-section-head"><div><h3>قوانین مزایا</h3><p>مزیت هر محدوده و اولویت اعمال.</p></div><button class="sc-button" type="button" data-benefit-new="rule">قانون جدید</button></div><div class="sc-table-wrap"><table class="sc-table sc-table--responsive"><thead><tr><th>قانون</th><th>طرح</th><th>محدوده</th><th>نوع مزیت</th><th>مقدار</th><th><span class="sc-visually-hidden">عملیات</span></th></tr></thead><tbody data-rule-list></tbody></table></div></div>
        <div class="sc-data-panel" data-benefit-view="profile" hidden><div class="sc-section-head"><div><h3>اختصاص طرح</h3><p>طرح فعال هر پرسنل و بازه اعتبار.</p></div><button class="sc-button" type="button" data-benefit-new="profile">اختصاص جدید</button></div><div class="sc-table-wrap"><table class="sc-table sc-table--responsive"><thead><tr><th>پرسنل</th><th>طرح مزایا</th><th>بازه</th><th>وضعیت</th></tr></thead><tbody data-profile-list></tbody></table></div></div>
        <div class="sc-data-panel" data-benefit-view="override" hidden><div class="sc-section-head"><div><h3>استثناهای شخصی</h3><p>استثناهای محدود و قابل ردیابی.</p></div><button class="sc-button" type="button" data-benefit-new="override">استثنای جدید</button></div><div class="sc-table-wrap"><table class="sc-table sc-table--responsive"><thead><tr><th>پرسنل</th><th>محدوده</th><th>نوع</th><th>بازه</th><th>دلیل</th><th><span class="sc-visually-hidden">عملیات</span></th></tr></thead><tbody data-override-list></tbody></table></div></div>
      </div>
      <aside class="sc-staff-benefit-editor-shell" data-benefit-editor-shell hidden>
      <form class="sc-card sc-card__body sc-form" data-policy-form data-benefit-editor="policy" hidden><h3>طرح مزایا</h3><input type="hidden" name="id"><input type="hidden" name="policy_key"><label class="sc-field"><span class="sc-field__label">نام</span><input class="sc-control" name="name" required></label><label class="sc-field"><span class="sc-field__label">توضیح</span><textarea class="sc-control" name="description"></textarea></label><label class="sc-field"><span class="sc-field__label">ترتیب اعمال</span><input class="sc-control" name="priority" type="text" inputmode="numeric" value="۱۰۰"></label><label class="sc-check"><input type="checkbox" name="is_default"> طرح پیش‌فرض</label><label class="sc-check"><input type="checkbox" name="active" checked> فعال</label><div class="sc-actions"><button class="sc-button" type="submit">ذخیره طرح</button><button class="sc-button sc-button--secondary" type="button" data-benefit-editor-cancel>انصراف</button></div></form>
      <form class="sc-card sc-card__body sc-form" data-rule-form data-benefit-editor="rule" hidden><h3>قانون مزایا</h3><input type="hidden" name="id"><label class="sc-field"><span class="sc-field__label">طرح مزایا</span><select class="sc-control" name="policy_id" required></select></label><label class="sc-field"><span class="sc-field__label">محدوده</span><select class="sc-control" name="scope_type"><option value="all">همه اقلام</option><option value="category">دسته</option><option value="item">آیتم</option></select></label><label class="sc-field"><span class="sc-field__label">هدف</span><select class="sc-control" name="scope_id"></select></label><label class="sc-field"><span class="sc-field__label">نوع مزیت</span><select class="sc-control" name="benefit_type"><option value="none">بدون مزیت</option><option value="free">رایگان</option><option value="percent">درصدی</option><option value="fixed">مبلغ ثابت</option></select></label><label class="sc-field"><span class="sc-field__label">درصد</span><input class="sc-control" name="percent" type="text" inputmode="decimal"></label><label class="sc-field"><span class="sc-field__label">مبلغ ثابت برای هر واحد</span><input class="sc-control" name="fixed_amount" type="text" inputmode="numeric" data-money-input="1"></label><label class="sc-field"><span class="sc-field__label">ترتیب اعمال</span><input class="sc-control" name="priority" type="text" inputmode="numeric" value="۱۰۰"></label><label class="sc-check"><input type="checkbox" name="active" checked> فعال</label><div class="sc-actions"><button class="sc-button" type="submit">ذخیره قانون</button><button class="sc-button sc-button--secondary" type="button" data-benefit-editor-cancel>انصراف</button></div></form>
      <form class="sc-card sc-card__body sc-form" data-profile-form data-benefit-editor="profile" hidden><h3>اختصاص طرح به پرسنل</h3><label class="sc-field"><span class="sc-field__label">پرسنل</span><select class="sc-control" name="personnel_id" required></select></label><label class="sc-field"><span class="sc-field__label">طرح مزایا</span><select class="sc-control" name="policy_id"><option value="0">بدون مزیت</option></select></label><label class="sc-field"><span class="sc-field__label">از تاریخ</span><input class="sc-control" type="date" name="valid_from"></label><label class="sc-field"><span class="sc-field__label">تا تاریخ</span><input class="sc-control" type="date" name="valid_until"></label><label class="sc-field"><span class="sc-field__label">یادداشت</span><textarea class="sc-control" name="notes"></textarea></label><label class="sc-check"><input type="checkbox" name="active" checked> فعال</label><div class="sc-actions"><button class="sc-button" type="submit">ذخیره اختصاص</button><button class="sc-button sc-button--secondary" type="button" data-benefit-editor-cancel>انصراف</button></div></form>
      <form class="sc-card sc-card__body sc-form" data-override-form data-benefit-editor="override" hidden><h3>استثنای شخصی</h3><input type="hidden" name="id"><label class="sc-field"><span class="sc-field__label">پرسنل</span><select class="sc-control" name="personnel_id" required></select></label><label class="sc-field"><span class="sc-field__label">محدوده</span><select class="sc-control" name="scope_type"><option value="all">همه اقلام</option><option value="category">دسته</option><option value="item">آیتم</option></select></label><label class="sc-field"><span class="sc-field__label">هدف</span><select class="sc-control" name="scope_id"></select></label><label class="sc-field"><span class="sc-field__label">نوع مزیت</span><select class="sc-control" name="benefit_type"><option value="none">بدون مزیت</option><option value="free">رایگان</option><option value="percent">درصدی</option><option value="fixed">مبلغ ثابت</option></select></label><label class="sc-field"><span class="sc-field__label">درصد</span><input class="sc-control" name="percent" type="text" inputmode="decimal"></label><label class="sc-field"><span class="sc-field__label">مبلغ ثابت برای هر واحد</span><input class="sc-control" name="fixed_amount" type="text" inputmode="numeric" data-money-input="1"></label><label class="sc-field"><span class="sc-field__label">از زمان</span><input class="sc-control" type="datetime-local" name="valid_from"></label><label class="sc-field"><span class="sc-field__label">تا زمان</span><input class="sc-control" type="datetime-local" name="valid_until"></label><label class="sc-field"><span class="sc-field__label">دلیل</span><textarea class="sc-control" name="reason" required></textarea></label><label class="sc-check"><input type="checkbox" name="active" checked> فعال</label><div class="sc-actions"><button class="sc-button" type="submit">ذخیره استثنا</button><button class="sc-button sc-button--secondary" type="button" data-benefit-editor-cancel>انصراف</button></div></form>
      </aside>
    </div>
  </section>
  <?php endif; ?>

  <?php if($canAccount): ?>
  <section class="sc-work-panel sc-staff-account-panel" data-panel="accounts" hidden>
    <div class="sc-section-head"><div><h2>حساب پرسنل</h2><p>مانده هر نفر شامل مصرف‌های قابل پرداخت، پرداخت‌ها، بخشودگی‌ها و برگشت اسناد است.</p></div></div>
    <div class="sc-toolbar sc-staff-account-selector"><label class="sc-field sc-toolbar__field"><span class="sc-field__label">پرسنل</span><select class="sc-control" data-account-personnel><option value="">انتخاب پرسنل</option></select></label><button class="sc-button" type="button" data-account-load>نمایش حساب</button></div>
    <div class="sc-empty sc-staff-account-empty" data-account-empty><strong>یک نفر را انتخاب کنید</strong><small>بعد از انتخاب، مانده، گردش حساب و عملیات مالی همان پرسنل نمایش داده می‌شود.</small></div>
    <div class="sc-staff-account-detail" data-account-detail hidden>
      <div class="sc-staff-account-summary"><article class="sc-card sc-metric"><span>پرسنل</span><strong data-account-person-name>—</strong><small>حساب انتخاب‌شده</small></article><article class="sc-card sc-metric"><span>مانده</span><strong data-account-balance>—</strong><small>بدهی جاری پرسنل</small></article></div>
      <div class="sc-staff-account-layout">
        <main class="sc-table-wrap"><table class="sc-table sc-table--responsive"><thead><tr><th>نوع</th><th>تغییر</th><th>مانده</th><th>مرجع/دلیل</th><th>ثبت‌کننده</th><th>زمان</th><th><span class="sc-visually-hidden">عملیات</span></th></tr></thead><tbody data-account-history></tbody></table></main>
        <aside class="sc-staff-account-actions">
          <details class="sc-card"><summary>ثبت پرداخت</summary><form class="sc-card__body sc-form" data-payment-form><label class="sc-field"><span class="sc-field__label">مبلغ</span><input class="sc-control" type="text" inputmode="numeric" data-money-input="1" name="amount" required></label><label class="sc-field"><span class="sc-field__label">روش</span><select class="sc-control" name="payment_method"><option value="cash">نقد</option><option value="card">کارت</option><option value="bank">بانک</option><option value="payroll">حقوق</option><option value="other">سایر</option></select></label><label class="sc-field"><span class="sc-field__label">مرجع</span><input class="sc-control" name="reference" maxlength="120"></label><label class="sc-field"><span class="sc-field__label">توضیح</span><textarea class="sc-control" name="reason"></textarea></label><button class="sc-button" type="submit">ثبت پرداخت</button></form></details>
          <details class="sc-card"><summary>بخشودگی</summary><form class="sc-card__body sc-form" data-waiver-form><label class="sc-field"><span class="sc-field__label">مبلغ</span><input class="sc-control" type="text" inputmode="numeric" data-money-input="1" name="amount" required></label><label class="sc-field"><span class="sc-field__label">دلیل</span><textarea class="sc-control" name="reason" required></textarea></label><label class="sc-field"><span class="sc-field__label">مرجع</span><input class="sc-control" name="reference" maxlength="120"></label><button class="sc-button" type="submit">ثبت بخشودگی</button></form></details>
        </aside>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <?php if($canReport): ?>
  <section class="sc-work-panel sc-staff-report-panel" data-panel="reports" hidden>
    <div class="sc-section-head"><div><h2>گزارش مصرف پرسنل</h2><p>گزارش مصرف، مزایا، مبالغ قابل پرداخت و هزینه ثبت‌شده را در بازه دلخواه بررسی کن.</p></div></div>
    <div class="sc-toolbar"><label class="sc-field"><span class="sc-field__label">از</span><input class="sc-control" type="date" data-report-from></label><label class="sc-field"><span class="sc-field__label">تا</span><input class="sc-control" type="date" data-report-to></label><label class="sc-field sc-toolbar__field"><span class="sc-field__label">پرسنل</span><select class="sc-control" data-report-personnel><option value="0">همه پرسنل</option></select></label><button class="sc-button" type="button" data-report-load>گزارش</button></div>
    <div class="sc-summary-grid"><article class="sc-card sc-metric"><span>ارزش منویی</span><strong data-report-metric="menu">—</strong><small>قبل از مزیت</small></article><article class="sc-card sc-metric"><span>مزیت</span><strong data-report-metric="benefit">—</strong><small>مجموع تخفیف و مزایای اعمال‌شده</small></article><article class="sc-card sc-metric"><span>قابل پرداخت</span><strong data-report-metric="payable">—</strong><small>بدهی ایجادشده</small></article><article class="sc-card sc-metric"><span>بخشودگی خالص</span><strong data-report-metric="waiver">—</strong><small>بخشودگی ثبت‌شده روی حساب‌ها</small></article><article class="sc-card sc-metric"><span>هزینه شناخته‌شده</span><strong data-report-metric="cost">—</strong><small>هزینه ثبت‌شده هنگام مصرف</small></article></div>
    <div class="sc-grid"><section class="sc-card"><div class="sc-card__head"><h3>به تفکیک مصرف‌کننده</h3></div><div class="sc-table-wrap"><table class="sc-table sc-table--responsive"><thead><tr><th>پرسنل</th><th>سند</th><th>ارزش</th><th>مزیت</th><th>قابل پرداخت</th><th>هزینه</th></tr></thead><tbody data-report-consumers></tbody></table></div></section><section class="sc-card"><div class="sc-card__head"><h3>به تفکیک ثبت‌کننده</h3></div><div class="sc-table-wrap"><table class="sc-table sc-table--responsive"><thead><tr><th>ثبت‌کننده</th><th>سند</th><th>ارزش</th><th>مزیت</th><th>قابل پرداخت</th></tr></thead><tbody data-report-recorders></tbody></table></div></section></div>
    <div class="sc-table-wrap"><table class="sc-table sc-table--responsive"><thead><tr><th>سند</th><th>مصرف‌کننده</th><th>ثبت‌کننده</th><th>اقلام</th><th>ارزش</th><th>مزیت</th><th>قابل پرداخت</th><th>هزینه</th><th>تاریخ</th></tr></thead><tbody data-report-rows></tbody></table></div>
  </section>
  <?php endif; ?>
</section>
<script src="<?=ProductShell::asset('assets/staff-consumption-workspace.js')?>" defer></script>
<?php ProductShell::end(); ?>
