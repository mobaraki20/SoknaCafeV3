<?php
declare(strict_types=1);

use Sokna\Local\UI\WebAction;

$core=require dirname(__DIR__).'/_app.php';
$user=$core->auth()->currentUser();
if($user===null)WebAction::json(['success'=>false,'code'=>'unauthenticated','message'=>'نشست شما پایان یافته؛ دوباره وارد شوید.'],401);
if(($_SERVER['REQUEST_METHOD']??'GET')!=='GET')WebAction::json(['success'=>false,'code'=>'method_not_allowed','message'=>'روش درخواست معتبر نیست.'],405);
try{
    $query=(string)($_GET['q']??'');
    WebAction::json(['success'=>true,'search'=>$core->globalSearch()->search($query,$user,18)]);
}catch(\Throwable $e){
    WebAction::unexpected($core,$e,'global_search.web_action_failed','جست‌وجو در حال حاضر انجام نشد.');
}
