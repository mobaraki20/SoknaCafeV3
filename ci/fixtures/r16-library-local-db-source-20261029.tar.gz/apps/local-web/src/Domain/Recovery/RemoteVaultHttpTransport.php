<?php
declare(strict_types=1);
namespace Sokna\Local\Domain\Recovery;

/**
 * Public 35FH /maintenance.php Vault wire adapter. Construction is strictly
 * service-owned: credential is never provided by a browser or placed in URL.
 */
final class RemoteVaultHttpTransport implements RemoteVaultUploadTransport
{
    public function __construct(private readonly string $endpoint,private readonly string $bearer,private readonly int $timeoutSeconds=30)
    {
        $url=parse_url($endpoint);
        if(!is_array($url)||strtolower((string)($url['scheme']??''))!=='https'
            ||!isset($url['host'])||isset($url['user'])||isset($url['pass'])||isset($url['query'])||isset($url['fragment'])
            ||!str_ends_with((string)($url['path']??''),'/maintenance.php')
            ||preg_match('/[\r\n]/',$endpoint))
            throw new RecoveryException('vault_endpoint_invalid','آدرس Remote Vault باید HTTPS و به maintenance.php محدود باشد.',422);
        if(!preg_match('/^vlt_[a-f0-9]{24}\.[A-Za-z0-9_-]{32,96}$/D',$bearer))
            throw new RecoveryException('vault_credential_invalid','اعتبارنامه Remote Vault معتبر نیست.',422);
        if($timeoutSeconds<3||$timeoutSeconds>120)throw new RecoveryException('vault_timeout_invalid','مهلت ارتباط معتبر نیست.',422);
    }

    public function begin(array $metadata): array{return $this->request('POST','vault-upload-begin',[],json_encode($metadata,JSON_THROW_ON_ERROR),['Content-Type: application/json']);}
    public function status(string $backupId): array{return $this->request('GET','vault-upload-status',['backup_id'=>$backupId]);}
    public function append(string $backupId,string $session,int $offset,string $chunk): array
    {return $this->request('PUT','vault-upload-chunk',['backup_id'=>$backupId],$chunk,[
        'Content-Type: application/octet-stream',
        'X-Sokna-Upload-Session: '.$session,
        'X-Sokna-Chunk-Offset: '.$offset,
        'X-Sokna-Chunk-Sha256: '.hash('sha256',$chunk),
    ]);}
    public function finalize(string $backupId,string $session): array
    {return $this->request('POST','vault-upload-finalize',[],json_encode(['backup_id'=>$backupId,'upload_session_id'=>$session],JSON_THROW_ON_ERROR),['Content-Type: application/json']);}

    private function request(string $method,string $action,array $query=[],string $body='',array $extra=[]): array
    {
        $params=array_merge(['action'=>$action],$query);
        $url=$this->endpoint.'?'.http_build_query($params,'','&',PHP_QUERY_RFC3986);
        $headers=array_merge(['Authorization: Bearer '.$this->bearer,'Accept: application/json','Connection: close','Content-Length: '.strlen($body)],$extra);
        $ctx=stream_context_create(['http'=>[
            'method'=>$method,'header'=>implode("\r\n",$headers),'content'=>$body,
            'timeout'=>$this->timeoutSeconds,'follow_location'=>0,'max_redirects'=>0,'ignore_errors'=>true,
        ],'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true,'allow_self_signed'=>false]]);
        $answer=@file_get_contents($url,false,$ctx);
        // No redirect follow (including HTTPS->HTTP); never expose the bearer in error messages.
        $responseHeaders=$http_response_header??[];
        $status=0;
        if(isset($responseHeaders[0])&&preg_match('/^HTTP\/\S+\s+(\d{3})\b/',(string)$responseHeaders[0],$m))$status=(int)$m[1];
        if($status===0||!is_string($answer))throw new RecoveryException('vault_transport_unknown','ارتباط Remote Vault نامعلوم است؛ وضعیت از سرور دوباره خوانده شود.',503);
        if(strlen($answer)>1048576)throw new RecoveryException('vault_response_too_large','پاسخ Remote Vault بیش از حد مجاز است.',502);
        try{$data=json_decode($answer,true,32,JSON_THROW_ON_ERROR);}catch(\JsonException){throw new RecoveryException('vault_response_invalid','پاسخ سرور معتبر نیست.',502);}
        if(!is_array($data))throw new RecoveryException('vault_response_invalid','پاسخ سرور معتبر نیست.',502);
        if($status===404&&$action==='vault-upload-status'&&($data['error']??'')==='vault_upload_not_found')
            throw new RemoteVaultUploadNotFound('Verified 404 for unknown backup');
        if($status<200||$status>=300||($data['ok']??false)!==true)
            throw new RecoveryException('vault_remote_rejected','سرور بکاپ درخواست را نپذیرفت.',in_array($status,[401,403,409,410,413,422,429,507],true)?409:503,
                ['server_status'=>$status,'server_code'=>substr((string)($data['error']??'unavailable'),0,100)]);
        return $data;
    }
}
