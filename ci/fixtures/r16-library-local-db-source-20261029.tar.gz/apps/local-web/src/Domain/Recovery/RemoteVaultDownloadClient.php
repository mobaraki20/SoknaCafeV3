<?php
declare(strict_types=1);
namespace Sokna\Local\Domain\Recovery;

/** Existing Public vault-download-begin / vault-download-chunk protocol. */
interface RemoteVaultDownloadTransport
{
    public function begin(string $backupId): array;
    /** @return array{status:int,body:string,content_range:string,backup_id:string,artifact_sha256:string,remote_receipt_id:string} */
    public function chunk(string $backupId,string $session,int $offset,int $length): array;
}

/**
 * Downloads one already-encrypted backup, verifies Public's independently issued
 * receipt and the full SHA256, and atomically makes it available for the EXISTING
 * empty-target recovery flow. It never imports data or touches an active DB.
 */
final class RemoteVaultDownloadClient
{
    public function __construct(private readonly string $destinationDir) {}

    public function download(string $backupId,RemoteVaultDownloadTransport $remote,int $chunkSize=1048576): array
    {
        if(!preg_match('/^business-[A-Za-z0-9._-]{8,100}$/D',$backupId))
            throw new RecoveryException('vault_download_id_invalid','شناسه بکاپ معتبر نیست.',422);
        if($chunkSize<4096||$chunkSize>4194304)
            throw new RecoveryException('vault_download_chunk_invalid','اندازه قطعه معتبر نیست.',422);
        $dir=rtrim($this->destinationDir,"/\\");
        if(!is_dir($dir)&&!@mkdir($dir,0700,true)&&!is_dir($dir))
            throw new RecoveryException('vault_download_storage_unavailable','پوشه بازیابی آماده نیست.',503);
        if(is_link($dir))throw new RecoveryException('vault_download_storage_unavailable','پوشه بازیابی نامعتبر است.',409);
        $lock=@fopen($dir.DIRECTORY_SEPARATOR.$backupId.'.download.lock','c+b');
        if(!$lock)throw new RecoveryException('vault_download_storage_unavailable','قفل بازیابی آماده نیست.',503);
        if(!flock($lock,LOCK_EX|LOCK_NB)){fclose($lock);throw new RecoveryException('vault_download_busy','دریافت این بکاپ در حال انجام است.',409);}
        $partial=null;
        try {
            $start=$remote->begin($backupId);
            if(($start['ok']??false)!==true||($start['state']??'')!=='DOWNLOAD_READY'||($start['backup_id']??'')!==$backupId)
                throw new RecoveryException('vault_download_begin_invalid','درخواست بازیابی تأیید نشد.',409);
            $session=(string)($start['download_session_id']??'');
            $size=$start['artifact_size']??null;
            $sha=(string)($start['artifact_sha256']??'');
            $receipt=(string)($start['remote_receipt_id']??'');
            if(!preg_match('/^dls_[a-f0-9]{32}$/D',$session)||!is_int($size)||$size<64||$size>8589934592
                ||!preg_match('/^[a-f0-9]{64}$/D',$sha)||!preg_match('/^rct_[a-f0-9]{40}$/D',$receipt))
                throw new RecoveryException('vault_download_receipt_invalid','رسید Remote Vault معتبر نیست.',409);
            $target=$dir.DIRECTORY_SEPARATOR.$backupId.'.skbf';
            if(file_exists($target)||is_link($target)) {
                if(is_link($target)||!is_file($target)||(int)filesize($target)!==$size||!hash_equals($sha,(string)hash_file('sha256',$target)))
                    throw new RecoveryException('vault_download_existing_conflict','فایل محلی با رسید Remote Vault متفاوت است؛ بازنویسی مجاز نیست.',409);
                return ['state'=>'REMOTE_RECOVERY_READY','backup_id'=>$backupId,'sha256'=>$sha,'size_bytes'=>$size,
                    'remote_receipt_id'=>$receipt,'path'=>$target,'already_present'=>true,'database_mutated'=>false];
            }
            $partial=$dir.DIRECTORY_SEPARATOR.$backupId.'.part.'.bin2hex(random_bytes(10));
            $out=@fopen($partial,'x+b');
            if(!$out)throw new RecoveryException('vault_download_storage_unavailable','ساخت فایل موقت ممکن نیست.',503);
            @chmod($partial,0600);
            $ctx=hash_init('sha256');$offset=0;
            try {
                while($offset<$size){
                    $need=min($chunkSize,$size-$offset);
                    $part=$remote->chunk($backupId,$session,$offset,$need);
                    $bytes=$part['body']??null;
                    if(($part['status']??0)!==206||!is_string($bytes)||strlen($bytes)!==$need
                        ||($part['content_range']??'')!==sprintf('bytes %d-%d/%d',$offset,$offset+$need-1,$size)
                        ||($part['backup_id']??'')!==$backupId
                        ||!hash_equals($sha,(string)($part['artifact_sha256']??''))
                        ||!hash_equals($receipt,(string)($part['remote_receipt_id']??'')))
                        throw new RecoveryException('vault_download_chunk_mismatch','قطعه دریافت‌شده با رسید سرور سازگار نیست.',409);
                    if($offset===0 && !str_starts_with($bytes,'SOKNA-SKB1' . "\n"))
                        throw new RecoveryException('vault_download_not_encrypted','فایل بازیابی رمزگذاری‌شده معتبر نیست.',409);
                    if(fwrite($out,$bytes)!==$need)
                        throw new RecoveryException('vault_download_write_failed','نوشتن فایل بازیابی کامل نشد.',503);
                    hash_update($ctx,$bytes);$offset+=$need;
                }
                fflush($out);if(function_exists('fsync'))@fsync($out);
            } finally { fclose($out); }
            $actual=hash_final($ctx);
            if(!hash_equals($sha,$actual)||(int)filesize($partial)!==$size)
                throw new RecoveryException('vault_download_hash_mismatch','هش بکاپ دریافت‌شده معتبر نیست.',409);
            if(file_exists($target)||is_link($target))
                throw new RecoveryException('vault_download_existing_conflict','در طول انتقال فایل مقصد ایجاد شد.',409);
            if(!@rename($partial,$target))
                throw new RecoveryException('vault_download_commit_failed','ثبت فایل کامل بازیابی انجام نشد.',503);
            $partial=null;
            return ['state'=>'REMOTE_RECOVERY_READY','backup_id'=>$backupId,'sha256'=>$sha,'size_bytes'=>$size,
                'remote_receipt_id'=>$receipt,'path'=>$target,'already_present'=>false,'database_mutated'=>false];
        } finally {
            if(is_string($partial)&&is_file($partial))@unlink($partial);
            flock($lock,LOCK_UN);fclose($lock);
        }
    }
}
