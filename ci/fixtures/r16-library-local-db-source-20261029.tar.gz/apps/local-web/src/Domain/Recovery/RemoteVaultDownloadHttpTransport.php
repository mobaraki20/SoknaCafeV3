<?php
declare(strict_types=1);
namespace Sokna\Local\Domain\Recovery;

/** Reuses Public 35FH's existing short-lived scoped vault.recovery_read API. */
final class RemoteVaultDownloadHttpTransport implements RemoteVaultDownloadTransport
{
    public function __construct(private readonly string $endpoint,private readonly string $bearer,private readonly int $timeoutSeconds=60)
    {
        $url=parse_url($endpoint);
        if(!is_array($url)||strtolower((string)($url['scheme']??''))!=='https'||!isset($url['host'])
            ||isset($url['user'])||isset($url['pass'])||isset($url['query'])||isset($url['fragment'])
            ||!str_ends_with((string)($url['path']??''),'/maintenance.php')||preg_match('/[\r\n]/',$endpoint))
            throw new RecoveryException('vault_endpoint_invalid','آدرس Vault معتبر نیست.',422);
        if(!preg_match('/^vlt_[a-f0-9]{24}\.[A-Za-z0-9_-]{32,96}$/D',$bearer)||$timeoutSeconds<5||$timeoutSeconds>180)
            throw new RecoveryException('vault_download_credential_invalid','اعتبار بازیابی Vault معتبر نیست.',422);
    }
    public function begin(string $backupId): array
    {
        $reply=$this->request('POST','vault-download-begin',[],json_encode(['backup_id'=>$backupId],JSON_THROW_ON_ERROR),true);
        return $reply['json'];
    }
    public function chunk(string $backupId,string $session,int $offset,int $length): array
    {
        $reply=$this->request('GET','vault-download-chunk',[
            'backup_id'=>$backupId,'download_session_id'=>$session,'offset'=>$offset,'length'=>$length], '', false);
        $h=$reply['headers'];
        return ['status'=>$reply['status'],'body'=>$reply['body'],'content_range'=>$h['content-range']??'',
            'backup_id'=>$h['x-sokna-backup-id']??'','artifact_sha256'=>$h['x-sokna-artifact-sha256']??'',
            'remote_receipt_id'=>$h['x-sokna-remote-receipt']??''];
    }
    private function request(string $method,string $action,array $args,string $body,bool $json): array
    {
        $url=$this->endpoint.'?'.http_build_query(['action'=>$action]+$args,'','&',PHP_QUERY_RFC3986);
        $headers=['Authorization: Bearer '.$this->bearer,'Accept: '.($json?'application/json':'application/octet-stream'),
            'Connection: close'];
        if($method==='POST'){$headers[]='Content-Type: application/json';$headers[]='Content-Length: '.strlen($body);}
        $options=['method'=>$method,'header'=>implode("\r\n",$headers),'timeout'=>$this->timeoutSeconds,
            'follow_location'=>0,'max_redirects'=>0,'ignore_errors'=>true];
        if($method==='POST')$options['content']=$body;
        $ctx=stream_context_create(['http'=>$options,'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true,'allow_self_signed'=>false]]);
        $answer=@file_get_contents($url,false,$ctx);
        $rawHeaders=$http_response_header??[];
        if(!is_string($answer))throw new RecoveryException('vault_download_transport_unknown','ارتباط بازیابی نامعلوم است.',503);
        $status=0;$parsed=[];
        foreach($rawHeaders as $line){
            if(preg_match('/^HTTP\/\S+\s+(\d{3})\b/',(string)$line,$m))$status=(int)$m[1];
            elseif(str_contains((string)$line,':')){[$name,$value]=explode(':',(string)$line,2);$parsed[strtolower(trim($name))]=trim($value);}
        }
        if($json){
            if($status!==200||strlen($answer)>262144)throw new RecoveryException('vault_download_remote_rejected','درخواست بازیابی پذیرفته نشد.',503);
            try{$decoded=json_decode($answer,true,32,JSON_THROW_ON_ERROR);}catch(\JsonException){throw new RecoveryException('vault_download_response_invalid','پاسخ سرور معتبر نیست.',502);}
            if(!is_array($decoded))throw new RecoveryException('vault_download_response_invalid','پاسخ سرور معتبر نیست.',502);
            return ['status'=>$status,'json'=>$decoded,'headers'=>$parsed,'body'=>''];
        }
        if($status!==206||strlen($answer)>4194304)throw new RecoveryException('vault_download_chunk_rejected','دریافت قطعه بازیابی معتبر نبود.',503);
        return ['status'=>$status,'body'=>$answer,'headers'=>$parsed];
    }
}
