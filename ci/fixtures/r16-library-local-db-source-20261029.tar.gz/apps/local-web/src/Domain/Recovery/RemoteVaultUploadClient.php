<?php
declare(strict_types=1);
namespace Sokna\Local\Domain\Recovery;

/** BK-2a: existing Public Remote Vault protocol, never a second storage engine. */
interface RemoteVaultUploadTransport
{
    public function begin(array $metadata): array;
    public function status(string $backupId): array;
    public function append(string $backupId,string $session,int $offset,string $chunk): array;
    public function finalize(string $backupId,string $session): array;
}

/**
 * Only encrypted SKB1 files already in the Local recovery directory are accepted.
 * Windows Maintenance must supply verified, host-owned source identity and release metadata.
 * Never re-encrypt or upload any plaintext / recovery key.
 */
final class RemoteVaultUploadClient
{
    public function __construct(private readonly string $businessBackupDirectory,private readonly string $ledgerDirectory) {}

    /** @throws RecoveryException */
    public function transfer(string $backupId,array $sourceMetadata,RemoteVaultUploadTransport $remote,int $chunkSize=1048576): array
    {
        if(!preg_match('/^business-[A-Za-z0-9._-]{8,100}$/D',$backupId))
            throw new RecoveryException('vault_backup_id_invalid','شناسه فایل پشتیبان معتبر نیست.',422);
        if($chunkSize<4096 || $chunkSize>4194304)
            throw new RecoveryException('vault_chunk_size_invalid','اندازه قطعه بکاپ معتبر نیست.',422);
        $path=rtrim($this->businessBackupDirectory,"/\\").DIRECTORY_SEPARATOR.$backupId.'.skbf';
        if(!is_file($path)||is_link($path)||!is_readable($path))
            throw new RecoveryException('vault_backup_missing','فایل بکاپ رمزگذاری‌شده در مسیر مجاز موجود نیست.',409);
        $h=@fopen($path,'rb');if($h===false)throw new RecoveryException('vault_backup_missing','باز کردن بکاپ ممکن نیست.',409);
        $dir=rtrim($this->ledgerDirectory,"/\\");
        if(!is_dir($dir)&&!@mkdir($dir,0700,true)&&!is_dir($dir))throw new RecoveryException('vault_ledger_unavailable','دفتر انتقال آماده نیست.',503);
        $lock=@fopen($dir.DIRECTORY_SEPARATOR.$backupId.'.lock','c+b');
        if(!$lock)throw new RecoveryException('vault_ledger_unavailable','قفل انتقال قابل ساخت نیست.',503);
        if(!flock($lock,LOCK_EX|LOCK_NB)){fclose($h);fclose($lock);throw new RecoveryException('vault_transfer_busy','انتقال همین بکاپ در حال انجام است.',409);}
        try{
            if(fread($h,11)!=="SOKNA-SKB1\n")throw new RecoveryException('vault_ciphertext_required','فقط نسخه پشتیبان رمزگذاری‌شده قابل انتقال است.',422);
            $stat=fstat($h);$size=(int)($stat['size']??0);
            if($size<64)throw new RecoveryException('vault_backup_invalid','بکاپ کامل نیست.',422);
            rewind($h);$sha=hash_file('sha256',$path);
            if(!is_string($sha)||!preg_match('/^[a-f0-9]{64}$/D',$sha))throw new RecoveryException('vault_hash_unavailable','هش بکاپ در دسترس نیست.',503);
            $meta=$this->metadata($backupId,$sourceMetadata,$size,$sha);
            $setPath=rtrim($this->businessBackupDirectory,"/\\").DIRECTORY_SEPARATOR.$backupId.'.recovery.json';
            if(!is_file($setPath)||is_link($setPath))
                throw new RecoveryException('vault_recovery_set_missing','مانیفست معتبر بکاپ موجود نیست.',409);
            try{$set=json_decode((string)file_get_contents($setPath),true,32,JSON_THROW_ON_ERROR);}
            catch(\JsonException){throw new RecoveryException('vault_recovery_set_invalid','مانیفست بکاپ خراب است.',409);}
            if(!is_array($set)||($set['format']??'')!=='sokna-recovery-set-v1'
                ||($set['business_backup']['path']??'')!==$backupId.'.skbf'
                ||($set['business_backup']['sha256']??'')!==$sha
                ||($set['source_installation_id']??'')!==$meta['source_installation_id'])
                throw new RecoveryException('vault_recovery_set_mismatch','مانیفست و فایل بکاپ تطبیق ندارند.',409);
            $ledger=$dir.DIRECTORY_SEPARATOR.$backupId.'.json';
            $previous=$this->readLedger($ledger);
            if($previous!==null && (($previous['sha256']??'')!==$sha || ($previous['size']??null)!==$size))
                throw new RecoveryException('vault_artifact_changed','فایل بکاپ پس از آغاز انتقال تغییر کرده است.',409);
            if($previous!==null && (($previous['installation_id']??'')!==$meta['source_installation_id']))
                throw new RecoveryException('vault_installation_mismatch','هویت نصب با انتقال قبلی یکسان نیست.',409);
            $this->saveLedger($ledger,['backup_id'=>$backupId,'sha256'=>$sha,'size'=>$size,'installation_id'=>$meta['source_installation_id'],'state'=>'PENDING','last_attempt_at'=>gmdate('c')]);
            // Begin is idempotent AND binds backup_id to exact size+SHA on Public.
            // Do not trust uploadStatus alone: a pre-existing ID with different bytes
            // can otherwise masquerade as a resumable session of the same length.
            $admitted=$remote->begin($meta);
            if(($admitted['state']??'')==='REMOTE_VERIFIED')return $this->verified($admitted,$meta,$ledger);
            if(($admitted['state']??'')!=='REMOTE_UPLOADING')
                throw new RecoveryException('vault_unexpected_state','سرور شروع انتقال را تأیید نکرد.',409);
            // Server owns the durable offset after any crash/ambiguous HTTP outcome.
            $remoteStatus=$remote->status($backupId);
            $state=(string)($remoteStatus['state']??'');
            if($state==='REMOTE_VERIFIED')return $this->verified($remoteStatus,$meta,$ledger);
            if($state!=='REMOTE_UPLOADING')throw new RecoveryException('vault_unexpected_state','وضعیت سرور بکاپ قابل اتکا نیست.',409);
            $session=(string)($remoteStatus['upload_session_id']??'');
            if(!preg_match('/^upl_[a-f0-9]{32}$/D',$session))throw new RecoveryException('vault_session_invalid','جلسه انتقال نامعتبر است.',409);
            $received=$this->offset($remoteStatus,$size);
            if(!isset($remoteStatus['expected_size']) || (int)$remoteStatus['expected_size']!==$size)
                throw new RecoveryException('vault_remote_size_conflict','اندازه فایل در سرور با بکاپ محلی متفاوت است.',409);
            $this->saveLedger($ledger,['backup_id'=>$backupId,'sha256'=>$sha,'size'=>$size,'installation_id'=>$meta['source_installation_id'],'state'=>'UPLOADING','received_bytes'=>$received,'last_attempt_at'=>gmdate('c')]);
            while($received<$size){
                if(fseek($h,$received)!==0)throw new RecoveryException('vault_read_failed','خواندن فایل پشتیبان ممکن نیست.',500);
                $chunk=fread($h,min($chunkSize,$size-$received));
                if($chunk===false||$chunk==='')throw new RecoveryException('vault_read_failed','بکاپ هنگام خواندن ناقص شد.',409);
                // Do not assume a failed request was not applied: ask server before next iteration.
                try{$ack=$remote->append($backupId,$session,$received,$chunk);}
                catch(\Throwable $e){
                    // Transport failures may be ambiguous; leave the ledger pending and reconcile next run.
                    $this->saveLedger($ledger,['backup_id'=>$backupId,'sha256'=>$sha,'size'=>$size,'installation_id'=>$meta['source_installation_id'],'state'=>'UNKNOWN_CHUNK_OUTCOME','received_bytes'=>$received,'last_attempt_at'=>gmdate('c')]);
                    throw $e;
                }
                if(($ack['state']??'')==='REMOTE_VERIFIED')return $this->verified($ack,$meta,$ledger);
                $new=$this->offset($ack,$size);
                if($new<$received+strlen($chunk))throw new RecoveryException('vault_chunk_not_durable','سرور دریافت کامل قطعه را تأیید نکرد.',409);
                $received=$new;
                $this->saveLedger($ledger,['backup_id'=>$backupId,'sha256'=>$sha,'size'=>$size,'installation_id'=>$meta['source_installation_id'],'state'=>'UPLOADING','received_bytes'=>$received,'last_attempt_at'=>gmdate('c')]);
            }
            // Local file must still match the original bytes immediately before remote Commit.
            clearstatcache(true,$path);
            if((int)filesize($path)!==$size||!hash_equals($sha,(string)hash_file('sha256',$path)))
                throw new RecoveryException('vault_artifact_changed','بکاپ حین انتقال تغییر کرده است.',409);
            try{$final=$remote->finalize($backupId,$session);}
            catch(\Throwable $e){
                $this->saveLedger($ledger,['backup_id'=>$backupId,'sha256'=>$sha,'size'=>$size,'installation_id'=>$meta['source_installation_id'],'state'=>'UNKNOWN_FINALIZE_OUTCOME','received_bytes'=>$size,'last_attempt_at'=>gmdate('c')]);
                throw $e;
            }
            return $this->verified($final,$meta,$ledger);
        }finally{flock($lock,LOCK_UN);fclose($lock);fclose($h);}
    }

    private function metadata(string $backupId,array $source,int $size,string $sha): array
    {
        $install=trim((string)($source['source_installation_id']??''));
        $release=$source['source_release']??null;
        $protection=$source['protection']??null;
        $created=(string)($source['created_at']??'');$completed=(string)($source['completed_at']??'');
        if(!preg_match('/^[A-Za-z0-9._:-]{1,96}$/D',$install)||!is_array($release)||!is_array($protection)
            ||!preg_match('/^[a-f0-9]{64}$/D',(string)($release['managed_tree_sha256']??''))
            ||trim((string)($release['version']??''))===''||($protection['encrypted']??null)!==true
            ||!in_array((string)($protection['suite']??''),['sokna-skb1-argon2id13-secretstream-xchacha20poly1305'],true)
            ||trim((string)($protection['key_id']??''))===''
            ||!is_string($created)||strtotime($created)===false||strtotime($completed)===false)
            throw new RecoveryException('vault_metadata_missing','اطلاعات مورد نیاز انتقال امن بکاپ ناقص است.',409);
        return ['backup_id'=>$backupId,'artifact_size'=>$size,'artifact_sha256'=>$sha,
            'format_version'=>'sokna-secure-business-backup-v1','source_installation_id'=>$install,
            'business_id'=>substr((string)($source['business_id']??''),0,160),
            'source_release'=>$release,'created_at'=>$created,'completed_at'=>$completed,'protection'=>$protection];
    }

    private function verified(array $result,array $meta,string $ledger): array
    {
        if(($result['state']??'')!=='REMOTE_VERIFIED'||!is_array($result['receipt']??null))
            throw new RecoveryException('vault_remote_receipt_missing','سرور رسید تأییدشده نفرستاد.',409);
        $r=$result['receipt'];
        if(($r['format']??'')!=='sokna-remote-backup-vault-receipt-v1'
            || ($r['backup_id']??'')!==$meta['backup_id']
            || ($r['artifact_size']??null)!==$meta['artifact_size']
            || !is_string($r['artifact_sha256']??null)
            || !hash_equals($meta['artifact_sha256'],$r['artifact_sha256'])
            || ($r['metadata']['source_installation_id']??'')!==$meta['source_installation_id']
            || !preg_match('/^rct_[a-f0-9]{40}$/D',(string)($r['remote_receipt_id']??'')))
            throw new RecoveryException('vault_remote_receipt_mismatch','رسید سرور متعلق به این بکاپ نیست.',409);
        $row=['backup_id'=>$meta['backup_id'],'sha256'=>$meta['artifact_sha256'],'size'=>$meta['artifact_size'],
            'installation_id'=>$meta['source_installation_id'],'state'=>'REMOTE_VERIFIED','remote_receipt_id'=>$r['remote_receipt_id'],
            'verified_at'=>$r['verified_at']??gmdate('c')];
        $this->saveLedger($ledger,$row);return $row;
    }
    private function offset(array $response,int $size): int
    {$v=$response['received_bytes']??null;if(!is_int($v)||$v<0||$v>$size)throw new RecoveryException('vault_offset_invalid','موقعیت دریافت شده از سرور نامعتبر است.',409);return $v;}
    private function readLedger(string $path): ?array
    {if(!is_file($path))return null;$raw=file_get_contents($path);try{$v=json_decode((string)$raw,true,32,JSON_THROW_ON_ERROR);}catch(\JsonException){throw new RecoveryException('vault_ledger_corrupt','دفتر انتقال آسیب دیده و نیاز به بررسی دارد.',409);}if(!is_array($v))throw new RecoveryException('vault_ledger_corrupt','دفتر انتقال معتبر نیست.',409);return $v;}
    private function saveLedger(string $path,array $row): void
    {$tmp=$path.'.tmp.'.bin2hex(random_bytes(6));$json=json_encode($row,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)."\n";
        if(@file_put_contents($tmp,$json,LOCK_EX)===false)throw new RecoveryException('vault_ledger_unavailable','ثبت وضعیت انتقال ممکن نیست.',503);
        @chmod($tmp,0600);if(!@rename($tmp,$path)){@unlink($tmp);throw new RecoveryException('vault_ledger_unavailable','ثبت وضعیت انتقال تأیید نشد.',503);}}
}

/** Narrowly distinguishes a real server-side 404 from a network timeout/5xx. */
final class RemoteVaultUploadNotFound extends \RuntimeException {}
