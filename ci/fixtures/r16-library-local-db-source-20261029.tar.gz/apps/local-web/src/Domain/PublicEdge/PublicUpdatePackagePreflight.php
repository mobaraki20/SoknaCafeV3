<?php
declare(strict_types=1);
namespace Sokna\Local\Domain\PublicEdge;

use ZipArchive;

/**
 * Local-side fail-closed release selection before ANY Public upload.
 * This does not replace the Public owner's signature or payload verification.
 * It prevents a new universal manifest from being sent to a legacy receiver
 * that silently ignores supported_baselines or the target version order.
 */
final class PublicUpdatePackagePreflight
{
    /** @return array{version:string,base_version:string,base_managed_tree_sha256:string,mode:string} */
    public static function inspect(string $zipPath, array $status): array
    {
        if (!class_exists(ZipArchive::class)) {
            throw new PublicEdgeSyncException('public_zip_unavailable','درایور ZIP برای بررسی بسته Public در دسترس نیست.',500);
        }
        $zip = new ZipArchive();
        if ($zip->open($zipPath) !== true) {
            throw new PublicEdgeSyncException('public_zip_invalid','بسته Public قابل خواندن نیست.',422);
        }
        try {
            if ($zip->numFiles < 2 || $zip->numFiles > 12020) {
                throw new PublicEdgeSyncException('public_manifest_invalid','تعداد فایل‌های بسته Public معتبر نیست.',422);
            }
            $raw = $zip->getFromName('manifest.json');
            if (!is_string($raw) || strlen($raw) > 2097152) {
                throw new PublicEdgeSyncException('public_manifest_invalid','مانیفست بسته Public معتبر نیست.',422);
            }
            $manifest = json_decode($raw,true,64,JSON_THROW_ON_ERROR);
            if (!is_array($manifest)) {
                throw new PublicEdgeSyncException('public_manifest_invalid','مانیفست بسته Public معتبر نیست.',422);
            }
            return self::check($manifest,$status);
        } catch (\JsonException $e) {
            throw new PublicEdgeSyncException('public_manifest_invalid','ساختار مانیفست بسته Public معتبر نیست.',422);
        } finally {
            $zip->close();
        }
    }

    /** Isolated contract gate; the actual Public receiver must still verify the whole ZIP/signature. */
    public static function check(array $manifest,array $status): array
    {
        $routine=is_array($status['routine_update']??null)?$status['routine_update']:[];
        $legacy=is_array($status['update']??null)?$status['update']:[];
        $current=trim((string)($routine['current_version']??$legacy['active_version']??$legacy['current_version']??''));
        $tree=strtolower(trim((string)($routine['managed_tree_sha256']??$legacy['managed_tree_sha256']??'')));
        // Legacy Emergency and Routine track separate lifecycle states; the legacy
        // active_version may legitimately lag after a Routine activation. Only
        // require the Routine disk/current version to agree with its own committed
        // active identity when there is no staged/pending verification in flight.
        if (isset($routine['active_version'],$routine['current_version'])
            && $routine['current_version']!=='unknown' && $routine['active_version']!==$routine['current_version']
            && empty($routine['pending_verification']) && empty($routine['activation_journal'])) {
            throw new PublicEdgeSyncException('public_remote_identity_conflict','نسخهٔ دیسک و نسخهٔ ثبت‌شده Public یکسان نیست.',409);
        }
        if (!preg_match('/^[a-f0-9]{64}$/D',$tree) || $current==='' || $current==='unknown'
            || ($routine['managed_tree_matches_expected']??null)===false) {
            throw new PublicEdgeSyncException('public_remote_identity_unverified','نسخه یا هش نصب‌شدهٔ Public قابل تأیید نیست.',409);
        }
        if (($manifest['component']??'')!=='public-edge') {
            throw new PublicEdgeSyncException('public_manifest_invalid','بسته برای مؤلفه Public نیست.',422);
        }
        $format=(string)($manifest['format']??'');
        if ($format==='sokna-component-package-v1') {
            if ((int)($manifest['schema_version']??0)!==1) {
                throw new PublicEdgeSyncException('public_manifest_invalid','نسخهٔ قرارداد Public نامعتبر است.',422);
            }
            $target=trim((string)($manifest['version']??''));
            self::requireForward($target,$current);
            $compat=$manifest['compatibility']??null;
            if (!is_array($compat)) {
                throw new PublicEdgeSyncException('public_baseline_missing','اطلاعات نسخهٔ مبنای Public وجود ندارد.',422);
            }
            if (array_key_exists('supported_baselines',$compat)) {
                if (array_key_exists('from_version',$compat)||array_key_exists('from_managed_tree_sha256',$compat)) {
                    throw new PublicEdgeSyncException('public_ambiguous_baselines','قراردادهای متفاوت نسخهٔ مبنا مخلوط شده‌اند.',422);
                }
                // A legacy Public owner ignores supported_baselines and does not check downgrades.
                // Do not transmit the ZIP until a trusted Public foundation advertises support.
                if (empty(((array)($status['protocols']??[]))['public_multi_baseline_exact_v1'])) {
                    throw new PublicEdgeSyncException('public_foundation_required',
                        'نسخهٔ Public ابتدا به ارتقای پایه نیاز دارد تا بستهٔ مشترک را ایمن بشناسد.',409);
                }
                $bases=$compat['supported_baselines'];
                if (!is_array($bases)||!array_is_list($bases)||count($bases)<1||count($bases)>64) {
                    throw new PublicEdgeSyncException('public_baselines_invalid','فهرست نسخه‌های مبنای Public نامعتبر است.',422);
                }
                $keys=[];$matched=false;
                foreach ($bases as $base) {
                    if (!is_array($base)||!is_string($base['version']??null)
                        ||!is_string($base['managed_tree_sha256']??null)
                        ||!preg_match('/^[a-f0-9]{64}$/D',$base['managed_tree_sha256'])) {
                        throw new PublicEdgeSyncException('public_baselines_invalid','یکی از نسخه‌های مبنا نامعتبر است.',422);
                    }
                    self::requireForward($target,$base['version']);
                    $key=$base['version']."\0".$base['managed_tree_sha256'];
                    if (isset($keys[$key])) throw new PublicEdgeSyncException('public_duplicate_baseline','نسخهٔ مبنا تکراری است.',422);
                    $keys[$key]=true;
                    if ($base['version']===$current && hash_equals($base['managed_tree_sha256'],$tree)) $matched=true;
                }
                if (!$matched) throw new PublicEdgeSyncException('public_baseline_not_supported','نسخهٔ Public نصب‌شده در فهرست بسته نیست.',409);
                return ['version'=>$target,'base_version'=>$current,'base_managed_tree_sha256'=>$tree,'mode'=>'universal_full'];
            }
            $baseVersion=$compat['from_version']??null;$baseTree=$compat['from_managed_tree_sha256']??null;
            if (!is_string($baseVersion)||!is_string($baseTree)
                ||!hash_equals($baseVersion,$current)||!hash_equals(strtolower($baseTree),$tree)) {
                throw new PublicEdgeSyncException('public_baseline_mismatch','بستهٔ ارتقای پایه با نسخه و هش نصب‌شدهٔ Public تطابق ندارد.',409);
            }
            return ['version'=>$target,'base_version'=>$current,'base_managed_tree_sha256'=>$tree,'mode'=>'legacy_exact_full'];
        }
        if ($format==='sokna-public-delta-v2') {
            if ((int)($manifest['schema_version']??0)!==2) throw new PublicEdgeSyncException('public_manifest_invalid','قرارداد Delta نامعتبر است.',422);
            $target=trim((string)($manifest['version']??''));self::requireForward($target,$current);
            $base=(array)($manifest['base']??[]);
            if (($base['version']??null)!==$current || !is_string($base['managed_tree_sha256']??null)
                || !hash_equals(strtolower($base['managed_tree_sha256']),$tree)) {
                throw new PublicEdgeSyncException('public_baseline_mismatch','نسخهٔ مبنای Delta با Public نصب‌شده یکسان نیست.',409);
            }
            return ['version'=>$target,'base_version'=>$current,'base_managed_tree_sha256'=>$tree,'mode'=>'legacy_exact_delta'];
        }
        throw new PublicEdgeSyncException('public_manifest_invalid','قالب بسته Public شناخته‌شده نیست.',422);
    }

    private static function requireForward(string $target,string $source): void
    {
        $parse=static function(string $version): array {
            if (!preg_match('/(?:^|-)workspace\.([0-9]{1,8})([a-z]{1,5})(?:-|$)/D',$version,$m)) {
                throw new PublicEdgeSyncException('public_version_order_unknown',
                    'ترتیب نسخه‌های Public قابل تأیید نیست؛ نصب متوقف شد.',409);
            }
            $n=0;foreach (str_split($m[2]) as $ch) $n=$n*26+ord($ch)-96;
            return [(int)$m[1],$n];
        };
        if ($parse($target)<=$parse($source)) {
            throw new PublicEdgeSyncException('public_downgrade_forbidden','نصب نسخهٔ قدیمی یا تکراری Public مجاز نیست.',409);
        }
    }
}
