<?php
declare(strict_types=1);

namespace Sokna\Local\Domain\System;

use RuntimeException;

/**
 * Ephemeral, backend-only Public Vault admin exchange. No session or credential
 * is returned to a browser or persisted by Local Web. Existing Public HTTPS
 * admin-login, vault-credential-* and admin-logout routes are reused.
 */
final class PublicVaultAdminClient
{
    private const TTL = 2592000; // 30 days; shorter than Public's 180-day limit
    private const MAX_RESPONSE = 65536;
    /** @var null|callable */
    private $transport;

    public function __construct(?callable $transport = null) { $this->transport=$transport; }

    /** @return array{credential:string,credential_id:string,expires_at:string} */
    public function issueUpload(string $publicBase, string $adminPassword, string $installationId, bool $renew): array
    {
        $endpoint=self::endpoint($publicBase);
        if ($adminPassword==='' || strlen($adminPassword)>1024 ||
            preg_match('/^[A-Za-z0-9._:-]{1,96}$/D',$installationId)!==1)
            throw new RuntimeException('BACKUP_PUBLIC_ADMIN_INPUT_INVALID');
        $token='';
        try {
            $login=$this->request($endpoint,'admin-login','POST',['emergency_password'=>$adminPassword]);
            $token=(string)($login['admin_session']??'');
            if (!preg_match('/^madm_[a-f0-9]{24}\.[A-Za-z0-9_-]{40,80}$/D',$token))
                throw new RuntimeException('BACKUP_PUBLIC_ADMIN_AUTH_FAILED');
            if ($renew) {
                $inventory=$this->request($endpoint,'vault-credential-list','GET',[], $token);
                $candidates=[];
                foreach ((array)($inventory['tokens']??[]) as $item) {
                    if (!is_array($item) || ($item['installation_id']??'')!==$installationId ||
                        ($item['label']??'')!=='sokna-backup-'.$installationId ||
                        ($item['active']??false)!==true || ($item['enabled']??false)!==true ||
                        ($item['scopes']??[])!==['vault.upload']) continue;
                    if (preg_match('/^vlt_[a-f0-9]{24}$/D',(string)($item['credential_id']??''))!==1) continue;
                    $candidates[]=$item;
                }
                usort($candidates, static fn(array $a,array $b):int =>
                    strcmp((string)$b['created_at'],(string)$a['created_at']));
                if ($candidates===[] || (count($candidates)>1 &&
                    $candidates[0]['created_at']===$candidates[1]['created_at']))
                    throw new RuntimeException('BACKUP_UPLOAD_CREDENTIAL_ID_UNVERIFIED');
                $issued=$this->request($endpoint,'vault-credential-renew-upload','POST',[
                    'credential_id'=>$candidates[0]['credential_id'],
                    'ttl_seconds'=>self::TTL, 'grace_seconds'=>300,
                ], $token);
            } else {
                // Initial policy is used only when Vault has not yet been provisioned.
                $issued=$this->request($endpoint,'vault-credential-provision','POST',[
                    'installation_id'=>$installationId,'scopes'=>['vault.upload'],
                    'ttl_seconds'=>self::TTL,'label'=>'sokna-backup-'.$installationId,
                    'policy'=>['max_artifact_bytes'=>8589934592,'max_chunk_bytes'=>1048576],
                ], $token);
            }
            $credential=(string)($issued['credential']??'');
            $id=(string)($issued['credential_id']??'');
            $expires=(string)($issued['expires_at']??'');
            $expiry=strtotime($expires);
            if (!preg_match('/^vlt_[a-f0-9]{24}\.[A-Za-z0-9_-]{32,96}$/D',$credential) ||
                $id!==strtok($credential,'.') ||
                ($issued['installation_id']??'')!==$installationId ||
                ($issued['scopes']??[])!==['vault.upload'] ||
                ($issued['secret_returned_once']??false)!==true ||
                $expiry===false || $expiry<time()+172800 || $expiry>time()+15552060)
                throw new RuntimeException('BACKUP_PUBLIC_CREDENTIAL_UNVERIFIED');
            return ['credential'=>$credential,'credential_id'=>$id,'expires_at'=>gmdate('Y-m-d\TH:i:s\Z',$expiry)];
        } finally {
            if ($token!=='') {
                try {$this->request($endpoint,'admin-logout','POST',[], $token);}
                catch (\Throwable) {} // Never replay a credential mutation.
            }
        }
    }

    public static function endpoint(string $base): string
    {
        $parts=parse_url($base);
        if (!is_array($parts)||strtolower((string)($parts['scheme']??''))!=='https' ||
            empty($parts['host']) || isset($parts['user'])||isset($parts['pass']) ||
            isset($parts['query'])||isset($parts['fragment']) || preg_match('/[\r\n]/',$base))
            throw new RuntimeException('BACKUP_PUBLIC_ENDPOINT_INVALID');
        $path=rtrim((string)($parts['path']??''),'/');
        if (str_contains($path,'..')||str_contains($path,'%')||str_contains($path,'\\'))
            throw new RuntimeException('BACKUP_PUBLIC_ENDPOINT_INVALID');
        return rtrim($base,'/').'/maintenance.php';
    }

    /** @param array<string,mixed> $body @return array<string,mixed> */
    private function request(string $endpoint,string $action,string $method,array $body=[],string $adminToken=''): array
    {
        if (!in_array($action,['admin-login','admin-logout','vault-credential-list',
            'vault-credential-provision','vault-credential-renew-upload'],true))
            throw new RuntimeException('BACKUP_PUBLIC_ACTION_FORBIDDEN');
        $url=$endpoint.'?action='.rawurlencode($action);
        $json=$method==='POST'?json_encode($body,JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES):'';
        if (strlen($json)>4096)throw new RuntimeException('BACKUP_PUBLIC_REQUEST_TOO_LARGE');
        $headers=['Accept: application/json','Content-Type: application/json',
            'User-Agent: SOKNA-Local-Backup-Admin/1','Connection: close'];
        if ($method==='POST')$headers[]='Content-Length: '.strlen($json);
        if ($adminToken!=='')$headers[]='X-Sokna-Maintenance-Admin: '.$adminToken;
        if (is_callable($this->transport)) {
            $response=($this->transport)($url,$method,$headers,$json);
            $status=(int)($response['status']??0);$raw=(string)($response['body']??'');
        } else {
            $context=stream_context_create(['http'=>[
                'method'=>$method,'header'=>implode("\r\n",$headers),'content'=>$json,
                'timeout'=>8,'ignore_errors'=>true,'follow_location'=>0,'max_redirects'=>0,
            ],'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true,'allow_self_signed'=>false]]);
            $answer=@file_get_contents($url,false,$context,0,self::MAX_RESPONSE+1);
            $raw=is_string($answer)?$answer:'';$status=0;
            foreach (($http_response_header??[]) as $h)
                if (preg_match('/^HTTP\/\S+\s+(\d{3})/',$h,$m))$status=(int)$m[1];
        }
        if (strlen($raw)>self::MAX_RESPONSE || $status<200 || $status>=300 || $raw==='')
            throw new RuntimeException('BACKUP_PUBLIC_REQUEST_UNVERIFIED');
        try {$parsed=json_decode($raw,true,32,JSON_THROW_ON_ERROR);}
        catch (\Throwable) {throw new RuntimeException('BACKUP_PUBLIC_RESPONSE_INVALID');}
        if (!is_array($parsed)||($parsed['ok']??false)!==true)
            throw new RuntimeException('BACKUP_PUBLIC_RESPONSE_INVALID');
        return $parsed;
    }
}
