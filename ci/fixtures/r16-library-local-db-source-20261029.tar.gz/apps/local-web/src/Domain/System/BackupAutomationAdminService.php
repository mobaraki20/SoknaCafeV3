<?php
declare(strict_types=1);

namespace Sokna\Local\Domain\System;

use Closure;
use RuntimeException;

/** Source-only Local administrative bridge for existing Windows Maintenance 0.3.17. */
final class BackupAutomationAdminService
{
    private Closure $windows;
    private Closure $public;
    private Closure $status;

    /**
     * $windows(string $operation,array $payload): array
     * $public(bool $renew,string $adminPassword,string $installationId): array
     * $status(): array
     */
    public function __construct(callable $windows,callable $public,callable $status)
    {
        $this->windows=Closure::fromCallable($windows);
        $this->public=Closure::fromCallable($public);
        $this->status=Closure::fromCallable($status);
    }

    /** @param array<string,mixed> $facts @param array<string,mixed> $input */
    public function configure(array $facts,array $input): array
    {
        $this->requireQualified(false);
        $pass=(string)($input['recovery_passphrase']??'');
        if (strlen($pass)<16||strlen($pass)>1024||
            !hash_equals($pass,(string)($input['recovery_passphrase_repeat']??'')) ||
            ($input['recovery_copy_confirmed']??false)!==true)
            throw new RuntimeException('BACKUP_OWNER_RECOVERY_SECRET_NOT_CONFIRMED');
        $adminPassword=(string)($input['public_admin_password']??'');
        if ($adminPassword==='')throw new RuntimeException('BACKUP_PUBLIC_ADMIN_PASSWORD_REQUIRED');
        $facts=self::validateFacts($facts);
        // Public issuance is intentionally AFTER all static Windows/Local checks.
        $issued=($this->public)(false,$adminPassword,$facts['installation_id']);
        $expiry=(string)($issued['expires_at']??'');
        if (!self::validExpiry($expiry))throw new RuntimeException('BACKUP_VAULT_EXPIRY_UNVERIFIED');
        $policy=[
            'format'=>'sokna-maintenance-backup-policy-v1',
            'enabled'=>true,
            'intervalHours'=>24,
            'recoveryCopyExternallyConfirmed'=>true,
            'phpExecutable'=>$facts['php_executable'],
            'expectedLocalBuild'=>$facts['local_build'],
            'expectedManagedTreeSha256'=>$facts['managed_tree_sha256'],
            'remoteVaultEndpoint'=>$facts['public_endpoint'],
            'sourceInstallationId'=>$facts['installation_id'],
            'vaultCredentialExpiresAtUtc'=>$expiry,
        ];
        $out=($this->windows)('configure',[
            'policy'=>$policy,'recoveryPassphrase'=>$pass,'vaultBearer'=>(string)($issued['credential']??''),
        ]);
        $this->requireWindowsAck($out);
        return ['configured'=>true,'policy_enabled'=>true,'release_qualified'=>false,
            'message_code'=>'BACKUP_CONFIGURED_SOURCE_UAT_NOT_RELEASE_QUALIFIED'];
    }

    /** @param array<string,mixed> $input */
    public function renew(string $installationId,array $input): array
    {
        $this->requireQualified(true);
        if (preg_match('/^[A-Za-z0-9._:-]{1,96}$/D',$installationId)!==1)
            throw new RuntimeException('BACKUP_INSTALLATION_UNVERIFIED');
        $password=(string)($input['public_admin_password']??'');
        if ($password==='')throw new RuntimeException('BACKUP_PUBLIC_ADMIN_PASSWORD_REQUIRED');
        $issued=($this->public)(true,$password,$installationId);
        $expiry=(string)($issued['expires_at']??'');
        if (!self::validExpiry($expiry))throw new RuntimeException('BACKUP_VAULT_EXPIRY_UNVERIFIED');
        $out=($this->windows)('renew',[
            'vaultBearer'=>(string)($issued['credential']??''),
            'expiresAtUtc'=>$expiry,
        ]);
        $this->requireWindowsAck($out);
        return ['renewed'=>true,'policy_enabled'=>true,'release_qualified'=>false,
            'message_code'=>'BACKUP_UPLOAD_CREDENTIAL_RENEWED'];
    }

    public function disable(): array
    {
        // Always permit stopping the scheduler. Do not silently revoke Vault
        // credentials: an in-flight operation might be reconciling UNKNOWN.
        $out=($this->windows)('disable',[]);
        $this->requireWindowsAck($out);
        return ['disabled'=>true,'policy_enabled'=>false];
    }

    /** @param array<string,mixed> $facts @return array<string,string> */
    public static function validateFacts(array $facts): array
    {
        $id=(string)($facts['installation_id']??'');
        $build=(string)($facts['local_build']??'');
        $tree=(string)($facts['managed_tree_sha256']??'');
        $php=(string)($facts['php_executable']??'');
        $base=(string)($facts['public_base']??'');
        $endpoint=PublicVaultAdminClient::endpoint($base);
        if (preg_match('/^[A-Za-z0-9._:-]{1,96}$/D',$id)!==1 ||
            preg_match('/^[A-Za-z0-9._:+-]{1,100}$/D',$build)!==1 ||
            preg_match('/^[a-f0-9]{64}$/D',$tree)!==1 ||
            $php===''||strlen($php)>400||!is_file($php)||
            !str_ends_with(strtolower($php),PHP_OS_FAMILY==='Windows'?'php.exe':'php') ||
            ($facts['inventory_complete']??false)!==true)
            throw new RuntimeException('BACKUP_LOCAL_HOST_IDENTITY_UNVERIFIED');
        return ['installation_id'=>$id,'local_build'=>$build,'managed_tree_sha256'=>$tree,
            'php_executable'=>$php,'public_endpoint'=>$endpoint];
    }

    /** @param array<string,mixed> $result */
    private function requireWindowsAck(array $result): void
    {
        if (($result['ok']??false)!==true)
            throw new RuntimeException(($result['outcome_unknown']??false)===true
                ? 'BACKUP_WINDOWS_MUTATION_OUTCOME_UNKNOWN'
                : 'BACKUP_WINDOWS_MUTATION_UNVERIFIED');
    }

    private function requireQualified(bool $requireEnabled): void
    {
        $s=($this->status)();
        if (($s['available']??false)!==true || ($s['release_qualified']??false)!==true)
            throw new RuntimeException('BACKUP_RELEASE_GATE_NOT_QUALIFIED');
        if ($requireEnabled && ($s['policy_enabled']??false)!==true)
            throw new RuntimeException('BACKUP_AUTOMATION_NOT_CONFIGURED');
        if (in_array($s['state']??'',['RUNNING','UNKNOWN','PREPARED','UPLOADING','EVIDENCE_UNAVAILABLE'],true))
            throw new RuntimeException('BACKUP_PENDING_OPERATION_BLOCKED');
    }

    public static function validExpiry(string $expiry): bool
    {
        if (!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/D',$expiry))return false;
        $time=strtotime($expiry);
        return $time!==false && $time>time()+172800 && $time<=time()+15552060;
    }
}
