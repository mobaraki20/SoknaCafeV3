<?php
declare(strict_types=1);
namespace Sokna\Local\Domain\System;

/**
 * Read-only precondition before forwarding a privileged Local activation.
 * Supervisor must revalidate the signed Stage/slot under its machine lease.
 * Never interpret LocalUpdateService's legacy staged ZIP as a Stage receipt.
 */
final class MaintenancePanelActivationGate
{
    /**
     * Shared, guarded orchestration for the Web adapter and the one-time
     * OS-administrator repair runner. Web still owns RBAC/CSRF; Supervisor
     * owns authorization, exact baseline, host verification and activation.
     * No POST is retried. The optional observer persists a runner checkpoint
     * before each POST and cannot change the payload or permit a failed gate.
     * @return array{status:int,body:array<string,mixed>}
     */
    public static function requestActivation(MaintenanceSupervisorClient $client, string $stageId,
        string $actor, string $idem, ?callable $beforePost=null): array
    {
        if(preg_match('/^user:[0-9]{1,16}$/D',$actor)!==1)
            return self::activationReply(['success'=>false,'code'=>'MAINTENANCE_OPERATOR_INVALID'],422);
        if(preg_match('/^[a-fA-F0-9]{32}$/D',$stageId)!==1||
            preg_match('/^[a-zA-Z0-9._:-]{16,128}$/D',$idem)!==1)
            return self::activationReply(['success'=>false,'code'=>'MAINTENANCE_REQUEST_INVALID','message'=>'شناسه Stage یا شناسه درخواست معتبر نیست.'],422);
        $cap=$client->updateCapabilities();
        if(($cap['ready']??false)!==true)
            return self::activationReply(['success'=>false,'code'=>(string)($cap['code']??'FOUNDATION_UPDATE_REQUIRED'),'message'=>'موتور Maintenance برای نصب از پنل تأیید نشده است.'],409);
        // The stage MUST be a currently verifiable signed Supervisor receipt,
        // not a legacy Local staged ZIP or an arbitrary browser-supplied ID.
        $ops=$client->updateOperations();
        $signedStage=$client->operationById($stageId);
        if(!\Sokna\Local\Domain\System\MaintenancePanelActivationGate::exactStageVerified($ops,$signedStage,$stageId,$actor))
            return self::activationReply(['success'=>false,'code'=>'MAINTENANCE_STAGE_NOT_VERIFIED','message'=>'Stage معتبر و متعلق به این مدیر در سوابق امضاشده یافت نشد، یا عملیات دیگری در جریان است.'],409);
        // One explicit click: Supervisor-owned inactive candidate and slot must
        // be independently verified BEFORE the code-only cutover. HMAC here
        // authenticates the Web adapter; no publisher signature/key enrollment.
        // Derive stable idempotency keys from the already durable Activate ID.
        $candidateIdem='candidate-'.substr(hash('sha256','private|'.$idem),0,32);
        $slotIdem='slot-'.substr(hash('sha256','slot|'.$idem),0,32);
        // New Supervisors reserve one durable parent before preparing anything.
        // Older installed Supervisors keep the guarded compatibility sequence.
        if (($cap['local_activation_workflow']??'')!=='supervisor-durable-prepare-v1') {
        if($beforePost!==null)$beforePost('prepare_inactive',$candidateIdem);
        $candidate=$client->requestLocalUpdateOperation('prepare_inactive',
            ['operator_id'=>$actor,'stage_operation_id'=>$stageId],$candidateIdem);
        $candidateReceipt=(array)($candidate['data']['receipt']??[]);
        if(($candidate['ok']??false)!==true||
            ($candidateReceipt['active_slot_unchanged']??false)!==true||
            ($candidateReceipt['activation_performed']??true)!==false)
            return self::activationReply(['success'=>false,'code'=>trim((string)($candidate['error_code']??''))?:'MAINTENANCE_CANDIDATE_UNPROVEN',
                'preparation_step'=>'prepare_inactive','maintenance_operation'=>$candidate,
                'message'=>'نسخه غیرفعال به‌صورت مستقل تأیید نشد؛ هیچ نصب جدیدی شروع نشده است.'],409);
        if($beforePost!==null)$beforePost('prepare_slot',$slotIdem);
        $slot=$client->requestLocalUpdateOperation('prepare_slot',
            ['operator_id'=>$actor,'stage_operation_id'=>$stageId,
             'private_candidate_idempotency_key'=>$candidateIdem],$slotIdem);
        $slotReceipt=(array)($slot['data']['receipt']??[]);
        if(($slot['ok']??false)!==true||
            ($slotReceipt['actual_host_health_qualified']??false)!==true||
            ($slotReceipt['activation_performed']??true)!==false)
            return self::activationReply(['success'=>false,'code'=>trim((string)($slot['error_code']??''))?:'MAINTENANCE_SLOT_UNPROVEN',
                'preparation_step'=>'prepare_slot','maintenance_operation'=>$slot,
                'message'=>'سلامت نسخه غیرفعال یا میزبان تأیید نشد؛ نصب شروع نشده است.'],409);
        }
        if($beforePost!==null)$beforePost('activate',$idem);
        $result=$client->requestLocalUpdateOperation('activate',
            ['operator_id'=>$actor,'stage_operation_id'=>$stageId],$idem);
        if(($result['ok']??false)!==true)
            return self::activationReply(['success'=>false,'code'=>(string)($result['error_code']??'MAINTENANCE_ACTIVATION_UNPROVEN'),'message'=>'نتیجه فعال‌سازی تأیید نشده است؛ عملیات را تکرار نکن و وضعیت Maintenance را بررسی کن.','maintenance_operation'=>$result],409);
        $classification=\Sokna\Local\Domain\System\MaintenancePanelActivationGate::classifyActivationResponse(
            $result,$stageId,$actor);
        $receipt=(array)($result['data']['operation']??[]);
        if($classification==='pending')
            return self::activationReply(['success'=>true,'accepted'=>true,'activation_committed'=>false,
                'operation_id'=>(string)$receipt['operation_id'],
                'message'=>'درخواست ثبت شد؛ نتیجه نصب باید از وضعیت پایدار عملیات خوانده شود.',
                'maintenance_operation'=>$result],202);
        if($classification!=='committed')
            return self::activationReply(['success'=>false,'code'=>'MAINTENANCE_COMMIT_EVIDENCE_UNPROVEN','message'=>'Maintenance پاسخ داده، اما مدرک معتبر پذیرش یا نصب کامل نیست. وضعیت واقعی را بررسی کن.'],409);
        return self::activationReply(['success'=>true,'accepted'=>false,'activation_committed'=>true,
            'operation_id'=>(string)$receipt['operation_id'],
            'maintenance_operation'=>$result]);
    }

    private static function activationReply(array $body, int $status=200): array
    {
        return ['status'=>$status,'body'=>$body];
    }

    /**
     * Check an exact signed Supervisor GET /v1/operations/{id} response.
     * Never accept a browser-provided stage receipt or recent-history window.
     */
    public static function exactStageVerified(array $operations, array $receipt, string $stageId, string $actor): bool
    {
        if (preg_match('/^[a-fA-F0-9]{32}$/D',$stageId)!==1
            || ($operations['ok']??false)!==true
            || ($operations['requires_recovery']??true)!==false
            || (int)($operations['active_count']??-1)!==0
            || (int)($operations['blocking_count']??-1)!==0
            || ($receipt['ok']??false)!==true
            || !is_array($receipt['data']??null)) return false;
        $stage=$receipt['data'];
        return hash_equals(strtolower($stageId),strtolower((string)($stage['operation_id']??'')))
            && ($stage['operation_type']??'')==='update.local-stage'
            && ($stage['state']??'')==='staged'
            && ($stage['operator_id']??'')===$actor
            && preg_match('/^[a-zA-Z0-9._:-]{1,160}$/D',(string)($stage['package_ref']??''))===1;
    }

    /**
     * Classify the *signed Supervisor response* from Activate without
     * confusing HTTP 202 acceptance with an installed/committed release.
     * The browser may poll the same durable operation but must never retry
     * POST on an ambiguous response.
     *
     * @return 'pending'|'committed'|'invalid'
     */
    public static function classifyActivationResponse(array $response, string $stageId, string $actor): string
    {
        if (($response['ok']??false)!==true ||
            preg_match('/^[a-fA-F0-9]{32}$/D',$stageId)!==1 ||
            preg_match('/^user:[0-9]{1,16}$/D',$actor)!==1) return 'invalid';
        $data=is_array($response['data']??null)?$response['data']:[];
        $op=is_array($data['operation']??null)?$data['operation']:[];
        if (preg_match('/^[a-fA-F0-9]{32}$/D',(string)($op['operation_id']??''))!==1 ||
            ($op['operation_type']??'')!=='update.local-code-only-activate' ||
            ($op['operator_id']??'')!==$actor ||
            !hash_equals(strtolower($stageId),strtolower((string)($op['package_ref']??''))) ||
            !is_bool($data['database_mutation_performed']??null) ||
            ($data['public_mutation_performed']??null)!==false)
            return 'invalid';
        $state=(string)($op['state']??'');
        $http=(int)($response['http_status']??0);
        if ($http===202 && in_array($state,['accepted','running','activating'],true) &&
            ($data['completion_requires_operation_poll']??null)===true &&
            ($data['activation_committed']??null)===false)
            return 'pending';
        if ($http===200 && $state==='committed' &&
            ($data['activation_committed']??true)===true)
            return 'committed';
        return 'invalid';
    }

    public static function stageVerified(array $operations, string $stageId, string $actor): bool
    {
        if (preg_match('/^[a-fA-F0-9]{32}$/D', $stageId) !== 1
            || ($operations['ok'] ?? false) !== true
            || ($operations['history_available'] ?? false) !== true
            || ($operations['requires_recovery'] ?? true) !== false
            || !isset($operations['active_count'], $operations['blocking_count'])
            || (int)$operations['active_count'] !== 0
            || (int)$operations['blocking_count'] !== 0)
            return false;
        foreach ((array)($operations['recent_operations'] ?? []) as $operation) {
            if (!is_array($operation)) continue;
            if (hash_equals(strtolower($stageId), strtolower((string)($operation['operation_id'] ?? '')))
                && ($operation['operation_type'] ?? '') === 'update.local-stage'
                && ($operation['state'] ?? '') === 'staged'
                && ($operation['operator_id'] ?? '') === $actor)
                return true;
        }
        return false;
    }
}
