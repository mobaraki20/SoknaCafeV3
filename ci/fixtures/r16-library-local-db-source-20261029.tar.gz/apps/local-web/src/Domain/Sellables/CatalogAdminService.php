<?php
declare(strict_types=1);

namespace Sokna\Local\Domain\Sellables;

use PDO;
use PDOException;
use Sokna\Local\Core\IdentityRepository;
use Throwable;

final class CatalogAdminService
{
    private const MENU_STATUSES=['active','draft','inactive'];
    private const AUDIENCES=['guest_staff','staff_only'];
    private const STATIONS=['kitchen','hot_bar','cold_bar','none'];
    private const LIFECYCLES=['active','inactive','retired'];

    public function __construct(
        private readonly PDO $pdo,
        private readonly IdentityRepository $identity,
        private readonly CategoryIconLibrary $icons,
    ){}

    public function snapshot(array $actor): array
    {
        $this->assertAdmin($actor);
        $menus=$this->pdo->query('SELECT id,menu_key,name,status,sort_order,schedule_days,daily_start,daily_end,created_at,updated_at FROM menus ORDER BY sort_order,id')->fetchAll(PDO::FETCH_ASSOC);
        foreach($menus as &$menu){$menu['id']=(int)$menu['id'];$menu['sort_order']=(int)$menu['sort_order'];$menu['schedule_days']=$this->daysFromCsv($menu['schedule_days']??null);}unset($menu);

        $categories=$this->pdo->query("SELECT id,category_key,name,audience,image_path,icon_key,sort_order,active,lifecycle_status,guest_visible,staff_visible,retired_at,retired_note,created_at,updated_at FROM categories WHERE lifecycle_status<>'retired' ORDER BY sort_order,id")->fetchAll(PDO::FETCH_ASSOC);
        $archivedCategories=$this->pdo->query("SELECT id,category_key,name,audience,image_path,icon_key,sort_order,active,lifecycle_status,guest_visible,staff_visible,retired_at,retired_note,created_at,updated_at FROM categories WHERE lifecycle_status='retired' ORDER BY retired_at DESC,id DESC")->fetchAll(PDO::FETCH_ASSOC)?:[];
        $categoryMenus=$this->pdo->query('SELECT category_id,menu_id,sort_order FROM menu_categories ORDER BY category_id,sort_order,menu_id')->fetchAll(PDO::FETCH_ASSOC);
        $categoryMenuMap=[];$categoryMenuSort=[];foreach($categoryMenus as $row){$cid=(int)$row['category_id'];$mid=(int)$row['menu_id'];$categoryMenuMap[$cid][]=$mid;$categoryMenuSort[$cid][(string)$mid]=(int)$row['sort_order'];}
        foreach($categories as &$category){$category=$this->normalizeCategoryRow($category,$categoryMenuMap,$categoryMenuSort);}unset($category);
        foreach($archivedCategories as &$category){$category=$this->normalizeCategoryRow($category,$categoryMenuMap,$categoryMenuSort);}unset($category);

        $items=$this->pdo->query("SELECT i.*,c.name category_name,c.audience category_audience,c.lifecycle_status category_lifecycle_status FROM items i JOIN categories c ON c.id=i.category_id WHERE i.lifecycle_status<>'retired' ORDER BY c.sort_order,c.id,i.sort_order,i.id")->fetchAll(PDO::FETCH_ASSOC);
        $archivedItems=$this->pdo->query("SELECT i.*,c.name category_name,c.audience category_audience,c.lifecycle_status category_lifecycle_status FROM items i JOIN categories c ON c.id=i.category_id WHERE i.lifecycle_status='retired' ORDER BY i.retired_at DESC,i.id DESC")->fetchAll(PDO::FETCH_ASSOC)?:[];
        $itemMenus=$this->pdo->query('SELECT item_id,menu_id FROM menu_items ORDER BY item_id,menu_id')->fetchAll(PDO::FETCH_ASSOC);
        $itemMenuMap=[];foreach($itemMenus as $row)$itemMenuMap[(int)$row['item_id']][]=(int)$row['menu_id'];
        $tags=$this->pdo->query('SELECT id,tag_key,name,active,sort_order,created_at,updated_at FROM catalog_tags ORDER BY sort_order,id')->fetchAll(PDO::FETCH_ASSOC)?:[];
        foreach($tags as &$tag){$tag['id']=(int)$tag['id'];$tag['active']=(int)$tag['active']===1;$tag['sort_order']=(int)$tag['sort_order'];}unset($tag);
        $itemTags=$this->pdo->query('SELECT item_id,tag_id FROM item_tags ORDER BY item_id,tag_id')->fetchAll(PDO::FETCH_ASSOC)?:[];$itemTagMap=[];foreach($itemTags as $row)$itemTagMap[(int)$row['item_id']][]=(int)$row['tag_id'];
        foreach($items as &$item)$item=$this->normalizeItemRow($item,$itemMenuMap,$itemTagMap);unset($item);
        foreach($archivedItems as &$item)$item=$this->normalizeItemRow($item,$itemMenuMap,$itemTagMap);unset($item);

        $families=$this->variantFamiliesSnapshot();
        $suggestions=$this->suggestionsSnapshot();
        $bundles=$this->bundlesSnapshot();

        return [
            'menus'=>$menus,
            'categories'=>$categories,
            'items'=>$items,
            'archived_categories'=>$archivedCategories,
            'archived_items'=>$archivedItems,
            'archive_counts'=>['items'=>count($archivedItems),'categories'=>count($archivedCategories)],
            'variant_families'=>$families,
            'suggestions'=>$suggestions,
            'bundles'=>$bundles,
            'tags'=>$tags,
            'definitions'=>[
                'menu_statuses'=>['active'=>'فعال','draft'=>'پیش‌نویس','inactive'=>'غیرفعال'],
                'audiences'=>['guest_staff'=>'مهمان و کارکنان','staff_only'=>'فقط کارکنان'],
                'lifecycles'=>['active'=>'فعال','inactive'=>'غیرفعال','retired'=>'آرشیو'],
                'sellable_kinds'=>SellableKind::labels(),
                'stations'=>['kitchen'=>'آشپزخانه','hot_bar'=>'بار گرم','cold_bar'=>'بار سرد','none'=>'بدون آماده‌سازی'],
                'days'=>[7=>'شنبه',1=>'یکشنبه',2=>'دوشنبه',3=>'سه‌شنبه',4=>'چهارشنبه',5=>'پنجشنبه',6=>'جمعه'],
                'category_icons'=>$this->icons->groups(),
            ],
            'notes'=>[
                'media'=>'تصویر آیتم از Media Library مدیریت می‌شود؛ آیکن دسته از کتابخانه داخلی امن انتخاب می‌شود.',
                'history'=>'Order snapshots مستقل‌اند؛ تغییر نام/قیمت/نوع آیتم، سفارش‌های گذشته را بازنویسی نمی‌کند.',
            ],
        ];
    }

    public function saveMenu(array $data,array $actor): array
    {
        $admin=$this->assertAdmin($actor);$id=(int)($data['id']??0);$name=$this->text($data['name']??'',120);$status=trim((string)($data['status']??'draft'));$sort=(int)($data['sort_order']??0);
        if($name==='')throw new CatalogAdminException('menu_name','نام منو لازم است.',422);
        if(!in_array($status,self::MENU_STATUSES,true))throw new CatalogAdminException('menu_status','وضعیت منو معتبر نیست.',422);
        [$days,$start,$end]=$this->schedule($data['schedule_days']??[],$data['daily_start']??null,$data['daily_end']??null);
        $this->pdo->beginTransaction();try{
            if($id>0){$q=$this->pdo->prepare('SELECT id,menu_key,name,status FROM menus WHERE id=? FOR UPDATE');$q->execute([$id]);$before=$q->fetch(PDO::FETCH_ASSOC);if(!is_array($before))throw new CatalogAdminException('menu_missing','منو پیدا نشد.',404);$q=$this->pdo->prepare('UPDATE menus SET name=?,status=?,sort_order=?,schedule_days=?,daily_start=?,daily_end=? WHERE id=?');$q->execute([$name,$status,$sort,$days,$start,$end,$id]);$created=false;}
            else{$key=$this->newKey('menus','menu_key');$q=$this->pdo->prepare('INSERT INTO menus(menu_key,name,status,sort_order,schedule_days,daily_start,daily_end) VALUES(?,?,?,?,?,?,?)');$q->execute([$key,$name,$status,$sort,$days,$start,$end]);$id=(int)$this->pdo->lastInsertId();$created=true;}
            $this->audit($created?'catalog.menu_created':'catalog.menu_updated','menu',$id,(int)$admin['id'],['name'=>$name,'status'=>$status,'sort_order'=>$sort,'schedule_days'=>$days,'daily_start'=>$start,'daily_end'=>$end]);
            $this->pdo->commit();return ['id'=>$id];
        }catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function saveCategory(array $data,array $actor): array
    {
        $admin=$this->assertAdmin($actor);$id=(int)($data['id']??0);$name=$this->text($data['name']??'',120);$audience=trim((string)($data['audience']??'guest_staff'));$sort=(int)($data['sort_order']??0);$lifecycle=$this->currentLifecycle($data['lifecycle_status']??(($data['active']??true)?'active':'inactive'));if($lifecycle==='retired')throw new CatalogAdminException('retire_requires_archive_action','برای انتقال دسته به آرشیو از اقدام آرشیو استفاده کنید.',409);$guestVisible=$this->bool($data['guest_visible']??($audience!=='staff_only'));$staffVisible=$this->bool($data['staff_visible']??true);$active=$lifecycle==='active';$audience=$guestVisible?'guest_staff':'staff_only';$icon=$this->nullableText($data['icon_key']??null,40);$menuIds=$this->intList($data['menu_ids']??[]);
        if($name==='')throw new CatalogAdminException('category_name','نام دسته‌بندی لازم است.',422);
        if(!in_array($audience,self::AUDIENCES,true))throw new CatalogAdminException('category_audience','مخاطب دسته‌بندی معتبر نیست.',422);
        if($icon!==null&&!$this->icons->isAllowed($icon))throw new CatalogAdminException('category_icon','آیکن دسته‌بندی معتبر نیست.',422);
        $this->pdo->beginTransaction();try{
            $this->lockMenus($menuIds);
            if($id>0){$q=$this->pdo->prepare('SELECT id,category_key,name FROM categories WHERE id=? FOR UPDATE');$q->execute([$id]);if(!is_array($q->fetch(PDO::FETCH_ASSOC)))throw new CatalogAdminException('category_missing','دسته‌بندی پیدا نشد.',404);$q=$this->pdo->prepare('UPDATE categories SET name=?,audience=?,icon_key=?,sort_order=?,active=?,lifecycle_status=?,guest_visible=?,staff_visible=? WHERE id=?');$q->execute([$name,$audience,$icon,$sort,$active?1:0,$lifecycle,$guestVisible?1:0,$staffVisible?1:0,$id]);$created=false;}
            else{$key=$this->newKey('categories','category_key');$q=$this->pdo->prepare('INSERT INTO categories(category_key,name,audience,icon_key,sort_order,active,lifecycle_status,guest_visible,staff_visible) VALUES(?,?,?,?,?,?,?,?,?)');$q->execute([$key,$name,$audience,$icon,$sort,$active?1:0,$lifecycle,$guestVisible?1:0,$staffVisible?1:0]);$id=(int)$this->pdo->lastInsertId();$created=true;}
            $this->setCategoryMenusTx($id,$menuIds);
            $this->audit($created?'catalog.category_created':'catalog.category_updated','category',$id,(int)$admin['id'],['name'=>$name,'audience'=>$audience,'lifecycle_status'=>$lifecycle,'guest_visible'=>$guestVisible,'staff_visible'=>$staffVisible,'sort_order'=>$sort,'menu_ids'=>$menuIds]);
            $this->pdo->commit();return ['id'=>$id];
        }catch(PDOException $e){if($this->pdo->inTransaction())$this->pdo->rollBack();if((int)($e->errorInfo[1]??0)===1062)throw new CatalogAdminException('category_duplicate','شناسه دسته‌بندی تکراری شد؛ دوباره تلاش کن.',409);throw $e;}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function saveItem(array $data,array $actor): array
    {
        $admin=$this->assertAdmin($actor);$id=(int)($data['id']??0);$name=$this->text($data['name']??'',160);$description=$this->nullableText($data['description']??null,2000);$price=$this->amount($data['price']??null);$categoryId=(int)($data['category_id']??0);$kind=SellableKind::requireWrite($data['sellable_kind']??SellableKind::MENU_ITEM);$station=$this->normalizeStation((string)($data['preparation_station']??'cold_bar'));$sort=(int)($data['sort_order']??0);$lifecycle=$this->currentLifecycle($data['lifecycle_status']??(($data['active']??true)?'active':'inactive'));if($lifecycle==='retired')throw new CatalogAdminException('retire_requires_archive_action','برای انتقال آیتم به آرشیو از اقدام آرشیو استفاده کنید.',409);$available=$lifecycle==='active'&&$this->bool($data['available']??true);$guestVisible=$this->bool($data['guest_visible']??!$this->bool($data['staff_only']??false));$staffVisible=$this->bool($data['staff_visible']??true);$active=$lifecycle==='active';$featured=$this->bool($data['featured']??false);$staffOnly=!$guestVisible;$takeaway=$this->bool($data['takeaway_allowed']??true);$menuIds=$this->intList($data['menu_ids']??[]);$tagIds=$this->intList($data['tag_ids']??[]);
        [$days,$dailyStart,$dailyEnd]=$this->schedule($data['schedule_days']??[],$data['daily_start']??null,$data['daily_end']??null);$scheduleStart=$this->dateTime($data['schedule_start']??null);$scheduleEnd=$this->dateTime($data['schedule_end']??null);if($scheduleStart!==null&&$scheduleEnd!==null&&$scheduleStart>$scheduleEnd)throw new CatalogAdminException('item_schedule_range','پایان بازه آیتم باید بعد از شروع باشد.',422);
        if($name===''||$categoryId<1)throw new CatalogAdminException('item_required','نام و دسته‌بندی آیتم لازم است.',422);
        $this->pdo->beginTransaction();try{
            $q=$this->pdo->prepare('SELECT id,lifecycle_status FROM categories WHERE id=? FOR UPDATE');$q->execute([$categoryId]);$categoryRow=$q->fetch(PDO::FETCH_ASSOC);if(!is_array($categoryRow)||(string)($categoryRow['lifecycle_status']??'active')==='retired')throw new CatalogAdminException('category_missing','دسته‌بندی انتخاب‌شده پیدا نشد یا در آرشیو است.',422);
            $allowed=$this->categoryMenuIdsTx($categoryId);if(array_diff($menuIds,$allowed))throw new CatalogAdminException('item_menu_boundary','یکی از منوهای انتخاب‌شده برای این دسته‌بندی مجاز نیست.',422,['allowed_menu_ids'=>$allowed]);
            if($id>0){$q=$this->pdo->prepare('SELECT id,item_code,image_path FROM items WHERE id=? FOR UPDATE');$q->execute([$id]);$before=$q->fetch(PDO::FETCH_ASSOC);if(!is_array($before))throw new CatalogAdminException('item_missing','آیتم پیدا نشد.',404);$q=$this->pdo->prepare('UPDATE items SET category_id=?,name=?,description=?,price=?,available=?,active=?,lifecycle_status=?,guest_visible=?,staff_visible=?,featured=?,staff_only=?,sellable_kind=?,takeaway_allowed=?,preparation_station=?,schedule_start=?,schedule_end=?,schedule_days=?,daily_start=?,daily_end=?,sort_order=? WHERE id=?');$q->execute([$categoryId,$name,$description,$price,$available?1:0,$active?1:0,$lifecycle,$guestVisible?1:0,$staffVisible?1:0,$featured?1:0,$staffOnly?1:0,$kind,$takeaway?1:0,$station,$scheduleStart,$scheduleEnd,$days,$dailyStart,$dailyEnd,$sort,$id]);$created=false;}
            else{$q=$this->pdo->prepare('INSERT INTO items(item_code,category_id,name,description,price,available,active,lifecycle_status,guest_visible,staff_visible,featured,staff_only,sellable_kind,takeaway_allowed,preparation_station,schedule_start,schedule_end,schedule_days,daily_start,daily_end,sort_order) VALUES(NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');$q->execute([$categoryId,$name,$description,$price,$available?1:0,$active?1:0,$lifecycle,$guestVisible?1:0,$staffVisible?1:0,$featured?1:0,$staffOnly?1:0,$kind,$takeaway?1:0,$station,$scheduleStart,$scheduleEnd,$days,$dailyStart,$dailyEnd,$sort]);$id=(int)$this->pdo->lastInsertId();$this->pdo->prepare('UPDATE items SET item_code=? WHERE id=?')->execute(['ITEM-'.$id,$id]);$created=true;}
            $this->setItemMenusTx($id,$menuIds);$this->setItemTagsTx($id,$tagIds);
            $this->audit($created?'catalog.item_created':'catalog.item_updated','menu_item',$id,(int)$admin['id'],['name'=>$name,'category_id'=>$categoryId,'price'=>$price,'sellable_kind'=>$kind,'available'=>$available,'lifecycle_status'=>$lifecycle,'guest_visible'=>$guestVisible,'staff_visible'=>$staffVisible,'featured'=>$featured,'takeaway_allowed'=>$takeaway,'preparation_station'=>$station,'menu_ids'=>$menuIds,'tag_ids'=>$tagIds]);
            $this->pdo->commit();return ['id'=>$id];
        }catch(PDOException $e){if($this->pdo->inTransaction())$this->pdo->rollBack();if((int)($e->errorInfo[1]??0)===1062)throw new CatalogAdminException('item_duplicate','شناسه داخلی آیتم تکراری شد؛ دوباره تلاش کن.',409);throw $e;}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function saveTag(array $data,array $actor): array
    {
        $admin=$this->assertAdmin($actor);$id=(int)($data['id']??0);$name=$this->text($data['name']??'',120);$active=$this->bool($data['active']??true);$sort=(int)($data['sort_order']??0);
        if($name==='')throw new CatalogAdminException('tag_name','نام برچسب لازم است.',422);
        $this->pdo->beginTransaction();try{
            if($id>0){$q=$this->pdo->prepare('SELECT id FROM catalog_tags WHERE id=? FOR UPDATE');$q->execute([$id]);if(!$q->fetchColumn())throw new CatalogAdminException('tag_missing','برچسب پیدا نشد.',404);$this->pdo->prepare('UPDATE catalog_tags SET name=?,active=?,sort_order=? WHERE id=?')->execute([$name,$active?1:0,$sort,$id]);$created=false;}
            else{$key=$this->newKey('catalog_tags','tag_key');$this->pdo->prepare('INSERT INTO catalog_tags(tag_key,name,active,sort_order) VALUES(?,?,?,?)')->execute([$key,$name,$active?1:0,$sort]);$id=(int)$this->pdo->lastInsertId();$created=true;}
            $this->audit($created?'catalog.tag_created':'catalog.tag_updated','catalog_tag',$id,(int)$admin['id'],['name'=>$name,'active'=>$active,'sort_order'=>$sort]);$this->pdo->commit();return ['id'=>$id];
        }catch(PDOException $e){if($this->pdo->inTransaction())$this->pdo->rollBack();if((int)($e->errorInfo[1]??0)===1062)throw new CatalogAdminException('tag_duplicate','برچسبی با این نام وجود دارد.',409);throw $e;}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function copyItem(int $id,array $actor): array
    {
        $admin=$this->assertAdmin($actor);if($id<1)throw new CatalogAdminException('item_invalid','آیتم معتبر نیست.',422);
        $this->pdo->beginTransaction();try{
            $q=$this->pdo->prepare('SELECT * FROM items WHERE id=? FOR UPDATE');$q->execute([$id]);$row=$q->fetch(PDO::FETCH_ASSOC);if(!is_array($row))throw new CatalogAdminException('item_missing','آیتم پیدا نشد.',404);
            $name=$this->text((string)$row['name'].' — کپی',160);
            $ins=$this->pdo->prepare('INSERT INTO items(item_code,category_id,name,description,price,image_path,available,active,lifecycle_status,guest_visible,staff_visible,featured,staff_only,sellable_kind,takeaway_allowed,preparation_station,schedule_start,schedule_end,schedule_days,daily_start,daily_end,suggested_item_id,sort_order) VALUES(NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
            $ins->execute([(int)$row['category_id'],$name,$row['description'],$row['price'],$row['image_path'],0,0,'inactive',0,0,(int)$row['featured'],1,$row['sellable_kind'],(int)$row['takeaway_allowed'],$row['preparation_station'],$row['schedule_start'],$row['schedule_end'],$row['schedule_days'],$row['daily_start'],$row['daily_end'],$row['suggested_item_id'],(int)$row['sort_order']+10]);
            $newId=(int)$this->pdo->lastInsertId();$this->pdo->prepare('UPDATE items SET item_code=? WHERE id=?')->execute(['ITEM-'.$newId,$newId]);
            $menus=$this->itemMenuIdsTx($id);$this->setItemMenusTx($newId,$menus);$tags=$this->itemTagIdsTx($id);$this->setItemTagsTx($newId,$tags);
            if(str_starts_with((string)($row['image_path']??''),'media:')){$key=substr((string)$row['image_path'],6);$mq=$this->pdo->prepare('SELECT id FROM guest_media_assets WHERE media_key=? AND active=1');$mq->execute([$key]);$mid=(int)($mq->fetchColumn()?:0);if($mid>0)$this->pdo->prepare("INSERT IGNORE INTO guest_media_references(media_id,owner_type,owner_id,slot_key) VALUES(?,'item',?,'card')")->execute([$mid,(string)$newId]);}
            $this->audit('catalog.item_copied','menu_item',$newId,(int)$admin['id'],['source_item_id'=>$id,'name'=>$name]);$this->pdo->commit();return ['id'=>$newId];
        }catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function bulkUpdateItems(array $data,array $actor): array
    {
        $admin=$this->assertAdmin($actor);$ids=$this->intList($data['ids']??[]);if($ids===[])throw new CatalogAdminException('bulk_items','حداقل یک آیتم انتخاب کن.',422);
        $field=(string)($data['field']??'');$allowed=['available','featured','guest_visible','staff_visible'];if(!in_array($field,$allowed,true))throw new CatalogAdminException('bulk_field','عملیات گروهی معتبر نیست.',422);$enabled=$this->bool($data['enabled']??false);
        $ph=implode(',',array_fill(0,count($ids),'?'));$this->pdo->beginTransaction();try{$q=$this->pdo->prepare("SELECT id,lifecycle_status FROM items WHERE id IN($ph) FOR UPDATE");$q->execute($ids);$rows=$q->fetchAll(PDO::FETCH_ASSOC);$found=array_map(static fn(array $row):int=>(int)$row['id'],$rows);if(count($found)!==count($ids))throw new CatalogAdminException('item_missing','یکی از آیتم‌های انتخاب‌شده پیدا نشد.',404);if($field==='available'&&$enabled){$blocked=array_values(array_filter($rows,static fn(array $row):bool=>(string)($row['lifecycle_status']??'active')!=='active'));if($blocked!==[])throw new CatalogAdminException('item_inactive','برای موجود کردن گروهی، همه آیتم‌های انتخاب‌شده باید فعال باشند.',409);}$sql='UPDATE items SET '.$field.'=? WHERE id IN('.$ph.')';$u=$this->pdo->prepare($sql);$u->execute(array_merge([$enabled?1:0],$ids));$this->audit('catalog.items_bulk_updated','menu_item',0,(int)$admin['id'],['ids'=>$ids,'field'=>$field,'enabled'=>$enabled]);$this->pdo->commit();return ['ids'=>$ids,'field'=>$field,'enabled'=>$enabled,'changed'=>$u->rowCount()];}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function reorderCategoriesForMenu(int $menuId,array $orderedIds,array $actor): array
    {
        $admin=$this->assertAdmin($actor);if($menuId<1)throw new CatalogAdminException('menu_missing','منو معتبر نیست.',422);$ids=$this->intList($orderedIds??[]);$this->pdo->beginTransaction();try{$q=$this->pdo->prepare("SELECT mc.category_id FROM menu_categories mc JOIN categories c ON c.id=mc.category_id WHERE mc.menu_id=? AND c.lifecycle_status<>'retired' ORDER BY mc.sort_order,mc.category_id FOR UPDATE");$q->execute([$menuId]);$current=array_map('intval',$q->fetchAll(PDO::FETCH_COLUMN));$a=$current;$b=$ids;sort($a);sort($b);if($a!==$b)throw new CatalogAdminException('category_reorder_set','فهرست دسته‌ها با عضویت این منو یکسان نیست.',409);$u=$this->pdo->prepare('UPDATE menu_categories SET sort_order=? WHERE menu_id=? AND category_id=?');foreach($ids as $idx=>$cid)$u->execute([($idx+1)*10,$menuId,$cid]);$this->audit('catalog.categories_reordered','menu',$menuId,(int)$admin['id'],['category_ids'=>$ids]);$this->pdo->commit();return ['menu_id'=>$menuId,'category_ids'=>$ids];}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function reorderItemsForCategory(int $categoryId,array $orderedIds,array $actor): array
    {
        $admin=$this->assertAdmin($actor);if($categoryId<1)throw new CatalogAdminException('category_missing','دسته‌بندی معتبر نیست.',422);$ids=$this->intList($orderedIds??[]);$this->pdo->beginTransaction();try{$q=$this->pdo->prepare("SELECT id FROM items WHERE category_id=? AND lifecycle_status<>'retired' ORDER BY sort_order,id FOR UPDATE");$q->execute([$categoryId]);$current=array_map('intval',$q->fetchAll(PDO::FETCH_COLUMN));$a=$current;$b=$ids;sort($a);sort($b);if($a!==$b)throw new CatalogAdminException('item_reorder_set','فهرست آیتم‌ها با این دسته یکسان نیست.',409);$u=$this->pdo->prepare('UPDATE items SET sort_order=? WHERE id=? AND category_id=?');foreach($ids as $idx=>$iid)$u->execute([($idx+1)*10,$iid,$categoryId]);$this->audit('catalog.items_reordered','category',$categoryId,(int)$admin['id'],['item_ids'=>$ids]);$this->pdo->commit();return ['category_id'=>$categoryId,'item_ids'=>$ids];}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function exportBundle(array $actor): array
    {
        $this->assertAdmin($actor);$snap=$this->snapshot($actor);
        return [
            'format'=>'sokna-catalog-transfer-v2','generated_at'=>gmdate('c'),
            'menus'=>$snap['menus'],
            'categories'=>array_values(array_merge($snap['categories'],$snap['archived_categories']??[])),
            'items'=>array_values(array_merge($snap['items'],$snap['archived_items']??[])),
            'tags'=>$snap['tags'],
            'variant_families'=>$snap['variant_families']??[],
            'suggestions'=>$snap['suggestions']??[],
            'bundles'=>$snap['bundles']??[],
        ];
    }

    public function previewImport(array $bundle,array $actor): array
    {
        $this->assertAdmin($actor);$this->validateTransfer($bundle);$v2=(string)($bundle['format']??'')==='sokna-catalog-transfer-v2';
        return ['format'=>(string)$bundle['format'],'menus'=>count($bundle['menus']),'categories'=>count($bundle['categories']),'items'=>count($bundle['items']),'tags'=>count($bundle['tags']??[]),'variant_families'=>$v2?count($bundle['variant_families']??[]):0,'mode'=>'merge_by_internal_key','warning'=>'رکوردهای هم‌کلید به‌روزرسانی می‌شوند و رکوردهای جدید ساخته می‌شوند؛ تاریخچه حذف نمی‌شود.'];
    }

    public function applyImport(array $bundle,array $actor): array
    {
        $admin=$this->assertAdmin($actor);$this->validateTransfer($bundle);$v2=(string)($bundle['format']??'')==='sokna-catalog-transfer-v2';$this->pdo->beginTransaction();try{
            $menuMap=[];foreach($bundle['menus'] as $m){$key=$this->transferKey($m['menu_key']??'');$name=$this->text($m['name']??'',120);$status=in_array(($m['status']??''),self::MENU_STATUSES,true)?(string)$m['status']:'draft';$q=$this->pdo->prepare('SELECT id FROM menus WHERE menu_key=? FOR UPDATE');$q->execute([$key]);$id=(int)($q->fetchColumn()?:0);$vals=[$name,$status,(int)($m['sort_order']??0),$this->csvDays($m['schedule_days']??[]),$this->time($m['daily_start']??null),$this->time($m['daily_end']??null)];if($id)$this->pdo->prepare('UPDATE menus SET name=?,status=?,sort_order=?,schedule_days=?,daily_start=?,daily_end=? WHERE id=?')->execute(array_merge($vals,[$id]));else{$this->pdo->prepare('INSERT INTO menus(menu_key,name,status,sort_order,schedule_days,daily_start,daily_end) VALUES(?,?,?,?,?,?,?)')->execute(array_merge([$key],$vals));$id=(int)$this->pdo->lastInsertId();}$menuMap[(string)($m['id']??$key)]=$id;$menuMap[$key]=$id;}
            $tagMap=[];foreach(($bundle['tags']??[]) as $t){$key=$this->transferKey($t['tag_key']??'');$name=$this->text($t['name']??'',120);$q=$this->pdo->prepare('SELECT id FROM catalog_tags WHERE tag_key=? FOR UPDATE');$q->execute([$key]);$id=(int)($q->fetchColumn()?:0);$vals=[$name,$this->bool($t['active']??true)?1:0,(int)($t['sort_order']??0)];if($id)$this->pdo->prepare('UPDATE catalog_tags SET name=?,active=?,sort_order=? WHERE id=?')->execute(array_merge($vals,[$id]));else{$this->pdo->prepare('INSERT INTO catalog_tags(tag_key,name,active,sort_order) VALUES(?,?,?,?)')->execute(array_merge([$key],$vals));$id=(int)$this->pdo->lastInsertId();}$tagMap[(string)($t['id']??$key)]=$id;$tagMap[$key]=$id;}
            $categoryMap=[];foreach($bundle['categories'] as $c){$key=$this->transferKey($c['category_key']??'');$name=$this->text($c['name']??'',120);$lc=$v2&&in_array((string)($c['lifecycle_status']??''),self::LIFECYCLES,true)?(string)$c['lifecycle_status']:($this->bool($c['active']??true)?'active':'inactive');$guest=$v2?$this->bool($c['guest_visible']??true):((string)($c['audience']??'guest_staff')!=='staff_only');$staff=$v2?$this->bool($c['staff_visible']??true):true;$active=$lc==='active';$aud=$guest?'guest_staff':'staff_only';$q=$this->pdo->prepare('SELECT id FROM categories WHERE category_key=? FOR UPDATE');$q->execute([$key]);$id=(int)($q->fetchColumn()?:0);$vals=[$name,$aud,$this->nullableText($c['image_path']??null,255),$this->nullableText($c['icon_key']??null,40),(int)($c['sort_order']??0),$active?1:0,$lc,$guest?1:0,$staff?1:0,$lc==='retired'?($this->dateTime($c['retired_at']??null)??date('Y-m-d H:i:s')):null,$lc==='retired'?$this->nullableText($c['retired_note']??null,1000):null];if($id)$this->pdo->prepare('UPDATE categories SET name=?,audience=?,image_path=?,icon_key=?,sort_order=?,active=?,lifecycle_status=?,guest_visible=?,staff_visible=?,retired_at=?,retired_note=? WHERE id=?')->execute(array_merge($vals,[$id]));else{$this->pdo->prepare('INSERT INTO categories(category_key,name,audience,image_path,icon_key,sort_order,active,lifecycle_status,guest_visible,staff_visible,retired_at,retired_note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)')->execute(array_merge([$key],$vals));$id=(int)$this->pdo->lastInsertId();}$categoryMap[(string)($c['id']??$key)]=$id;$categoryMap[$key]=$id;$mapped=[];foreach(($c['menu_ids']??[]) as $old)if(isset($menuMap[(string)$old]))$mapped[]=$menuMap[(string)$old];$this->setCategoryMenusTx($id,array_values(array_unique($mapped)));foreach((array)($c['menu_sort_orders']??[]) as $oldMenu=>$order)if(isset($menuMap[(string)$oldMenu]))$this->pdo->prepare('UPDATE menu_categories SET sort_order=? WHERE menu_id=? AND category_id=?')->execute([(int)$order,$menuMap[(string)$oldMenu],$id]);}
            $itemMap=[];$itemCount=0;foreach($bundle['items'] as $i){$code=trim((string)($i['item_code']??''));$cat=$categoryMap[(string)($i['category_id']??'')]??0;if($cat<1)continue;$name=$this->text($i['name']??'',160);$lc=$v2&&in_array((string)($i['lifecycle_status']??''),self::LIFECYCLES,true)?(string)$i['lifecycle_status']:($this->bool($i['active']??true)?'active':'inactive');$guest=$v2?$this->bool($i['guest_visible']??!$this->bool($i['staff_only']??false)):!$this->bool($i['staff_only']??false);$staff=$v2?$this->bool($i['staff_visible']??true):true;$active=$lc==='active';$available=$active&&$this->bool($i['available']??true);$q=$code!==''?$this->pdo->prepare('SELECT id FROM items WHERE item_code=? FOR UPDATE'):null;if($q){$q->execute([$code]);$id=(int)($q->fetchColumn()?:0);}else $id=0;$vals=[$cat,$name,$this->nullableText($i['description']??null,2000),$this->amount($i['price']??0),$this->nullableText($i['image_path']??null,255),$available?1:0,$active?1:0,$lc,$guest?1:0,$staff?1:0,$this->bool($i['featured']??false)?1:0,$guest?0:1,SellableKind::requireWrite($i['sellable_kind']??SellableKind::MENU_ITEM),$this->bool($i['takeaway_allowed']??true)?1:0,$this->normalizeStation((string)($i['preparation_station']??'cold_bar')),$this->dateTime($i['schedule_start']??null),$this->dateTime($i['schedule_end']??null),$this->csvDays($i['schedule_days']??[]),$this->time($i['daily_start']??null),$this->time($i['daily_end']??null),(int)($i['sort_order']??0),$lc==='retired'?($this->dateTime($i['retired_at']??null)??date('Y-m-d H:i:s')):null,$lc==='retired'?$this->nullableText($i['retired_note']??null,1000):null];if($id)$this->pdo->prepare('UPDATE items SET category_id=?,name=?,description=?,price=?,image_path=?,available=?,active=?,lifecycle_status=?,guest_visible=?,staff_visible=?,featured=?,staff_only=?,sellable_kind=?,takeaway_allowed=?,preparation_station=?,schedule_start=?,schedule_end=?,schedule_days=?,daily_start=?,daily_end=?,sort_order=?,retired_at=?,retired_note=? WHERE id=?')->execute(array_merge($vals,[$id]));else{$this->pdo->prepare('INSERT INTO items(item_code,category_id,name,description,price,image_path,available,active,lifecycle_status,guest_visible,staff_visible,featured,staff_only,sellable_kind,takeaway_allowed,preparation_station,schedule_start,schedule_end,schedule_days,daily_start,daily_end,sort_order,retired_at,retired_note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute(array_merge([$code!==''?$code:null],$vals));$id=(int)$this->pdo->lastInsertId();if($code==='')$this->pdo->prepare('UPDATE items SET item_code=? WHERE id=?')->execute(['ITEM-'.$id,$id]);}$itemMap[(string)($i['id']??$code)]=$id;if($code!=='')$itemMap[$code]=$id;$mappedMenus=[];foreach(($i['menu_ids']??[]) as $old)if(isset($menuMap[(string)$old]))$mappedMenus[]=$menuMap[(string)$old];$allowed=$this->categoryMenuIdsTx($cat);$this->setItemMenusTx($id,array_values(array_intersect($mappedMenus,$allowed)));$mappedTags=[];foreach(($i['tag_ids']??[]) as $old)if(isset($tagMap[(string)$old]))$mappedTags[]=$tagMap[(string)$old];$this->setItemTagsTx($id,$mappedTags);$itemCount++;}
            if($v2){foreach(($bundle['variant_families']??[]) as $f){$members=[];foreach(($f['members']??[]) as $m){$mapped=$itemMap[(string)($m['item_id']??'')]??0;if($mapped>0)$members[]=['item_id'=>$mapped,'label'=>$this->text($m['label']??'',80),'sort_order'=>(int)($m['sort_order']??0)];}if(count($members)<2)continue;$cat=$categoryMap[(string)($f['category_id']??'')]??0;if($cat<1)continue;$key=$this->transferKey($f['family_key']??('family-'.bin2hex(random_bytes(6))));$q=$this->pdo->prepare('SELECT id FROM item_variant_families WHERE family_key=? FOR UPDATE');$q->execute([$key]);$fid=(int)($q->fetchColumn()?:0);$vals=[$cat,$this->text($f['name']??'',160),$this->nullableText($f['description']??null,2000),$this->nullableText($f['image_path']??null,255),(int)($f['sort_order']??0),$this->bool($f['featured']??false)?1:0];if($fid)$this->pdo->prepare('UPDATE item_variant_families SET category_id=?,name=?,description=?,image_path=?,sort_order=?,featured=?,active=1 WHERE id=?')->execute(array_merge($vals,[$fid]));else{$this->pdo->prepare('INSERT INTO item_variant_families(family_key,category_id,name,description,image_path,sort_order,featured,active) VALUES(?,?,?,?,?,?,?,1)')->execute(array_merge([$key],$vals));$fid=(int)$this->pdo->lastInsertId();}$this->pdo->prepare('DELETE FROM item_variant_members WHERE family_id=?')->execute([$fid]);$ins=$this->pdo->prepare('INSERT INTO item_variant_members(family_id,item_id,label,sort_order) VALUES(?,?,?,?)');foreach($members as $m)$ins->execute([$fid,$m['item_id'],$m['label'],$m['sort_order']]);}
                foreach(($bundle['suggestions']??[]) as $oldSource=>$targets){$src=$itemMap[(string)$oldSource]??0;if($src<1)continue;$this->pdo->prepare('DELETE FROM item_suggestions WHERE source_item_id=?')->execute([$src]);$ins=$this->pdo->prepare('INSERT INTO item_suggestions(source_item_id,suggested_item_id,sort_order,active) VALUES(?,?,?,1)');$seen=[];foreach(array_slice((array)$targets,0,2) as $idx=>$oldTarget){$dst=$itemMap[(string)$oldTarget]??0;if($dst<1||$dst===$src||isset($seen[$dst]))continue;$seen[$dst]=1;$ins->execute([$src,$dst,($idx+1)*10]);}}
                foreach(($bundle['bundles']??[]) as $oldParent=>$b){$parent=$itemMap[(string)($b['bundle_item_id']??$oldParent)]??0;if($parent<1)continue;$comps=[];foreach(($b['components']??[]) as $c){$cid=$itemMap[(string)($c['component_item_id']??'')]??0;if($cid<1||$cid===$parent)continue;$comps[]=['id'=>$cid,'mode'=>in_array((string)($c['mode']??''),['fixed','choice'],true)?(string)$c['mode']:'fixed','qty'=>max(1,(int)($c['quantity']??1)),'delta'=>(int)($c['price_delta']??0),'sort'=>(int)($c['sort_order']??0)];}if(!$comps)continue;$this->pdo->prepare('INSERT INTO item_bundles(bundle_item_id,choice_label,choice_min,choice_max) VALUES(?,?,1,1) ON DUPLICATE KEY UPDATE choice_label=VALUES(choice_label),choice_min=1,choice_max=1')->execute([$parent,$this->nullableText($b['choice_label']??null,160)]);$this->pdo->prepare('DELETE FROM item_bundle_components WHERE bundle_item_id=?')->execute([$parent]);$ins=$this->pdo->prepare('INSERT INTO item_bundle_components(bundle_item_id,component_item_id,mode,quantity,price_delta,sort_order) VALUES(?,?,?,?,?,?)');foreach($comps as $c)$ins->execute([$parent,$c['id'],$c['mode'],$c['qty'],$c['delta'],$c['sort']]);}}
            $this->audit('catalog.transfer_imported','catalog',0,(int)$admin['id'],['format'=>(string)$bundle['format'],'menus'=>count($bundle['menus']),'categories'=>count($bundle['categories']),'items'=>$itemCount,'tags'=>count($bundle['tags']??[])]);$this->pdo->commit();return ['imported'=>true,'format'=>(string)$bundle['format'],'menus'=>count($bundle['menus']),'categories'=>count($bundle['categories']),'items'=>$itemCount,'tags'=>count($bundle['tags']??[])];
        }catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function setItemState(int $id,string $field,bool $enabled,array $actor): array
    {
        $admin=$this->assertAdmin($actor);if($id<1||!in_array($field,['available'],true))throw new CatalogAdminException('item_state','آیتم یا وضعیت معتبر نیست.',422);
        $this->pdo->beginTransaction();try{$q=$this->pdo->prepare('SELECT id,name,available,lifecycle_status FROM items WHERE id=? FOR UPDATE');$q->execute([$id]);$row=$q->fetch(PDO::FETCH_ASSOC);if(!is_array($row))throw new CatalogAdminException('item_missing','آیتم پیدا نشد.',404);$lifecycle=(string)($row['lifecycle_status']??'active');if($lifecycle==='retired')throw new CatalogAdminException('item_retired','آیتم آرشیوشده باید ابتدا به کاتالوگ بازگردانده شود.',409);if($field==='available'&&$enabled&&$lifecycle!=='active')throw new CatalogAdminException('item_inactive','برای موجود کردن آیتم، ابتدا آن را فعال کن.',409);$before=(int)$row[$field]===1;if($before!==$enabled){$sql='UPDATE items SET '.$field.'=? WHERE id=?';$this->pdo->prepare($sql)->execute([$enabled?1:0,$id]);$this->audit('catalog.item_'.$field.'_changed','menu_item',$id,(int)$admin['id'],['name'=>(string)$row['name'],'before'=>$before,'after'=>$enabled]);}$this->pdo->commit();return ['id'=>$id,'field'=>$field,'enabled'=>$enabled,'changed'=>$before!==$enabled];}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function setItemLifecycleState(int $id,bool $enabled,array $actor): array
    {
        $admin=$this->assertAdmin($actor);if($id<1)throw new CatalogAdminException('item_state','آیتم معتبر نیست.',422);
        $this->pdo->beginTransaction();try{$q=$this->pdo->prepare('SELECT id,name,lifecycle_status,active,available FROM items WHERE id=? FOR UPDATE');$q->execute([$id]);$row=$q->fetch(PDO::FETCH_ASSOC);if(!is_array($row))throw new CatalogAdminException('item_missing','آیتم پیدا نشد.',404);$before=(string)($row['lifecycle_status']??'active');if($before==='retired')throw new CatalogAdminException('item_retired','آیتم آرشیوشده باید ابتدا به کاتالوگ بازگردانده شود.',409);$after=$enabled?'active':'inactive';$availableBefore=(int)($row['available']??0)===1;if($before!==$after||(!$enabled&&$availableBefore)){$this->pdo->prepare('UPDATE items SET lifecycle_status=?,active=?,available=? WHERE id=?')->execute([$after,$enabled?1:0,$enabled?($availableBefore?1:0):0,$id]);$this->audit('catalog.item_lifecycle_changed','menu_item',$id,(int)$admin['id'],['name'=>(string)$row['name'],'before'=>$before,'after'=>$after,'available_before'=>$availableBefore,'available_after'=>$enabled?$availableBefore:false]);}$this->pdo->commit();return ['id'=>$id,'lifecycle_status'=>$after,'active'=>$enabled,'available'=>$enabled?$availableBefore:false,'changed'=>$before!==$after||(!$enabled&&$availableBefore)];}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }


    public function retireItem(int $id,?string $note,array $actor): array
    {
        $admin=$this->assertAdmin($actor);if($id<1)throw new CatalogAdminException('item_invalid','آیتم معتبر نیست.',422);
        $this->pdo->beginTransaction();try{$q=$this->pdo->prepare('SELECT id,name,lifecycle_status FROM items WHERE id=? FOR UPDATE');$q->execute([$id]);$row=$q->fetch(PDO::FETCH_ASSOC);if(!is_array($row))throw new CatalogAdminException('item_missing','آیتم پیدا نشد.',404);if((string)$row['lifecycle_status']!=='retired'){$n=$this->nullableText($note,1000);$this->pdo->prepare("UPDATE items SET lifecycle_status='retired',active=0,available=0,guest_visible=0,staff_visible=0,staff_only=1,retired_at=NOW(),retired_note=? WHERE id=?")->execute([$n,$id]);$this->audit('catalog.item_retired','menu_item',$id,(int)$admin['id'],['name'=>$row['name'],'note'=>$n]);}$this->pdo->commit();return ['id'=>$id,'lifecycle_status'=>'retired'];}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function restoreItem(int $id,array $actor): array
    {
        $admin=$this->assertAdmin($actor);if($id<1)throw new CatalogAdminException('item_invalid','آیتم معتبر نیست.',422);
        $this->pdo->beginTransaction();try{$q=$this->pdo->prepare("SELECT id,name,lifecycle_status FROM items WHERE id=? FOR UPDATE");$q->execute([$id]);$row=$q->fetch(PDO::FETCH_ASSOC);if(!is_array($row))throw new CatalogAdminException('item_missing','آیتم پیدا نشد.',404);if((string)$row['lifecycle_status']!=='retired')throw new CatalogAdminException('item_not_retired','این آیتم در آرشیو نیست.',409);$this->pdo->prepare("UPDATE items SET lifecycle_status='inactive',active=0,available=0,guest_visible=0,staff_visible=0,staff_only=1,retired_at=NULL WHERE id=?")->execute([$id]);$this->audit('catalog.item_restored','menu_item',$id,(int)$admin['id'],['name'=>$row['name'],'result'=>'inactive_safe_defaults']);$this->pdo->commit();return ['id'=>$id,'lifecycle_status'=>'inactive','guest_visible'=>false,'staff_visible'=>false,'available'=>false];}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function retireCategory(int $id,?string $note,array $actor): array
    {
        $admin=$this->assertAdmin($actor);if($id<1)throw new CatalogAdminException('category_invalid','دسته معتبر نیست.',422);
        $this->pdo->beginTransaction();try{$q=$this->pdo->prepare('SELECT id,name,lifecycle_status FROM categories WHERE id=? FOR UPDATE');$q->execute([$id]);$row=$q->fetch(PDO::FETCH_ASSOC);if(!is_array($row))throw new CatalogAdminException('category_missing','دسته پیدا نشد.',404);$live=$this->pdo->prepare("SELECT COUNT(*) FROM items WHERE category_id=? AND lifecycle_status<>'retired'");$live->execute([$id]);if((int)$live->fetchColumn()>0)throw new CatalogAdminException('category_not_empty','قبل از آرشیو دسته، آیتم‌های جاری آن را منتقل یا آرشیو کن.',409);$n=$this->nullableText($note,1000);$this->pdo->prepare("UPDATE categories SET lifecycle_status='retired',active=0,guest_visible=0,staff_visible=0,retired_at=NOW(),retired_note=? WHERE id=?")->execute([$n,$id]);$this->audit('catalog.category_retired','category',$id,(int)$admin['id'],['name'=>$row['name'],'note'=>$n]);$this->pdo->commit();return ['id'=>$id,'lifecycle_status'=>'retired'];}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function restoreCategory(int $id,array $actor): array
    {
        $admin=$this->assertAdmin($actor);if($id<1)throw new CatalogAdminException('category_invalid','دسته معتبر نیست.',422);
        $this->pdo->beginTransaction();try{$q=$this->pdo->prepare('SELECT id,name,lifecycle_status FROM categories WHERE id=? FOR UPDATE');$q->execute([$id]);$row=$q->fetch(PDO::FETCH_ASSOC);if(!is_array($row))throw new CatalogAdminException('category_missing','دسته پیدا نشد.',404);if((string)$row['lifecycle_status']!=='retired')throw new CatalogAdminException('category_not_retired','این دسته در آرشیو نیست.',409);$this->pdo->prepare("UPDATE categories SET lifecycle_status='inactive',active=0,guest_visible=0,staff_visible=0,retired_at=NULL WHERE id=?")->execute([$id]);$this->audit('catalog.category_restored','category',$id,(int)$admin['id'],['name'=>$row['name'],'result'=>'inactive_safe_defaults']);$this->pdo->commit();return ['id'=>$id,'lifecycle_status'=>'inactive'];}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function saveVariantFamily(array $data,array $actor): array
    {
        $admin=$this->assertAdmin($actor);$id=(int)($data['id']??0);$name=$this->text($data['name']??'',160);$categoryId=(int)($data['category_id']??0);$description=$this->nullableText($data['description']??null,2000);$sort=(int)($data['sort_order']??0);$featured=$this->bool($data['featured']??false);$members=is_array($data['members']??null)?$data['members']:[];
        if($name===''||$categoryId<1||count($members)<2||count($members)>8)throw new CatalogAdminException('variant_family_invalid','خانواده باید نام، دسته و حداقل دو گزینه سایز/مدل داشته باشد.',422);
        $normalized=[];foreach($members as $m){if(!is_array($m))throw new CatalogAdminException('variant_member_invalid','برای هر گزینه سایز/مدل آیتم و عنوان معتبر لازم است.',422);$itemId=(int)($m['item_id']??0);$label=$this->text($m['label']??'',80);if($itemId<1||$label==='')throw new CatalogAdminException('variant_member_invalid','برای هر گزینه سایز/مدل آیتم و عنوان معتبر لازم است.',422);if(isset($normalized[$itemId]))throw new CatalogAdminException('variant_member_duplicate','یک آیتم نمی‌تواند دو بار عضو خانواده باشد.',409);$normalized[$itemId]=['label'=>$label,'sort_order'=>(int)($m['sort_order']??((count($normalized)+1)*10))];}
        if(count($normalized)<2)throw new CatalogAdminException('variant_family_invalid','خانواده سایز/مدل باید حداقل دو گزینه معتبر داشته باشد.',422);$this->pdo->beginTransaction();try{$c=$this->pdo->prepare("SELECT id FROM categories WHERE id=? AND lifecycle_status<>'retired' FOR UPDATE");$c->execute([$categoryId]);if(!$c->fetchColumn())throw new CatalogAdminException('category_missing','دسته خانواده معتبر نیست.',422);$ids=array_keys($normalized);$ph=implode(',',array_fill(0,count($ids),'?'));$q=$this->pdo->prepare("SELECT id,category_id,lifecycle_status FROM items WHERE id IN($ph) FOR UPDATE");$q->execute($ids);$rows=$q->fetchAll(PDO::FETCH_ASSOC);if(count($rows)!==count($ids))throw new CatalogAdminException('variant_item_missing','یکی از گزینه‌های سایز/مدل پیدا نشد.',404);foreach($rows as $r){if((string)$r['lifecycle_status']==='retired')throw new CatalogAdminException('variant_item_retired','آیتم آرشیوشده نمی‌تواند عضو خانواده سایز/مدل باشد.',409);if((int)$r['category_id']!==$categoryId)throw new CatalogAdminException('variant_category_mismatch','همه گزینه‌های سایز/مدل یک خانواده باید در همان دسته باشند.',409);}$conf=$this->pdo->prepare("SELECT item_id FROM item_variant_members WHERE item_id IN($ph)".($id>0?' AND family_id<>?':'').' LIMIT 1');$args=$ids;if($id>0)$args[]=$id;$conf->execute($args);if($conf->fetchColumn()!==false)throw new CatalogAdminException('variant_item_owned','یکی از آیتم‌ها عضو خانواده دیگری است.',409);
            if($id>0){$q=$this->pdo->prepare('SELECT id,family_key FROM item_variant_families WHERE id=? FOR UPDATE');$q->execute([$id]);$row=$q->fetch(PDO::FETCH_ASSOC);if(!is_array($row))throw new CatalogAdminException('variant_family_missing','خانواده پیدا نشد.',404);$this->pdo->prepare('UPDATE item_variant_families SET category_id=?,name=?,description=?,sort_order=?,featured=?,active=1 WHERE id=?')->execute([$categoryId,$name,$description,$sort,$featured?1:0,$id]);}
            else{$key='family-'.bin2hex(random_bytes(8));$this->pdo->prepare('INSERT INTO item_variant_families(family_key,category_id,name,description,sort_order,featured,active) VALUES(?,?,?,?,?,?,1)')->execute([$key,$categoryId,$name,$description,$sort,$featured?1:0]);$id=(int)$this->pdo->lastInsertId();}
            $this->pdo->prepare('DELETE FROM item_variant_members WHERE family_id=?')->execute([$id]);$ins=$this->pdo->prepare('INSERT INTO item_variant_members(family_id,item_id,label,sort_order) VALUES(?,?,?,?)');foreach($normalized as $itemId=>$m)$ins->execute([$id,$itemId,$m['label'],$m['sort_order']]);$this->audit('catalog.variant_family_saved','variant_family',$id,(int)$admin['id'],['name'=>$name,'category_id'=>$categoryId,'item_ids'=>array_keys($normalized)]);$this->pdo->commit();return ['id'=>$id];
        }catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function removeVariantFamily(int $id,array $actor): array
    {
        $admin=$this->assertAdmin($actor);if($id<1)throw new CatalogAdminException('variant_family_invalid','خانواده معتبر نیست.',422);
        $this->pdo->beginTransaction();try{$q=$this->pdo->prepare('SELECT id,name FROM item_variant_families WHERE id=? FOR UPDATE');$q->execute([$id]);$row=$q->fetch(PDO::FETCH_ASSOC);if(!is_array($row))throw new CatalogAdminException('variant_family_missing','خانواده پیدا نشد.',404);$this->pdo->prepare('DELETE FROM item_variant_families WHERE id=?')->execute([$id]);$this->audit('catalog.variant_family_removed','variant_family',$id,(int)$admin['id'],['name'=>$row['name']]);$this->pdo->commit();return ['id'=>$id,'removed'=>true];}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function saveSuggestions(int $sourceItemId,array $suggestedIds,array $actor): array
    {
        $admin=$this->assertAdmin($actor);$ids=$this->intList($suggestedIds);if($sourceItemId<1||count($ids)>2||in_array($sourceItemId,$ids,true))throw new CatalogAdminException('suggestion_invalid','برای هر آیتم حداکثر دو پیشنهاد متفاوت انتخاب کن.',422);
        $this->pdo->beginTransaction();try{$all=array_values(array_unique(array_merge([$sourceItemId],$ids)));$ph=implode(',',array_fill(0,count($all),'?'));$q=$this->pdo->prepare("SELECT id,lifecycle_status FROM items WHERE id IN($ph) FOR UPDATE");$q->execute($all);$rows=$q->fetchAll(PDO::FETCH_ASSOC);if(count($rows)!==count($all))throw new CatalogAdminException('suggestion_item_missing','یکی از آیتم‌های پیشنهاد پیدا نشد.',404);foreach($rows as $r)if((string)$r['lifecycle_status']==='retired')throw new CatalogAdminException('suggestion_item_retired','آیتم آرشیوشده قابل پیشنهاد نیست.',409);$this->pdo->prepare('DELETE FROM item_suggestions WHERE source_item_id=?')->execute([$sourceItemId]);$ins=$this->pdo->prepare('INSERT INTO item_suggestions(source_item_id,suggested_item_id,sort_order,active) VALUES(?,?,?,1)');foreach($ids as $i=>$target)$ins->execute([$sourceItemId,$target,($i+1)*10]);$this->audit('catalog.suggestions_saved','menu_item',$sourceItemId,(int)$admin['id'],['suggested_item_ids'=>$ids]);$this->pdo->commit();return ['source_item_id'=>$sourceItemId,'suggested_item_ids'=>$ids];}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function saveBundle(array $data,array $actor): array
    {
        $admin=$this->assertAdmin($actor);$bundleItemId=(int)($data['bundle_item_id']??0);$choiceLabel=$this->nullableText($data['choice_label']??null,160);$components=is_array($data['components']??null)?$data['components']:[];if($bundleItemId<1||$components===[]||count($components)>20)throw new CatalogAdminException('bundle_invalid','ترکیب باید parent و حداقل یک جزء داشته باشد.',422);$norm=[];$choice=0;
        foreach($components as $row){if(!is_array($row))throw new CatalogAdminException('bundle_component_invalid','جزء ترکیب باید اطلاعات معتبر داشته باشد.',422);$itemId=(int)($row['component_item_id']??0);$mode=(string)($row['mode']??'fixed');$qty=$this->strictBundleQuantity($row['quantity']??1);$delta=$this->strictBundlePriceDelta($row['price_delta']??0);if($itemId<1||$itemId===$bundleItemId||!in_array($mode,['fixed','choice'],true))throw new CatalogAdminException('bundle_component_invalid','جزء ترکیب معتبر نیست.',422);$key=$itemId.':'.$mode;if(isset($norm[$key]))throw new CatalogAdminException('bundle_component_duplicate','جزء تکراری در ترکیب وجود دارد.',409);$norm[$key]=['component_item_id'=>$itemId,'mode'=>$mode,'quantity'=>$qty,'price_delta'=>$delta,'sort_order'=>(int)($row['sort_order']??((count($norm)+1)*10))];if($mode==='choice')$choice++;}
        if($norm===[])throw new CatalogAdminException('bundle_invalid','ترکیب بدون جزء معتبر قابل ذخیره نیست.',422);if($choice>0&&$choiceLabel===null)$choiceLabel='انتخاب';
        $this->pdo->beginTransaction();try{$ids=array_values(array_unique(array_merge([$bundleItemId],array_column($norm,'component_item_id'))));$ph=implode(',',array_fill(0,count($ids),'?'));$q=$this->pdo->prepare("SELECT i.id,i.lifecycle_status,i.guest_visible,i.staff_visible,EXISTS(SELECT 1 FROM item_bundles b WHERE b.bundle_item_id=i.id) is_bundle FROM items i WHERE i.id IN($ph) FOR UPDATE");$q->execute($ids);$rows=$q->fetchAll(PDO::FETCH_ASSOC);if(count($rows)!==count($ids))throw new CatalogAdminException('bundle_item_missing','یکی از آیتم‌های ترکیب پیدا نشد.',404);$byId=[];foreach($rows as $r)$byId[(int)$r['id']]=$r;$parent=$byId[$bundleItemId]??null;if(!is_array($parent)||((string)$parent['lifecycle_status']==='retired'))throw new CatalogAdminException('bundle_parent_invalid','آیتم اصلی ترکیب معتبر نیست.',409);foreach($rows as $r){$rid=(int)$r['id'];if($rid===$bundleItemId)continue;if((string)$r['lifecycle_status']!=='active')throw new CatalogAdminException('bundle_component_inactive','جزء ترکیب باید در کاتالوگ فعال باشد.',409);if((int)$r['is_bundle']===1)throw new CatalogAdminException('nested_bundle','ترکیب تو در تو مجاز نیست.',409);if((int)$parent['guest_visible']===1&&(int)$r['guest_visible']!==1)throw new CatalogAdminException('bundle_guest_visibility','جزء ترکیب مهمان باید برای مهمان قابل نمایش باشد.',409);if((int)$parent['staff_visible']===1&&(int)$r['staff_visible']!==1)throw new CatalogAdminException('bundle_staff_visibility','جزء ترکیب کارکنان باید برای کارکنان قابل نمایش باشد.',409);}$this->pdo->prepare('INSERT INTO item_bundles(bundle_item_id,choice_label,choice_min,choice_max) VALUES(?,?,1,1) ON DUPLICATE KEY UPDATE choice_label=VALUES(choice_label),choice_min=1,choice_max=1')->execute([$bundleItemId,$choiceLabel]);$this->pdo->prepare('DELETE FROM item_bundle_components WHERE bundle_item_id=?')->execute([$bundleItemId]);$ins=$this->pdo->prepare('INSERT INTO item_bundle_components(bundle_item_id,component_item_id,mode,quantity,price_delta,sort_order) VALUES(?,?,?,?,?,?)');foreach($norm as $r)$ins->execute([$bundleItemId,$r['component_item_id'],$r['mode'],$r['quantity'],$r['price_delta'],$r['sort_order']]);$this->audit('catalog.bundle_saved','menu_item',$bundleItemId,(int)$admin['id'],['choice_label'=>$choiceLabel,'components'=>array_values($norm)]);$this->pdo->commit();return ['bundle_item_id'=>$bundleItemId];}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    public function removeBundle(int $bundleItemId,array $actor): array
    {
        $admin=$this->assertAdmin($actor);if($bundleItemId<1)throw new CatalogAdminException('bundle_invalid','ترکیب معتبر نیست.',422);$this->pdo->beginTransaction();try{$this->pdo->prepare('DELETE FROM item_bundles WHERE bundle_item_id=?')->execute([$bundleItemId]);$this->audit('catalog.bundle_removed','menu_item',$bundleItemId,(int)$admin['id'],[]);$this->pdo->commit();return ['bundle_item_id'=>$bundleItemId,'removed'=>true];}catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }

    private function strictBundleQuantity(mixed $value): int
    {
        if (!is_int($value) && !is_string($value)) throw new CatalogAdminException('bundle_quantity_invalid','تعداد جزء ترکیب باید عدد صحیح بین ۱ تا ۱۰۰ باشد.',422);
        $text=trim((string)$value);
        if (!preg_match('/^[0-9]{1,3}$/D',$text)) throw new CatalogAdminException('bundle_quantity_invalid','تعداد جزء ترکیب باید عدد صحیح بین ۱ تا ۱۰۰ باشد.',422);
        $qty=(int)$text;
        if ($qty<1 || $qty>100) throw new CatalogAdminException('bundle_quantity_invalid','تعداد جزء ترکیب باید عدد صحیح بین ۱ تا ۱۰۰ باشد.',422);
        return $qty;
    }
    private function strictBundlePriceDelta(mixed $value): int
    {
        if (!is_int($value) && !is_string($value)) throw new CatalogAdminException('bundle_price_invalid','تغییر قیمت جزء ترکیب باید عدد صحیح باشد.',422);
        $text=trim((string)$value);
        if (!preg_match('/^-?[0-9]{1,19}$/D',$text)) throw new CatalogAdminException('bundle_price_invalid','تغییر قیمت جزء ترکیب باید عدد صحیح باشد.',422);
        $delta=filter_var($text,FILTER_VALIDATE_INT);
        if ($delta === false) throw new CatalogAdminException('bundle_price_invalid','تغییر قیمت جزء ترکیب باید در محدوده مجاز باشد.',422);
        return $delta;
    }
    private function variantFamiliesSnapshot(): array
    {
        $rows=$this->pdo->query("SELECT f.*,m.item_id,m.label member_label,m.sort_order member_sort,i.name item_name,i.price,i.available,i.lifecycle_status FROM item_variant_families f LEFT JOIN item_variant_members m ON m.family_id=f.id LEFT JOIN items i ON i.id=m.item_id WHERE f.active=1 ORDER BY f.sort_order,f.id,m.sort_order,m.item_id")->fetchAll(PDO::FETCH_ASSOC)?:[];$out=[];foreach($rows as $r){$id=(int)$r['id'];if(!isset($out[$id]))$out[$id]=['id'=>$id,'family_key'=>(string)$r['family_key'],'category_id'=>(int)$r['category_id'],'name'=>(string)$r['name'],'description'=>$r['description'],'image_path'=>$r['image_path'],'sort_order'=>(int)$r['sort_order'],'featured'=>(int)$r['featured']===1,'members'=>[]];if($r['item_id']!==null)$out[$id]['members'][]=['item_id'=>(int)$r['item_id'],'label'=>(string)$r['member_label'],'sort_order'=>(int)$r['member_sort'],'item_name'=>(string)$r['item_name'],'price'=>(int)$r['price'],'available'=>(int)$r['available']===1,'lifecycle_status'=>(string)$r['lifecycle_status']];}return array_values($out);
    }
    private function suggestionsSnapshot(): array
    {
        $rows=$this->pdo->query("SELECT source_item_id,suggested_item_id,sort_order FROM item_suggestions WHERE active=1 ORDER BY source_item_id,sort_order,suggested_item_id")->fetchAll(PDO::FETCH_ASSOC)?:[];$out=[];foreach($rows as $r)$out[(string)(int)$r['source_item_id']][]=(int)$r['suggested_item_id'];return $out;
    }
    private function bundlesSnapshot(): array
    {
        $rows=$this->pdo->query("SELECT b.bundle_item_id,b.choice_label,b.choice_min,b.choice_max,c.id component_id,c.component_item_id,c.mode,c.quantity,c.price_delta,c.sort_order,i.name component_name,i.price component_price,i.available,i.lifecycle_status,i.guest_visible,i.staff_visible,i.preparation_station FROM item_bundles b LEFT JOIN item_bundle_components c ON c.bundle_item_id=b.bundle_item_id LEFT JOIN items i ON i.id=c.component_item_id ORDER BY b.bundle_item_id,c.sort_order,c.id")->fetchAll(PDO::FETCH_ASSOC)?:[];$out=[];foreach($rows as $r){$id=(int)$r['bundle_item_id'];if(!isset($out[$id]))$out[(string)$id]=['bundle_item_id'=>$id,'choice_label'=>$r['choice_label'],'choice_min'=>(int)$r['choice_min'],'choice_max'=>(int)$r['choice_max'],'components'=>[]];if($r['component_id']!==null)$out[(string)$id]['components'][]=['id'=>(int)$r['component_id'],'component_item_id'=>(int)$r['component_item_id'],'mode'=>(string)$r['mode'],'quantity'=>(int)$r['quantity'],'price_delta'=>(int)$r['price_delta'],'sort_order'=>(int)$r['sort_order'],'component_name'=>(string)$r['component_name'],'component_price'=>(int)$r['component_price'],'available'=>(int)$r['available']===1,'lifecycle_status'=>(string)$r['lifecycle_status'],'guest_visible'=>(int)$r['guest_visible']===1,'staff_visible'=>(int)$r['staff_visible']===1,'preparation_station'=>(string)$r['preparation_station']];}return $out;
    }
    private function normalizeCategoryRow(array $category,array $menuMap,array $sortMap): array
    {
        $category['id']=(int)$category['id'];$category['sort_order']=(int)$category['sort_order'];foreach(['active','guest_visible','staff_visible'] as $flag)$category[$flag]=(int)($category[$flag]??0)===1;$category['lifecycle_status']=(string)($category['lifecycle_status']??($category['active']?'active':'inactive'));$category['menu_ids']=$menuMap[$category['id']]??[];$category['menu_sort_orders']=$sortMap[$category['id']]??[];return $category;
    }
    private function normalizeItemRow(array $item,array $menuMap,array $tagMap): array
    {
        $item['id']=(int)$item['id'];$item['category_id']=(int)$item['category_id'];$item['price']=(int)$item['price'];$item['sort_order']=(int)$item['sort_order'];foreach(['available','active','guest_visible','staff_visible','featured','staff_only','takeaway_allowed'] as $flag)$item[$flag]=(int)($item[$flag]??0)===1;$item['lifecycle_status']=(string)($item['lifecycle_status']??($item['active']?'active':'inactive'));$item['sellable_kind']=SellableKind::normalizeRead($item['sellable_kind']??null);$item['sellable_kind_label']=SellableKind::label($item['sellable_kind']);$item['preparation_station']=$this->normalizeStation((string)($item['preparation_station']??'cold_bar'));$item['schedule_days']=$this->daysFromCsv($item['schedule_days']??null);$item['menu_ids']=$menuMap[$item['id']]??[];$item['tag_ids']=$tagMap[$item['id']]??[];return $item;
    }
    private function currentLifecycle(mixed $value): string
    {
        $v=trim((string)$value);if(!in_array($v,['active','inactive'],true))throw new CatalogAdminException('lifecycle_invalid','وضعیت چرخه عمر معتبر نیست.',422);return $v;
    }

    private function setItemTagsTx(int $itemId,array $tagIds): void{$this->pdo->prepare('DELETE FROM item_tags WHERE item_id=?')->execute([$itemId]);if($tagIds===[])return;$ph=implode(',',array_fill(0,count($tagIds),'?'));$q=$this->pdo->prepare("SELECT id FROM catalog_tags WHERE id IN($ph) AND active=1 FOR UPDATE");$q->execute($tagIds);$found=array_map('intval',$q->fetchAll(PDO::FETCH_COLUMN));sort($found);$expected=$tagIds;sort($expected);if($found!==$expected)throw new CatalogAdminException('tag_missing','یکی از برچسب‌های انتخاب‌شده معتبر نیست.',422);$ins=$this->pdo->prepare('INSERT INTO item_tags(item_id,tag_id) VALUES(?,?)');foreach($tagIds as $tagId)$ins->execute([$itemId,$tagId]);}
    private function itemTagIdsTx(int $itemId): array{$q=$this->pdo->prepare('SELECT tag_id FROM item_tags WHERE item_id=? ORDER BY tag_id FOR UPDATE');$q->execute([$itemId]);return array_map('intval',$q->fetchAll(PDO::FETCH_COLUMN));}
    private function validateTransfer(array $bundle): void{if(!in_array((string)($bundle['format']??''),['sokna-catalog-transfer-v1','sokna-catalog-transfer-v2'],true))throw new CatalogAdminException('transfer_format','فرمت فایل انتقال کاتالوگ معتبر نیست.',422);foreach(['menus','categories','items'] as $k)if(!is_array($bundle[$k]??null))throw new CatalogAdminException('transfer_shape','ساختار فایل انتقال ناقص است.',422);if(isset($bundle['tags'])&&!is_array($bundle['tags']))throw new CatalogAdminException('transfer_shape','ساختار برچسب‌ها معتبر نیست.',422);if(count($bundle['menus'])>100||count($bundle['categories'])>1000||count($bundle['items'])>10000||count($bundle['tags']??[])>1000)throw new CatalogAdminException('transfer_size','فایل انتقال بیش از حد بزرگ است.',413);}
    private function transferKey(mixed $value): string{$v=trim((string)$value);if($v===''||!preg_match('/^[A-Za-z0-9._-]{1,80}$/D',$v))throw new CatalogAdminException('transfer_key','شناسه داخلی فایل انتقال معتبر نیست.',422);return $v;}
    private function csvDays(mixed $days): ?string{$list=$this->intList(is_array($days)?$days:($days===null?[]:explode(',',(string)$days)),1,7);sort($list);return $list?implode(',',$list):null;}

    private function assertAdmin(array $user): array{$id=(int)($user['id']??0);if($id<1)throw new CatalogAdminException('forbidden','حساب معتبر نیست.',403);$fresh=$this->identity->findActiveById($id);if($fresh===null||(string)($fresh['role']??'')!=='admin')throw new CatalogAdminException('forbidden','مدیریت کاتالوگ فقط برای مدیر فعال است.',403);return $fresh;}
    private function lockMenus(array $ids): void{if($ids===[])return;$ph=implode(',',array_fill(0,count($ids),'?'));$q=$this->pdo->prepare("SELECT id FROM menus WHERE id IN($ph) FOR UPDATE");$q->execute($ids);$found=array_map('intval',$q->fetchAll(PDO::FETCH_COLUMN));sort($found);$expected=$ids;sort($expected);if($found!==$expected)throw new CatalogAdminException('menu_missing','یکی از منوهای انتخاب‌شده پیدا نشد.',422);}
    private function setCategoryMenusTx(int $categoryId,array $menuIds): void{$this->lockMenus($menuIds);$oldQ=$this->pdo->prepare('SELECT menu_id,sort_order FROM menu_categories WHERE category_id=? FOR UPDATE');$oldQ->execute([$categoryId]);$old=[];foreach($oldQ->fetchAll(PDO::FETCH_ASSOC) as $r)$old[(int)$r['menu_id']]=(int)$r['sort_order'];$this->pdo->prepare('DELETE FROM menu_categories WHERE category_id=?')->execute([$categoryId]);if($menuIds!==[]){$ins=$this->pdo->prepare('INSERT INTO menu_categories(menu_id,category_id,sort_order) VALUES(?,?,?)');$maxQ=$this->pdo->prepare('SELECT COALESCE(MAX(sort_order),0) FROM menu_categories WHERE menu_id=?');foreach($menuIds as $menuId){if(isset($old[$menuId]))$sort=$old[$menuId];else{$maxQ->execute([$menuId]);$sort=(int)$maxQ->fetchColumn()+10;}$ins->execute([$menuId,$categoryId,$sort]);}}$allowed=$menuIds;$q=$this->pdo->prepare('SELECT id FROM items WHERE category_id=?');$q->execute([$categoryId]);foreach(array_map('intval',$q->fetchAll(PDO::FETCH_COLUMN)) as $itemId){$current=$this->itemMenuIdsTx($itemId);$keep=array_values(array_intersect($current,$allowed));$this->setItemMenusTx($itemId,$keep);}}
    private function setItemMenusTx(int $itemId,array $menuIds): void{$this->pdo->prepare('DELETE FROM menu_items WHERE item_id=?')->execute([$itemId]);if($menuIds!==[]){$ins=$this->pdo->prepare('INSERT INTO menu_items(menu_id,item_id) VALUES(?,?)');foreach($menuIds as $menuId)$ins->execute([$menuId,$itemId]);}}
    private function categoryMenuIdsTx(int $categoryId): array{$q=$this->pdo->prepare('SELECT menu_id FROM menu_categories WHERE category_id=? ORDER BY menu_id FOR UPDATE');$q->execute([$categoryId]);return array_map('intval',$q->fetchAll(PDO::FETCH_COLUMN));}
    private function itemMenuIdsTx(int $itemId): array{$q=$this->pdo->prepare('SELECT menu_id FROM menu_items WHERE item_id=? ORDER BY menu_id FOR UPDATE');$q->execute([$itemId]);return array_map('intval',$q->fetchAll(PDO::FETCH_COLUMN));}
    private function newKey(string $table,string $column): string{$q=$this->pdo->prepare("SELECT 1 FROM $table WHERE $column=? LIMIT 1");for($i=0;$i<5;$i++){$key='custom-'.bin2hex(random_bytes(10));$q->execute([$key]);if(!$q->fetchColumn())return $key;}throw new CatalogAdminException('key_generation','شناسه داخلی ساخته نشد؛ دوباره تلاش کن.',500);}
    private function schedule(mixed $days,mixed $start,mixed $end): array{$dayList=$this->intList($days,1,7);sort($dayList);$start=$this->time($start);$end=$this->time($end);if(($start===null)!==($end===null))throw new CatalogAdminException('schedule_pair','شروع و پایان ساعت سرو را با هم وارد کن.',422);return [$dayList?implode(',',$dayList):null,$start,$end];}
    private function daysFromCsv(mixed $value): array{if($value===null||trim((string)$value)==='')return [];return $this->intList(explode(',',(string)$value),1,7);}
    private function time(mixed $value): ?string{$v=trim((string)$value);if($v==='')return null;if(!preg_match('/^(?:[01]\\d|2[0-3]):[0-5]\\d(?::[0-5]\\d)?$/',$v))throw new CatalogAdminException('time_invalid','ساعت واردشده معتبر نیست.',422);return substr($v,0,5);}
    private function dateTime(mixed $value): ?string{$v=trim((string)$value);if($v==='')return null;$v=str_replace('T',' ',$v);if(!preg_match('/^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}(?::\\d{2})?$/',$v))throw new CatalogAdminException('datetime_invalid','تاریخ/ساعت واردشده معتبر نیست.',422);return strlen($v)===16?$v.':00':$v;}
    private function normalizeStation(string $station): string{if($station==='other')$station='cold_bar';if(!in_array($station,self::STATIONS,true))throw new CatalogAdminException('station_invalid','ایستگاه آماده‌سازی معتبر نیست.',422);return $station;}
    private function amount(mixed $value): int{$raw=trim(strtr((string)$value,['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']));if($raw===''||str_starts_with($raw,'-'))throw new CatalogAdminException('price_invalid','قیمت معتبر لازم است.',422);$s=preg_replace('/[^0-9]/','',$raw)??'';if($s==='')throw new CatalogAdminException('price_invalid','قیمت معتبر لازم است.',422);return (int)$s;}
    private function bool(mixed $value): bool{return is_bool($value)?$value:in_array(strtolower(trim((string)$value)),['1','true','yes','on'],true);}
    private function text(mixed $value,int $max): string{$v=trim((string)$value);if(function_exists('mb_substr'))return mb_substr($v,0,$max,'UTF-8');$ok=preg_match_all('/./us',$v,$m);return $ok===false?substr($v,0,$max):implode('',array_slice($m[0],0,$max));}
    private function nullableText(mixed $value,int $max): ?string{$v=$this->text($value,$max);return $v===''?null:$v;}
    private function intList(mixed $value,int $min=1,int $max=PHP_INT_MAX): array{$items=is_array($value)?$value:[];$result=[];foreach($items as $item){$n=filter_var($item,FILTER_VALIDATE_INT);if($n!==false&&$n>=$min&&$n<=$max)$result[]=(int)$n;}return array_values(array_unique($result));}
    private function audit(string $action,string $entity,int $entityId,int $actorId,array $details): void{$q=$this->pdo->prepare('SELECT display_name FROM users WHERE id=? LIMIT 1');$q->execute([$actorId]);$name=$q->fetchColumn();$this->pdo->prepare('INSERT INTO audit_log(actor_user_id,actor_display_name_snapshot,action,entity_type,entity_id,details_json) VALUES(?,?,?,?,?,?)')->execute([$actorId,$name!==false?$name:null,$action,$entity,(string)$entityId,json_encode($details,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)]);}
}
